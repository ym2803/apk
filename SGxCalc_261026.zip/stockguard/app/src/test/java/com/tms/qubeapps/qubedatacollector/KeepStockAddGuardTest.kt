package com.tms.qubeapps.qubedatacollector

import org.junit.Assert.*
import org.junit.Test

class KeepStockAddGuardTest {
    private fun r(n: Int, ctn: String, sku: String, qty: String) = KeepStockSheetReader.KsRow(n, ctn, sku, qty)
    private val rows = listOf(r(6, "A001", "111", "5"), r(7, "A001", "222", "3"), r(8, "b002", "111", "4"))

    @Test fun ctnExists_ignoresCaseAndSpaces() {
        assertTrue(KeepStockAddGuard.ctnExists(rows, " a001 "))
        assertTrue(KeepStockAddGuard.ctnExists(rows, "B002"))
        assertFalse(KeepStockAddGuard.ctnExists(rows, "C003"))
        assertFalse(KeepStockAddGuard.ctnExists(rows, ""))
    }

    @Test fun rowsForSku_andOnePerCtn() {
        val m = KeepStockAddGuard.rowsForSku(rows, listOf("111", "-", ""))
        assertEquals(2, m.size)
        assertEquals(listOf("A001", "b002"), KeepStockAddGuard.onePerCtn(m).map { it.noCtn })
        assertTrue(KeepStockAddGuard.rowsForSku(rows, listOf("999")).isEmpty())
    }

    @Test fun over_reportsExcess() {
        val o = KeepStockAddGuard.over(10.0, 9.0, 0.0, 4.0)!!
        assertEquals(13.0, o.total, 0.0)
        assertEquals(3.0, o.excess, 0.0)
        assertNull(KeepStockAddGuard.over(10.0, 6.0, 0.0, 4.0))   // pas = tidak lebih
        assertNull(KeepStockAddGuard.over(null, 99.0, 0.0, 4.0))  // tanpa data System
        assertEquals(2.0, KeepStockAddGuard.over(10.0, 5.0, 3.0, 4.0)!!.excess, 0.0) // pending ikut dihitung
    }

    @Test fun parseSystem() {
        assertEquals(1234.0, KeepStockAddGuard.parseSystem("1,234")!!, 0.0)
        assertNull(KeepStockAddGuard.parseSystem("-"))
        assertNull(KeepStockAddGuard.parseSystem(null))
    }
}
