package com.tms.qubeapps.qubedatacollector

/**
 * ★ FIX (baru — validasi Add Box / Add di Keep Stock): logika MURNI (tanpa Android) untuk
 * mendeteksi:
 *  1. No Ctn yang diinput SUDAH ada di data Keep Stock,
 *  2. SKU yang diinput sudah ada (dobel) di data Keep Stock,
 *  3. Total Qty SKU (Keep Stock + yang diinput) MELEBIHI Qty System, beserta qty lebihnya.
 * Dipakai bersama oleh Data Collector (mode Add Box) & Keep Stock → View Data → ADD BOX,
 * dan dites di KeepStockAddGuardTest.
 */
object KeepStockAddGuard {

    private fun same(a: String, b: String) = a.trim().equals(b.trim(), ignoreCase = true)

    /** True kalau No Ctn ini sudah dipakai di data Keep Stock (tanpa beda huruf besar/kecil). */
    fun ctnExists(rows: List<KeepStockSheetReader.KsRow>, noCtn: String): Boolean =
        noCtn.isNotBlank() && rows.any { same(it.noCtn, noCtn) }

    /** Semua baris Keep Stock untuk salah satu dari [skuKeys] (SKU pendek / long SKU). */
    fun rowsForSku(rows: List<KeepStockSheetReader.KsRow>, skuKeys: Collection<String>): List<KeepStockSheetReader.KsRow> {
        val keys = skuKeys.map { it.trim() }.filter { it.isNotEmpty() && it != "-" }.toSet()
        if (keys.isEmpty()) return emptyList()
        return rows.filter { it.sku.trim() in keys }
    }

    /** Satu baris per No Ctn (baris pertama), urutan kemunculan dijaga — untuk pilihan "tambah ke No Ctn". */
    fun onePerCtn(rows: List<KeepStockSheetReader.KsRow>): List<KeepStockSheetReader.KsRow> {
        val seen = LinkedHashMap<String, KeepStockSheetReader.KsRow>()
        rows.forEach { seen.getOrPut(it.noCtn.trim().uppercase()) { it } }
        return seen.values.toList()
    }

    fun qtyOf(r: KeepStockSheetReader.KsRow): Double = r.qty.replace(",", "").trim().toDoubleOrNull() ?: 0.0

    /** Parse Qty System (katalog 02), mis. "1,234" → 1234.0; null kalau kosong / "-". */
    fun parseSystem(balance: String?): Double? =
        balance?.replace(",", "")?.trim()?.takeIf { it.isNotEmpty() && it != "-" }?.toDoubleOrNull()

    data class Over(val system: Double, val keepStock: Double, val pending: Double, val input: Double) {
        val total: Double get() = keepStock + pending + input
        val excess: Double get() = total - system
    }

    /**
     * Hitung kelebihan: total = Keep Stock + [pending] (Add Box lokal yang belum diupload)
     * + [input] > System. null = tidak melebihi atau Qty System tidak tersedia.
     */
    fun over(system: Double?, keepStock: Double, pending: Double, input: Double): Over? {
        if (system == null) return null
        val o = Over(system, keepStock, pending, input)
        return if (o.excess > 0.0) o else null
    }

    /** Keep Stock + pending + input PERSIS sama dengan System (>0) → SKU "belum display" (semua stok masuk Keep Stock). */
    fun matchesSystem(system: Double?, keepStock: Double, pending: Double, input: Double): Boolean =
        system != null && system > 0.0 && Math.abs(keepStock + pending + input - system) < 1e-9

    fun fmt(d: Double): String = if (d == d.toLong().toDouble()) d.toLong().toString() else d.toString()
}
