package com.tms.qubeapps.qubedatacollector

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.File
import java.util.zip.ZipInputStream

/**
 * ★ FIX (baru — Stock Balance Check): import file untuk MENGUBAH Qty System (balance
 * katalog 02) tanpa download ulang 02.txt:
 *   • KURANGI (penjualan) — Excel/TXT, hanya kolom A (SKU) & kolom H (Qty).
 *   • TAMBAH  — TXT/Excel, hanya kolom ke-5 (SKU) & kolom ke-6 (Qty),
 *               contoh: IDHQ-B-0000536897-JW5006|0000536897|JW5006|B|9101538|4|F|...
 *
 * Pembaca file: .xls (jxl), .xlsx (zip+XML, tanpa library), .txt/.csv (pemisah otomatis).
 * Selisih disimpan di qty_adjust.json supaya tetap terpasang setelah katalog di-parse ulang
 * (ganti kolom); dikosongkan saat 02.txt di-download baru.
 */
object QtyAdjustImporter {

    data class Parsed(val deltas: LinkedHashMap<String, Double>, val rowsRead: Int, val rowsUsed: Int,
                      val note: String = "")

    // ── Pembaca file → grid sel ────────────────────────────────────────────────
    fun readGrid(ctx: Context, uri: Uri): List<List<String>> {
        val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            ?: throw IllegalStateException("File tidak bisa dibaca")
        val isXls  = bytes.size > 4 && bytes[0] == 0xD0.toByte() && bytes[1] == 0xCF.toByte()
        val isXlsx = bytes.size > 2 && bytes[0] == 'P'.code.toByte() && bytes[1] == 'K'.code.toByte()
        // ★ FIX (baru): file ".XLS" dari beberapa sistem kasir/laporan berformat Excel 4/3/2 MENTAH
        // (BIFF4/3/2, bukan wadah OLE seperti Excel 97) — diawali record BOF: 09 04 / 09 02 / 09 00.
        // jxl tidak bisa membacanya (dulu jatuh ke pembaca TXT → "tidak ada data terbaca").
        val isBiffRaw = bytes.size > 4 && bytes[0] == 0x09.toByte() &&
            (bytes[1] == 0x00.toByte() || bytes[1] == 0x02.toByte() || bytes[1] == 0x04.toByte())
        return when {
            isXls     -> readXls(bytes)
            isXlsx    -> readXlsx(bytes)
            isBiffRaw -> readBiffRaw(bytes)
            else      -> readText(String(bytes, Charsets.UTF_8))
        }
    }

    private fun fmtNum(d: Double): String =
        if (d == Math.floor(d) && Math.abs(d) < 1e15) d.toLong().toString() else d.toString()

    private fun readXls(bytes: ByteArray): List<List<String>> {
        // jxl memakai logger log4j secara default → paksa logger sederhana.
        System.setProperty("logger", "jxl.common.log.SimpleLogger")
        // WorkbookSettings hanya punya setter (tanpa getter) → properti Kotlin tidak ada.
        val ws = jxl.WorkbookSettings()
        ws.setSuppressWarnings(true)
        val wb = jxl.Workbook.getWorkbook(ByteArrayInputStream(bytes), ws)
        try {
            val out = ArrayList<List<String>>()
            for (si in 0 until wb.numberOfSheets) {          // SEMUA sheet dibaca
                val sh = wb.getSheet(si)
                for (r in 0 until sh.rows) {
                    val cells = sh.getRow(r)
                    val row = ArrayList<String>(sh.columns)
                    for (c in cells) {
                        while (row.size < c.column) row.add("")
                        row.add(if (c is jxl.NumberCell) fmtNum(c.value) else (c.contents ?: "").trim())
                    }
                    out.add(row)
                }
            }
            return out
        } finally { wb.close() }
    }

    /** Pembaca Excel BIFF2/3/4 mentah: record NUMBER, INTEGER, LABEL, RK, FORMULA (hasil angka). */
    private fun readBiffRaw(b: ByteArray): List<List<String>> {
        val bb = java.nio.ByteBuffer.wrap(b).order(java.nio.ByteOrder.LITTLE_ENDIAN)
        val cs = runCatching { java.nio.charset.Charset.forName("windows-1252") }.getOrDefault(Charsets.ISO_8859_1)
        fun u16(o: Int) = bb.getShort(o).toInt() and 0xFFFF
        fun key(r: Int, c: Int) = (r.toLong() shl 16) or c.toLong()
        val sheets = ArrayList<java.util.TreeMap<Long, String>>()
        var cur: java.util.TreeMap<Long, String>? = null
        var pos = 0
        while (pos + 4 <= b.size) {
            val op = u16(pos); val len = u16(pos + 2); val d = pos + 4
            pos = d + len
            if (pos > b.size) break
            val t = op and 0xFF; val hi = op shr 8
            if (t == 0x09) { cur = java.util.TreeMap(); sheets.add(cur); continue }   // BOF = sheet baru
            val sh = cur ?: continue
            try {
                when (t) {
                    0x03 -> if (len >= 14) {                                   // NUMBER
                        val off = d + if (hi == 0) 7 else 6
                        sh[key(u16(d), u16(d + 2))] = fmtNum(bb.getDouble(off))
                    }
                    0x02 -> if (hi == 0 && len >= 9)                            // INTEGER (BIFF2)
                        sh[key(u16(d), u16(d + 2))] = u16(d + 7).toString()
                    0x04 -> {                                                   // LABEL
                        val n: Int; val start: Int
                        if (hi == 0) { n = b[d + 7].toInt() and 0xFF; start = d + 8 }
                        else { n = u16(d + 6); start = d + 8 }
                        if (start + n <= b.size)
                            sh[key(u16(d), u16(d + 2))] = String(b, start, n, cs).trim()
                    }
                    0x7E -> if (hi != 0 && len >= 10) {                         // RK
                        val v = bb.getInt(d + 6)
                        val num = if (v and 2 != 0) (v shr 2).toDouble()
                                  else java.lang.Double.longBitsToDouble((v.toLong() and 0xFFFFFFFCL) shl 32)
                        sh[key(u16(d), u16(d + 2))] = fmtNum(if (v and 1 != 0) num / 100.0 else num)
                    }
                    0x06 -> {                                                   // FORMULA (hasil tersimpan: angka)
                        val off = d + if (hi == 0) 7 else 6
                        if (len >= off - d + 8 && !(b[off + 6] == 0xFF.toByte() && b[off + 7] == 0xFF.toByte()))
                            sh[key(u16(d), u16(d + 2))] = fmtNum(bb.getDouble(off))
                    }
                }
            } catch (e: Exception) { /* record rusak → lewati */ }
        }
        val out = ArrayList<List<String>>()
        for (sh in sheets) {
            if (sh.isEmpty()) continue
            val rowsMax = (sh.lastKey() shr 16).toInt()
            val maxCol = sh.keys.maxOf { (it and 0xFFFFL).toInt() }
            val byRow = HashMap<Int, MutableList<String>>()
            for ((k, v) in sh) {
                val r = (k shr 16).toInt(); val c = (k and 0xFFFFL).toInt()
                val row = byRow.getOrPut(r) { ArrayList<String>().apply { repeat(maxCol + 1) { add("") } } }
                row[c] = v
            }
            for (r in 0..rowsMax) out.add(byRow[r] ?: emptyList())
        }
        return out
    }

    private fun colIndex(ref: String): Int {
        var n = 0
        for (ch in ref) { if (ch in 'A'..'Z') n = n * 26 + (ch - 'A' + 1) else break }
        return n - 1
    }

    private fun readXlsx(bytes: ByteArray): List<List<String>> {
        var shared = ArrayList<String>()
        val sheets = java.util.TreeMap<String, ByteArray>()     // urut nama: sheet1, sheet10, sheet2…
        ZipInputStream(ByteArrayInputStream(bytes)).use { zis ->
            while (true) {
                val e = zis.nextEntry ?: break
                when {
                    e.name == "xl/sharedStrings.xml" -> shared = parseShared(zis.readBytes())
                    e.name.startsWith("xl/worksheets/sheet") && e.name.endsWith(".xml") -> sheets[e.name] = zis.readBytes()
                }
            }
        }
        if (sheets.isEmpty()) throw IllegalStateException("Sheet tidak ditemukan di file xlsx")
        val out = ArrayList<List<String>>()
        sheets.entries.sortedBy { it.key.filter { ch -> ch.isDigit() }.toIntOrNull() ?: 0 }
            .forEach { out.addAll(parseSheetXml(it.value, shared)) }
        return out
    }

    private fun parseSheetXml(xml: ByteArray, shared: List<String>): List<List<String>> {
        val p = android.util.Xml.newPullParser()
        p.setInput(ByteArrayInputStream(xml), "UTF-8")
        val rows = ArrayList<MutableList<String>>()
        var curRow: MutableList<String>? = null
        var cellCol = 0; var cellType = ""; var inV = false; var inT = false
        val txt = StringBuilder()
        var ev = p.eventType
        while (ev != org.xmlpull.v1.XmlPullParser.END_DOCUMENT) {
            when (ev) {
                org.xmlpull.v1.XmlPullParser.START_TAG -> when (p.name) {
                    "row" -> { curRow = ArrayList(); rows.add(curRow) }
                    "c" -> {
                        cellCol = colIndex(p.getAttributeValue(null, "r") ?: "A1")
                        cellType = p.getAttributeValue(null, "t") ?: ""
                        txt.setLength(0)
                    }
                    "v" -> { inV = true; txt.setLength(0) }
                    "t" -> { inT = true }
                }
                org.xmlpull.v1.XmlPullParser.TEXT -> if (inV || inT) txt.append(p.text)
                org.xmlpull.v1.XmlPullParser.END_TAG -> when (p.name) {
                    "v" -> inV = false
                    "t" -> inT = false
                    "c" -> {
                        val raw = txt.toString().trim()
                        val v = when (cellType) {
                            "s" -> shared.getOrElse(raw.toIntOrNull() ?: -1) { "" }
                            "str", "inlineStr" -> raw
                            else -> raw.toDoubleOrNull()?.let { fmtNum(it) } ?: raw
                        }
                        val r = curRow
                        if (r != null) { while (r.size < cellCol) r.add(""); r.add(v) }
                    }
                }
            }
            ev = p.next()
        }
        return rows
    }

    private fun parseShared(xml: ByteArray): ArrayList<String> {
        val out = ArrayList<String>()
        val p = android.util.Xml.newPullParser()
        p.setInput(ByteArrayInputStream(xml), "UTF-8")
        val sb = StringBuilder(); var inT = false
        var ev = p.eventType
        while (ev != org.xmlpull.v1.XmlPullParser.END_DOCUMENT) {
            when (ev) {
                org.xmlpull.v1.XmlPullParser.START_TAG -> { if (p.name == "si") sb.setLength(0); if (p.name == "t") inT = true }
                org.xmlpull.v1.XmlPullParser.TEXT -> if (inT) sb.append(p.text)
                org.xmlpull.v1.XmlPullParser.END_TAG -> { if (p.name == "t") inT = false; if (p.name == "si") out.add(sb.toString().trim()) }
            }
            ev = p.next()
        }
        return out
    }

    private fun readText(text: String): List<List<String>> {
        val lines = text.lineSequence().filter { it.isNotBlank() }.toList()
        if (lines.isEmpty()) return emptyList()
        val delim = listOf("\t", "|", ";", ",").maxByOrNull { d -> lines.take(20).sumOf { it.split(d).size - 1 } } ?: ","
        return lines.map { l -> l.split(delim).map { it.trim().trim('"') } }
    }

    // ── ★ FIX (baru): konversi sel berformat TEKS → angka ───────────────────────────
    // Excel kadang menyimpan angka sebagai teks: awalan apostrof ('8944850), spasi / spasi
    // tak terlihat (NBSP, zero-width), akhiran ".0", pemisah ribuan, koma desimal, notasi ilmiah.
    private val invisibleRegex = Regex("[\\u00A0\\u200B\\u200C\\u200D\\u2007\\u202F\\uFEFF\\s]")
    private val thousandsRegex = Regex("^\\d{1,3}([.,]\\d{3})+$")

    private fun cleanCell(raw: String): String =
        raw.replace(invisibleRegex, "").trim('\'', '"', '`', '\u2018', '\u2019')

    /** Teks → SKU berupa digit saja; null kalau bukan angka. */
    fun toSku(raw: String): String? {
        val t = cleanCell(raw)
        if (t.isEmpty()) return null
        if (t.all { it.isDigit() }) return t
        if (thousandsRegex.matches(t)) return t.filter { it.isDigit() }
        val bd = runCatching { java.math.BigDecimal(t.replace(",", ".")) }.getOrNull() ?: return null
        return if (bd.signum() >= 0 && bd.stripTrailingZeros().scale() <= 0) bd.toBigInteger().toString() else null
    }

    /** Teks → angka Qty; null kalau bukan angka. */
    fun toQty(raw: String): Double? {
        var t = cleanCell(raw)
        if (t.isEmpty()) return null
        if (t.startsWith("(") && t.endsWith(")")) t = "-" + t.substring(1, t.length - 1)
        val c = t.lastIndexOf(','); val d = t.lastIndexOf('.')
        t = when {
            c >= 0 && d >= 0 -> if (c > d) t.replace(".", "").replace(',', '.') else t.replace(",", "")
            c >= 0 -> if (Regex("^-?\\d{1,3}(,\\d{3})+$").matches(t)) t.replace(",", "") else t.replace(',', '.')
            else -> t
        }
        return t.toDoubleOrNull()
    }

    // ── Ambil SKU & Qty dari kolom tertentu (index 0-based) ───────────────────────
    fun extract(grid: List<List<String>>, skuIdx: Int, qtyIdx: Int): Parsed {
        val deltas = LinkedHashMap<String, Double>()
        var used = 0
        for (row in grid) {
            val rawSku = row.getOrNull(skuIdx).orEmpty()
            val sku = toSku(rawSku) ?: cleanCell(rawSku)
            val qty = toQty(row.getOrNull(qtyIdx).orEmpty())
            // Baris judul / subtotal / departemen (Qty kosong atau bukan angka) dilewati.
            if (sku.isEmpty() || qty == null || sku.any { it.isWhitespace() }) continue
            deltas[sku] = (deltas[sku] ?: 0.0) + qty
            used++
        }
        return Parsed(deltas, grid.size, used)
    }

    /**
     * ★ FIX (baru): pembacaan FLEKSIBEL untuk laporan penjualan (kolom A = SKU, kolom H = Qty):
     *  • SKU  = isi kolom A yang berupa ANGKA SAJA & minimal [minSkuDigits] digit
     *           (kode departemen 3 digit, "894C", judul, dll di kolom A diabaikan).
     *  • Qty  = isi kolom H yang berupa ANGKA (teks/judul/kosong diabaikan).
     *  1) SKU & Qty yang SEBARIS dipasangkan dulu.
     *  2) Sisa SKU & sisa Qty (data tidak sebaris/acak) dipasangkan BERDASARKAN URUTAN
     *     kemunculan, bila jumlah sisanya sama.
     *  3) Yang tidak bisa dipasangkan dilaporkan di `note` (tidak dihiraukan).
     */
    fun extractFlexible(grid: List<List<String>>, skuIdx: Int, qtyIdx: Int, minSkuDigits: Int = 6): Parsed {
        class Cell(val row: Int, val sku: String?, val qty: Double?)
        val skus = ArrayList<Pair<Int, String>>()
        val qtys = ArrayList<Pair<Int, Double>>()
        var converted = 0
        for ((i, row) in grid.withIndex()) {
            val rawA = row.getOrNull(skuIdx).orEmpty()
            val rawH = row.getOrNull(qtyIdx).orEmpty()
            val a = toSku(rawA).orEmpty()
            val h = toQty(rawH)
            if (a.length >= minSkuDigits) { skus.add(i to a); if (a != rawA.trim()) converted++ }
            if (h != null) { qtys.add(i to h); if (rawH.trim() != fmtNum(h)) converted++ }
        }
        val deltas = LinkedHashMap<String, Double>()
        var used = 0
        // 1) sebaris
        val qtyByRow = qtys.toMap()
        val usedQtyRows = HashSet<Int>()
        val leftSkus = ArrayList<Pair<Int, String>>()
        var sameRow = 0
        for ((i, sku) in skus) {
            val q = qtyByRow[i]
            if (q != null) { deltas[sku] = (deltas[sku] ?: 0.0) + q; used++; sameRow++; usedQtyRows.add(i) }
            else leftSkus.add(i to sku)
        }
        val leftQtys = qtys.filter { it.first !in usedQtyRows }
        // 2) sisa → pasangkan berdasarkan urutan
        var byOrder = 0
        val notes = ArrayList<String>()
        if (leftSkus.isNotEmpty() && leftSkus.size == leftQtys.size) {
            for (k in leftSkus.indices) {
                val sku = leftSkus[k].second; val q = leftQtys[k].second
                deltas[sku] = (deltas[sku] ?: 0.0) + q; used++; byOrder++
            }
            notes.add("$byOrder pasangan dicocokkan berdasarkan URUTAN (SKU & Qty tidak sebaris)")
        } else if (leftSkus.isNotEmpty() || leftQtys.isNotEmpty()) {
            notes.add("Tidak terpasang: ${leftSkus.size} SKU tanpa Qty, ${leftQtys.size} Qty tanpa SKU (diabaikan)")
        }
        if (sameRow > 0) notes.add(0, "$sameRow pasangan sebaris")
        if (converted > 0) notes.add("$converted sel kolom A/H berformat teks sudah dikonversi ke angka")
        return Parsed(deltas, grid.size, used, notes.joinToString("\n"))
    }

    // ── Penyimpanan selisih (supaya bertahan setelah katalog di-parse ulang) ───────
    private fun storeFile(ctx: Context) = File(ctx.filesDir, "qty_adjust.json")

    class Store(val deltas: LinkedHashMap<String, Double>, val imports: MutableList<String>)

    fun loadStore(ctx: Context): Store {
        val d = LinkedHashMap<String, Double>(); val imps = ArrayList<String>()
        runCatching {
            val f = storeFile(ctx)
            if (f.exists()) {
                val root = JSONObject(f.readText())
                root.optJSONObject("deltas")?.let { o -> o.keys().forEach { k -> d[k] = o.optDouble(k, 0.0) } }
                root.optJSONArray("imports")?.let { a -> for (i in 0 until a.length()) imps.add(a.getString(i)) }
            }
        }
        return Store(d, imps)
    }

    fun saveStore(ctx: Context, st: Store) {
        runCatching {
            val root = JSONObject()
            val o = JSONObject(); st.deltas.forEach { (k, v) -> o.put(k, v) }
            root.put("deltas", o); root.put("imports", JSONArray(st.imports))
            storeFile(ctx).writeText(root.toString())
        }
    }

    fun clearStore(ctx: Context) { runCatching { storeFile(ctx).delete() } }
}
