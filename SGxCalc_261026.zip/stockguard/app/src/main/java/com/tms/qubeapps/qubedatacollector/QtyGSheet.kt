package com.tms.qubeapps.qubedatacollector

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import com.tms.qubeapps.qubedatacollector.Prefs.ksApiToken
import com.tms.qubeapps.qubedatacollector.Prefs.ksWebAppUrl
import com.tms.qubeapps.qubedatacollector.Prefs.secondCheckSheetToken
import com.tms.qubeapps.qubedatacollector.Prefs.secondCheckSheetUrl
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * ★ FIX (baru): Kurangi / Tambah Qty System lewat Google Sheet.
 *
 * Pengaturannya SAMA dengan Export Comparison / 2nd Check (URL Web App + Token yang sama,
 * disimpan di secondCheckSheetUrl/Token; kalau kosong dipakai URL/Token Keep Stock-Layout),
 * jadi cukup SATU Web App / satu file Google Sheet — bedanya hanya NAMA TAB:
 *   "Kurangi Qty" · "Tambah Qty" · "Qty Adjust Log" · "2nd Check" · "Comparison Export".
 *
 * Di sini juga ada kode Apps Script siap-salin + panduan pemasangan sederhana.
 */
object QtyGSheet {

    fun url(ctx: Context): String = ctx.secondCheckSheetUrl.ifBlank { ctx.ksWebAppUrl }.trim()
    fun token(ctx: Context): String = ctx.secondCheckSheetToken.ifBlank { ctx.ksApiToken }.trim()

    private fun copy(ctx: Context, label: String, text: String) {
        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText(label, text))
        Toast.makeText(ctx, "$label disalin — tempel di editor Apps Script", Toast.LENGTH_LONG).show()
    }

    /** Dialog: isi URL/Token (dipakai bersama Export Comparison/2nd Check), salin script, panduan. */
    fun showSetupDialog(act: androidx.appcompat.app.AppCompatActivity) {
        val dp = act.resources.displayMetrics.density
        val pad = (16 * dp).toInt()
        val box = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad / 2, pad, 0)
        }
        val etUrl = EditText(act).apply {
            hint = "Google Sheets Web App URL (…/exec)"
            setText(url(act)); setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        }
        val etToken = EditText(act).apply {
            hint = "Token (kosongkan kalau script tidak pakai token)"
            setText(token(act)); setSingleLine(true)
        }
        fun btn(t: String, onClick: () -> Unit) = Button(act).apply {
            text = t; isAllCaps = false; textSize = 13f
            setOnClickListener { onClick() }
        }
        val steps = TextView(act).apply {
            textSize = 13f
            setPadding(0, (8 * dp).toInt(), 0, (8 * dp).toInt())
            setTextIsSelectable(true)
            text = "CARA PASANG (±2 menit):\n" +
                "1. Buka file Google Sheet (boleh file yang SAMA dengan 2nd Check / Comparison / Layout) → menu Extensions › Apps Script.\n" +
                "2. Tekan tombol \"Salin Script Lengkap\" di bawah, lalu di editor: hapus isi lama → Paste → Save (ikon disket).\n" +
                "   (Kalau Web App-mu SUDAH ada isinya, pakai \"Salin Script Tambahan\" — petunjuk 2 baris ada di bagian atas kodenya.)\n" +
                "3. Deploy › New deployment › ikon roda gigi › Web app → Execute as: Me, Who has access: Anyone → Deploy → izinkan akses.\n" +
                "4. Copy URL yang berakhiran /exec, tempel di kolom URL di atas → Simpan.\n" +
                "5. Tab di Google Sheet dibuat otomatis:\n" +
                "   • \"$SHEET_SUBTRACT\" → paste laporan penjualan (SKU kolom A, Qty kolom H)\n" +
                "   • \"$SHEET_ADD\" → paste data TXT (SKU kolom ke-5, Qty kolom ke-6; boleh ditempel utuh, dipisah |)\n" +
                "   • \"$SHEET_LOG\" → arsip otomatis setelah diterapkan\n" +
                "6. Di aplikasi: menu Kurangi / Tambah Qty System → tombol \"GSheet\".\n\n" +
                "Kalau script diubah, deploy ulang: Deploy › Manage deployments › Edit › New version."
        }
        box.addView(etUrl); box.addView(etToken)
        box.addView(btn("Salin Script Lengkap (Web App baru)") { copy(act, "Script lengkap", SCRIPT_FULL) })
        box.addView(btn("Salin Script Tambahan (Web App lama)") { copy(act, "Script tambahan", SCRIPT_ADDON) })
        box.addView(btn("Tes koneksi") {
            val u = etUrl.text.toString().trim()
            if (u.isEmpty()) { Toast.makeText(act, "Isi URL dulu", Toast.LENGTH_SHORT).show(); return@btn }
            act.lifecycleScope.launch {
                val msg = try {
                    val r = withContext(Dispatchers.IO) {
                        KeepStockGasClient.getQtyAdjustRows(u, etToken.text.toString().trim(), "subtract")
                    }
                    if (r.optBoolean("ok")) "Koneksi OK ✔ (tab \"${r.optString("sheet")}\": ${r.optJSONArray("rows")?.length() ?: 0} baris)"
                    else "Gagal: ${r.optString("error")}" +
                        (if (r.optString("error").startsWith("Unknown action")) "\nScript belum berisi fitur Qty System — salin script & deploy ulang (New version)." else "")
                } catch (e: org.json.JSONException) {
                    "Respons bukan JSON. Cek: URL berakhiran /exec, akses \"Anyone\", dan sudah di-deploy."
                } catch (e: Exception) { "Gagal: ${e.message}" }
                AlertDialog.Builder(act).setTitle("Tes koneksi").setMessage(msg).setPositiveButton("OK", null).show()
            }
        })
        box.addView(steps)

        AlertDialog.Builder(act)
            .setTitle("Setting GSheet — Qty System")
            .setView(ScrollView(act).apply { addView(box) })
            .setPositiveButton("Simpan") { _, _ ->
                // Sama dengan Export Comparison / 2nd Check → satu pengaturan untuk semuanya.
                act.secondCheckSheetUrl = etUrl.text.toString().trim()
                act.secondCheckSheetToken = etToken.text.toString().trim()
                Toast.makeText(act, "Tersimpan (dipakai juga oleh 2nd Check & Comparison)", Toast.LENGTH_LONG).show()
            }
            .setNegativeButton("Tutup", null)
            .show()
    }

    const val SHEET_SUBTRACT = "Kurangi Qty"
    const val SHEET_ADD = "Tambah Qty"
    const val SHEET_LOG = "Qty Adjust Log"

    // ═════════════ KODE APPS SCRIPT (disalin lewat tombol di dialog) ═════════════
    val SCRIPT_FULL: String = """/*
 * SGxCalc — Web App Google Sheets (SATU FILE, beda nama tab)
 * Dipakai bersama: 2nd Check, Comparison Export, Kurangi/Tambah Qty System.
 * Tab dibuat otomatis kalau belum ada:
 *   "2nd Check" | "Comparison Export" | "Kurangi Qty" | "Tambah Qty" | "Qty Adjust Log"
 */
var TOKEN = "";   // kosongkan kalau tidak pakai token. Kalau diisi, isi SAMA di kolom Token aplikasi.

var SHEET_SUBTRACT     = "Kurangi Qty";
var SHEET_ADD          = "Tambah Qty";
var SHEET_LOG          = "Qty Adjust Log";
var SHEET_SECOND_CHECK = "2nd Check";
var SHEET_COMPARISON   = "Comparison Export";

function doGet() {
  return ContentService.createTextOutput("SGxCalc Web App OK");
}

function doPost(e) {
  var result;
  try {
    var body = JSON.parse(e.postData.contents);
    if (TOKEN && String(body.token || "") !== TOKEN) {
      result = { ok: false, error: "Token salah" };
    } else if (body.action === "getQtyAdjust") {
      result = handleGetQtyAdjust(body);
    } else if (body.action === "archiveQtyAdjust") {
      result = handleArchiveQtyAdjust(body);
    } else if (body.action === "appendSecondCheck") {
      result = handleAppendSecondCheck(body);
    } else if (body.action === "appendComparisonExport") {
      result = handleAppendComparisonExport(body);
    } else {
      result = { ok: false, error: "Unknown action: " + body.action };
    }
  } catch (err) {
    result = { ok: false, error: String(err) };
  }
  return ContentService.createTextOutput(JSON.stringify(result))
      .setMimeType(ContentService.MimeType.JSON);
}

// ---------- helper ----------
function getOrCreateSheet_(name, header) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName(name);
  if (!sh) {
    sh = ss.insertSheet(name);
    if (header) sh.appendRow(header);
  }
  return sh;
}

function cellStr_(v) {
  if (v === null || v === undefined) return "";
  if (v instanceof Date) {
    return Utilities.formatDate(v, Session.getScriptTimeZone(), "yyyy-MM-dd HH:mm:ss");
  }
  return String(v);
}

// ---------- Kurangi / Tambah Qty System ----------
// Paste data mentah ke tab "Kurangi Qty" (SKU kolom A, Qty kolom H)
// atau tab "Tambah Qty" (SKU kolom ke-5, Qty kolom ke-6).
function qtyAdjustSheetName_(type) {
  return type === "add" ? SHEET_ADD : SHEET_SUBTRACT;
}

function handleGetQtyAdjust(body) {
  var name = qtyAdjustSheetName_(body.type);
  var sh = getOrCreateSheet_(name, null);
  var rows = [];
  if (sh.getLastRow() > 0 && sh.getLastColumn() > 0) {
    var values = sh.getDataRange().getValues();
    for (var i = 0; i < values.length; i++) {
      var r = [];
      for (var j = 0; j < values[i].length; j++) r.push(cellStr_(values[i][j]));
      // data TXT yang di-paste utuh dalam 1 kolom (dipisah "|") → pecah otomatis
      var onlyFirst = r.length > 0 && r[0].indexOf("|") >= 0;
      for (var k = 1; k < r.length && onlyFirst; k++) if (r[k] !== "") onlyFirst = false;
      if (onlyFirst) r = r[0].split("|");
      rows.push(r);
    }
  }
  return { ok: true, sheet: name, rows: rows };
}

function handleArchiveQtyAdjust(body) {
  var name = qtyAdjustSheetName_(body.type);
  var sh = getOrCreateSheet_(name, null);
  if (sh.getLastRow() === 0 || sh.getLastColumn() === 0) return { ok: true, archived: 0 };
  var values = sh.getDataRange().getValues();
  var log = getOrCreateSheet_(SHEET_LOG, ["Timestamp", "Type", "Source Sheet", "Row Data..."]);
  var now = new Date().toISOString();
  var width = 3, out = [];
  for (var i = 0; i < values.length; i++) {
    var r = [now, body.type === "add" ? "TAMBAH" : "KURANGI", name];
    for (var j = 0; j < values[i].length; j++) r.push(cellStr_(values[i][j]));
    if (r.length > width) width = r.length;
    out.push(r);
  }
  for (var m = 0; m < out.length; m++) while (out[m].length < width) out[m].push("");
  log.getRange(log.getLastRow() + 1, 1, out.length, width).setValues(out);
  sh.clearContents();
  return { ok: true, archived: out.length };
}

// ---------- 2nd Check ----------
function handleAppendSecondCheck(body) {
  var rows = body.rows;
  if (!rows || !rows.length) return { ok: false, error: "Missing rows" };
  var sh = getOrCreateSheet_(SHEET_SECOND_CHECK,
    ["SKU", "Shelf", "Description", "Balance", "Keep Stock", "System Balance", "Difference", "Timestamp"]);
  for (var i = 0; i < rows.length; i++) {
    var r = rows[i];
    sh.appendRow([r.sku || "", r.shelf || "", r.description || "", r.balance, r.keepStock,
      r.systemBalance, r.difference, r.timestamp || new Date().toISOString()]);
  }
  return { ok: true, appended: rows.length };
}

// ---------- Comparison Export ----------
function handleAppendComparisonExport(body) {
  var rows = body.rows;
  if (!rows || !rows.length) return { ok: false, error: "Missing rows" };
  var sh = getOrCreateSheet_(SHEET_COMPARISON,
    ["SKU", "Shelf", "Description", "Scanned", "Scan Result", "Keep Stock", "System Balance", "Difference", "Sent At"]);
  var now = new Date().toISOString();
  for (var i = 0; i < rows.length; i++) {
    var r = rows[i];
    sh.appendRow([r.sku || "", r.shelf || "", r.description || "", r.scanned ? "YES" : "NO",
      r.scanResult, r.keepStock, r.systemBalance, r.difference, now]);
  }
  return { ok: true, appended: rows.length };
}
"""

    val SCRIPT_ADDON: String = """/*
 * TAMBAHAN Qty System (untuk Web App yang SUDAH ADA: Keep Stock / Layout / 2nd Check).
 * Tab dibuat otomatis: "Kurangi Qty", "Tambah Qty", "Qty Adjust Log".
 *
 * LANGKAH:
 * 1) Tempel SEMUA kode ini di BAWAH kode lama (file .gs yang sama).
 * 2) Di dalam fungsi doPost(e) lama, tambahkan 2 baris ini SEBELUM return/else default:
 *
 *      else if (action === "getQtyAdjust")     { return jsonResponse(handleGetQtyAdjust(body)); }
 *      else if (action === "archiveQtyAdjust") { return jsonResponse(handleArchiveQtyAdjust(body)); }
 *
 *    (kalau fungsi respons di script lamamu bukan jsonResponse, pakai nama itu; atau pakai
 *     qaJson_(...) di bawah)
 * 3) Deploy > Manage deployments > Edit (pensil) > Version: New version > Deploy.
 */
var QA_SHEET_SUBTRACT = "Kurangi Qty";
var QA_SHEET_ADD      = "Tambah Qty";
var QA_SHEET_LOG      = "Qty Adjust Log";

function qaJson_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
      .setMimeType(ContentService.MimeType.JSON);
}

function qaSheet_(name, header) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName(name);
  if (!sh) {
    sh = ss.insertSheet(name);
    if (header) sh.appendRow(header);
  }
  return sh;
}

function qaCell_(v) {
  if (v === null || v === undefined) return "";
  if (v instanceof Date) {
    return Utilities.formatDate(v, Session.getScriptTimeZone(), "yyyy-MM-dd HH:mm:ss");
  }
  return String(v);
}

function qaSheetName_(type) {
  return type === "add" ? QA_SHEET_ADD : QA_SHEET_SUBTRACT;
}

function handleGetQtyAdjust(body) {
  var name = qaSheetName_(body.type);
  var sh = qaSheet_(name, null);
  var rows = [];
  if (sh.getLastRow() > 0 && sh.getLastColumn() > 0) {
    var values = sh.getDataRange().getValues();
    for (var i = 0; i < values.length; i++) {
      var r = [];
      for (var j = 0; j < values[i].length; j++) r.push(qaCell_(values[i][j]));
      var onlyFirst = r.length > 0 && r[0].indexOf("|") >= 0;
      for (var k = 1; k < r.length && onlyFirst; k++) if (r[k] !== "") onlyFirst = false;
      if (onlyFirst) r = r[0].split("|");
      rows.push(r);
    }
  }
  return { ok: true, sheet: name, rows: rows };
}

function handleArchiveQtyAdjust(body) {
  var name = qaSheetName_(body.type);
  var sh = qaSheet_(name, null);
  if (sh.getLastRow() === 0 || sh.getLastColumn() === 0) return { ok: true, archived: 0 };
  var values = sh.getDataRange().getValues();
  var log = qaSheet_(QA_SHEET_LOG, ["Timestamp", "Type", "Source Sheet", "Row Data..."]);
  var now = new Date().toISOString();
  var width = 3, out = [];
  for (var i = 0; i < values.length; i++) {
    var r = [now, body.type === "add" ? "TAMBAH" : "KURANGI", name];
    for (var j = 0; j < values[i].length; j++) r.push(qaCell_(values[i][j]));
    if (r.length > width) width = r.length;
    out.push(r);
  }
  for (var m = 0; m < out.length; m++) while (out[m].length < width) out[m].push("");
  log.getRange(log.getLastRow() + 1, 1, out.length, width).setValues(out);
  sh.clearContents();
  return { ok: true, archived: out.length };
}
"""
}
