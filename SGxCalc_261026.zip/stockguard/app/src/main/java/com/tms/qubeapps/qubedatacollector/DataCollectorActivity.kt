package com.tms.qubeapps.qubedatacollector

import android.app.AlertDialog
import android.database.Cursor
import android.net.Uri
import android.os.Bundle
import android.content.Intent
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.VibrationEffect
import android.os.Vibrator
import android.text.Editable
import android.text.TextWatcher
import android.util.TypedValue
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.ArrayAdapter
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.lifecycleScope
import com.tms.qubeapps.qubedatacollector.Prefs.dcMode
import com.tms.qubeapps.qubedatacollector.Prefs.dcScanMethod
import com.tms.qubeapps.qubedatacollector.Prefs.dcSumMode
import com.tms.qubeapps.qubedatacollector.Prefs.fileFormat
import com.tms.qubeapps.qubedatacollector.Prefs.smbUploadPathDataCollector
import com.tms.qubeapps.qubedatacollector.Prefs.ksWebAppUrl
import com.tms.qubeapps.qubedatacollector.Prefs.ksApiToken
import com.tms.qubeapps.qubedatacollector.Prefs.ksLastStore
import com.tms.qubeapps.qubedatacollector.Prefs.catalogUpdatedTime
import com.tms.qubeapps.qubedatacollector.Prefs.exioSpreadsheetId
import com.tms.qubeapps.qubedatacollector.Prefs.exioGid
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * ★ FIX (baru — Menu 4: Data Collector).
 *
 * Layar generik untuk mencatat data lapangan lewat scan HID/kamera, dengan
 * 2 mode kerja (pengganti fungsi lama "Menu QTY"):
 *  - Shelf Record : cuma Shelf + Scan Code (TANPA Qty).
 *  - Stock Take   : Shelf + Scan Code + Qty (proses stock opname).
 *
 * 2 metode input:
 *  - Manual     : user isi/pilih Shelf dulu, fokus pindah ke Scan Code,
 *                 tiap barcode discan langsung tersimpan (Auto Enter),
 *                 fokus balik ke Scan Code untuk scan berikutnya.
 *  - Auto Detect: SATU field scan (Scan Code) dipakai untuk SEMUA input —
 *                 kalau hasil scan mengandung huruf dianggap Shelf baru,
 *                 kalau cuma angka dianggap Scan Code dan langsung disimpan.
 *
 * Output TXT (dibuat saat Upload to PC ditekan):
 *  - Mode Shelf Record : setiap baris "Shelf,ScanCode"
 *  - Mode Stock Take   : setiap baris "Shelf,ScanCode,Qty"
 *  Nama file: <FileFormat>_<ModeCode>_<YYYYMMDD>_<HHMMSS>.txt
 *  - <FileFormat> diambil dari isian "File Format" di menu Setting (default "YM").
 *  - <ModeCode> tetap (bukan Store Code isian user): 05 untuk Shelf Record,
 *    04 untuk Stock Take / add box.
 */
class DataCollectorActivity : BaseScanner() {

    private lateinit var db: AppDatabase
    private lateinit var etShelf: EditText
    private lateinit var etScanCode: EditText
    private lateinit var etQty: EditText
    private lateinit var rowQty: View
    private lateinit var rowScanCode: View
    private lateinit var rowAutoDetect: View
    private lateinit var btnModeShelfRecord: TextView
    private lateinit var btnModeStockTake: TextView
    private lateinit var switchAutoDetect: android.widget.Switch
    private lateinit var lvRecords: ListView
    private lateinit var tvDcCount: TextView
    private lateinit var tvDcEmpty: TextView
    private lateinit var adapter: BaseAdapter
    private lateinit var btnUploadToKs: View
    private lateinit var btnCompareStock: View
    private lateinit var btnImportFromHistory: View
    private lateinit var tvSkuInfo: TextView
    private lateinit var btnModeAddBox: TextView
    private lateinit var tvLabelShelf: TextView

    private val DEFAULT_SMB_STOCK_TAKE = "smb://BACKEND/QasDev/QubeV10/BackEnd/Data/Seuic/04"
    private val DEFAULT_SMB_SHELF_RECORD = "smb://BACKEND/QasDev/QubeV10/BackEnd/Data/Seuic/05"

    // ★ FIX (baru): mode kerja kini 3 — SHELF_RECORD, STOCK_TAKE, ADD_BOX (dipisah).
    private fun isQtyMode(m: String) = m == "STOCK_TAKE" || m == "ADD_BOX"
    private fun modeLabelOf(m: String) = when (m) { "STOCK_TAKE" -> "Stock Take"; "ADD_BOX" -> "Add Box"; else -> "Shelf Record" }
    private fun locLabelOf(m: String) = if (m == "ADD_BOX") "No Ctn" else "Shelf"

    // ★ FIX (baru — Qty System & Qty Keep Stock saat scan Stock Take/Add Box):
    // cache Keep Stock live (SKU -> total Qty semua Ctn) dari Google Sheet toko aktif.
    // Di-load SEKALI di background (bukan tiap scan, supaya cepat); tap teks info
    // untuk memuat ulang.
    private var ksQtyBySku: Map<String, Double>? = null
    private var ksLoadState = "IDLE"   // IDLE | LOADING | OK | NOT_CONFIGURED | ERROR
    // ★ FIX (baru — validasi Add Box): baris Keep Stock live (No Ctn, SKU, Qty) untuk deteksi
    // No Ctn / SKU dobel & qty melebihi System. No Ctn yang sudah dikonfirmasi user
    // ("Tambah SKU") tidak ditanya ulang tiap scan.
    private var ksRowsCache: List<KeepStockSheetReader.KsRow>? = null
    private val approvedCtns = mutableSetOf<String>()
    private var infoScanCode: String = ""

    // ★ FIX (baru — efisiensi scanning Stock Take/Add Box)
    private lateinit var btnUndo: ImageView
    private lateinit var btnUnscanned: TextView
    private lateinit var btnRedo: ImageView
    private lateinit var btnSearch: ImageView
    private lateinit var rowSumMode: View
    private lateinit var switchSumMode: android.widget.Switch
    private lateinit var btnEditShelf: TextView
    private lateinit var etSearch: EditText
    private lateinit var tvMatchAlert: TextView
    private var highlightId: String = ""      // baris yang baru disimpan (diberi warna sebentar)
    private var stockTakeSaveCounter = 0      // pemicu auto-backup tiap 10 record
    private val toneGen: ToneGenerator? by lazy {
        try { ToneGenerator(AudioManager.STREAM_MUSIC, 80) } catch (e: Exception) { null }
    }

    // Baris [_id, shelf, scanCode, qty, mode, time, uploaded]
    // ★ FIX: data record SHELF_RECORD & STOCK_TAKE disimpan/ditampilkan
    // terpisah per mode (tidak digabung) — daftar penuh tetap disimpan di
    // DB (rowsAll), tapi yang dirender ke adapter cuma yang sesuai mode aktif.
    private val rowsAll = mutableListOf<Array<String>>()
    private val rows = mutableListOf<Array<String>>()      // SEMUA record mode aktif
    private val viewRows = mutableListOf<Array<String>>()  // hasil saring pencarian → dipakai adapter
    private var searchQuery = ""

    // ★ FIX (baru): riwayat scan untuk UNDO / REDO (per sesi layar ini).
    private data class ScanOp(val mode: String, val shelf: String, val code: String,
                              val qty: Int, val newRow: Boolean)
    private val scanLog = ArrayList<ScanOp>()
    private val redoStack = ArrayList<ScanOp>()

    private val onlyLettersRegex = Regex(".*[A-Za-z].*")

    // ★ FIX (baru — #2): deteksi hasil scan berformat link/URL atau konten QR
    // umum lainnya (bukan kode Shelf biasa) — dipakai KHUSUS di mode Shelf
    // Record (Auto maupun Manual) supaya link/QR tidak ikut kesimpan sebagai
    // Shelf. Mencakup URL berskema (http/https/www/ftp) dan skema QR umum
    // lain (mailto/tel/sms/geo/wifi/market/intent/vCard), plus pola
    // "domain.tld" tanpa skema eksplisit.
    private val linkOrQrRegex = Regex(
        "^(https?://|www\\.|ftp://|mailto:|tel:|sms(to)?:|geo:|wifi:|market:|intent:|BEGIN:VCARD)",
        RegexOption.IGNORE_CASE
    )
    private val domainLikeRegex = Regex("^[\\w-]+\\.[A-Za-z]{2,}(/\\S*)?$")

    private fun isLinkOrQrFormat(value: String): Boolean {
        val v = value.trim()
        if (v.isEmpty()) return false
        if (linkOrQrRegex.containsMatchIn(v)) return true
        if (domainLikeRegex.matches(v)) return true
        return false
    }

    // ── Import from TXT file ────────────────────────────────────────────
    /** ★ FIX (baru): Import data lewat file .txt, mengikuti mode kerja yang
     *  sedang aktif SAAT file dipilih:
     *  - Shelf Record       : tiap baris "Shelf,SKU"        (2 kolom)
     *    contoh: AG01-01,1234567
     *  - Stock Take/Add Box : tiap baris "Shelf,SKU,Qty"    (3 kolom)
     *    contoh: A001/AG01-01,1234567,100
     *  Baris yang tidak sesuai format (jumlah kolom salah, Shelf/SKU kosong,
     *  atau Qty bukan angka untuk Stock Take) dilewati (tidak disimpan) dan
     *  dilaporkan di dialog ringkasan sesudah proses selesai. */
    private val importFileLauncher =
        // ★ FIX (baru): pilih BANYAK file sekaligus (tahan/centang beberapa file di picker).
        registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris: List<Uri>? ->
            if (!uris.isNullOrEmpty()) importFromTxtFiles(uris)
        }

    /** ★ FIX (baru): tampilkan format yang berlaku sesuai mode aktif SEBELUM
     *  membuka file picker, supaya user menyiapkan file .txt dengan format
     *  yang benar (jumlah baris besar/import massal jadi tidak sia-sia). */
    private fun showImportConfirmDialog() {
        val isStockTake = isQtyMode(dcMode)
        val modeLabel = modeLabelOf(dcMode)
        val formatDesc = if (dcMode == "ADD_BOX")
            "No Ctn,SKU,Qty\nExample: A001,1234567,100"
        else if (isStockTake)
            "Shelf,SKU,Qty\nExample: AG01-01,1234567,100"
        else
            "Shelf,SKU\nExample: AG01-01,1234567\n\n(3 columns also supported: Shelf,SKU,Qty → Qty ignored, e.g. AG01-01,1234567,100; or Prefix,Shelf,SKU → first column ignored, e.g. S,AG01-01,1234567)"
        AlertDialog.Builder(this)
            .setTitle("Import File — $modeLabel")
            .setMessage("Select one or MORE .txt files (long-press / tick several files) with one record per line, format:\n\n$formatDesc")
            .setPositiveButton("Choose File(s)") { _, _ -> importFileLauncher.launch("text/plain") }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ── Export ke file TXT (pasangan Import File) ──────────────────────────
    private var pendingExportContent: String = ""
    private val exportFileLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
            val uri = res.data?.data
            if (res.resultCode == RESULT_OK && uri != null) {
                try {
                    contentResolver.openOutputStream(uri, "wt")?.use { it.write(pendingExportContent.toByteArray(Charsets.UTF_8)) }
                    Toast.makeText(this, "Exported: ${displayNameOf(uri)}", Toast.LENGTH_LONG).show()
                } catch (e: Exception) {
                    AlertDialog.Builder(this).setTitle("Export Failed")
                        .setMessage(e.message ?: "Unknown error").setPositiveButton("OK", null).show()
                }
            }
        }

    /** Shelf Record → "Shelf,SKU"; Stock Take/Add Box → "Shelf,SKU,Qty". Pilih lokasi simpan sendiri. */
    private fun startExportFile() {
        if (rows.isEmpty()) { Toast.makeText(this, "No data to export yet", Toast.LENGTH_SHORT).show(); return }
        pendingExportContent = buildTxtContent()
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/plain"
            putExtra(Intent.EXTRA_TITLE, buildFileName())
        }
        exportFileLauncher.launch(i)
    }

    private fun displayNameOf(uri: Uri): String {
        runCatching {
            contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0)?.let { return it }
            }
        }
        return uri.lastPathSegment ?: "file"
    }

    private fun importFromTxtFiles(uris: List<Uri>) {
        val mode = dcMode
        var successCount = 0
        val failedLines = mutableListOf<String>()
        val multi = uris.size > 1
        val unreadable = mutableListOf<String>()
        var fileOk = 0

        for (uri in uris) {
            val fname = displayNameOf(uri)
            val tag = if (multi) "[$fname] " else ""
            val lines = try {
                contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readLines() }
                    ?: emptyList()
            } catch (e: Exception) {
                unreadable.add("$fname (${e.message})")
                continue
            }
            fileOk++

            for ((idx, rawLine) in lines.withIndex()) {
                val line = rawLine.trim()
                if (line.isEmpty()) continue
                val cols = line.split(",").map { it.trim() }

                if (isQtyMode(mode)) {
                    // Format wajib: Shelf/No Ctn,SKU,Qty (3 kolom)
                    if (cols.size != 3) {
                        failedLines.add("${tag}Line ${idx + 1}: \"$line\" (expected Shelf,SKU,Qty)")
                        continue
                    }
                    val (shelf, sku, qtyStr) = cols
                    val qty = qtyStr.toIntOrNull()
                    if (shelf.isEmpty() || sku.isEmpty() || qty == null || qty < 0) {
                        failedLines.add("${tag}Line ${idx + 1}: \"$line\" (Shelf/SKU empty or Qty is not a valid number)")
                        continue
                    }
                    db.insertDataCollect(shelf, sku, qty.toString(), mode)
                    successCount++
                } else {
                    // Mode Shelf Record — Shelf,SKU (2 kolom) atau Prefix,Shelf,SKU (3 kolom,
                    // kolom pertama diabaikan).
                    val (shelf, sku) = when (cols.size) {
                        2 -> cols[0] to cols[1]
                        // ★ FIX (baru): 3 kolom — kalau kolom ke-2 ANGKA SAJA berarti format
                        // "Shelf,SKU,Qty" (mis. AG01-01,1234567,100) → ambil kolom 1 & 2,
                        // Qty (kolom 3) diabaikan. Selain itu "Prefix,Shelf,SKU" (kolom 1 diabaikan).
                        3 -> if (cols[1].isNotEmpty() && cols[1].all { it.isDigit() }) cols[0] to cols[1]
                             else cols[1] to cols[2]
                        else -> {
                            failedLines.add("${tag}Line ${idx + 1}: \"$line\" (expected Shelf,SKU or Prefix,Shelf,SKU)")
                            continue
                        }
                    }
                    if (shelf.isEmpty() || sku.isEmpty()) {
                        failedLines.add("${tag}Line ${idx + 1}: \"$line\" (Shelf/SKU empty)")
                        continue
                    }
                    db.insertDataCollect(shelf, sku, "", mode)
                    successCount++
                }
            }
        }

        if (fileOk == 0) {
            AlertDialog.Builder(this)
                .setTitle("Import Failed")
                .setMessage("Unable to read the selected file(s).\n\n" + unreadable.joinToString("\n"))
                .setPositiveButton("OK", null).show()
            return
        }

        loadRecords()

        val modeLabel = modeLabelOf(mode)
        val summary = StringBuilder()
        summary.append("Mode: $modeLabel\n")
        if (multi) summary.append("Files: $fileOk of ${uris.size} read\n")
        summary.append("Imported: $successCount record(s)\n")
        summary.append("Failed: ${failedLines.size} line(s)")
        if (unreadable.isNotEmpty()) summary.append("\nUnreadable: ${unreadable.joinToString("; ")}")
        if (failedLines.isNotEmpty()) {
            summary.append("\n\n").append(failedLines.take(10).joinToString("\n"))
            if (failedLines.size > 10) summary.append("\n… and ${failedLines.size - 10} more")
        }

        AlertDialog.Builder(this)
            .setTitle("Import Result")
            .setMessage(summary.toString())
            .setPositiveButton("OK", null).show()
    }

    // ── Import from Stock Balance Check (History Scan) ─────────────────────
    /**
     * ★ FIX (baru): tarik data langsung dari menu "Stock Balance Check" >
     * History Scan (tabel Price, diisi lewat scan di layar itu) ke daftar
     * mode kerja yang SEDANG AKTIF (dcMode) — TANPA perlu scan ulang.
     *  - Mode Stock Take/Add Box : ambil Shelf + SKU + Qty (Qty = HASIL SCAN,
     *    dijumlahkan per Shelf+SKU kalau SKU yang sama discan berkali-kali).
     *  - Mode Shelf Record       : HANYA ambil kolom 1 (Shelf) & kolom 2
     *    (SKU) dari History Scan — Qty sengaja DIABAIKAN karena Shelf Record
     *    memang tidak punya kolom Qty. Contoh data yang diambil: "AG01-01,1234567".
     * Data ditambahkan (append) ke list mode aktif yang sudah ada — kalau
     * dijalankan 2x, baris akan ikut ter-dobel (sama seperti Import File),
     * jadi dialog konfirmasi menyebutkan ini dengan jelas.
     */
    private fun showImportFromHistoryDialog() {
        lifecycleScope.launch {
            val groups = withContext(Dispatchers.IO) { db.getPriceHistoryGrouped() }
            val isStockTake = dcMode == "STOCK_TAKE"
            val modeLabel = if (isStockTake) "Stock Take" else "Shelf Record"
            if (groups.isEmpty()) {
                AlertDialog.Builder(this@DataCollectorActivity)
                    .setTitle("Import from History Scan")
                    .setMessage("No History Scan data yet. Scan some items in \"Stock Balance Check\" first.")
                    .setPositiveButton("OK", null).show()
                return@launch
            }
            val detailLine = if (isStockTake) {
                "Total Qty (from SCAN result, not system): ${groups.sumOf { it.qty }}"
            } else {
                // ★ FIX (baru — Shelf Record): Qty History Scan TIDAK relevan buat Shelf Record
                // (format wajib Shelf,SKU saja), jadi tidak ditampilkan di sini supaya tidak
                // menyesatkan — hanya kolom 1 (Shelf) & kolom 2 (SKU) yang akan diambil.
                "Only column 1 (Shelf) & column 2 (SKU) will be taken — Qty is ignored.\nExample: AG01-01,1234567"
            }
            AlertDialog.Builder(this@DataCollectorActivity)
                .setTitle("Import from History Scan — $modeLabel")
                .setMessage(
                    "Pull data from \"Stock Balance Check\" > History Scan into $modeLabel?\n\n" +
                        "Shelf+SKU groups: ${groups.size}\n" +
                        "$detailLine\n\n" +
                        "This will be ADDED to the current $modeLabel list " +
                        "(running this again will add the data again)."
                )
                .setPositiveButton("Import") { _, _ -> importFromHistory(groups) }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    private fun importFromHistory(groups: List<AppDatabase.PriceHistoryGroup>) {
        val mode = dcMode
        lifecycleScope.launch {
            val imported = withContext(Dispatchers.IO) {
                var count = 0
                groups.forEach { g ->
                    if (mode == "STOCK_TAKE") {
                        db.insertDataCollect(g.shelf, g.sku, g.qty.toString(), mode)
                    } else {
                        // ★ FIX (baru — Shelf Record): cuma kolom 1 (Shelf) & kolom 2 (SKU)
                        // yang diambil dari History Scan, Qty diabaikan (Shelf Record memang
                        // tidak punya kolom Qty) — sama seperti pola Import File di atas.
                        db.insertDataCollect(g.shelf, g.sku, "", mode)
                    }
                    count++
                }
                count
            }
            loadRecords()
            val modeLabel = if (mode == "STOCK_TAKE") "Stock Take" else "Shelf Record"
            val detail = if (mode == "STOCK_TAKE") "qty from scan result" else "Shelf & SKU only, Qty ignored"
            Toast.makeText(
                this@DataCollectorActivity,
                "Imported $imported record(s) into $modeLabel from History Scan ($detail)",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_data_collector)
        db = AppDatabase(this)

        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<View>(R.id.btnSmbOutputSettings).setOnClickListener { showSmbOutputSettingsDialog() }
        findViewById<View>(R.id.btnImportFile).setOnClickListener { showImportConfirmDialog() }
        findViewById<View>(R.id.btnCompareStock).setOnClickListener {
            startActivity(android.content.Intent(this, StockTakeCompareActivity::class.java))
        }

        etShelf    = findViewById(R.id.etShelf)
        etScanCode = findViewById(R.id.etScanCode)
        etQty      = findViewById(R.id.etQty)
        rowQty     = findViewById(R.id.rowQty)
        rowScanCode = findViewById(R.id.rowScanCode)
        rowAutoDetect = findViewById(R.id.rowAutoDetect)
        btnModeShelfRecord = findViewById(R.id.btnModeShelfRecord)
        btnModeStockTake   = findViewById(R.id.btnModeStockTake)
        btnModeAddBox      = findViewById(R.id.btnModeAddBox)
        tvLabelShelf       = findViewById(R.id.tvLabelShelf)
        switchAutoDetect   = findViewById(R.id.switchAutoDetect)
        lvRecords  = findViewById(R.id.lvRecords)
        tvDcCount  = findViewById(R.id.tvDcCount)
        tvDcEmpty  = findViewById(R.id.tvDcEmpty)
        btnUploadToKs = findViewById(R.id.btnUploadToKs)
        btnCompareStock = findViewById(R.id.btnCompareStock)
        btnImportFromHistory = findViewById(R.id.btnImportFromHistory)
        tvSkuInfo = findViewById(R.id.tvSkuInfo)
        btnUndo = findViewById(R.id.btnUndo)
        btnUnscanned = findViewById(R.id.btnUnscanned)
        btnUndo.setOnClickListener { undoLastRecord() }
        btnUnscanned.setOnClickListener { showUnscannedDialog() }
        btnRedo = findViewById(R.id.btnRedo)
        btnSearch = findViewById(R.id.btnSearch)
        btnEditShelf = findViewById(R.id.btnEditShelf)
        etSearch = findViewById(R.id.etSearch)
        tvMatchAlert = findViewById(R.id.tvMatchAlert)
        btnRedo.setOnClickListener { redoLastRecord() }
        rowSumMode = findViewById(R.id.rowSumMode)
        switchSumMode = findViewById(R.id.switchSumMode)
        switchSumMode.isChecked = dcSumMode
        switchSumMode.setOnCheckedChangeListener { _, on ->
            dcSumMode = on
            if (::adapter.isInitialized) adapter.notifyDataSetChanged()   // warna pink ikut berubah
            Toast.makeText(this,
                if (on) "SUM ON: SKU sama di shelf sama digabung (qty dijumlahkan)"
                else "SUM OFF: tiap scan jadi baris sendiri, notifikasi tetap pakai total qty",
                Toast.LENGTH_LONG).show()
        }
        btnEditShelf.setOnClickListener { showBulkEditShelfDialog() }
        btnSearch.setOnClickListener { toggleSearch() }
        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                searchQuery = s?.toString()?.trim().orEmpty()
                if (::adapter.isInitialized) applyModeFilter()
            }
        })
        findViewById<View>(R.id.btnExportFile).setOnClickListener { startExportFile() }
        // Ringkasan per-shelf ikut berubah saat Shelf aktif berganti.
        etShelf.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { if (::adapter.isInitialized) updateSummary() }
        })
        tvSkuInfo.setOnClickListener { loadKeepStockQty(force = true) }
        // ★ FIX (crash — UninitializedPropertyAccessException): listener ini
        // HARUS dipasang SETELAH findViewById di atas, bukan sebelumnya —
        // sebelumnya dipasang duluan sebelum btnImportFromHistory di-assign,
        // jadi lateinit property-nya belum terisi saat diakses -> force close
        // setiap kali menu Data Collector dibuka.
        btnImportFromHistory.setOnClickListener { showImportFromHistoryDialog() }

        initScanner(findViewById(R.id.scannerView))
        findViewById<View>(R.id.btnCamera).setOnClickListener { toggleCamera() }

        // ★ FIX (baru): "Shelf Price Enquiry" — pintasan ke ShelfPriceEnquireActivity
        // (mode Enquire), dipindah kesini dari menu utama. TIDAK mengubah dcMode.
        // ★ FIX (baru): Shelf Price Enquiry kini MODE di dalam layar ini (bukan jendela baru).
        findViewById<View>(R.id.btnShelfPriceEnquiry).setOnClickListener { setEnquire(true) }
        findViewById<View>(R.id.btnEnqResultClose).setOnClickListener { hideEnquireResult() }
        findViewById<View>(R.id.btnEnqResultSettings).setOnClickListener {
            startActivity(android.content.Intent(this, ResultLayoutActivity::class.java))
        }
        findViewById<View>(R.id.btnEnqOverflow).setOnClickListener { showEnquireOverflow(it) }
        btnModeShelfRecord.setOnClickListener { setEnquire(false); setMode("SHELF_RECORD") }
        btnModeStockTake.setOnClickListener { setEnquire(false); setMode("STOCK_TAKE") }
        btnModeAddBox.setOnClickListener { setEnquire(false); setMode("ADD_BOX") }
        // ★ FIX (baru): Auto Detect / Manual sekarang 1 toggle on/off (Switch).
        switchAutoDetect.setOnCheckedChangeListener { _, isChecked ->
            setScanMethod(if (isChecked) "AUTO" else "MANUAL")
        }

        // ★ FIX (baru — #2): setelah user isi/scan Shelf, fokus otomatis pindah
        // ke Scan Code TANPA perlu di-tap manual — dipanggil lewat .post{}
        // (bukan langsung) supaya tidak "kalah rebutan" fokus dengan proses IME
        // yang menutup keyboard setelah actionNext (ini pola yang sama persis
        // dipakai submitRecord() di bawah, yang sudah terbukti stabil). Ini
        // berlaku tiap kali Shelf BERUBAH/berpindah (mis. AG01-01 -> AG01-02),
        // termasuk kalau Shelf diisi lewat scan barcode (HID mengirim Enter,
        // yang pada EditText singleLine dgn imeOptions="actionNext" ditangkap
        // sebagai IME_ACTION_NEXT juga).
        etShelf.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_NEXT) {
                // ★ FIX (baru — #2): mode Shelf Record (Manual) — tolak Shelf
                // berformat link/URL atau QR umum lainnya.
                val shelfVal = etShelf.text.toString()
                if (dcMode == "SHELF_RECORD" && isLinkOrQrFormat(shelfVal)) {
                    Toast.makeText(this,
                        "Invalid Shelf: link/QR format is not allowed", Toast.LENGTH_SHORT).show()
                    etShelf.setText("")
                    etShelf.post { etShelf.requestFocus() }
                    return@setOnEditorActionListener true
                }
                // ★ FIX (baru — #3): mode Stock Take/Add Box — Scan Code & Qty
                // baru ditampilkan SETELAH Shelf terisi (progressive reveal).
                // ★ FIX (baru): Add Box — No Ctn yang sudah ada di Keep Stock → popup pilihan dulu.
                if (dcMode == "ADD_BOX" && checkAddBoxCtn(shelfVal.trim())) return@setOnEditorActionListener true
                if (isQtyMode(dcMode)) {
                    rowScanCode.visibility = View.VISIBLE
                    rowQty.visibility = View.VISIBLE
                }
                etScanCode.post { etScanCode.requestFocus() }
                // jaring pengaman: pastikan fokus benar-benar di Scan Code (scanner HID kadang telat)
                etScanCode.postDelayed({ if (rowScanCode.visibility == View.VISIBLE && !etScanCode.hasFocus() && !etQty.hasFocus()) etScanCode.requestFocus() }, 150)
                true
            } else false
        }
        // ★ FIX (baru — #2): jaga-jaga scanner HID kirim raw KEYCODE_ENTER
        // (bukan lewat IME action) saat men-scan Shelf — sama pola dengan
        // etScanCode di bawah, supaya perpindahan Shelf -> Scan Code tetap
        // otomatis walau device scanner tertentu tidak memicu actionNext.
        etShelf.setOnKeyListener { _, keyCode, event ->
            // ★ FIX (baru): ACTION_UP Enter/Tab ikut DIKONSUMSI. Dulu event UP-nya jatuh ke field
            // yang baru mendapat fokus (mis. Scan Code setelah scan Shelf) lalu memicu "pindah
            // fokus ke berikutnya" bawaan TextView → fokus lepas dari Scan Code, user harus
            // klik manual. Sekarang fokus bertahan, langsung bisa scan SKU.
            if (event.action == KeyEvent.ACTION_UP &&
                (keyCode == KeyEvent.KEYCODE_ENTER || keyCode == KeyEvent.KEYCODE_TAB)) {
                return@setOnKeyListener true
            }
            if (event.action == KeyEvent.ACTION_DOWN &&
                (keyCode == KeyEvent.KEYCODE_ENTER || keyCode == KeyEvent.KEYCODE_TAB)) {
                val shelfVal = etShelf.text.toString()
                if (dcMode == "SHELF_RECORD" && isLinkOrQrFormat(shelfVal)) {
                    Toast.makeText(this,
                        "Invalid Shelf: link/QR format is not allowed", Toast.LENGTH_SHORT).show()
                    etShelf.setText("")
                    etShelf.post { etShelf.requestFocus() }
                    return@setOnKeyListener true
                }
                // ★ FIX (baru): Add Box — No Ctn yang sudah ada di Keep Stock → popup pilihan dulu.
                if (dcMode == "ADD_BOX" && checkAddBoxCtn(shelfVal.trim())) return@setOnKeyListener true
                if (isQtyMode(dcMode)) {
                    rowScanCode.visibility = View.VISIBLE
                    rowQty.visibility = View.VISIBLE
                }
                etScanCode.post { etScanCode.requestFocus() }
                // jaring pengaman: pastikan fokus benar-benar di Scan Code (scanner HID kadang telat)
                etScanCode.postDelayed({ if (rowScanCode.visibility == View.VISIBLE && !etScanCode.hasFocus() && !etQty.hasFocus()) etScanCode.requestFocus() }, 150)
                true
            } else false
        }

        // ★ FIX: Scan Code — dipakai untuk Manual (khusus kode) MAUPUN Auto
        // Detect (kode ATAU shelf, dibedakan otomatis). Barcode scanner HID
        // mengirim teks lalu Enter, ditangkap di sini sebagai IME_ACTION_DONE
        // → "Auto Enter", user tidak perlu menekan tombol apa pun.
        etScanCode.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                handleScanInput(etScanCode.text.toString()); true
            } else false
        }
        // ★ FIX: jaga-jaga kalau scanner HID kirim raw KEYCODE_ENTER (bukan
        // lewat IME action) — beberapa scanner/keyboard eksternal begitu.
        etScanCode.setOnKeyListener { _, keyCode, event ->
            // ★ FIX (baru): ACTION_UP Enter/Tab ikut DIKONSUMSI. Dulu event UP-nya jatuh ke field
            // yang baru mendapat fokus (mis. Scan Code setelah scan Shelf) lalu memicu "pindah
            // fokus ke berikutnya" bawaan TextView → fokus lepas dari Scan Code, user harus
            // klik manual. Sekarang fokus bertahan, langsung bisa scan SKU.
            if (event.action == KeyEvent.ACTION_UP &&
                (keyCode == KeyEvent.KEYCODE_ENTER || keyCode == KeyEvent.KEYCODE_TAB)) {
                return@setOnKeyListener true
            }
            if (event.action == KeyEvent.ACTION_DOWN &&
                (keyCode == KeyEvent.KEYCODE_ENTER || keyCode == KeyEvent.KEYCODE_TAB)) {
                handleScanInput(etScanCode.text.toString()); true
            } else false
        }

        // ★ FIX (#2): Qty — setelah user mengisi Qty dan menekan Enter/Done
        // (baik lewat keyboard maupun scanner HID yang kirim Enter), baris
        // baru benar-benar disimpan di sini. submitRecord() akan menolak
        // (Toast + fokus balik ke Qty) kalau Qty masih kosong.
        etQty.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                submitRecord(etScanCode.text.toString()); true
            } else false
        }
        etQty.setOnKeyListener { _, keyCode, event ->
            // ★ FIX (baru): ACTION_UP Enter/Tab ikut DIKONSUMSI. Dulu event UP-nya jatuh ke field
            // yang baru mendapat fokus (mis. Scan Code setelah scan Shelf) lalu memicu "pindah
            // fokus ke berikutnya" bawaan TextView → fokus lepas dari Scan Code, user harus
            // klik manual. Sekarang fokus bertahan, langsung bisa scan SKU.
            if (event.action == KeyEvent.ACTION_UP &&
                (keyCode == KeyEvent.KEYCODE_ENTER || keyCode == KeyEvent.KEYCODE_TAB)) {
                return@setOnKeyListener true
            }
            if (event.action == KeyEvent.ACTION_DOWN &&
                (keyCode == KeyEvent.KEYCODE_ENTER || keyCode == KeyEvent.KEYCODE_TAB)) {
                submitRecord(etScanCode.text.toString()); true
            } else false
        }

        // Tombol ↵ di sebelah Qty — submit manual (dipakai kalau user isi
        // Scan Code & Qty lewat keyboard biasa tanpa menekan Enter/Done).
        // submitRecord() sendiri yang menjaga validasi Shelf/Scan Code/Qty.
        findViewById<View>(R.id.btnEnter).setOnClickListener {
            submitRecord(etScanCode.text.toString())
        }

        adapter = object : BaseAdapter() {
            override fun getCount() = viewRows.size
            override fun getItem(p: Int) = viewRows[p]
            override fun getItemId(p: Int) = p.toLong()
            override fun getView(pos: Int, convertView: View?, parent: ViewGroup): View {
                val v = convertView ?: layoutInflater.inflate(R.layout.item_data_collector_row, parent, false)
                val r = viewRows[pos]
                v.findViewById<TextView>(R.id.tvDcShelf).text = r[1]
                v.findViewById<TextView>(R.id.tvDcCode).text = r[2]
                // ★ FIX (baru): deskripsi barang dari katalog 02 (kolom sejajar, maks 2 baris kecil
                // sehingga tinggi baris tetap).
                v.findViewById<TextView>(R.id.tvDcDesc).text =
                    catOf(r[2])?.get("desc")?.takeIf { it.isNotBlank() && it != "-" } ?: ""
                // ★ FIX (baru): drag handle — tekan & geser ≡ untuk memindah posisi data.
                v.findViewById<View>(R.id.ivDcDrag).setOnTouchListener { handle, ev ->
                    if (ev.action == android.view.MotionEvent.ACTION_DOWN) { startRowDrag(v, r); true } else false
                }
                // ★ FIX (baru): baris yang baru disimpan diberi warna hijau muda sebentar.
                v.alpha = if (dragRec != null && r[0] == dragRec!![0]) 0.35f else 1f
                if (dragRec != null && pos == dragOverPos && r[0] != dragRec!![0]) v.setBackgroundColor(0xFFBBDEFB.toInt())
                else if (r[0] == highlightId) v.setBackgroundColor(0xFFC8E6C9.toInt())
                // ★ FIX (baru): mode NON-SUM — SKU yang muncul di lebih dari satu baris diberi
                // latar PINK supaya mudah terlihat mana yang dobel.
                else if (!dcSumMode && isQtyMode(r[4]) && (skuRowCount[r[2].trim()] ?: 0) > 1)
                    v.setBackgroundColor(0xFFF8BBD0.toInt())
                else {
                    val tvBg = TypedValue()
                    theme.resolveAttribute(android.R.attr.selectableItemBackground, tvBg, true)
                    v.setBackgroundResource(tvBg.resourceId)
                }
                val tvQty = v.findViewById<TextView>(R.id.tvDcQty)
                if (isQtyMode(r[4]) && r[3].isNotBlank()) {
                    tvQty.visibility = View.VISIBLE
                    tvQty.text = r[3]
                } else {
                    tvQty.visibility = View.GONE
                }
                // ★ FIX (baru): waktu scan (tanggal+jam, dari "dd/MM/yy HH:mm:ss").
                val t = r[5]
                v.findViewById<TextView>(R.id.tvDcTime).text =
                    if (t.length >= 14) t.substring(0, 5) + " " + t.substring(9, 14) else t
                // ★ FIX (baru): selisih total scan SKU vs System — ORANYE = lebih, KUNING = kurang,
                // ✓ hijau = sesuai. Hanya Stock Take (Add Box tidak dibandingkan dengan System).
                val tvDiff = v.findViewById<TextView>(R.id.tvDcDiff)
                tvDiff.background = null
                tvDiff.visibility = if (r[4] == "STOCK_TAKE") View.INVISIBLE else View.GONE
                if (r[4] == "STOCK_TAKE") {
                    val d = diffFor(r[2])
                    if (d != null) {
                        tvDiff.visibility = View.VISIBLE
                        if (d == 0.0) {
                            tvDiff.text = "✓"; tvDiff.setTextColor(0xFF2E7D32.toInt())
                        } else {
                            val over = d > 0
                            tvDiff.text = (if (over) "+" else "−") + fmtQty(Math.abs(d))
                            tvDiff.setTextColor(0xFF000000.toInt())
                            tvDiff.background = android.graphics.drawable.GradientDrawable().apply {
                                cornerRadius = 6f * resources.displayMetrics.density
                                setColor(if (over) 0xFFFF9800.toInt() else 0xFFFFEB3B.toInt())
                            }
                        }
                    }
                }
                return v
            }
        }
        lvRecords.adapter = adapter
        setupRowDrag()

        // ★ FIX (baru): tap salah satu record → dialog konfirmasi hapus.
        // Hapus langsung dari list (UI) + DB, nomor urut & total otomatis
        // diperbarui, tanpa perlu refresh halaman.
        // ★ FIX (baru): TAP = edit (Shelf/SKU/Qty), TAHAN = hapus (sebelumnya terbalik).
        lvRecords.setOnItemClickListener { _, _, position, _ ->
            showEditRecordDialog(position)
        }

        // ★ FIX (baru): tekan & tahan record → langsung edit Shelf, SKU, Qty.
        lvRecords.setOnItemLongClickListener { _, _, position, _ ->
            confirmDeleteRecord(position)
            true
        }

        findViewById<View>(R.id.btnClearAll).setOnClickListener { confirmClearAll() }
        findViewById<View>(R.id.btnUploadToPc).setOnClickListener { showUploadChoiceDialog() }
        btnUploadToKs.setOnClickListener { showUploadToKsDialog() }

        setMode(dcMode, persist = false)
        setScanMethod(dcScanMethod, persist = false)
        loadRecords()

        // ★ FIX (samakan dgn Scan Process/SKU Code, disesuaikan #3): kalau mode
        // aktif Stock Take/Add Box dan Shelf masih kosong, fokus mulai dari
        // Shelf dulu (Scan Code & Qty belum tampil). Selain itu (Shelf Record,
        // atau Stock Take yang Shelf-nya sudah terisi), Scan Code langsung
        // standby seperti sebelumnya.
        if (isQtyMode(dcMode) && etShelf.text.toString().trim().isEmpty()) {
            etShelf.post { etShelf.requestFocus() }
        } else {
            etScanCode.post { etScanCode.requestFocus() }
        }
    }

    override fun onPause() {
        super.onPause()
        autoBackupStockTake()
    }

    override fun onDestroy() {
        super.onDestroy()
        toneGen?.release()
    }

    override fun onResume() {
        super.onResume()
        loadRecords()
        if (enquireActive) { refreshEnquireInfo(); etScanCode.requestFocus(); return }
        if (isQtyMode(dcMode) && etShelf.text.toString().trim().isEmpty()) {
            etShelf.requestFocus()
        } else {
            etScanCode.requestFocus()
        }
    }

    override fun onBarcodeScanned(barcode: String) {
        etScanCode.setText(barcode)
        handleScanInput(barcode)
    }

    // ── Mode Shelf Price Enquiry (di dalam Data Collector) ───────────────────
    /** True = layar sedang di mode Shelf Price Enquiry. dcMode (mode kerja tersimpan) TIDAK diubah. */
    private var enquireActive = false

    private fun setEnquire(on: Boolean) {
        if (enquireActive == on) return
        enquireActive = on
        val vis = if (on) View.GONE else View.VISIBLE
        findViewById<View>(R.id.panelEnquire).visibility = if (on) View.VISIBLE else View.GONE
        findViewById<View>(R.id.rowShelf).visibility = vis
        findViewById<View>(R.id.blockRecordsHeader).visibility = vis
        findViewById<View>(R.id.rowBottomButtons).visibility = vis
        findViewById<View>(R.id.btnImportFile).visibility = vis
        findViewById<View>(R.id.btnExportFile).visibility = vis
        findViewById<View>(R.id.btnSmbOutputSettings).visibility = vis
        if (on) {
            // hanya input Scan Code (dipakai sebagai kolom SKU) yang tersisa di area input
            rowAutoDetect.visibility = View.GONE
            rowSumMode.visibility = View.GONE
            rowQty.visibility = View.GONE
            rowScanCode.visibility = View.VISIBLE
            btnImportFromHistory.visibility = View.GONE
            btnCompareStock.visibility = View.GONE
            lvRecords.visibility = View.GONE
            tvDcEmpty.visibility = View.GONE
            hideSkuInfo(); hideMatchAlert()
            etScanCode.setText("")
            listOf(btnModeShelfRecord, btnModeStockTake, btnModeAddBox).forEach {
                it.setBackgroundColor(resources.getColor(R.color.gray_button)); it.setTextColor(0xFF000000.toInt())
            }
            findViewById<TextView>(R.id.btnShelfPriceEnquiry).apply {
                setBackgroundResource(R.drawable.bg_card_gradient_1); setTextColor(0xFFFFFFFF.toInt())
            }
            refreshEnquireInfo()
            etScanCode.post { etScanCode.requestFocus() }
        } else {
            // setMode() (dipanggil sesudah ini) memulihkan visibilitas khusus tiap mode
            findViewById<View>(R.id.layoutEnqResult).visibility = View.GONE
        }
    }

    private fun refreshEnquireInfo() {
        lifecycleScope.launch {
            val count = withContext(Dispatchers.IO) { db.countCatalog() }
            findViewById<TextView>(R.id.tvEnqTotal).text = "Total Item : $count"
            val ts = catalogUpdatedTime
            findViewById<TextView>(R.id.tvEnqLastUpdate).text = if (ts > 0L)
                "Last Updated Date : " + SimpleDateFormat("EEE MMM dd HH:mm:ss z yyyy", Locale.ENGLISH).format(Date(ts))
            else "Last Updated Date : -"
        }
    }

    private fun hideEnquireResult() { findViewById<View>(R.id.layoutEnqResult).visibility = View.GONE }

    /** Cari SKU di katalog 02 lalu tampilkan di kartu RESULT. Tidak menyimpan apa pun ke History/record. */
    private fun enquireSearch(raw: String) {
        val sku = raw.trim().uppercase()
        etScanCode.setText("")
        if (sku.isEmpty()) return
        lifecycleScope.launch {
            val data = withContext(Dispatchers.IO) { db.findCatalog(sku) }
            val shown = data ?: mapOf(
                "sku" to sku, "desc" to "NOT FOUND", "shelf" to "-",
                "price" to "0", "balance" to "0",
                "discount" to "-", "discStart" to "-", "discEnd" to "-",
                "longSku" to "-", "keepStock" to "-"
            )
            ResultCardRenderer.render(this@DataCollectorActivity, findViewById(R.id.llEnqResultAll), shown)
            findViewById<View>(R.id.layoutEnqResult).visibility = View.VISIBLE
            if (data == null) Toast.makeText(this@DataCollectorActivity, "SKU $sku not found", Toast.LENGTH_SHORT).show()
            etScanCode.post { etScanCode.requestFocus() }
        }
    }

    /** Menu ⋮ mode Shelf Price Enquiry (sama dengan menu ⋮ layar Shelf Price Enquire sebelumnya). */
    private fun showEnquireOverflow(anchor: View) {
        val popup = android.widget.PopupMenu(this, anchor)
        popup.menu.add(0, 1, 0, "Download Latest Data From PC")
        popup.menu.add(0, 2, 1, "View Downloaded Data 02")
        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                // proses download besar (progress, parse, mapping) dipakai bersama dgn Stock Balance Check
                1 -> { startActivity(android.content.Intent(this, ShelfPriceEnquireActivity::class.java).apply {
                    putExtra(ShelfPriceEnquireActivity.EXTRA_MODE, ShelfPriceEnquireActivity.MODE_ENQUIRE)
                    putExtra(ShelfPriceEnquireActivity.EXTRA_AUTO_DOWNLOAD, true)
                }); true }
                2 -> { startActivity(android.content.Intent(this, PriceCatalogViewActivity::class.java)); true }
                else -> false
            }
        }
        popup.show()
    }

    // ── Mode Kerja & Metode Scan ─────────────────────────────────────────
    private fun setMode(mode: String, persist: Boolean = true) {
        val previous = dcMode
        if (persist) dcMode = mode
        val isQty = isQtyMode(mode)
        val isStockTake = mode == "STOCK_TAKE"
        val isAddBox = mode == "ADD_BOX"

        // ★ FIX (baru): pindah mode oleh user → kosongkan isian (Shelf / No Ctn tidak
        // boleh terbawa antar mode) supaya data tidak salah masuk.
        if (persist && previous != mode) {
            etShelf.setText(""); etScanCode.setText(""); etQty.setText("")
            hideSkuInfo(); hideMatchAlert()
        }
        fun style(btn: TextView, active: Boolean) {
            if (active) btn.setBackgroundResource(R.drawable.bg_card_gradient_1)
            else btn.setBackgroundColor(resources.getColor(R.color.gray_button))
            btn.setTextColor(if (active) 0xFFFFFFFF.toInt() else 0xFF000000.toInt())
        }
        style(btnModeShelfRecord, mode == "SHELF_RECORD")
        style(btnModeStockTake, isStockTake)
        style(btnModeAddBox, isAddBox)
        style(findViewById<TextView>(R.id.btnShelfPriceEnquiry), false)

        // Label kolom pertama: Shelf (Shelf Record / Stock Take) vs No Ctn (Add Box).
        tvLabelShelf.text = "${locLabelOf(mode)} :"
        etShelf.hint = if (isAddBox) "Ex : A001" else "Ex : AG01-01"

        // UPLOAD TO KS (Keep Stock) HANYA Add Box; Compare Stock (vs System) HANYA Stock Take.
        btnUploadToKs.visibility = if (isAddBox) View.VISIBLE else View.GONE
        btnCompareStock.visibility = if (isStockTake) View.VISIBLE else View.GONE
        // Import dari History Scan (Shelf+SKU+Qty hasil scan): Shelf Record & Stock Take saja.
        btnImportFromHistory.visibility = if (isAddBox) View.GONE else View.VISIBLE

        if (isQty) loadKeepStockQty() else hideSkuInfo()
        btnUnscanned.visibility = if (isStockTake) View.VISIBLE else View.GONE
        btnUndo.visibility = View.VISIBLE
        if (!isStockTake) hideMatchAlert()
        if (isQty) {
            // Stock Take & Add Box SELALU mode Manual — Auto Detect disembunyikan.
            rowAutoDetect.visibility = View.GONE
            rowSumMode.visibility = View.VISIBLE
            setScanMethod("MANUAL", persist = false)
            // Pengisian dimulai dari Shelf/No Ctn dulu — Scan Code & Qty muncul SETELAH terisi.
            val shelfFilled = etShelf.text.toString().trim().isNotEmpty()
            rowScanCode.visibility = if (shelfFilled) View.VISIBLE else View.GONE
            rowQty.visibility = if (shelfFilled) View.VISIBLE else View.GONE
            if (!shelfFilled) etShelf.post { etShelf.requestFocus() }
        } else {
            // Shelf Record: perilaku seperti sebelumnya — Auto Detect
            // tersedia, Scan Code selalu tampil (Manual maupun Auto Detect).
            rowAutoDetect.visibility = View.VISIBLE
            rowSumMode.visibility = View.GONE
            rowScanCode.visibility = View.VISIBLE
            rowQty.visibility = View.GONE
            setScanMethod(dcScanMethod, persist = false)
        }

        // ★ FIX: data record Shelf Record & Stock Take dipisah — tiap
        // ganti mode, list yang dirender cuma milik mode aktif (tidak digabung).
        applyModeFilter()
    }

    private fun setScanMethod(method: String, persist: Boolean = true) {
        if (persist) dcScanMethod = method
        val isAuto = method == "AUTO"
        // ★ FIX (baru): sync posisi Switch tanpa memicu ulang listener-nya.
        if (switchAutoDetect.isChecked != isAuto) {
            switchAutoDetect.setOnCheckedChangeListener(null)
            switchAutoDetect.isChecked = isAuto
            switchAutoDetect.setOnCheckedChangeListener { _, isChecked ->
                setScanMethod(if (isChecked) "AUTO" else "MANUAL")
            }
        }

        // ★ FIX: Manual — Shelf diisi manual duluan, fokus ke Scan Code.
        //        Auto Detect → langsung fokus ke Scan Code (field serbaguna).
        // ★ FIX (baru — #3): kalau Scan Code sedang disembunyikan (mode Stock
        // Take/Add Box sebelum Shelf diisi), JANGAN paksa fokus ke situ —
        // fokus Shelf yang mengurus (lihat setMode()).
        if (rowScanCode.visibility == View.VISIBLE) {
            etScanCode.requestFocus()
        }
    }

    // ── Proses Scan ───────────────────────────────────────────────────────
    /** ★ FIX (baru): titik masuk tunggal untuk semua hasil scan (kamera, HID
     *  keyboard scanner via Enter/Tab, atau ketik manual + tombol ↵). */
    private fun handleScanInput(raw: String) {
        val value = raw.trim()
        if (value.isEmpty()) return
        // ★ FIX (baru): mode Shelf Price Enquiry — scan = cari harga, tidak menyimpan record.
        if (enquireActive) { enquireSearch(value); return }

        val method = dcScanMethod
        if (method == "AUTO") {
            // ★ FIX: Auto Detect — huruf di dalam hasil scan = Shelf baru,
            // cuma angka = Scan Code (langsung simpan baris).
            // (Auto Detect hanya berlaku di mode Shelf Record — Stock
            // Take/Add Box selalu MANUAL, lihat setMode().)
            if (onlyLettersRegex.matches(value)) {
                // ★ FIX (#1): mode Shelf Record — tolak hasil scan
                // berformat link/URL atau QR umum lainnya sebagai Shelf.
                if (isLinkOrQrFormat(value)) {
                    Toast.makeText(this,
                        "Invalid Shelf: link/QR format is not allowed", Toast.LENGTH_SHORT).show()
                    etScanCode.setText("")
                    etScanCode.post { etScanCode.requestFocus() }
                    return
                }
                etShelf.setText(value)
                etScanCode.setText("")
                etScanCode.requestFocus()
                Toast.makeText(this, "Shelf set to: $value", Toast.LENGTH_SHORT).show()
            } else {
                // ★ FIX (#1): mode Shelf Record — tolak Scan Code berformat
                // link/URL atau QR umum lainnya.
                if (isLinkOrQrFormat(value)) {
                    Toast.makeText(this,
                        "Invalid Scan Code: link/QR format is not allowed", Toast.LENGTH_SHORT).show()
                    etScanCode.setText("")
                    etScanCode.post { etScanCode.requestFocus() }
                    return
                }
                submitRecord(value)
            }
        } else if (isQtyMode(dcMode)) {
            // ★ FIX (#2): Manual, mode Stock Take/Add Box — Scan Code TIDAK
            // langsung disimpan. Setelah Scan Code terdeteksi/masuk (scan
            // maupun ketik manual), fokus otomatis pindah (auto-tab) ke Qty;
            // baris baru benar-benar tersimpan setelah Qty diisi & di-Enter
            // (lihat listener etQty & submitRecord()).
            val shelf = etShelf.text.toString().trim()
            if (shelf.isEmpty()) {
                Toast.makeText(this, "Fill in Shelf before scanning Scan Code", Toast.LENGTH_SHORT).show()
                etScanCode.setText("")
                etShelf.requestFocus()
                return
            }
            etScanCode.setText(value)
            etQty.setText("")
            // ★ FIX (baru): tampilkan Qty System (02) & Qty Keep Stock SKU ini
            // sebelum user mengisi Qty.
            hideMatchAlert()
            showSkuInfo(value)
            etQty.post { etQty.requestFocus() }
        } else {
            // ★ FIX: Manual, mode Shelf Record — field Scan Code SELALU
            // dianggap Scan Code (Shelf sudah diisi terpisah oleh user
            // sebelumnya). ★ FIX (#1): tolak format link/URL/QR.
            if (isLinkOrQrFormat(value)) {
                Toast.makeText(this,
                    "Invalid Scan Code: link/QR format is not allowed", Toast.LENGTH_SHORT).show()
                etScanCode.setText("")
                etScanCode.post { etScanCode.requestFocus() }
                return
            }
            submitRecord(value)
        }
    }

    // ── Info Qty System & Keep Stock (mode Stock Take/Add Box) ─────────────

    private fun hideSkuInfo() {
        infoScanCode = ""
        tvSkuInfo.text = ""
        tvSkuInfo.visibility = View.GONE
    }

    /** Muat data Keep Stock live (toko aktif = ksLastStore) ke cache SKU -> total Qty. */
    private fun loadKeepStockQty(force: Boolean = false) {
        if (ksLoadState == "LOADING") return
        if (!force && (ksLoadState == "OK" || ksLoadState == "NOT_CONFIGURED")) return
        val store = ksLastStore.ifBlank { Prefs.KEEP_STOCK_STORES.first() }
        val ssid = exioSpreadsheetId(store)
        val gid = exioGid(store)
        if (ssid.isBlank() || gid.isBlank()) {
            ksLoadState = "NOT_CONFIGURED"; ksQtyBySku = null; ksRowsCache = null
            if (infoScanCode.isNotEmpty()) showSkuInfo(infoScanCode, alert = false)
            return
        }
        ksLoadState = "LOADING"
        if (infoScanCode.isNotEmpty()) showSkuInfo(infoScanCode, alert = false)
        lifecycleScope.launch {
            try {
                val fetched = withContext(Dispatchers.IO) { KeepStockSheetReader.fetchRows(ssid, gid) }
                val map = HashMap<String, Double>()
                fetched.forEach { r ->
                    val q = r.qty.toDoubleOrNull() ?: 0.0
                    map[r.sku] = (map[r.sku] ?: 0.0) + q
                }
                ksRowsCache = fetched
                ksQtyBySku = map; ksLoadState = "OK"
                diffCache.clear(); if (::adapter.isInitialized) adapter.notifyDataSetChanged()
            } catch (e: Exception) {
                ksQtyBySku = null; ksRowsCache = null; ksLoadState = "ERROR"
            }
            if (infoScanCode.isNotEmpty()) showSkuInfo(infoScanCode, alert = false)
        }
    }

    private fun fmtQty(d: Double): String =
        if (d == d.toLong().toDouble()) d.toLong().toString() else d.toString()

    /** Qty Keep Stock (live) untuk SKU ini; null kalau data KS belum ter-load. */
    private fun ksQtyFor(code: String, cat: Map<String, String>?): Double? {
        if (ksLoadState != "OK") return null
        val m = ksQtyBySku ?: return null
        val keys = listOfNotNull(code, cat?.get("sku"), cat?.get("longSku")?.takeIf { it != "-" })
        return keys.firstNotNullOfOrNull { m[it] } ?: 0.0
    }

    private fun showSkuInfo(code: String, alert: Boolean = true) {
        infoScanCode = code
        val cat = db.findCatalogForComparison(code)
        val sys = if (cat == null) "- (not in 02)"
                  else cat["balance"]?.takeIf { it.isNotBlank() && it != "-" } ?: "-"
        val ks = when (ksLoadState) {
            "OK" -> fmtQty(ksQtyFor(code, cat) ?: 0.0)
            "LOADING" -> "loading..."
            "NOT_CONFIGURED" -> "- (KS sheet not set)"
            "ERROR" -> "failed (tap to retry)"
            else -> { loadKeepStockQty(); "loading..." }
        }
        val already = if (dcMode == "STOCK_TAKE") scannedTotal(code) else 0
        val sb = StringBuilder("System: $sys   |   Keep Stock: $ks" + (if (already > 0) "   |   Sudah scan: $already" else ""))
        var warn = cat == null
        var color = if (cat == null) 0xFFD32F2F.toInt() else 0xFF5E35B1.toInt()
        // ★ FIX (baru): peringatan kalau Shelf katalog 02 BERBEDA dari Shelf aktif.
        val catShelf = cat?.get("shelf")?.trim().orEmpty()
        val activeShelf = etShelf.text.toString().trim()
        if (dcMode == "STOCK_TAKE" && cat != null && catShelf.isNotBlank() && catShelf != "-" &&
            activeShelf.isNotBlank() && !catShelf.equals(activeShelf, ignoreCase = true)) {
            sb.append("\n⚠ Shelf 02: $catShelf (aktif: $activeShelf)")
            warn = true
            color = 0xFFE65100.toInt()
        }
        if (dcMode == "STOCK_TAKE" && cat != null && activeShelf.isNotBlank()) {
            duplicateShelfMessage(code, activeShelf)?.let {
                sb.append("\n").append(it); warn = true; color = 0xFFE65100.toInt()
            }
        }
        tvSkuInfo.text = sb.toString()
        tvSkuInfo.setTextColor(color)
        tvSkuInfo.visibility = View.VISIBLE
        if (alert && warn) beepError()
    }

    // ── Feedback suara & getar ──────────────────────────────────────────────
    private fun beepOk() { runCatching { toneGen?.startTone(ToneGenerator.TONE_PROP_BEEP, 80) } }

    @Suppress("DEPRECATION")
    private fun beepError() {
        runCatching { toneGen?.startTone(ToneGenerator.TONE_SUP_ERROR, 350) }
        runCatching {
            val vib = getSystemService(VIBRATOR_SERVICE) as? Vibrator
            if (android.os.Build.VERSION.SDK_INT >= 26)
                vib?.vibrate(VibrationEffect.createOneShot(250, VibrationEffect.DEFAULT_AMPLITUDE))
            else vib?.vibrate(250)
        }
    }

    // ── Undo, ringkasan, daftar Belum Scan, auto-backup ───────────────────────
    /** Cari record (mode aktif) dengan Shelf+Kode sama. */
    private fun findRecord(mode: String, shelf: String, code: String): Array<String>? =
        rowsAll.firstOrNull { it[4] == mode && it[1].trim().equals(shelf.trim(), ignoreCase = true) && it[2].trim() == code.trim() }

    /** UNDO: batalkan scan TERAKHIR. Kalau scan itu hanya menambah qty (akumulasi), yang
     *  dikurangi hanya qty scan itu — record-nya tidak ikut terhapus. */
    private fun undoLastRecord() {
        val idx = scanLog.indexOfLast { it.mode == dcMode }
        if (idx < 0) {
            // Tidak ada riwayat sesi ini (mis. data lama) → hapus record terbaru seperti dulu.
            val r = rows.firstOrNull()
            if (r == null) { Toast.makeText(this, "Nothing to undo", Toast.LENGTH_SHORT).show(); return }
            db.deleteDataCollect(r[0].toInt())
            redoStack.add(ScanOp(dcMode, r[1], r[2], r[3].toIntOrNull() ?: 0, true))
            loadRecords(); hideSkuInfo(); hideMatchAlert()
            Toast.makeText(this, "Undo: ${r[2]}", Toast.LENGTH_SHORT).show()
            return
        }
        val op = scanLog.removeAt(idx)
        val rec = findRecord(op.mode, op.shelf, op.code)
        if (rec != null) {
            val left = (rec[3].toIntOrNull() ?: 0) - op.qty
            if (op.newRow || left <= 0) db.deleteDataCollect(rec[0].toInt())
            else db.updateDataCollect(rec[0].toInt(), rec[1], rec[2], left.toString())
        }
        redoStack.add(op)
        loadRecords(); hideSkuInfo(); hideMatchAlert()
        Toast.makeText(this, "Undo: ${op.code}" + (if (isQtyMode(op.mode)) " (-${op.qty})" else ""), Toast.LENGTH_SHORT).show()
        etScanCode.post { etScanCode.requestFocus() }
    }

    /** REDO: ulangi scan yang barusan di-UNDO. */
    private fun redoLastRecord() {
        val idx = redoStack.indexOfLast { it.mode == dcMode }
        if (idx < 0) { Toast.makeText(this, "Nothing to redo", Toast.LENGTH_SHORT).show(); return }
        val op = redoStack.removeAt(idx)
        val rec = if (isQtyMode(op.mode) && dcSumMode) findRecord(op.mode, op.shelf, op.code) else null
        val newRow: Boolean
        if (rec != null) {
            db.updateDataCollect(rec[0].toInt(), rec[1], rec[2], ((rec[3].toIntOrNull() ?: 0) + op.qty).toString())
            newRow = false
        } else {
            db.insertDataCollect(op.shelf, op.code, if (isQtyMode(op.mode)) op.qty.toString() else "", op.mode)
            newRow = true
        }
        scanLog.add(ScanOp(op.mode, op.shelf, op.code, op.qty, newRow))
        loadRecords()
        Toast.makeText(this, "Redo: ${op.code}", Toast.LENGTH_SHORT).show()
        etScanCode.post { etScanCode.requestFocus() }
    }

    // ── Cari hasil scan ──────────────────────────────────────────────────────
    private fun toggleSearch() {
        if (etSearch.visibility == View.VISIBLE) {
            etSearch.setText("")
            etSearch.visibility = View.GONE
            etScanCode.post { etScanCode.requestFocus() }
        } else {
            etSearch.visibility = View.VISIBLE
            etSearch.post {
                etSearch.requestFocus()
                (getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager)
                    .showSoftInput(etSearch, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
            }
        }
    }

    private fun updateSummary() {
        val filterNote = if (searchQuery.isNotEmpty()) "  (tampil ${viewRows.size})" else ""
        val tag = modeLabelOf(dcMode).uppercase()
        if (!isQtyMode(dcMode)) { tvDcCount.text = "$tag • ${rows.size} record$filterNote"; return }
        val totalQty = rows.sumOf { it[3].toIntOrNull() ?: 0 }
        val uniqueSku = rows.map { it[2].trim() }.toSet().size
        val sb = StringBuilder("$tag • ${rows.size} record • $uniqueSku SKU • $totalQty pcs$filterNote")
        val shelf = etShelf.text.toString().trim()
        if (shelf.isNotEmpty()) {
            val sr = rows.filter { it[1].trim().equals(shelf, ignoreCase = true) }
            sb.append("\n${locLabelOf(dcMode)} $shelf: ${sr.map { it[2].trim() }.toSet().size} SKU • ${sr.sumOf { it[3].toIntOrNull() ?: 0 }} pcs")
        }
        tvDcCount.text = sb.toString()
    }

    /** Daftar item ber-stok (System > 0) di Shelf aktif menurut katalog 02:
     *  • BELUM SCAN  = tidak ada di scan manapun
     *  • TERSCAN BUKAN DI SHELF INI = sudah di-scan, tapi di shelf lain (ditampilkan shelf & qty-nya)
     *  SKU yang sudah di-scan di shelf lain TIDAK dimasukkan ke daftar "belum scan". */
    private fun showUnscannedDialog() {
        val shelf = etShelf.text.toString().trim()
        if (shelf.isEmpty()) { Toast.makeText(this, "Fill in Shelf first", Toast.LENGTH_SHORT).show(); return }
        val items = db.getCatalogItemsByShelf(shelf)
        if (items.isEmpty()) {
            AlertDialog.Builder(this).setTitle("Belum Scan — $shelf")
                .setMessage("Shelf ini tidak ditemukan di katalog 02.")
                .setPositiveButton("OK", null).show()
            return
        }
        fun bal(m: Map<String, String>) = m["balance"]?.replace(",", "")?.toDoubleOrNull() ?: 0.0
        val stRows = rows.filter { it[4] == "STOCK_TAKE" }
        val stocked = items.filter { bal(it) > 0 }
        val missing = ArrayList<Map<String, String>>()
        val elsewhere = ArrayList<Pair<Map<String, String>, String>>()
        var scannedHere = 0
        for (m in stocked) {
            val sku = m["sku"].orEmpty().trim()
            val lng = m["longSku"].orEmpty().trim().takeIf { it.isNotBlank() && it != "-" }
            val hits = stRows.filter { r -> val c = r[2].trim(); c == sku || (lng != null && c == lng) }
            if (hits.isEmpty()) { missing.add(m); continue }
            val here = hits.any { it[1].trim().equals(shelf, ignoreCase = true) }
            if (here) { scannedHere++; continue }
            val where = hits.groupBy { it[1].trim().uppercase() }
                .entries.joinToString(", ") { e -> "${e.key} (${e.value.sumOf { it[3].toIntOrNull() ?: 0 }})" }
            elsewhere.add(m to where)
        }
        val sb = StringBuilder()
        sb.append("BELUM SCAN (${missing.size})\n")
        if (missing.isEmpty()) sb.append("—  semua sudah ter-scan ✔\n")
        else missing.forEach { m -> sb.append("${m["sku"]}  ${m["desc"].orEmpty().take(28)}  (Sys ${fmtQty(bal(m))})\n") }
        sb.append("\nTERSCAN BUKAN DI SHELF INI (${elsewhere.size})\n")
        if (elsewhere.isEmpty()) sb.append("—\n")
        else elsewhere.forEach { (m, where) ->
            sb.append("${m["sku"]}  ${m["desc"].orEmpty().take(24)}\n   ↳ terscan di: $where\n")
        }
        AlertDialog.Builder(this)
            .setTitle("$shelf — ${stocked.size} SKU ber-stok, $scannedHere sudah di shelf ini")
            .setMessage(sb.toString().trimEnd())
            .setPositiveButton("OK", null).show()
    }

    // ── Edit Shelf banyak sekaligus ──────────────────────────────────────────
    /** Pilih cara: per SHELF (semua record shelf itu) atau per DATA SCAN (sebagian record). */
    private fun showBulkEditShelfDialog() {
        if (rows.isEmpty()) { Toast.makeText(this, "No data yet", Toast.LENGTH_SHORT).show(); return }
        AlertDialog.Builder(this)
            .setTitle("Edit ${locLabelOf(dcMode)}")
            .setItems(arrayOf("Pilih per ${locLabelOf(dcMode)} (semua data di dalamnya)", "Pilih per Data Scan (sebagian saja)",
                "Kelompokkan data per ${locLabelOf(dcMode)} (rapikan urutan)")) { _, which ->
                when (which) { 0 -> showBulkEditByShelf(); 1 -> showBulkEditByRecord(); else -> confirmGroupByShelf() }
            }
            .setNegativeButton("Batal", null).show()
    }

    private fun showBulkEditByShelf() {
        val groups = LinkedHashMap<String, MutableList<Array<String>>>()
        rows.sortedBy { it[1].trim().uppercase() }.forEach { groups.getOrPut(it[1].trim().uppercase()) { mutableListOf() }.add(it) }
        val keys = groups.keys.toList()
        val labels = keys.map { "$it  (${groups.getValue(it).size} record)" }.toTypedArray()
        val checked = BooleanArray(keys.size)
        AlertDialog.Builder(this)
            .setTitle("Centang ${locLabelOf(dcMode)} yang salah")
            .setMultiChoiceItems(labels, checked) { _, which, isChecked -> checked[which] = isChecked }
            .setPositiveButton("Lanjut") { _, _ ->
                val sel = keys.filterIndexed { i, _ -> checked[i] }
                if (sel.isEmpty()) { Toast.makeText(this, "Pilih minimal satu", Toast.LENGTH_SHORT).show(); return@setPositiveButton }
                promptNewShelfAndApply(sel.flatMap { groups.getValue(it) }, "${sel.size} ${locLabelOf(dcMode)}")
            }
            .setNegativeButton("Batal", null).show()
    }

    /** Pilih data scan satu per satu (daftar mengikuti hasil CARI kalau sedang mencari). */
    private fun showBulkEditByRecord() {
        val list = viewRows.toList()
        if (list.isEmpty()) { Toast.makeText(this, "Tidak ada data", Toast.LENGTH_SHORT).show(); return }
        val labels = list.map { r ->
            "${r[1]}  •  ${r[2]}" + (if (isQtyMode(r[4]) && r[3].isNotBlank()) "  •  ${r[3]}" else "")
        }.toTypedArray()
        val checked = BooleanArray(list.size)
        val dlg = AlertDialog.Builder(this)
            .setTitle("Centang data scan (${list.size})")
            .setMultiChoiceItems(labels, checked) { _, which, isChecked -> checked[which] = isChecked }
            .setPositiveButton("Lanjut") { _, _ ->
                val sel = list.filterIndexed { i, _ -> checked[i] }
                if (sel.isEmpty()) { Toast.makeText(this, "Pilih minimal satu", Toast.LENGTH_SHORT).show(); return@setPositiveButton }
                promptNewShelfAndApply(sel, "${sel.size} data scan")
            }
            .setNeutralButton("Pilih Semua", null)
            .setNegativeButton("Batal", null).create()
        dlg.show()
        // "Pilih Semua" = centang/lepas semua tanpa menutup dialog.
        dlg.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
            val all = checked.any { !it }
            for (i in checked.indices) { checked[i] = all; dlg.listView.setItemChecked(i, all) }
        }
    }

    private fun promptNewShelfAndApply(selected: List<Array<String>>, what: String) {
        val label = locLabelOf(dcMode)
        val et = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
            setSingleLine(true); hint = "$label baru"
        }
        val box = android.widget.LinearLayout(this).apply {
            val pad = (20 * resources.displayMetrics.density).toInt()
            setPadding(pad, pad / 2, pad, 0); addView(et)
        }
        AlertDialog.Builder(this)
            .setTitle("Pindahkan $what (${selected.size} record) ke:")
            .setView(box)
            .setPositiveButton("Simpan") { _, _ ->
                val ns = et.text.toString().trim().uppercase()
                if (ns.isEmpty()) { Toast.makeText(this, "$label baru tidak boleh kosong", Toast.LENGTH_SHORT).show(); return@setPositiveButton }
                selected.forEach { r -> db.updateDataCollect(r[0].toInt(), ns, r[2], r[3]) }
                // Riwayat UNDO/REDO mode ini tidak valid lagi setelah shelf dipindah.
                scanLog.removeAll { it.mode == dcMode }; redoStack.removeAll { it.mode == dcMode }
                loadRecords()
                if (isQtyMode(dcMode)) mergeDuplicateStockTake()
                Toast.makeText(this, "${selected.size} record dipindah ke $ns", Toast.LENGTH_LONG).show()
            }
            .setNegativeButton("Batal", null).show()
    }

    /** Setelah shelf digabung: SKU yang sama di shelf yang sama dijumlahkan jadi satu record. */
    private fun mergeDuplicateStockTake() {
        if (!dcSumMode) return   // NON-SUM: data sama sengaja dibiarkan terpisah
        val groups = rowsAll.filter { it[4] == dcMode }
            .groupBy { it[1].trim().uppercase() + "|" + it[2].trim() }
            .filter { it.value.size > 1 }
        if (groups.isEmpty()) return
        groups.values.forEach { list ->
            val keep = list.minByOrNull { it[0].toInt() }!!
            val sum = list.sumOf { it[3].toIntOrNull() ?: 0 }
            db.updateDataCollect(keep[0].toInt(), keep[1], keep[2], sum.toString())
            list.filter { it !== keep }.forEach { db.deleteDataCollect(it[0].toInt()) }
        }
        loadRecords()
        Toast.makeText(this, "${groups.size} SKU ganda digabung (qty dijumlahkan)", Toast.LENGTH_LONG).show()
    }

    /** Cadangan otomatis data Stock Take/Add Box ke file lokal (tiap 10 record & saat layar
     *  ditinggalkan) — nama: {fileFormat}_04_AUTOSAVE.txt, ditimpa tiap kali. */
    private fun autoBackupStockTake() {
        val prefix = fileFormat.ifBlank { "YM" }
        for (mode in listOf("STOCK_TAKE", "ADD_BOX")) {
            val list = rowsAll.filter { it[4] == mode }
            if (list.isEmpty()) continue
            val content = list.asReversed().joinToString("\n") { "${it[1]},${it[2]},${it[3].ifBlank { "0" }}" }
            val name = if (mode == "ADD_BOX") "${prefix}_04_ADDBOX_AUTOSAVE.txt" else "${prefix}_04_AUTOSAVE.txt"
            lifecycleScope.launch(Dispatchers.IO) {
                runCatching { OutputWriter.writeToLocalDirect(this@DataCollectorActivity, name, content) }
            }
        }
    }

    private fun submitRecord(scanCode: String) {
        val shelf = etShelf.text.toString().trim()
        if (shelf.isEmpty()) {
            Toast.makeText(this, "Fill in Shelf before scanning Scan Code", Toast.LENGTH_SHORT).show()
            etScanCode.setText("")
            etShelf.requestFocus()
            return
        }
        if (scanCode.isEmpty()) {
            Toast.makeText(this, "Fill in Scan Code before saving", Toast.LENGTH_SHORT).show()
            etScanCode.post { etScanCode.requestFocus() }
            return
        }
        val mode = dcMode
        val qty = if (isQtyMode(mode)) etQty.text.toString().trim() else ""
        // ★ FIX (#2): mode Stock Take/Add Box — data TIDAK BOLEH tersimpan
        // selama field Qty masih kosong. User wajib mengisi Qty dulu sebelum
        // baris ini benar-benar disubmit ke DB.
        if (isQtyMode(mode) && qty.isEmpty()) {
            Toast.makeText(this, "Fill in Qty before saving", Toast.LENGTH_SHORT).show()
            etQty.post { etQty.requestFocus() }
            return
        }

        // ★ FIX (baru): Stock Take/Add Box — peringatan kalau Qty tidak wajar
        // dibanding System / Keep Stock; user bisa ubah atau tetap simpan.
        if (isQtyMode(mode)) {
            val q = qty.toIntOrNull()
            if (q == null || q < 0) {
                beepError()
                Toast.makeText(this, "Qty must be a valid number", Toast.LENGTH_SHORT).show()
                etQty.post { etQty.requestFocus() }
                return
            }
            // ★ FIX (baru): SKU ini SUDAH di-scan di shelf lain (dan belum ada di shelf aktif)
            // → popup: tetap simpan di shelf ini, atau tambahkan qty ke shelf sebelumnya.
            if (mode == "STOCK_TAKE") {
                val others = rowsAll.filter { it[4] == "STOCK_TAKE" && it[2].trim() == scanCode.trim() &&
                    !it[1].trim().equals(shelf.trim(), ignoreCase = true) }
                // NON-SUM: kalau SKU ini sudah ada di shelf aktif, user sudah pernah memutuskan
                // (boleh 2 shelf) → tidak ditanya lagi tiap scan.
                val hereExists = rowsAll.any { it[4] == "STOCK_TAKE" && it[2].trim() == scanCode.trim() &&
                    it[1].trim().equals(shelf.trim(), ignoreCase = true) }
                if (others.isNotEmpty() && !(!dcSumMode && hereExists)) {
                    showDuplicateShelfPopup(shelf, scanCode, qty, q, others); return
                }
            }
        }
        // ★ FIX (baru): Add Box — validasi terhadap data Keep Stock (No Ctn ada, SKU dobel, qty > System).
        if (mode == "ADD_BOX") {
            if (checkAddBoxCtn(shelf)) return          // jaring pengaman kalau Shelf diisi tanpa Enter
            val q = qty.toIntOrNull() ?: 0
            if (checkAddBoxSku(shelf, scanCode, qty, q)) return
            if (checkAddBoxOver(shelf, scanCode, qty, q)) return
        }
        commitRecord(shelf, scanCode, qty, mode)
    }

    // ── Validasi Add Box vs Keep Stock ────────────────────────────────────────
    private val skuDecided = mutableSetOf<String>()   // "NOCTN|SKU" yang sudah diputuskan user

    private fun revealScanRows() {
        rowScanCode.visibility = View.VISIBLE
        rowQty.visibility = View.VISIBLE
        etScanCode.post { etScanCode.requestFocus() }
    }

    /** No Ctn yang diinput SUDAH ada di Keep Stock → popup: tambah SKU ke No Ctn itu, atau buat No Ctn baru.
     *  Return true kalau popup ditampilkan (proses lanjut lewat tombol popup). */
    private fun checkAddBoxCtn(noCtn: String): Boolean {
        val ksRows = ksRowsCache ?: return false
        if (noCtn.isBlank() || approvedCtns.contains(noCtn.uppercase())) return false
        if (!KeepStockAddGuard.ctnExists(ksRows, noCtn)) return false
        val existing = ksRows.filter { it.noCtn.trim().equals(noCtn.trim(), ignoreCase = true) }
        val preview = existing.take(5).joinToString("\n") { "• ${it.sku}  (qty ${it.qty})" } +
            if (existing.size > 5) "\n• ... +${existing.size - 5} SKU lagi" else ""
        beepError()
        AlertDialog.Builder(this)
            .setTitle("⚠ No Ctn sudah ada")
            .setMessage("No Ctn $noCtn sudah ada di data Keep Stock (${existing.size} SKU):\n$preview\n\nMau tambah SKU ke No Ctn ini, atau buat No Ctn baru?")
            .setCancelable(false)
            .setPositiveButton("Tambah SKU") { _, _ ->
                approvedCtns.add(noCtn.uppercase())
                revealScanRows()
            }
            .setNegativeButton("Buat No Ctn baru") { _, _ ->
                etShelf.setText("")
                etScanCode.setText(""); etQty.setText(""); hideSkuInfo()
                etShelf.post { etShelf.requestFocus() }
                Toast.makeText(this, "Isi No Ctn baru", Toast.LENGTH_SHORT).show()
            }
            .showSafely()
        return true
    }

    private fun skuKeysOf(code: String): List<String> {
        val cat = db.findCatalogForComparison(code)
        return listOfNotNull(code, cat?.get("sku"), cat?.get("longSku")?.takeIf { it != "-" }).distinct()
    }

    /** SKU dobel dengan data Keep Stock → popup: tambahkan ke No Ctn yang sudah ada, atau buat data baru. */
    private fun checkAddBoxSku(shelf: String, code: String, qty: String, q: Int): Boolean {
        val ksRows = ksRowsCache ?: return false
        val key = "${shelf.trim().uppercase()}|${code.trim()}"
        if (skuDecided.contains(key)) return false
        val dups = KeepStockAddGuard.onePerCtn(KeepStockAddGuard.rowsForSku(ksRows, skuKeysOf(code)))
        if (dups.isEmpty()) return false
        beepError()
        val items = ArrayList<String>()
        dups.forEach { r ->
            val sum = ksRows.filter { it.noCtn.trim().equals(r.noCtn.trim(), ignoreCase = true) && it.sku.trim() == r.sku.trim() }
                .sumOf { KeepStockAddGuard.qtyOf(it) }
            items.add("Tambahkan ke No Ctn ${r.noCtn}  (qty ${KeepStockAddGuard.fmt(sum)} → ${KeepStockAddGuard.fmt(sum + q)})")
        }
        items.add("Buat data baru di No Ctn $shelf  (+$q)")
        val dp = resources.displayMetrics.density
        val info = TextView(this).apply {
            text = "SKU $code sudah ada di data Keep Stock (No Ctn: ${dups.joinToString(", ") { it.noCtn }}).\n\nPilih salah satu:"
            textSize = 14f
            setPadding((20 * dp).toInt(), (12 * dp).toInt(), (20 * dp).toInt(), (8 * dp).toInt())
        }
        val list = ListView(this).apply {
            adapter = ArrayAdapter(this@DataCollectorActivity, android.R.layout.simple_list_item_1, items)
        }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(info); addView(list) }
        val dlg = AlertDialog.Builder(this).setTitle("⚠ SKU dobel di Keep Stock").setView(box)
            .setCancelable(false)
            .setNegativeButton("Batal") { _, _ -> etQty.post { etQty.requestFocus() } }
            .create()
        list.setOnItemClickListener { _, _, which, _ ->
            dlg.dismiss()
            skuDecided.add(key)
            val target = if (which < dups.size) dups[which].noCtn.trim() else shelf
            if (checkAddBoxOver(target, code, qty, q)) return@setOnItemClickListener
            commitRecord(target, code, qty, "ADD_BOX")
        }
        dlg.show()
        return true
    }

    /** Total (Keep Stock + Add Box lokal belum upload + qty ini) melebihi Qty System → notifikasi + qty lebihnya. */
    private fun checkAddBoxOver(shelf: String, code: String, qty: String, q: Int): Boolean {
        val ksRows = ksRowsCache ?: return false
        val cat = db.findCatalogForComparison(code)
        val sys = KeepStockAddGuard.parseSystem(cat?.get("balance")) ?: return false
        val keys = skuKeysOf(code).toSet()
        val ks = KeepStockAddGuard.rowsForSku(ksRows, keys).sumOf { KeepStockAddGuard.qtyOf(it) }
        val pending = rowsAll.filter { it[4] == "ADD_BOX" && it[6] != "1" && it[2].trim() in keys }
            .sumOf { (it[3].toIntOrNull() ?: 0).toDouble() }
        val over = KeepStockAddGuard.over(sys, ks, pending, q.toDouble())
        if (over == null) {
            // ★ FIX (baru): total PERSIS sama dengan System → SKU belum display, konfirmasi dulu.
            if (!KeepStockAddGuard.matchesSystem(sys, ks, pending, q.toDouble())) return false
            beepError()
            AlertDialog.Builder(this)
                .setTitle("⚠ SKU belum display")
                .setMessage("SKU $code\nQty System ${KeepStockAddGuard.fmt(sys)} = Keep Stock + Add Box + qty diinput.\n\nSKU belum display, yakin mau lanjut Keep Stock?")
                .setCancelable(false)
                .setPositiveButton("Lanjut") { _, _ -> commitRecord(shelf, code, qty, "ADD_BOX") }
                .setNegativeButton("Batal") { _, _ -> etQty.post { etQty.requestFocus(); etQty.selectAll() } }
                .showSafely()
            return true
        }
        val f = KeepStockAddGuard::fmt
        beepError()
        AlertDialog.Builder(this)
            .setTitle("⚠ Qty melebihi System")
            .setMessage("SKU $code\n" +
                "Qty System      : ${f(over.system)}\n" +
                "Keep Stock      : ${f(over.keepStock)}\n" +
                (if (over.pending > 0) "Add Box (belum upload): ${f(over.pending)}\n" else "") +
                "Qty diinput     : ${f(over.input)}\n" +
                "Total           : ${f(over.total)}\n\n" +
                "LEBIH ${f(over.excess)} dari Qty System.")
            .setCancelable(false)
            .setPositiveButton("Tetap Simpan") { _, _ -> commitRecord(shelf, code, qty, "ADD_BOX") }
            .setNegativeButton("Ubah Qty") { _, _ -> etQty.post { etQty.requestFocus(); etQty.selectAll() } }
            .showSafely()
        return true
    }

    /** SKU ini sudah terscan di shelf LAIN → WAJIB pilih SATU shelf untuk menyatukan:
     *  semua data SKU ini (shelf lain + scan baru) dipindah ke shelf pilihan. Tidak ada
     *  tombol batal — user harus memilih salah satu. */
    private fun showDuplicateShelfPopup(shelf: String, code: String, qty: String, q: Int, others: List<Array<String>>) {
        beepError()
        val groups = others.groupBy { it[1].trim().uppercase() }.values.toList()
        val prevTotal = others.sumOf { it[3].toIntOrNull() ?: 0 } +
            rowsAll.filter { it[4] == "STOCK_TAKE" && it[2].trim() == code.trim() &&
                it[1].trim().equals(shelf.trim(), ignoreCase = true) }.sumOf { it[3].toIntOrNull() ?: 0 }
        val grand = prevTotal + q
        val items = ArrayList<String>()
        items.add("$shelf  (shelf aktif, +$q)  →  total $grand")
        groups.forEach { g ->
            items.add("${g[0][1].trim()}  (sudah ada ${g.sumOf { it[3].toIntOrNull() ?: 0 }})  →  total $grand")
        }
        // ★ FIX (baru): HANYA mode NON-SUM — boleh simpan APA ADANYA: SKU yang sama tetap
        // di 2 shelf (tidak disatukan); notifikasi selisih tetap memakai total.
        val asIs = !dcSumMode
        if (asIs) items.add("Simpan apa adanya di $shelf  (+$q, tanpa menyatukan shelf)")
        // FIX: AlertDialog TIDAK menampilkan daftar pilihan kalau setMessage() dipakai bersamaan
        // dengan setItems() → dulu pilihan shelf tidak muncul & dialog "macet". Sekarang pakai
        // tampilan kustom: teks penjelasan + ListView pilihan shelf.
        val dp = resources.displayMetrics.density
        val info = TextView(this).apply {
            text = "SKU $code terscan di beberapa shelf: " +
                (listOf(shelf) + groups.map { it[0][1].trim() }).joinToString(", ") +
                (if (asIs) ".\n\nPilih SATU shelf untuk menyatukan data SKU ini (total $grand pcs), atau simpan apa adanya (2 shelf). Tap salah satu:"
                 else ".\n\nWAJIB pilih SATU shelf untuk menyatukan data SKU ini (total $grand pcs). Tap salah satu:")
            textSize = 14f
            setPadding((20 * dp).toInt(), (12 * dp).toInt(), (20 * dp).toInt(), (8 * dp).toInt())
        }
        val list = ListView(this).apply {
            adapter = ArrayAdapter(this@DataCollectorActivity, android.R.layout.simple_list_item_1, items)
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(info)
            addView(list)
        }
        val dlg = AlertDialog.Builder(this)
            .setTitle("⚠ SKU dobel shelf")
            .setView(box)
            .setCancelable(false)
            .create()
        list.setOnItemClickListener { _, _, which, _ ->
            dlg.dismiss()
            if (asIs && which == items.size - 1) {      // simpan apa adanya, shelf tidak disatukan
                commitRecord(shelf, code, qty, "STOCK_TAKE")
                return@setOnItemClickListener
            }
            val target = if (which == 0) shelf else groups[which - 1][0][1].trim()
            // Pindahkan semua data SKU ini dari shelf lain ke shelf pilihan.
            rowsAll.filter { it[4] == "STOCK_TAKE" && it[2].trim() == code.trim() &&
                !it[1].trim().equals(target, ignoreCase = true) }.forEach {
                db.updateDataCollect(it[0].toInt(), target, it[2], it[3]); it[1] = target
            }
            commitRecord(target, code, qty, "STOCK_TAKE")
            mergeDuplicateStockTake()
        }
        dlg.show()
    }

    private fun commitRecord(shelf: String, scanCode: String, qty: String, mode: String) {
        val addQty = qty.toIntOrNull() ?: 0
        var newRow = true
        var accumulatedNote: String? = null
        val newId: Long
        // ★ FIX (baru): Stock Take/Add Box — SKU yang sama di Shelf yang sama
        // otomatis DIAKUMULASI ke record yang sudah ada (qty ditambah). SKU berbeda
        // (atau SKU sama di Shelf lain) tetap jadi record TERPISAH.
        val existing = if (isQtyMode(mode) && dcSumMode)
            rowsAll.firstOrNull { it[4] == mode &&
                it[1].trim().equals(shelf.trim(), ignoreCase = true) && it[2].trim() == scanCode.trim() }
        else null
        if (existing != null) {
            val old = existing[3].toIntOrNull() ?: 0
            db.updateDataCollect(existing[0].toInt(), existing[1], existing[2], (old + addQty).toString())
            newId = existing[0].toLong()
            newRow = false
            accumulatedNote = "Qty $scanCode: $old + $addQty = ${old + addQty}"
        } else {
            newId = db.insertDataCollect(shelf, scanCode, qty, mode)
        }
        scanLog.add(ScanOp(mode, shelf, scanCode, addQty, newRow))
        redoStack.removeAll { it.mode == mode }
        etScanCode.setText("")
        etQty.setText("")
        hideSkuInfo()
        highlightId = newId.toString()
        etScanCode.postDelayed({ highlightId = ""; if (::adapter.isInitialized) adapter.notifyDataSetChanged() }, 1500)
        // ★ FIX: loadRecords() (refresh ListView) HARUS dijalankan SEBELUM requestFocus().
        loadRecords()
        if (isQtyMode(mode)) {
            stockTakeSaveCounter++
            if (accumulatedNote != null) Toast.makeText(this, accumulatedNote, Toast.LENGTH_SHORT).show()
            // ★ FIX (baru): HANYA Stock Take — langsung beri tahu kalau TOTAL scan SKU ini
            // tidak sesuai System. Add Box tidak dibandingkan dengan System (isi karton
            // memang dipindah ke Keep Stock).
            val mismatch = if (mode == "STOCK_TAKE") stockTakeWarning(scanCode, shelf) else null
            if (mismatch != null) { showMatchAlert(mismatch); beepError() } else beepOk()
            if (stockTakeSaveCounter % 10 == 0) autoBackupStockTake()
        }
        etScanCode.post { etScanCode.requestFocus() }
    }

    // ── Banner peringatan sesuai/tidak sesuai System ──────────────────────────
    /** SKU yang sama sudah ada di shelf LAIN (mode Stock Take) → "dobel shelf". */
    private fun duplicateShelfMessage(code: String, shelf: String): String? {
        val others = rowsAll.filter { it[4] == "STOCK_TAKE" && it[2].trim() == code.trim() &&
            !it[1].trim().equals(shelf.trim(), ignoreCase = true) }
        if (others.isEmpty()) return null
        val where = others.groupBy { it[1].trim().uppercase() }
            .entries.joinToString(", ") { e -> "${e.key} (${e.value.sumOf { it[3].toIntOrNull() ?: 0 }})" }
        return "⚠ DOBEL SHELF: $code juga ada di $where"
    }

    /** Gabungan peringatan Stock Take: selisih vs System + dobel shelf. null = tidak ada. */
    private fun stockTakeWarning(code: String, shelf: String): String? =
        listOfNotNull(matchMismatchMessage(code), duplicateShelfMessage(code, shelf))
            .takeIf { it.isNotEmpty() }?.joinToString("\n")

    private fun showMatchAlert(msg: String) { tvMatchAlert.text = msg; tvMatchAlert.visibility = View.VISIBLE }
    private fun hideMatchAlert() { tvMatchAlert.visibility = View.GONE }

    /** Total qty yang SUDAH di-scan untuk kode ini di SEMUA shelf (mode Stock Take). */
    private fun scannedTotal(code: String): Int =
        rowsAll.filter { it[4] == "STOCK_TAKE" && it[2].trim() == code.trim() }
            .sumOf { it[3].toIntOrNull() ?: 0 }

    /** Total scan SKU ini (semua shelf) dibanding System (katalog 02). Dianggap SESUAI kalau
     *  sama dengan System, atau sama dengan System − Keep Stock (stok yang di rak). Selisih
     *  satu saja (kurang/lebih) langsung dilaporkan. null = sesuai / tidak ada data pembanding. */
    private fun matchMismatchMessage(code: String): String? {
        val cat = db.findCatalogForComparison(code) ?: return null
        val sys = cat["balance"]?.replace(",", "")?.toDoubleOrNull() ?: return null
        val total = scannedTotal(code).toDouble()
        val ks = ksQtyFor(code, cat)
        if (total == sys) return null
        if (ks != null && ks > 0 && total == maxOf(sys - ks, 0.0)) return null
        val diff = total - sys
        val ket = if (diff < 0) "KURANG ${fmtQty(-diff)}" else "LEBIH ${fmtQty(diff)}"
        val ksNote = if (ks != null && ks > 0) "  |  Keep Stock ${fmtQty(ks)}" else ""
        return "⚠ $code: total scan ${fmtQty(total)} ≠ System ${fmtQty(sys)} ($ket)$ksNote"
    }

    private fun loadRecords() {
        rowsAll.clear()
        val c: Cursor = db.getAllDataCollect()
        c.use {
            while (it.moveToNext()) {
                rowsAll.add(arrayOf(
                    it.getInt(it.getColumnIndexOrThrow(AppDatabase.C_DC_ID)).toString(),
                    it.getString(it.getColumnIndexOrThrow(AppDatabase.C_DC_SHELF)) ?: "",
                    it.getString(it.getColumnIndexOrThrow(AppDatabase.C_DC_CODE)) ?: "",
                    it.getString(it.getColumnIndexOrThrow(AppDatabase.C_DC_QTY)) ?: "",
                    it.getString(it.getColumnIndexOrThrow(AppDatabase.C_DC_MODE)) ?: "",
                    it.getString(it.getColumnIndexOrThrow(AppDatabase.C_DC_TIME)) ?: "",
                    it.getInt(it.getColumnIndexOrThrow(AppDatabase.C_DC_UPLOADED)).toString()
                ))
            }
        }
        applyModeFilter()
    }

    /** ★ FIX (baru): saring `rowsAll` (semua data di DB) supaya yang tampil
     *  di layar cuma milik mode kerja yang sedang aktif — Shelf Record dan
     *  Stock Take/Add Box punya daftar record masing-masing, tidak digabung
     *  saat user pindah mode. Data mode lain TETAP ada di DB (tidak hilang),
     *  cuma disembunyikan dari tampilan sampai mode-nya diaktifkan lagi. */
    // ── Drag handle: ubah posisi data dengan menggeser ≡ ───────────────────────
    private var dragRec: Array<String>? = null
    private var dragOverPos = -1

    @Suppress("DEPRECATION")
    private fun startRowDrag(rowView: View, r: Array<String>) {
        if (searchQuery.isNotEmpty()) {
            Toast.makeText(this, "Tutup pencarian dulu sebelum memindah posisi", Toast.LENGTH_SHORT).show()
            return
        }
        dragRec = r; dragOverPos = -1
        val clip = android.content.ClipData.newPlainText("row", r[0])
        val shadow = View.DragShadowBuilder(rowView)
        if (android.os.Build.VERSION.SDK_INT >= 24) rowView.startDragAndDrop(clip, shadow, null, 0)
        else rowView.startDrag(clip, shadow, null, 0)
        adapter.notifyDataSetChanged()
    }

    private fun setupRowDrag() {
        lvRecords.setOnDragListener { _, ev ->
            when (ev.action) {
                android.view.DragEvent.ACTION_DRAG_STARTED -> dragRec != null
                android.view.DragEvent.ACTION_DRAG_LOCATION -> {
                    val p = lvRecords.pointToPosition(ev.x.toInt(), ev.y.toInt())
                    if (p >= 0 && p != dragOverPos) { dragOverPos = p; adapter.notifyDataSetChanged() }
                    // auto-scroll di dekat tepi atas/bawah daftar
                    val edge = 56 * resources.displayMetrics.density
                    val step = (22 * resources.displayMetrics.density).toInt()
                    if (ev.y < edge) lvRecords.scrollListBy(-step)
                    else if (ev.y > lvRecords.height - edge) lvRecords.scrollListBy(step)
                    true
                }
                android.view.DragEvent.ACTION_DROP -> {
                    val p = lvRecords.pointToPosition(ev.x.toInt(), ev.y.toInt()).let { if (it >= 0) it else dragOverPos }
                    finishRowDrag(p)
                    true
                }
                android.view.DragEvent.ACTION_DRAG_ENDED -> {
                    dragRec = null; dragOverPos = -1
                    adapter.notifyDataSetChanged()
                    true
                }
                else -> true
            }
        }
    }

    /** Lepas di baris `targetPos`: record yang digeser menempati posisi itu. Kalau shelf-nya
     *  berbeda dari baris tujuan, ditanya apakah shelf-nya ikut diubah. */
    private fun finishRowDrag(targetPos: Int) {
        val dragged = dragRec ?: return
        val target = viewRows.getOrNull(targetPos) ?: return
        if (target[0] == dragged[0]) return
        val order = rows.toMutableList()          // urutan tampilan (baru → lama)
        val from = order.indexOfFirst { it[0] == dragged[0] }
        val to = order.indexOfFirst { it[0] == target[0] }
        if (from < 0 || to < 0) return
        val mode = dcMode
        val item = order.removeAt(from)
        order.add(to, item)
        db.reorderDataCollect(mode, order.reversed().map { it[0].toInt() })   // lama → baru
        val draggedShelf = dragged[1]; val targetShelf = target[1]
        val draggedCode = dragged[2]
        loadRecords()
        val moved = rows.getOrNull(to)?.takeIf { it[2] == draggedCode }
        if (moved != null) {
            highlightId = moved[0]
            etScanCode.postDelayed({ highlightId = ""; if (::adapter.isInitialized) adapter.notifyDataSetChanged() }, 1500)
            if (!draggedShelf.trim().equals(targetShelf.trim(), ignoreCase = true)) {
                AlertDialog.Builder(this)
                    .setTitle("Ubah ${locLabelOf(mode)} juga?")
                    .setMessage("$draggedCode dipindah ke jajaran ${targetShelf.trim()}.\n${locLabelOf(mode)} sekarang: ${draggedShelf.trim()}\nUbah menjadi ${targetShelf.trim()}?")
                    .setPositiveButton("Ya, ubah") { _, _ ->
                        db.updateDataCollect(moved[0].toInt(), targetShelf.trim(), moved[2], moved[3])
                        loadRecords()
                        if (isQtyMode(mode)) mergeDuplicateStockTake()
                    }
                    .setNegativeButton("Tidak", null).show()
            }
        }
    }

    // ── Selisih per SKU vs System (untuk kolom di daftar) ─────────────────────
    private var totalByCode: Map<String, Int> = emptyMap()
    private val diffCache = HashMap<String, Double?>()

    private var skuRowCount: Map<String, Int> = emptyMap()

    private fun rebuildTotals() {
        skuRowCount = rowsAll.filter { it[4] == dcMode }.groupingBy { it[2].trim() }.eachCount()
        totalByCode = rowsAll.filter { it[4] == "STOCK_TAKE" }
            .groupBy { it[2].trim() }.mapValues { e -> e.value.sumOf { it[3].toIntOrNull() ?: 0 } }
        diffCache.clear()
        catCache.clear()
    }

    private val catCache = HashMap<String, Map<String, String>?>()
    private fun catOf(code: String): Map<String, String>? {
        val k = code.trim()
        if (catCache.containsKey(k)) return catCache[k]
        val c = db.findCatalogForComparison(k)
        catCache[k] = c
        return c
    }

    /** null = tidak ada pembanding (SKU tak ada di 02 / balance bukan angka);
     *  0.0 = sesuai (sama dengan System, atau System − Keep Stock); selain itu = total − System. */
    private fun diffFor(code: String): Double? {
        if (diffCache.containsKey(code)) return diffCache[code]
        val cat = catOf(code)
        val sys = cat?.get("balance")?.replace(",", "")?.toDoubleOrNull()
        val v: Double? = if (sys == null) null else {
            val total = (totalByCode[code.trim()] ?: 0).toDouble()
            val ks = ksQtyFor(code, cat)
            if (total == sys || (ks != null && ks > 0 && total == maxOf(sys - ks, 0.0))) 0.0 else total - sys
        }
        diffCache[code] = v
        return v
    }

    private fun applyModeFilter() {
        rebuildTotals()
        rows.clear()
        rows.addAll(rowsAll.filter { it[4] == dcMode })
        viewRows.clear()
        if (searchQuery.isEmpty()) viewRows.addAll(rows)
        else {
            val q = searchQuery.lowercase()
            viewRows.addAll(rows.filter { it[1].lowercase().contains(q) || it[2].lowercase().contains(q) || it[3].lowercase().contains(q) })
        }
        adapter.notifyDataSetChanged()
        updateSummary()
        val empty = viewRows.isEmpty()
        tvDcEmpty.visibility = if (empty && !enquireActive) View.VISIBLE else View.GONE
        lvRecords.visibility = if (empty || enquireActive) View.GONE else View.VISIBLE
    }

    /** ★ FIX (baru): tap record → dialog konfirmasi hapus. Setelah dihapus,
     *  list, nomor urut & total counter otomatis diperbarui tanpa refresh. */
    private fun confirmDeleteRecord(position: Int) {
        if (position !in viewRows.indices) return
        val r = viewRows[position]
        val summary = if (isQtyMode(r[4]) && r[3].isNotBlank())
            "${r[1]}, ${r[2]}, ${r[3]}" else "${r[1]}, ${r[2]}"
        AlertDialog.Builder(this)
            .setTitle("Delete this record?")
            .setMessage(summary)
            .setPositiveButton("Delete") { _, _ ->
                db.deleteDataCollect(r[0].toInt())
                loadRecords()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    /** ★ FIX (baru): dialog edit record (tekan & tahan). Qty hanya tampil di mode Stock Take. */
    private fun showEditRecordDialog(position: Int) {
        if (position !in viewRows.indices) return
        val r = viewRows[position]
        val isStockTake = isQtyMode(r[4])
        val pad = (20 * resources.displayMetrics.density).toInt()

        fun field(label: String, value: String, numeric: Boolean = false) = EditText(this).apply {
            hint = label
            setText(value)
            setSingleLine(true)
            if (numeric) inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setSelectAllOnFocus(true)
        }
        val etShelf = field(locLabelOf(r[4]), r[1])
        val etSku   = field("SKU", r[2])
        val etQty   = field("Qty", r[3], numeric = true)

        val box = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(pad, pad / 2, pad, 0)
            addView(etShelf); addView(etSku)
            if (isStockTake) addView(etQty)
        }

        AlertDialog.Builder(this)
            .setTitle("Edit record")
            .setView(box)
            .setPositiveButton("Save") { _, _ ->
                val shelf = etShelf.text.toString().trim()
                val sku   = etSku.text.toString().trim()
                val qty   = if (isStockTake) etQty.text.toString().trim() else ""
                if (shelf.isBlank() || sku.isBlank() || (isStockTake && qty.isBlank())) {
                    android.widget.Toast.makeText(this, "Shelf, SKU${if (isStockTake) ", Qty" else ""} must not be empty", android.widget.Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                db.updateDataCollect(r[0].toInt(), shelf, sku, qty)
                // array yang sama dipakai rows & rowsAll → cukup ubah di tempat
                r[1] = shelf; r[2] = sku; r[3] = qty; r[6] = "0"
                rebuildTotals()
                adapter.notifyDataSetChanged()
                updateSummary()
                // Edit bisa membuat SKU ganda di shelf yang sama → gabungkan (qty dijumlahkan).
                if (isStockTake) mergeDuplicateStockTake()
                // ★ FIX (baru): hasil edit pun dicek seperti saat scan — selisih Qty vs System
                // & dobel shelf langsung diberi peringatan (khusus Stock Take).
                if (r[4] == "STOCK_TAKE") {
                    val w = stockTakeWarning(sku, shelf)
                    if (w != null) { showMatchAlert(w); beepError() } else { hideMatchAlert(); beepOk() }
                }
            }
            .setNeutralButton("Pindah Posisi") { _, _ -> showMoveToGroupDialog(r) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ── Pindah posisi data / rapikan urutan ──────────────────────────────────
    /** Urutan kronologis (lama→baru) record mode aktif. rowsAll sudah urut baru→lama. */
    private fun chronological(mode: String): MutableList<Array<String>> =
        rowsAll.filter { it[4] == mode }.reversed().toMutableList()

    private fun afterReorder() {
        scanLog.removeAll { it.mode == dcMode }; redoStack.removeAll { it.mode == dcMode }
        loadRecords()
    }

    /** Pindahkan SATU record ke jajaran kelompok shelf pilihan (ditempatkan setelah record
     *  terakhir kelompok itu; Shelf record ikut diubah ke shelf kelompok tsb). */
    private fun showMoveToGroupDialog(r: Array<String>) {
        val mode = r[4]
        val asc = chronological(mode)
        val groupKeys = LinkedHashMap<String, Pair<String, Int>>()   // KEY -> (nama asli, jumlah)
        asc.filter { it !== r && it[0] != r[0] }.forEach {
            val k = it[1].trim().uppercase()
            val old = groupKeys[k]
            groupKeys[k] = (old?.first ?: it[1].trim()) to ((old?.second ?: 0) + 1)
        }
        if (groupKeys.isEmpty()) { Toast.makeText(this, "Tidak ada kelompok tujuan", Toast.LENGTH_SHORT).show(); return }
        val keys = groupKeys.keys.toList()
        val labels = keys.map { "${groupKeys.getValue(it).first}  (${groupKeys.getValue(it).second} record)" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Pindahkan ${r[2]} ke jajaran ${locLabelOf(mode)}:")
            .setItems(labels) { _, which ->
                val target = groupKeys.getValue(keys[which]).first
                db.updateDataCollect(r[0].toInt(), target, r[2], r[3])
                r[1] = target
                val order = chronological(mode).toMutableList()
                order.removeAll { it[0] == r[0] }
                val lastIdx = order.indexOfLast { it[1].trim().equals(target, ignoreCase = true) }
                order.add(if (lastIdx >= 0) lastIdx + 1 else order.size, r)
                db.reorderDataCollect(mode, order.map { it[0].toInt() })
                afterReorder()
                if (isQtyMode(mode)) mergeDuplicateStockTake()
                Toast.makeText(this, "${r[2]} dipindah ke $target", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Batal", null).show()
    }

    /** Rapikan: kelompokkan semua record per shelf (urutan kelompok = kemunculan pertama;
     *  urutan di dalam kelompok tetap). Mengatasi SKU yang terlewat & terscan di ujung. */
    private fun confirmGroupByShelf() {
        AlertDialog.Builder(this)
            .setTitle("Kelompokkan per ${locLabelOf(dcMode)}")
            .setMessage("Semua data ${modeLabelOf(dcMode)} disusun ulang per ${locLabelOf(dcMode)} (isi data tidak berubah). Lanjut?")
            .setPositiveButton("Susun") { _, _ ->
                val asc = chronological(dcMode)
                val ordered = LinkedHashMap<String, MutableList<Array<String>>>()
                asc.forEach { ordered.getOrPut(it[1].trim().uppercase()) { mutableListOf() }.add(it) }
                db.reorderDataCollect(dcMode, ordered.values.flatten().map { it[0].toInt() })
                afterReorder()
                Toast.makeText(this, "Data dikelompokkan (${ordered.size} ${locLabelOf(dcMode)})", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Batal", null).show()
    }

    private fun confirmClearAll() {
        if (rows.isEmpty()) return
        AlertDialog.Builder(this)
            .setTitle("Clear All")
            .setMessage("Delete all ${rows.size} ${modeLabelOf(dcMode)} record(s) in Data Collector? Both uploaded and not-yet-uploaded data will be deleted.")
            .setPositiveButton("Delete") { _, _ ->
                // ★ FIX: Clear All hanya menghapus record milik mode aktif
                // (Shelf Record / Stock Take/Add Box), bukan seluruh data.
                val idsToDelete = rowsAll.filter { it[4] == dcMode }.map { it[0] }
                idsToDelete.forEach { db.deleteDataCollect(it.toInt()) }
                scanLog.removeAll { it.mode == dcMode }; redoStack.removeAll { it.mode == dcMode }
                hideMatchAlert()
                loadRecords()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ── Upload to PC ─────────────────────────────────────────────────────
    private fun showUploadChoiceDialog() {
        if (rows.isEmpty()) {
            Toast.makeText(this, "No data to upload yet", Toast.LENGTH_SHORT).show()
            return
        }
        // ★ FIX (baru — tampilan pop-up disamakan dengan gambar acuan):
        // "Upload Selection" / "Do You Wan To Upload To Server Directly or
        // Save To Local?", tombol LOCAL (kiri/negative) & UPLOAD (kanan/positive).
        AlertDialog.Builder(this)
            .setTitle("Upload Selection")
            .setMessage("Do You Wan To Upload To Server Directly or Save To Local?")
            .setNegativeButton("LOCAL") { _, _ -> doUpload(toLocal = true) }
            .setPositiveButton("UPLOAD") { _, _ -> doUpload(toLocal = false) }
            .show()
    }

    /** ★ FIX (baru): bangun isi TXT sesuai mode aktif SAAT INI —
     *  Shelf Record → "Shelf,ScanCode" per baris (kolom Qty TIDAK ada);
     *  Stock Take   → "Shelf,ScanCode,Qty" per baris (Qty WAJIB ada).
     *  Tidak ada header, tidak ada baris kosong di akhir, pemisah koma,
     *  encoding UTF-8 (default String di Kotlin/JVM). */
    private fun buildTxtContent(): String {
        val mode = dcMode
        val sb = StringBuilder()
        // Urutan file mengikuti urutan scan (lama → baru), rows di memori
        // urut _id DESC (terbaru dulu) jadi dibalik dulu.
        val ordered = rows.asReversed()
        ordered.forEachIndexed { idx, r ->
            val shelf = r[1]; val code = r[2]; val qty = r[3]
            if (isQtyMode(mode)) {
                sb.append(shelf).append(",").append(code).append(",").append(qty.ifBlank { "0" })
            } else {
                sb.append(shelf).append(",").append(code)
            }
            if (idx != ordered.lastIndex) sb.append("\n")
        }
        return sb.toString()
    }

    private fun buildFileName(): String {
        val prefix = fileFormat.ifBlank { "YM" }
        // Store code segment: fixed per mode, not the user-entered Store Code.
        //  - Shelf Record   -> 05
        //  - Stock Take     -> 04 (juga dipakai untuk alur add box)
        val store = if (isQtyMode(dcMode)) "04" else "05"
        val fmt = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        return "${prefix}_${store}_$fmt.txt"
    }

    private fun doUpload(toLocal: Boolean) {
        val fileName = buildFileName()
        val content = buildTxtContent()
        val modeAtUpload = dcMode
        lifecycleScope.launch {
            try {
                val path = withContext(Dispatchers.IO) {
                    if (toLocal) OutputWriter.writeToLocalDirect(this@DataCollectorActivity, fileName, content)
                    else OutputWriter.writeToSmbDirect(this@DataCollectorActivity, fileName, content, OutputModule.DATA_COLLECTOR,
                        // ★ FIX (baru): setting menu (titik-3) & Setting global kosong → default
                        // Stock Take/Add Box = Seuic/04, Shelf Record = Seuic/05.
                        fallbackPath = if (modeAtUpload == "SHELF_RECORD") DEFAULT_SMB_SHELF_RECORD else DEFAULT_SMB_STOCK_TAKE)
                }
                // ★ FIX (baru): "Upload to PC (Data Local)" khusus mode Stock
                // Take — selain nulis file TXT lokal, data hasil scan JUGA
                // otomatis ditambahkan ke Keep Stock (Google Sheets), reuse
                // proses backend yang SAMA PERSIS dengan tombol Add di
                // Keep Stock → View & Edit Data (KeepStockGasClient.addRows).
                // Tidak berlaku untuk mode Shelf Record atau untuk pilihan
                // "Server Directly (Via SMB)".
                if (toLocal && modeAtUpload == "ADD_BOX") {
                    syncStockTakeToKeepStock(path)
                } else {
                    Toast.makeText(this@DataCollectorActivity, "Successfully saved: $path", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                AlertDialog.Builder(this@DataCollectorActivity)
                    .setTitle("Upload failed")
                    .setMessage(e.message ?: "Unknown error")
                    .setPositiveButton("OK", null).showSafely()
            }
        }
    }

    /**
     * ★ FIX (baru): kirim seluruh baris Stock Take (Shelf → No Ctn, Scan
     * Code → SKU, Qty → Qty) ke Keep Stock (GSheet) — dikelompokkan per
     * Shelf/No Ctn (persis seperti dialog Add: 1 No Ctn bisa punya beberapa
     * SKU sekaligus), lalu dipanggil lewat `KeepStockGasClient.addRows`
     * (fungsi backend YANG SAMA dipakai tombol Add — TIDAK ada endpoint/
     * struktur data baru). Toko yang dipakai = toko Keep Stock aktif
     * (`ksLastStore`, sama dengan sesi login Keep Stock terakhir).
     *
     * `localPath` bersifat opsional — dipakai HANYA untuk ditampilkan di
     * pesan toast/dialog kalau proses ini dipanggil sesudah simpan lokal.
     * Dipanggil sendiri (tanpa `localPath`) dari menu "UPLOAD TO KS" →
     * "Upload Data Gsheet", independen dari "Save to Local".
     */
    private suspend fun syncStockTakeToKeepStock(localPath: String? = null) {
        val prefix = if (localPath != null) "Successfully saved locally: $localPath\n" else ""
        if (ksWebAppUrl.isBlank()) {
            Toast.makeText(this,
                "$prefix(Keep Stock sync skipped — Web App URL is not set in the Keep Stock menu)",
                Toast.LENGTH_LONG).show()
            return
        }
        val stockTakeRows = rows.filter { it[4] == "ADD_BOX" }
        if (stockTakeRows.isEmpty()) {
            Toast.makeText(this, "${prefix}No Add Box data to sync yet", Toast.LENGTH_LONG).show()
            return
        }
        // Group per Shelf (No Ctn) → List<Pair<SKU, Qty>>, urutan scan asli dijaga.
        val grouped = LinkedHashMap<String, MutableList<Pair<String, String>>>()
        stockTakeRows.asReversed().forEach { r ->
            val noCtn = r[1]; val sku = r[2]; val qty = r[3].ifBlank { "1" }
            grouped.getOrPut(noCtn) { mutableListOf() }.add(sku to qty)
        }
        val store = ksLastStore.ifBlank { Prefs.KEEP_STOCK_STORES.first() }
        var successGroups = 0
        var failGroups = 0
        val errors = mutableListOf<String>()
        // ★ FIX (baru): SKU yang SUDAH ada di No Ctn yang sama di Keep Stock → qty-nya DITAMBAH ke baris
        // yang ada (updateRow), bukan jadi baris dobel. Sisanya tetap addRows seperti biasa.
        val ssid = exioSpreadsheetId(store); val gid = exioGid(store)
        val liveRows: List<KeepStockSheetReader.KsRow> = withContext(Dispatchers.IO) {
            if (ssid.isBlank() || gid.isBlank()) emptyList()
            else try { KeepStockSheetReader.fetchRows(ssid, gid) } catch (e: Exception) { emptyList() }
        }
        withContext(Dispatchers.IO) {
            for ((noCtn, itemsAll) in grouped) {
                try {
                    val toAdd = mutableListOf<Pair<String, String>>()
                    val merged = HashMap<Int, Pair<KeepStockSheetReader.KsRow, Double>>()   // rowNumber -> (baris, qty tambahan)
                    itemsAll.forEach { (sku, qty) ->
                        val hit = liveRows.firstOrNull { it.noCtn.trim().equals(noCtn.trim(), ignoreCase = true) && it.sku.trim() == sku.trim() }
                        if (hit == null) toAdd.add(sku to qty)
                        else {
                            val add = qty.toDoubleOrNull() ?: 0.0
                            val prev = merged[hit.rowNumber]
                            merged[hit.rowNumber] = hit to ((prev?.second ?: 0.0) + add)
                        }
                    }
                    merged.values.forEach { (hit, add) ->
                        val newQty = KeepStockAddGuard.qtyOf(hit) + add
                        KeepStockGasClient.updateRow(ksWebAppUrl, ksApiToken, store, hit.rowNumber, hit.noCtn, hit.sku, KeepStockAddGuard.fmt(newQty))
                    }
                    if (toAdd.isNotEmpty()) KeepStockGasClient.addRows(ksWebAppUrl, ksApiToken, store, noCtn, toAdd)
                    successGroups++
                } catch (e: Exception) {
                    failGroups++
                    errors.add("$noCtn: ${e.message}")
                }
            }
        }
        // data Keep Stock berubah → muat ulang cache validasi Add Box
        approvedCtns.clear(); skuDecided.clear()
        if (failGroups == 0) { db.markDataCollectUploadedByMode("ADD_BOX"); loadRecords() }
        loadKeepStockQty(force = true)
        // ★ FIX: notifikasi bahwa sinkronisasi Keep Stock berhasil (atau
        // sebagian gagal, supaya user tahu perlu retry lewat Keep Stock →
        // View & Edit Data → Add secara manual untuk grup yang gagal).
        if (failGroups == 0) {
            Toast.makeText(this,
                "$prefix$successGroups No Ctn successfully synced to Keep Stock (Google Sheets)",
                Toast.LENGTH_LONG).show()
        } else {
            AlertDialog.Builder(this)
                .setTitle("Keep Stock sync partially failed")
                .setMessage("$prefix\nSucceeded: $successGroups No Ctn\nFailed: $failGroups No Ctn\n\n${errors.joinToString("\n")}")
                .setPositiveButton("OK", null).showSafely()
        }
    }

    // ── UPLOAD TO KS (khusus Stock Take/Add Box) ───────────────────────────
    /** ★ FIX (baru): menu "UPLOAD TO KS" — "Save to Local" & "Upload Data
     *  Gsheet" sekarang dua tombol/aksi independen (tidak lagi otomatis
     *  bergandengan seperti sebelumnya). Hanya tersedia di mode Stock
     *  Take/Add Box. Tidak mengubah proses "Upload to PC" (SMB) yang lama. */
    private fun showUploadToKsDialog() {
        if (rows.isEmpty()) {
            Toast.makeText(this, "No Add Box data to upload yet", Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Upload to KS")
            .setItems(arrayOf("Save to Local", "Upload Data Gsheet")) { _, which ->
                if (which == 0) saveStockTakeToLocalOnly() else uploadStockTakeToGsheetOnly()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    /** ★ FIX (baru): simpan file TXT ke penyimpanan lokal HP SAJA, TIDAK
     *  memicu sinkronisasi ke Keep Stock (Google Sheets). Independen dari
     *  "Upload Data Gsheet". */
    private fun saveStockTakeToLocalOnly() {
        val fileName = buildFileName()
        val content = buildTxtContent()
        lifecycleScope.launch {
            try {
                val path = withContext(Dispatchers.IO) {
                    OutputWriter.writeToLocalDirect(this@DataCollectorActivity, fileName, content)
                }
                Toast.makeText(this@DataCollectorActivity, "Successfully saved: $path", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                AlertDialog.Builder(this@DataCollectorActivity)
                    .setTitle("Local save failed")
                    .setMessage(e.message ?: "Unknown error")
                    .setPositiveButton("OK", null).showSafely()
            }
        }
    }

    /** ★ FIX (baru): kirim data Stock Take/Add Box langsung ke Keep Stock
     *  (Google Sheets) SAJA, TIDAK menyimpan file TXT lokal. Independen
     *  dari "Save to Local". Reuse proses backend yang sama persis dengan
     *  tombol Add di Keep Stock (`KeepStockGasClient.addRows`). */
    private fun uploadStockTakeToGsheetOnly() {
        lifecycleScope.launch {
            syncStockTakeToKeepStock(localPath = null)
        }
    }

    // ── SMB Output Settings (khusus Data Collector, terpisah dari Setting global) ──
    private fun showSmbOutputSettingsDialog() {
        val container = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            val pad = (16 * resources.displayMetrics.density).toInt()
            setPadding(pad, 8, pad, 0)
        }
        val etPath = EditText(this).apply {
            setText(smbUploadPathDataCollector)
            hint = "smb://HOSTNAME/share/subfolder"
        }
        container.addView(etPath)
        AlertDialog.Builder(this)
            .setTitle("SMB Output Settings — Data Collector")
            .setMessage("File name format: <FileFormat>_<ModeCode>_<date>_<time>.txt (FileFormat diatur di menu Setting, ModeCode tetap: 05 Shelf Record / 04 Stock Take). Leave SMB folder empty to use the path from global Settings. If that is empty too, files go to smb://BACKEND/QasDev/QubeV10/BackEnd/Data/Seuic/04 (Stock Take / Add Box) or /05 (Shelf Record).")
            .setView(container)
            .setPositiveButton("Save") { _, _ ->
                smbUploadPathDataCollector = etPath.text.toString().trim()
                Toast.makeText(this, "Data Collector setting saved", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
