package com.tms.qubeapps.qubedatacollector

import android.content.Context
import android.graphics.Paint
import android.graphics.Typeface
import android.view.LayoutInflater
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/**
 * ★ FIX (baru): kartu RESULT Shelf Price Enquiry untuk dipakai di dalam Data Collector
 * (mode Shelf Price Enquiry). Aturan tampilannya SAMA dengan ShelfPriceEnquireActivity.showResult():
 * slot/label dari ResultLayoutPrefs, jumlah baris & skala font dari ColMappingPrefs/ResultLayoutPrefs,
 * Balance besar & merah, Price dicoret kalau Discount > 0 dan Discount End Date belum lewat.
 */
object ResultCardRenderer {

    private val discEndDateFormats = listOf("dd/MM/yyyy", "MM/dd/yyyy", "yyyy-MM-dd", "dd-MM-yyyy")

    private fun parseDiscEndDate(dateStr: String?): Long? {
        val s = dateStr?.trim().orEmpty()
        if (s.isEmpty() || s == "-") return null
        for (fmt in discEndDateFormats) {
            try {
                val sdf = SimpleDateFormat(fmt, Locale.US)
                sdf.isLenient = false
                return sdf.parse(s)?.time
            } catch (e: Exception) { continue }
        }
        return null
    }

    private fun isDiscountEndStillActive(discEndRaw: String?): Boolean {
        val endMillis = parseDiscEndDate(discEndRaw) ?: return false
        val startOfToday = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        return endMillis >= startOfToday
    }

    /** Isi [container] dengan baris-baris hasil untuk [data] (map hasil AppDatabase.findCatalog). */
    fun render(ctx: Context, container: LinearLayout, data: Map<String, String>) {
        val inflater = LayoutInflater.from(ctx)
        val allSlots = ResultLayoutPrefs.load(ctx)
        val rowCount = ColMappingPrefs.load(ctx).resultRowCount // 10 atau 5
        val slots = allSlots.take(rowCount)
        container.removeAllViews()

        val fontScale = ResultLayoutPrefs.fontPct(ctx) / 100f
        val rowPadPx = (ResultLayoutPrefs.rowPaddingDp(ResultLayoutPrefs.spacing(ctx)) *
            ctx.resources.displayMetrics.density).toInt()
        val labelSize = (if (rowCount <= 5) 15f else 13f) * fontScale
        val valueSize = (if (rowCount <= 5) 24f else 19f) * fontScale
        val balanceSize = (if (rowCount <= 5) 30f else 24f) * fontScale

        val discountValue = data["discount"]?.replace(",", "")?.trim()?.toDoubleOrNull() ?: 0.0
        val shouldStrikePrice = discountValue > 0.0 && isDiscountEndStillActive(data["discEnd"])

        slots.forEach { slot ->
            val row = inflater.inflate(R.layout.item_result_line, container, false)
            (row.findViewById<TextView>(R.id.tvFieldLabel).parent as View).setPadding(0, rowPadPx, 0, rowPadPx)
            row.findViewById<TextView>(R.id.tvFieldLabel).apply { text = slot.label; textSize = labelSize }
            val tvValue = row.findViewById<TextView>(R.id.tvFieldValue)
            tvValue.text = if (slot.fieldKey.isBlank()) "" else (data[slot.fieldKey] ?: "-")
            tvValue.textSize = valueSize
            when (slot.fieldKey) {
                "balance" -> {
                    tvValue.textSize = balanceSize
                    tvValue.setTextColor(0xFFE53935.toInt())
                    tvValue.setTypeface(tvValue.typeface, Typeface.BOLD)
                    tvValue.paintFlags = tvValue.paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()
                }
                "price" -> {
                    tvValue.setTextColor(0xFF000000.toInt())
                    tvValue.setTypeface(tvValue.typeface, Typeface.NORMAL)
                    tvValue.paintFlags = if (shouldStrikePrice) tvValue.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
                                         else tvValue.paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()
                }
                else -> {
                    tvValue.setTextColor(0xFF000000.toInt())
                    tvValue.setTypeface(tvValue.typeface, Typeface.BOLD)
                    tvValue.paintFlags = tvValue.paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()
                }
            }
            container.addView(row)
        }
    }
}
