# ── Atribut umum ──
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod,SourceFile,LineNumberTable

# ── Itemize: fungsi yang dipanggil dari JavaScript (window.AndroidItemize) HARUS tetap ada ──
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# ── BouncyCastle (dipakai smbj): algoritma didaftarkan lewat nama kelas (refleksi) ──
-keep class org.bouncycastle.jcajce.provider.** { *; }
-keep class org.bouncycastle.jce.provider.** { *; }
-dontwarn org.bouncycastle.**

# ── smbj + dependensinya (event bus mbassador memakai anotasi/refleksi) ──
-keep class com.hierynomus.** { *; }
-keep class net.engio.mbassy.** { *; }
-keep class com.rapid7.** { *; }
-dontwarn com.hierynomus.**
-dontwarn net.engio.mbassy.**
-dontwarn javax.el.**
-dontwarn org.ietf.jgss.**
-dontwarn javax.security.auth.**
-dontwarn org.slf4j.**
-dontwarn org.slf4j.impl.**

# ── jcifs-ng (hanya untuk resolusi nama NetBIOS) ──
-keep class jcifs.** { *; }
-dontwarn jcifs.**
-dontwarn org.apache.log4j.**

# ── jxl (.xls): logger dimuat lewat nama kelas (System.setProperty("logger", ...)) ──
-keep class jxl.common.** { *; }
-dontwarn jxl.**

# ── NanoHTTPD (server HTTP bawaan) ──
-keep class fi.iki.elonen.** { *; }
-dontwarn fi.iki.elonen.**

# ── Java 8+ API yang tidak ada di Android ──
-dontwarn java.lang.invoke.**
-dontwarn javax.annotation.**
