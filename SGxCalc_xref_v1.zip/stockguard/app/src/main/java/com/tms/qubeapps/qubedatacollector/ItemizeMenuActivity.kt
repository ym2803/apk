package com.tms.qubeapps.qubedatacollector

import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import com.tms.qubeapps.qubedatacollector.Prefs.itemizeApiUrl
import com.tms.qubeapps.qubedatacollector.Prefs.itemizeSheetUrl
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

/**
 * Menu "Itemize": pintu masuk ke aplikasi web Itemized (index.html + sw.js di assets/itemize)
 * + Setting Google Sheet (URL Web App Apps Script) + tutorial singkat membuat backend-nya
 * (Code.gs ada di assets/itemize/Code.gs.txt dan bisa disalin dengan satu tombol).
 */
class ItemizeMenuActivity : BaseActivity() {

    private lateinit var etUrl: EditText
    private lateinit var etSheetUrl: EditText
    private lateinit var tvStatus: TextView
    private lateinit var tvTest: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_itemize_menu)

        etUrl = findViewById(R.id.etItemizeUrl)
        tvStatus = findViewById(R.id.tvItemizeStatus)
        tvTest = findViewById(R.id.tvItemizeTest)
        etSheetUrl = findViewById(R.id.etItemizeSheetUrl)
        etUrl.setText(itemizeApiUrl)
        etSheetUrl.setText(itemizeSheetUrl)
        findViewById<TextView>(R.id.tvItemizeTutorial).text = TUTORIAL

        findViewById<android.view.View>(R.id.btnBackItemize).setOnClickListener { finish() }
        findViewById<android.view.View>(R.id.btnItemizeSave).setOnClickListener { save(true) }
        findViewById<android.view.View>(R.id.btnItemizeTest).setOnClickListener { testConnection() }
        findViewById<android.view.View>(R.id.btnOpenItemize).setOnClickListener {
            if (!save(false)) return@setOnClickListener
            startActivity(Intent(this, ItemizeWebActivity::class.java))
        }
        findViewById<android.view.View>(R.id.btnItemizeCopyCode).setOnClickListener { copyCode() }
        findViewById<android.view.View>(R.id.btnItemizeOpenSheets).setOnClickListener { openSavedSheet() }

        // Tutorial disembunyikan dulu; tampil hanya setelah "Buka Tutorial" ditekan.
        val tutorialBody = findViewById<android.view.View>(R.id.layoutItemizeTutorialBody)
        val btnToggle = findViewById<TextView>(R.id.btnItemizeToggleTutorial)
        btnToggle.setOnClickListener {
            val show = tutorialBody.visibility != android.view.View.VISIBLE
            tutorialBody.visibility = if (show) android.view.View.VISIBLE else android.view.View.GONE
            btnToggle.text = if (show) "Tutup Tutorial" else "Buka Tutorial"
        }
        refreshStatus()
    }

    private fun refreshStatus() {
        tvStatus.text = if (itemizeApiUrl.isBlank())
            "Google Sheet belum diatur. Ikuti tutorial di bawah, lalu tempel URL Web App."
        else if (itemizeSheetUrl.isBlank()) "URL Web App sudah diatur. Tempel juga Link Google Sheet agar tombol Open Google Sheet bisa dipakai."
        else "Google Sheet sudah diatur."
    }

    /** Validasi + simpan URL. Mengembalikan true bila URL valid. */
    private fun save(toast: Boolean): Boolean {
        val u = etUrl.text.toString().trim()
        if (u.isEmpty()) {
            Toast.makeText(this, "Isi URL Web App dulu (lihat tutorial)", Toast.LENGTH_LONG).show()
            return false
        }
        if (!u.startsWith("https://script.google.com/") || !u.endsWith("/exec")) {
            Toast.makeText(this, "URL harus diawali https://script.google.com/ dan berakhiran /exec", Toast.LENGTH_LONG).show()
            return false
        }
        val sheet = etSheetUrl.text.toString().trim()
        if (sheet.isNotEmpty() && !sheet.startsWith("https://docs.google.com/spreadsheets/")) {
            Toast.makeText(this, "Link Google Sheet harus diawali https://docs.google.com/spreadsheets/", Toast.LENGTH_LONG).show()
            return false
        }
        itemizeApiUrl = u
        itemizeSheetUrl = sheet
        refreshStatus()
        if (toast) Toast.makeText(this, "URL tersimpan", Toast.LENGTH_SHORT).show()
        return true
    }

    /** Buka Google Sheet yang link-nya sudah ditempel di Setting Google Sheet
     *  (TIDAK membuat Google Sheet baru). */
    private fun openSavedSheet() {
        val link = etSheetUrl.text.toString().trim().ifEmpty { itemizeSheetUrl }
        if (link.isEmpty()) {
            Toast.makeText(this, "Tempel dulu Link Google Sheet di Setting Google Sheet, lalu Save", Toast.LENGTH_LONG).show()
            return
        }
        if (!link.startsWith("https://docs.google.com/spreadsheets/")) {
            Toast.makeText(this, "Link Google Sheet harus diawali https://docs.google.com/spreadsheets/", Toast.LENGTH_LONG).show()
            return
        }
        runCatching { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(link))) }
            .onFailure { Toast.makeText(this, "Tidak bisa membuka link Google Sheet", Toast.LENGTH_LONG).show() }
    }

    private fun testConnection() {
        if (!save(false)) return
        val url = itemizeApiUrl
        tvTest.visibility = android.view.View.VISIBLE
        tvTest.setTextColor(0xFF4A5B6C.toInt()); tvTest.text = "Menguji koneksi…"
        lifecycleScope.launch(Safe.handler) {
            val res = withContext(Dispatchers.IO) {
                runCatching {
                    val c = URL(url).openConnection() as HttpURLConnection
                    c.connectTimeout = 15000; c.readTimeout = 20000; c.instanceFollowRedirects = true
                    val body = c.inputStream.bufferedReader().use { it.readText() }
                    c.disconnect(); body
                }
            }
            val body = res.getOrNull()
            if (body != null && body.contains("\"ok\":true")) {
                tvTest.setTextColor(0xFF1B7F52.toInt()); tvTest.text = "✓ Terhubung. Backend Itemized aktif."
            } else {
                tvTest.setTextColor(0xFFB8322A.toInt())
                tvTest.text = "✗ Gagal. " + (res.exceptionOrNull()?.message
                    ?: "Respons bukan dari Itemized. Pastikan Deploy sebagai Web app dengan akses \"Anyone\".")
            }
        }
    }

    private fun copyCode() {
        val code = runCatching { assets.open("itemize/Code.gs.txt").bufferedReader().use { it.readText() } }.getOrNull()
        if (code == null) { Toast.makeText(this, "Code.gs tidak ditemukan di aplikasi", Toast.LENGTH_LONG).show(); return }
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
            .setPrimaryClip(ClipData.newPlainText("Code.gs", code))
        AlertDialog.Builder(this)
            .setTitle("Code.gs disalin")
            .setMessage("Buka Apps Script di Google Sheet Anda, hapus isi file Code.gs, lalu tempel (paste).")
            .setPositiveButton("OK", null).show()
    }

    companion object {
        private val TUTORIAL = """
1. Buat Google Sheet baru lewat browser/aplikasi Google Sheets (buka sheets.new, pilih Blank). Beri nama bebas, misal "Itemized". Salin link Google Sheet tersebut (dari address bar atau Share > Copy link).

2. Di Google Sheet: menu Extensions > Apps Script. Hapus semua isi file Code.gs.

3. Tekan tombol "Copy Code.gs" di bawah, lalu tempel (paste) ke editor Apps Script. Tekan ikon Save.

4. Pilih fungsi setupSheets di daftar fungsi, tekan Run. Izinkan akses saat diminta (Advanced > Go to project > Allow). Sheet users, master, sesi, scan_log akan dibuat otomatis.

5. Buka sheet "users". Ganti PIN contoh (Admin 1234, Petugas 1111) dengan PIN Anda sendiri.

6. Tekan Deploy > New deployment > ikon roda gigi > Web app.
   • Execute as: Me
   • Who has access: Anyone
   Tekan Deploy, lalu salin Web app URL (berakhiran /exec).

7. Tempel URL itu di kolom "URL Web App" pada Setting Google Sheet di atas, tempel juga link Google Sheet dari langkah 1 di kolom "Link Google Sheet", tekan Save, lalu Test connection sampai muncul tanda ✓. Tombol "Open Google Sheet" akan membuka link tersebut (tidak membuat Google Sheet baru).

8. Tekan "Open Itemize", masuk dengan PIN admin, buka tab Admin untuk membuat sesi dan upload data system.

Catatan: setiap kali Code.gs diubah, lakukan Deploy > Manage deployments > ikon pensil > Version: New version > Deploy. URL tetap sama.
""".trimIndent()
    }
}
