package com.tms.qubeapps.qubedatacollector

import android.app.AlertDialog
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.view.WindowManager
import android.webkit.WebView
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.coroutines.resume

/**
 * ★ X-Ref (tahap 1) — padanan Android dari xref.py, tab "Ambil Ref":
 *   1. Buka & Login  2. Pindai Ref No  3. Ambil SKU dari Ref terpilih  + Auto (1→2→pilih→3).
 * Data masuk ke cache lokal (XRef.loadCache/saveCache). Tahap berikutnya: tab Data SKU, Excel, Stock Enquiry, Google Sheet.
 */
class XRefActivity : BaseActivity() {

    private lateinit var browser: XRefBrowser
    private lateinit var s: XRefSettings
    private var cache = mutableListOf<JSONObject>()
    private var items: List<XRef.RefItem> = emptyList()
    private var listWv: WebView? = null
    private var listUrl = ""
    private var opened = false
    private var job: Job? = null
    private var showBrowser = false

    private lateinit var tvLog: TextView
    private lateinit var logScroll: ScrollView
    private lateinit var tvStatus: TextView
    private lateinit var prog: ProgressBar
    private lateinit var btnView: Button
    private val actionButtons = ArrayList<Button>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_xref)
        s = XRefSettings.load(this)
        cache = XRef.loadCache(this)

        tvLog = findViewById(R.id.tvXLog)
        logScroll = findViewById(R.id.xrLogScroll)
        tvStatus = findViewById(R.id.tvXStatus)
        prog = findViewById(R.id.xrProg)
        btnView = findViewById(R.id.btnXView)
        browser = XRefBrowser(this, findViewById<FrameLayout>(R.id.xrWebHost)) { appendLog(it) }

        findViewById<View>(R.id.btnXBack).setOnClickListener { finish() }
        findViewById<View>(R.id.btnXSettings).setOnClickListener { showSettings() }
        listOf(R.id.btnXOpen, R.id.btnXScan, R.id.btnXFetch, R.id.btnXAuto).forEach { actionButtons.add(findViewById(it)) }

        findViewById<View>(R.id.btnXOpen).setOnClickListener { runJob { doOpen() } }
        findViewById<View>(R.id.btnXScan).setOnClickListener { runJob { doScan() } }
        findViewById<View>(R.id.btnXFetch).setOnClickListener { runJob { cmdFetch() } }
        findViewById<View>(R.id.btnXAuto).setOnClickListener { runJob { cmdAuto() } }
        findViewById<View>(R.id.btnXStop).setOnClickListener {
            if (job?.isActive == true) job?.cancel() else Toast.makeText(this, "Tidak ada proses berjalan", Toast.LENGTH_SHORT).show()
        }
        btnView.setOnClickListener { setBrowserVisible(!showBrowser) }
        findViewById<View>(R.id.btnXCsv).setOnClickListener {
            if (cache.isEmpty()) Toast.makeText(this, "Cache masih kosong", Toast.LENGTH_SHORT).show()
            else ShareHelper.shareTextAsFile(this, "data_sku_" + SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date()) + ".csv",
                XRef.toCsv(cache), "Bagikan Data SKU")
        }
        findViewById<View>(R.id.btnXClear).setOnClickListener {
            AlertDialog.Builder(this).setTitle("Hapus cache SKU?")
                .setMessage("${cache.size} baris data SKU di HP ini akan dihapus. Data di situs ERP tidak terpengaruh.")
                .setPositiveButton("Hapus") { _, _ -> cache.clear(); XRef.clearCache(this); refreshStatus(); appendLog("Cache dihapus.") }
                .setNegativeButton("Batal", null).show()
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (showBrowser && browser.main.canGoBack()) browser.main.goBack()
                else { isEnabled = false; onBackPressedDispatcher.onBackPressed() }
            }
        })

        setBrowserVisible(false)
        refreshStatus()
        appendLog("X-Ref siap. Isi Pengaturan (login & filter) lalu tekan Auto ▶, atau jalankan langkah 1 → 2 → 3.")
    }

    override fun onDestroy() {
        job?.cancel()
        browser.destroy()
        super.onDestroy()
    }

    // ── UI helper ────────────────────────────────────────────────────────
    private fun appendLog(m: String) {
        val t = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        tvLog.append("$t  $m\n")
        if (tvLog.length() > 24000) tvLog.text = tvLog.text.toString().takeLast(16000)
        logScroll.post { logScroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun setBrowserVisible(v: Boolean) {
        showBrowser = v
        logScroll.visibility = if (v) View.INVISIBLE else View.VISIBLE
        btnView.text = if (v) "Log" else "Browser"
    }

    private fun setBusy(on: Boolean) {
        actionButtons.forEach { it.isEnabled = !on }
        if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun setProgress(n: Int, total: Int) {
        prog.max = if (total > 0) total else 1
        prog.progress = n
    }

    private fun refreshStatus() {
        val refs = cache.map { XRef.refOf(it.optString("Label")) }.toSet().size
        tvStatus.text = "Ref di daftar: ${items.size} (baru ${items.count { !it.cached }})  ·  Cache: ${cache.size} SKU dari $refs Ref"
    }

    private fun runJob(block: suspend () -> Unit) {
        if (job?.isActive == true) { Toast.makeText(this, "Proses masih berjalan", Toast.LENGTH_SHORT).show(); return }
        setBusy(true)
        job = lifecycleScope.launch(Safe.handler) {
            try {
                block()
            } catch (e: CancellationException) {
                appendLog("Dihentikan.")
                throw e
            } catch (e: Exception) {
                appendLog("ERROR: ${e.javaClass.simpleName}: ${e.message}")
            } finally {
                setBusy(false)
                refreshStatus()
            }
        }
    }

    // ── langkah 1: buka + login ──────────────────────────────────────────
    private suspend fun doOpen() {
        val hasCred = s.userId.isNotBlank() && s.password.isNotBlank()
        if (opened) {
            if (hasCred && browser.loginFormVisible() && browser.login(s)) { appendLog("Login otomatis dikirim."); delay(3000) }
            else appendLog("Browser sudah terbuka.")
            return
        }
        opened = true
        appendLog("Membuka ${XRef.LOGIN_URL}")
        browser.open(browser.main, XRef.LOGIN_URL)
        delay(2500)
        if (hasCred) {
            if (browser.login(s)) {
                appendLog("Login otomatis dikirim.")
                delay(3000)
                if (browser.loginFormVisible()) appendLog("Peringatan: form login masih tampil, cek Store Code / User ID / Password (atau login manual lewat tombol Browser).")
            } else appendLog("Form login tidak terlihat (mungkin sudah login).")
        } else appendLog("Data login belum lengkap. Isi di Pengaturan, atau login manual lewat tombol Browser.")
    }

    // ── langkah 2: filter + pindai daftar Ref No ─────────────────────────
    private suspend fun doScan(): Boolean {
        if (!opened) { appendLog("Buka browser dulu (tombol 1)."); return false }
        if (s.listUrl.isNotBlank()) { browser.open(browser.main, s.listUrl); delay(2000) }
        val wv: WebView?
        if (s.autoFilter) {
            appendLog("Mengisi filter...")
            val order = listOf(
                Triple("txtType", "Report Type", s.reportType), Triple("txtStartDate", "Start Date", s.startDate),
                Triple("txtEndDate", "End Date", s.endDate), Triple("txtStatus", "Status", s.status),
                Triple("txttransit", "Transit", s.transit))
            for ((id, name, v) in order) {
                val msg = try { browser.fillField(id, name, v) }
                catch (e: CancellationException) { throw e }
                catch (e: Exception) { "  gagal isi $name: ${(e.message ?: "").take(100)}" }
                if (msg != null) appendLog(msg)
                if (id == "txtType" && v.isNotBlank()) delay(2000)   // perubahan Report Type memicu pemuatan ulang pilihan lain
            }
            if (!browser.clickSearch()) appendLog("  (tombol Search tidak ditemukan)")
            else { appendLog("Search diklik, menunggu hasil..."); delay(3000) }
            wv = browser.findList(40)
        } else wv = browser.findList(5)

        if (wv == null) {
            appendLog("Daftar Ref No tidak ditemukan. Ringkasan halaman:")
            browser.diagnose()
            appendLog("Buka halaman daftar manual lewat tombol Browser, lalu tekan 2 lagi (matikan 'Isi filter otomatis' di Pengaturan bila filter sudah diisi manual).")
            return false
        }
        listWv = wv
        listUrl = wv.url ?: ""
        appendLog("Memindai semua halaman daftar...")
        val found = browser.scanAll(wv)
        val done = cache.map { XRef.refOf(it.optString("Label")) }.toSet()
        found.forEach { it.cached = it.ref in done }
        items = found
        val total = found.sumOf { it.sku.replace(Regex("\\D"), "").toIntOrNull() ?: 0 }
        appendLog("Ditemukan ${found.size} Ref No, total SKU sekitar $total.")
        refreshStatus()
        return true
    }

    // ── langkah 3: ambil detail SKU ──────────────────────────────────────
    private suspend fun cmdFetch() {
        if (items.isEmpty()) { appendLog("Belum ada daftar Ref. Pindai dulu (tombol 2)."); return }
        val targets = pickTargets() ?: run { appendLog("Dibatalkan oleh user."); return }
        if (targets.isEmpty()) { appendLog("Tidak ada Ref No baru untuk diambil."); return }
        doFetch(targets)
    }

    private suspend fun cmdAuto() {
        doOpen()
        if (!doScan()) return
        val targets = pickTargets() ?: run { appendLog("Dibatalkan oleh user."); return }
        if (targets.isEmpty()) { appendLog("Tidak ada Ref No baru untuk diambil."); return }
        appendLog("Mode otomatis: mengambil ${targets.size} Ref No (${s.autoPick}).")
        doFetch(targets)
    }

    private suspend fun pickTargets(): List<XRef.RefItem>? {
        if (!s.confirmPick) return if (s.autoPick == "semua") items else items.filter { !it.cached }
        appendLog("Pilih Ref No yang diambil, lalu tekan Lanjutkan.")
        return chooseRefs(items, s.autoPick)
    }

    private suspend fun chooseRefs(list: List<XRef.RefItem>, pick: String): List<XRef.RefItem>? =
        suspendCancellableCoroutine { c ->
            val checked = BooleanArray(list.size) { if (pick == "semua") true else !list[it].cached }
            val labels = Array(list.size) { i ->
                val t = list[i]
                (if (t.cached) "✓ " else "") + "${t.ref}  ·  ${t.remark}  ·  ${t.created}  ·  ${t.sku} SKU"
            }
            val dlg = AlertDialog.Builder(this)
                .setTitle("Pilih Ref No (${list.size})  ✓ = sudah ada di cache")
                .setMultiChoiceItems(labels, checked) { _, i, v -> checked[i] = v }
                .setPositiveButton("Lanjutkan") { _, _ -> if (c.isActive) c.resume(list.filterIndexed { i, _ -> checked[i] }) }
                .setNegativeButton("Batal") { _, _ -> if (c.isActive) c.resume(null) }
                .setOnCancelListener { if (c.isActive) c.resume(null) }
                .create()
            dlg.show()
            c.invokeOnCancellation { dlg.dismiss() }
        }

    private suspend fun doFetch(targets: List<XRef.RefItem>) {
        var lw = listWv ?: run { appendLog("Pindai dulu (tombol 2)."); return }
        setProgress(0, targets.size)
        for ((i, t) in targets.withIndex()) {
            val n = i + 1
            val label = "${t.ref} | ${t.remark}"
            val before = browser.snapshot()
            try {
                val w = browser.ensureList(lw, listUrl)
                if (w == null) { appendLog("Daftar tidak bisa dibuka lagi, berhenti."); break }
                lw = w; listWv = w
                browser.goPage(w, t.page)
                if (!browser.openRef(w, t.ref)) throw IllegalStateException("baris ${t.ref} tidak ditemukan di halaman ${t.page}")
                val rows = browser.grabPage(label, 20)
                val (add, old) = XRef.merge(cache, rows)
                appendLog("[$n/${targets.size}] ${if (rows.isNotEmpty()) "OK    " else "KOSONG"} ${t.ref} (${t.remark}): $add SKU disimpan" +
                        (if (old > 0) ", $old data lama diganti" else ""))
                XRef.saveCache(this, cache)
                browser.closeExtras(before, lw)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                appendLog("[$n/${targets.size}] GAGAL  ${t.ref}: ${e.javaClass.simpleName}: ${(e.message ?: "").take(100)}")
                try { browser.closeExtras(before, lw) } catch (e2: Exception) { }
            }
            setProgress(n, targets.size)
            refreshStatus()
        }
        XRef.saveCache(this, cache)
        appendLog("Selesai. ${cache.size} baris tersimpan di cache. Gunakan 'Bagikan CSV' untuk mengekspor.")
    }

    // ── pengaturan ───────────────────────────────────────────────────────
    private fun showSettings() {
        val pad = (16 * resources.displayMetrics.density).toInt()
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad / 2, pad, 0) }
        fun field(label: String, value: String, pw: Boolean = false, hintText: String = ""): EditText {
            box.addView(TextView(this).apply { text = label; textSize = 12f; setPadding(0, pad / 2, 0, 0) })
            val e = EditText(this).apply {
                setText(value); setSingleLine(true); hint = hintText
                if (pw) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            }
            box.addView(e)
            return e
        }
        fun check(text: String, v: Boolean): CheckBox {
            val c = CheckBox(this).apply { this.text = text; isChecked = v }
            box.addView(c)
            return c
        }
        val eStore = field("Store Code", s.storeCode)
        val eUser = field("User ID", s.userId)
        val ePass = field("Password (disimpan terenkripsi)", s.password, pw = true)
        val eUrl = field("URL halaman daftar Ref (opsional)", s.listUrl, hintText = "https://iderp.mrdiy.com/...")
        val cFilter = check("Isi filter otomatis", s.autoFilter)
        val eType = field("Report Type", s.reportType, hintText = "mis. Internal Billing")
        val eStart = field("Start Date", s.startDate, hintText = "today atau dd-mm-yyyy")
        val eEnd = field("End Date", s.endDate, hintText = "today atau dd-mm-yyyy")
        val eStatus = field("Status", s.status, hintText = "H / P / T")
        val eTransit = field("Transit", s.transit, hintText = "T / Without T")
        val cAll = check("Ambil semua Ref (bukan hanya yang belum ada di cache)", s.autoPick == "semua")
        val cConfirm = check("Konfirmasi pilihan Ref sebelum mengambil", s.confirmPick)
        val sv = ScrollView(this).apply { addView(box) }
        AlertDialog.Builder(this).setTitle("Pengaturan X-Ref").setView(sv)
            .setPositiveButton("Simpan") { _, _ ->
                s.storeCode = eStore.text.toString().trim(); s.userId = eUser.text.toString().trim()
                s.password = ePass.text.toString(); s.listUrl = eUrl.text.toString().trim()
                s.autoFilter = cFilter.isChecked
                s.reportType = eType.text.toString().trim(); s.startDate = eStart.text.toString().trim()
                s.endDate = eEnd.text.toString().trim(); s.status = eStatus.text.toString().trim()
                s.transit = eTransit.text.toString().trim()
                s.autoPick = if (cAll.isChecked) "semua" else "baru"
                s.confirmPick = cConfirm.isChecked
                s.save(this)
                Toast.makeText(this, "Pengaturan disimpan", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Batal", null).show()
    }
}
