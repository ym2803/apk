package com.tms.qubeapps.qubedatacollector

/**
 * ★ TxtClean — merapikan output .txt (format CSV sederhana, pemisah koma).
 *
 * Spasi / tab / enter di ujung (atau awal) tiap kolom dibuang, contoh:
 *   "A001 ,1234567 ,12"  →  "A001,1234567,12"
 * Spasi di TENGAH isi kolom (mis. nama barang) tidak diubah.
 * Gaya akhir baris (\n atau \r\n) dan jumlah baris dipertahankan; kolom kosong tetap
 * ada (",SKU" tetap ",SKU").
 */
object TxtClean {

    /** Bersihkan SATU nilai kolom: buang spasi/tab/enter di ujung; tab/enter yang
     *  nyangkut di tengah diganti satu spasi supaya tidak memecah baris/kolom. */
    fun field(s: String?): String =
        (s ?: "").replace(Regex("[\\r\\n\\t]+"), " ").trim()

    /** Bersihkan SELURUH isi file: tiap baris dipecah per koma, tiap kolom di-trim. */
    fun content(text: String): String {
        if (text.isEmpty()) return text
        val eol = if (text.contains("\r\n")) "\r\n" else "\n"
        return text.split(Regex("\r\n|\n|\r")).joinToString(eol) { line ->
            if (line.isEmpty()) line else line.split(',').joinToString(",") { it.trim() }
        }
    }
}
