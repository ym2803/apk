package com.tms.qubeapps.qubedatacollector

import android.content.Context
import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.annotation.RequiresApi
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.KeyStore
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.spec.GCMParameterSpec

/**
 * ★ X-Ref (tahap 1) — padanan Android untuk xref.py (X-Ref by YM): data, cache, pengaturan.
 * Logika merge/cache sengaja SAMA dengan versi Python (kunci JSON sama: "Label", "Plucode", "Stock Pack", dst.)
 * sehingga file sku_cache.json dari PC bisa dipakai bersama.
 */
object XRef {
    const val LOGIN_URL = "https://iderp.mrdiy.com/Default.aspx?country=id_diy"
    val COLS = listOf("Label", "Plucode", "Desc", "Stock Pack", "Barcode", "Link Code", "PLU Link ID", "Unit Cost", "Qty")

    /** atribut data-cell di grid situs -> nama kolom */
    val FIELDS = linkedMapOf(
        "Plucode" to "Plucode", "Desc" to "Desc", "M_STOCKPACK" to "Stock Pack",
        "Barcode" to "Barcode", "M_LINKCODE" to "Link Code", "M_PLULINKID" to "PLU Link ID",
        "M_UNITCOST" to "Unit Cost", "Qty" to "Qty"
    )

    data class RefItem(val ref: String, val created: String, val remark: String, val sku: String,
                       var page: Int = 1, var cached: Boolean = false)

    fun toFloat(v: Any?): Double = v?.toString()?.replace(",", "")?.trim()?.toDoubleOrNull() ?: 0.0

    /** Label 'RefNo | remark' -> 'RefNo' */
    fun refOf(label: String): String = label.split("|")[0].trim()

    /** Tanggal di situs berformat dd-mm-yyyy. 'today' = hari ini; 01/10/2026 otomatis jadi 01-10-2026. */
    fun resolveDate(v: String): String {
        val t = v.trim()
        if (t.equals("today", true) || t.equals("hari ini", true))
            return SimpleDateFormat("dd-MM-yyyy", Locale.US).format(Date())
        return t.replace(Regex("^(\\d{1,2})/(\\d{1,2})/(\\d{4})$"), "\$1-\$2-\$3")
    }

    // ── cache ────────────────────────────────────────────────────────────
    private fun cacheFile(ctx: Context) = File(ctx.filesDir, "xref_sku_cache.json")
    private fun backupFile(ctx: Context) = File(ctx.filesDir, "xref_sku_cache.backup.json")

    fun loadCache(ctx: Context): MutableList<JSONObject> {
        for (f in listOf(cacheFile(ctx), backupFile(ctx))) {
            if (!f.exists()) continue
            try {
                val a = JSONArray(f.readText(Charsets.UTF_8))
                return MutableList(a.length()) { a.getJSONObject(it) }
            } catch (e: Exception) { /* rusak: coba cadangan */ }
        }
        return mutableListOf()
    }

    fun saveCache(ctx: Context, cache: List<JSONObject>) {
        val arr = JSONArray()
        cache.forEach { arr.put(it) }
        val tmp = File(ctx.filesDir, "xref_sku_cache.tmp")
        tmp.writeText(arr.toString(), Charsets.UTF_8)
        val f = cacheFile(ctx)
        if (f.exists()) f.copyTo(backupFile(ctx), overwrite = true)
        tmp.copyTo(f, overwrite = true)
        tmp.delete()
    }

    fun clearCache(ctx: Context) { cacheFile(ctx).delete(); backupFile(ctx).delete() }

    /** Ref No yang diproses ulang: data SKU lama milik Ref itu diganti data baru. Return (SKU baru disimpan, baris lama dihapus). */
    fun merge(cache: MutableList<JSONObject>, rows: List<JSONObject>): Pair<Int, Int> {
        if (rows.isEmpty()) return Pair(0, 0)           // hasil kosong: data lama jangan dihapus
        val refs = rows.map { refOf(it.optString("Label")) }.toSet()
        val keep = cache.filter { refOf(it.optString("Label")) !in refs }
        val removed = cache.size - keep.size
        val fresh = ArrayList<JSONObject>()
        val pos = HashMap<String, Int>()
        for (r in rows) {                                // satu Plucode satu baris per Ref (yang terakhir menang)
            val k = r.optString("Plucode")
            val i = pos[k]
            if (i != null) fresh[i] = r else { pos[k] = fresh.size; fresh.add(r) }
        }
        cache.clear(); cache.addAll(keep); cache.addAll(fresh)
        return Pair(fresh.size, removed)
    }

    /** CSV: kolom asli + Total Cost (Unit Cost x Qty) + Sum (total Qty untuk Plucode yang sama di semua Ref). */
    fun toCsv(cache: List<JSONObject>): String {
        val tot = HashMap<String, Double>()
        cache.forEach { tot[it.optString("Plucode").trim()] = (tot[it.optString("Plucode").trim()] ?: 0.0) + toFloat(it.opt("Qty")) }
        fun q(s: String) = "\"" + s.replace("\"", "\"\"") + "\""
        fun n(d: Double) = if (d == Math.floor(d) && Math.abs(d) < 1e15) d.toLong().toString() else d.toString()
        val sb = StringBuilder()
        sb.append((COLS + listOf("Total Cost", "Sum")).joinToString(",") { q(it) }).append("\n")
        for (r in cache) {
            val k = r.optString("Plucode").trim()
            val cells = COLS.map { c ->
                if (c == "Unit Cost" || c == "Qty") n(toFloat(r.opt(c))) else q(r.optString(c))
            }
            val total = toFloat(r.opt("Unit Cost")) * toFloat(r.opt("Qty"))
            val sum = if (k.isNotEmpty()) tot[k] ?: 0.0 else toFloat(r.opt("Qty"))
            sb.append((cells + listOf(n(Math.round(total * 10000) / 10000.0), n(Math.round(sum * 10000) / 10000.0))).joinToString(",")).append("\n")
        }
        return sb.toString()
    }
}

/** Pengaturan X-Ref. Password disimpan terenkripsi (Android Keystore, API 23+). */
class XRefSettings(
    var storeCode: String = "", var userId: String = "", var password: String = "",
    var listUrl: String = "",
    var autoFilter: Boolean = true,
    var reportType: String = "", var startDate: String = "", var endDate: String = "",
    var status: String = "", var transit: String = "",
    var autoPick: String = "baru",        // "baru" | "semua"
    var confirmPick: Boolean = true
) {
    companion object {
        private const val SP = "xref_prefs"
        fun load(ctx: Context): XRefSettings {
            val raw = ctx.getSharedPreferences(SP, Context.MODE_PRIVATE).getString("settings", null) ?: return XRefSettings()
            return try {
                val j = JSONObject(raw)
                XRefSettings(
                    j.optString("store_code"), j.optString("user_id"), XRefSecret.dec(j.optString("password")),
                    j.optString("list_url"), j.optBoolean("auto_filter", true),
                    j.optString("report_type"), j.optString("start_date"), j.optString("end_date"),
                    j.optString("status"), j.optString("transit"),
                    j.optString("auto_pick", "baru").ifBlank { "baru" }, j.optBoolean("confirm_pick", true)
                )
            } catch (e: Exception) { XRefSettings() }
        }
    }

    fun save(ctx: Context) {
        val j = JSONObject()
            .put("store_code", storeCode).put("user_id", userId).put("password", XRefSecret.enc(password))
            .put("list_url", listUrl).put("auto_filter", autoFilter)
            .put("report_type", reportType).put("start_date", startDate).put("end_date", endDate)
            .put("status", status).put("transit", transit)
            .put("auto_pick", autoPick).put("confirm_pick", confirmPick)
        ctx.getSharedPreferences(SP, Context.MODE_PRIVATE).edit().putString("settings", j.toString()).apply()
    }
}

object XRefSecret {
    private const val ALIAS = "xref_secret_key"

    fun enc(s: String): String {
        if (s.isEmpty()) return ""
        if (Build.VERSION.SDK_INT >= 23) {
            try { return "e:" + encrypt(s) } catch (e: Exception) { /* jatuh ke teks biasa */ }
        }
        return "p:" + s
    }

    fun dec(s: String): String {
        if (s.startsWith("p:")) return s.substring(2)
        if (s.startsWith("e:") && Build.VERSION.SDK_INT >= 23) {
            try { return decrypt(s.substring(2)) } catch (e: Exception) { return "" }
        }
        return ""
    }

    @RequiresApi(23)
    private fun key(): javax.crypto.SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        if (!ks.containsAlias(ALIAS)) {
            val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
            kg.init(KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .build())
            kg.generateKey()
        }
        return (ks.getEntry(ALIAS, null) as KeyStore.SecretKeyEntry).secretKey
    }

    @RequiresApi(23)
    private fun encrypt(s: String): String {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key())
        val ct = c.doFinal(s.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(c.iv + ct, Base64.NO_WRAP)
    }

    @RequiresApi(23)
    private fun decrypt(b64: String): String {
        val all = Base64.decode(b64, Base64.NO_WRAP)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, all.copyOfRange(0, 12)))
        return String(c.doFinal(all.copyOfRange(12, all.size)), Charsets.UTF_8)
    }
}
