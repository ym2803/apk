package com.tms.qubeapps.qubedatacollector

import android.app.AlertDialog
import android.app.ProgressDialog
import android.net.Uri
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.tms.qubeapps.qubedatacollector.Prefs.qtyAddUpdatedCount
import com.tms.qubeapps.qubedatacollector.Prefs.qtyAddUpdatedTime
import com.tms.qubeapps.qubedatacollector.Prefs.qtySubtractUpdatedCount
import com.tms.qubeapps.qubedatacollector.Prefs.qtySubtractUpdatedTime
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * ★ FIX (baru — menu utama): alur Subtract/Add Qty System yang bisa dipakai langsung dari
 * Menu Utama (tanpa membuka layar Stock Balance Check). Logikanya sama dengan menu ⋮ di
 * ShelfPriceEnquireActivity: sumber File / SMB (nama = tanggal hari ini) / GSheet → pratinjau →
 * Terapkan (AppDatabase.adjustCatalogBalance) → selisih disimpan di QtyAdjustImporter.Store.
 *
 * WAJIB dibuat di onCreate() activity (registerForActivityResult harus sebelum STARTED).
 * @param onApplied dipanggil setelah Qty System berhasil diubah (untuk menyegarkan keterangan).
 */
class QtyAdjustFlow(private val act: AppCompatActivity, private val onApplied: () -> Unit) {

    private val db = AppDatabase(act)
    private var adjustSign = -1      // -1 = KURANGI (penjualan), +1 = TAMBAH

    private val fileLauncher =
        act.registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            if (uri != null) handleFile(uri)
        }

    private fun alive() = !act.isFinishing && !act.isDestroyed

    fun start(sign: Int) {
        if (db.countCatalog() == 0) {
            Toast.makeText(act, "Download 02.txt data first", Toast.LENGTH_SHORT).show(); return
        }
        adjustSign = sign
        val msg = if (sign < 0)
            "Select an Excel file (.xls/.xlsx) or a sales report TXT.\nOnly column A (SKU) and column H (Qty) are read. Qty is subtracted from Qty System."
        else
            "Select a TXT file (or Excel).\nOnly the 5th column (SKU) and the 6th column (Qty) are read, for example:\nIDHQ-B-0000536897-JW5006|0000536897|JW5006|B|9101538|4|F|...\nQty is added to Qty System."
        val today = SimpleDateFormat("ddMMyyyy", Locale.US).format(Date())
        val options = arrayOf("Select File", "Fetch via SMB ($today.xlsx/.xls/.xlsm)", "GSheet")
        val dp = act.resources.displayMetrics.density
        val info = TextView(act).apply {
            text = msg + "\n\nSMB: an Excel file in the SMB Path folder (same as the 02.txt download) named with today's date."
            textSize = 14f
            setPadding((20 * dp).toInt(), (12 * dp).toInt(), (20 * dp).toInt(), (8 * dp).toInt())
        }
        val list = ListView(act).apply {
            adapter = ArrayAdapter(act, android.R.layout.simple_list_item_1, options)
        }
        val box = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; addView(info); addView(list) }
        val dlg = AlertDialog.Builder(act)
            .setTitle(if (sign < 0) "Subtract Qty System" else "Add Qty System")
            .setView(box)
            .setNeutralButton("GSheet Settings") { _, _ -> QtyGSheet.showSetupDialog(act) }
            .setNegativeButton("Cancel", null).create()
        list.setOnItemClickListener { _, _, which, _ ->
            dlg.dismiss()
            when (which) {
                0 -> fileLauncher.launch("*/*")
                1 -> fromSmb(sign)
                else -> fromGSheet(sign)
            }
        }
        dlg.show()
    }

    private fun errorDialog(title: String, msg: String) {
        if (alive()) AlertDialog.Builder(act).setTitle(title).setMessage(msg).setPositiveButton("OK", null).show()
    }

    private fun dismissSafe(pd: ProgressDialog) { try { if (pd.isShowing) pd.dismiss() } catch (_: Exception) {} }

    private fun fromSmb(sign: Int) {
        val pd = ProgressDialog(act).apply { setMessage("Fetching today's file from SMB…"); setCancelable(false); show() }
        act.lifecycleScope.launch(Safe.handler) {
            try {
                val (name, grid) = withContext(Dispatchers.IO) { QtyAdjustImporter.fetchByDate(act) }
                dismissSafe(pd)
                showPreview(grid, sign, "SMB: $name", null)
            } catch (e: Throwable) {
                dismissSafe(pd)
                errorDialog("Failed to fetch file via SMB", e.message ?: e.javaClass.simpleName)
            }
        }
    }

    private fun displayNameOf(uri: Uri): String {
        runCatching {
            act.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0)?.let { return it }
            }
        }
        return uri.lastPathSegment ?: "file"
    }

    private fun handleFile(uri: Uri) {
        val sign = adjustSign
        val fname = displayNameOf(uri)
        val pd = ProgressDialog(act).apply { setMessage("Reading $fname…"); setCancelable(false); show() }
        act.lifecycleScope.launch(Safe.handler) {
            try {
                val grid = withContext(Dispatchers.IO) { QtyAdjustImporter.readGrid(act, uri) }
                dismissSafe(pd)
                showPreview(grid, sign, fname, null)
            } catch (e: Throwable) {
                dismissSafe(pd)
                errorDialog("Failed to read file", e.message ?: e.javaClass.simpleName)
            }
        }
    }

    private fun fromGSheet(sign: Int) {
        val url = QtyGSheet.url(act)
        if (url.isBlank()) {
            Toast.makeText(act, "Enter the Google Sheet Web App URL first", Toast.LENGTH_LONG).show()
            QtyGSheet.showSetupDialog(act); return
        }
        val type = if (sign < 0) "subtract" else "add"
        val pd = ProgressDialog(act).apply { setMessage("Fetching data from Google Sheet…"); setCancelable(false); show() }
        act.lifecycleScope.launch(Safe.handler) {
            try {
                val resp = withContext(Dispatchers.IO) { KeepStockGasClient.getQtyAdjustRows(url, QtyGSheet.token(act), type) }
                dismissSafe(pd)
                if (!resp.optBoolean("ok")) {
                    val err = resp.optString("error", "Unknown error")
                    if (alive()) AlertDialog.Builder(act).setTitle("GSheet failed")
                        .setMessage(err + if (err.startsWith("Unknown action"))
                            "\n\nThe script in Google Sheet does not include the Qty System feature yet. Open GSheet Settings → copy the script → redeploy (New version)." else "")
                        .setPositiveButton("GSheet Settings") { _, _ -> QtyGSheet.showSetupDialog(act) }
                        .setNegativeButton("Close", null).show()
                    return@launch
                }
                val arr = resp.optJSONArray("rows")
                val grid = ArrayList<List<String>>()
                if (arr != null) for (i in 0 until arr.length()) {
                    val r = arr.optJSONArray(i) ?: continue
                    grid.add((0 until r.length()).map { r.optString(it, "") })
                }
                val sheetName = resp.optString("sheet", if (sign < 0) QtyGSheet.SHEET_SUBTRACT else QtyGSheet.SHEET_ADD)
                if (grid.isEmpty()) {
                    errorDialog("Tab \"$sheetName\" is empty", "Paste the data into tab \"$sheetName\" in Google Sheet first, then try again.")
                    return@launch
                }
                showPreview(grid, sign, "GSheet: $sheetName", type)
            } catch (e: org.json.JSONException) {
                dismissSafe(pd)
                if (alive()) AlertDialog.Builder(act).setTitle("Response is not JSON")
                    .setMessage("Check: the URL ends with /exec, access is \"Anyone\", and the script has been deployed (New version).")
                    .setPositiveButton("GSheet Settings") { _, _ -> QtyGSheet.showSetupDialog(act) }
                    .setNegativeButton("Close", null).show()
            } catch (e: Throwable) {
                dismissSafe(pd)
                errorDialog("GSheet failed", e.message ?: e.javaClass.simpleName)
            }
        }
    }

    private fun showPreview(grid: List<List<String>>, sign: Int, fname: String, gsheetType: String?) {
        act.lifecycleScope.launch(Safe.handler) {
            try {
                val (parsed, prev) = withContext(Dispatchers.IO) {
                    // Kurangi: kolom A(0) & H(7). Tambah: kolom 5(4) & 6(5).
                    val p = if (sign < 0) QtyAdjustImporter.extractFlexible(grid, 0, 7) else QtyAdjustImporter.extract(grid, 4, 5)
                    p to db.adjustCatalogBalance(p.deltas, sign, false)
                }
                val sig = "${if (sign < 0) "-" else "+"}|$fname|${grid.size}|${parsed.rowsUsed}"
                if (parsed.rowsUsed == 0) {
                    errorDialog("No data read",
                        "No SKU (number) + Qty (number) pairs found in the specified columns. Check the data format." +
                            (if (parsed.note.isNotBlank()) "\n\n" + parsed.note else "") +
                            "\n\nRows read: ${parsed.rowsRead}")
                    return@launch
                }
                val already = QtyAdjustImporter.loadStore(act).imports.contains(sig)
                val total = parsed.deltas.values.sum()
                fun f(d: Double) = if (d == Math.floor(d)) d.toLong().toString() else d.toString()
                val sb = StringBuilder()
                if (already) sb.append("⚠ This data has ALREADY been imported (same name & content). Avoid duplicates!\n\n")
                sb.append("${if (sign < 0) "SUBTRACT" else "ADD"} Qty System\n")
                if (parsed.note.isNotBlank()) sb.append(parsed.note).append("\n\n")
                sb.append("Rows read   : ${parsed.rowsUsed}\nUnique SKUs : ${parsed.deltas.size}\nTotal qty   : ${f(total)}\n")
                sb.append("Found in catalog : ${prev.found}\nNOT found        : ${prev.notFound.size}")
                if (prev.notFound.isNotEmpty())
                    sb.append("\n  " + prev.notFound.take(8).joinToString(", ") + (if (prev.notFound.size > 8) ", …" else ""))
                if (prev.negative > 0) sb.append("\n⚠ ${prev.negative} SKUs will go negative")
                if (gsheetType != null) sb.append("\n\nAfter applying, the tab contents are moved to \"${QtyGSheet.SHEET_LOG}\" and cleared.")
                if (alive()) AlertDialog.Builder(act)
                    .setTitle(fname)
                    .setMessage(sb.toString())
                    .setPositiveButton("Apply") { _, _ -> apply(parsed.deltas, sign, sig, gsheetType) }
                    .setNegativeButton("Cancel", null).show()
            } catch (e: Throwable) {
                errorDialog("Failed to process data", e.message ?: e.javaClass.simpleName)
            }
        }
    }

    private fun apply(deltas: Map<String, Double>, sign: Int, sig: String, gsheetType: String?) {
        act.lifecycleScope.launch(Safe.handler) {
            val res = withContext(Dispatchers.IO) { db.adjustCatalogBalance(deltas, sign, true) }
            // catat selisih (hanya SKU yang ditemukan) supaya tetap terpasang saat kolom diganti
            val st = QtyAdjustImporter.loadStore(act)
            deltas.forEach { (k, v) -> if (k !in res.notFound) st.deltas[k] = (st.deltas[k] ?: 0.0) + sign * v }
            st.imports.add(sig)
            QtyAdjustImporter.saveStore(act, st)
            // catat waktu update terakhir (tampil di menu utama)
            if (sign < 0) { act.qtySubtractUpdatedTime = System.currentTimeMillis(); act.qtySubtractUpdatedCount = res.found }
            else { act.qtyAddUpdatedTime = System.currentTimeMillis(); act.qtyAddUpdatedCount = res.found }
            var archiveNote = ""
            if (gsheetType != null) {
                archiveNote = try {
                    val r = withContext(Dispatchers.IO) { KeepStockGasClient.archiveQtyAdjust(QtyGSheet.url(act), QtyGSheet.token(act), gsheetType) }
                    if (r.optBoolean("ok")) "\nGSheet tab archived to \"${QtyGSheet.SHEET_LOG}\" & cleared (${r.optInt("archived")} rows)"
                    else "\n⚠ Failed to archive GSheet tab: ${r.optString("error")} — clear it manually to avoid double counting"
                } catch (e: Throwable) {
                    "\n⚠ Failed to archive GSheet tab (${e.message}) — clear it manually to avoid double counting"
                }
            }
            onApplied()
            errorDialog("Qty System updated",
                "${res.found} SKUs updated" +
                    (if (res.notFound.isNotEmpty()) "\n${res.notFound.size} SKUs not in catalog (skipped)" else "") +
                    (if (res.negative > 0) "\n⚠ ${res.negative} SKUs went negative" else "") + archiveNote)
        }
    }
}
