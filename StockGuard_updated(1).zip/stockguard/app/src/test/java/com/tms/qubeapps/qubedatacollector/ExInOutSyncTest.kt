package com.tms.qubeapps.qubedatacollector

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

/**
 * Unit test murni JVM untuk ExInOutSync.computeSync() — logika Sync IN/OUT yang
 * diselaraskan dengan Exiov2.py (_build_plan / _merge_stable / _check_sync_guard).
 *
 * Format baris CSV: "NoCtn,SKU[,...]" (kolom B = index 0, tanpa baris header).
 * State dasar [baseKeys] dipakai supaya sync BUKAN dianggap "pertama kali"
 * (state kosong total = baseline, tidak ada IN yang dicetak).
 */
class ExInOutSyncTest {

    private fun csv(vararg rows: String): String = rows.joinToString("\n")

    private val base = "Z00,1"
    private val baseKeys = setOf("Z00|1")

    /** Baris dengan nilai di kolom AH (index 32, kolom B = 0). */
    private fun rowWithAh(noCtn: String, sku: String, ah: String) =
        "$noCtn,$sku" + ",".repeat(31) + ah

    // ── IN / baseline / RE-IN ────────────────────────────────────────────
    @Test
    fun `SKU baru pada No Ctn baru terdeteksi IN`() {
        val r = ExInOutSync.computeSync(csv(base, "A01,1001"), baseKeys, emptySet())
        assertTrue(r.foundNew)
        assertEquals(listOf("A01,1001"), r.out1)
        assertEquals(listOf("1001,1"), r.out2)
        assertEquals(baseKeys + "A01|1001", r.updatedKeys)
        assertTrue(r.out3.isEmpty())
    }

    @Test
    fun `Sync pertama kali (state kosong) hanya baseline, tidak ada IN dicetak`() {
        val r = ExInOutSync.computeSync(csv("A01,1001", "A02,2002"), emptySet(), emptySet())
        assertTrue(r.isBaseline)
        assertFalse(r.foundNew)
        assertTrue(r.out1.isEmpty())
        assertEquals(setOf("A01|1001", "A02|2002"), r.updatedKeys)
    }

    @Test
    fun `SKU yang pernah OUT lalu muncul lagi terdeteksi RE-IN`() {
        val r = ExInOutSync.computeSync(csv(base, "A01,1001"), baseKeys, setOf("A01|1001"))
        assertTrue(r.foundNew)
        assertTrue(r.updatedKeys.contains("A01|1001"))
        assertFalse(r.updatedOutHistory.contains("A01|1001"))
        assertTrue(r.log.any { it.contains("RE-IN") })
    }

    @Test
    fun `IN diurutkan berdasarkan kunci seperti sorted(new_active_keys)`() {
        val r = ExInOutSync.computeSync(csv(base, "B01,2002", "A01,1001"), baseKeys, emptySet())
        assertEquals(listOf("A01,1001", "B01,2002"), r.out1)
    }

    // ── OUT / MOVE / ACTIVE ──────────────────────────────────────────────
    @Test
    fun `SKU hilang total dari snapshot terdeteksi OUT`() {
        val r = ExInOutSync.computeSync(csv(base), baseKeys + "A01|1001", emptySet())
        assertTrue(r.foundOut)
        assertEquals(listOf(",1001"), r.out3)
        assertEquals(listOf("1001,3"), r.out4)
        assertFalse(r.updatedKeys.contains("A01|1001"))
        assertTrue(r.updatedOutHistory.contains("A01|1001"))
    }

    @Test
    fun `SKU pindah No Ctn TIDAK ter-OUT, kunci baru IN, kunci lama tetap di state seperti Python`() {
        val r = ExInOutSync.computeSync(csv(base, "A02,1001"), baseKeys + "A01|1001", emptySet())
        assertFalse(r.foundOut)
        assertTrue(r.out3.isEmpty())
        assertTrue(r.foundNew)
        assertEquals(listOf("A02,1001"), r.out1)
        assertTrue(r.updatedKeys.contains("A02|1001"))
        // Python: kunci lama baru gugur lewat OUT (commit_out), bukan saat MOVE.
        assertTrue(r.updatedKeys.contains("A01|1001"))
    }

    @Test
    fun `SKU yang pindah lalu benar-benar OUT hanya tercetak SATU kali di file OUT`() {
        val r1 = ExInOutSync.computeSync(csv(base, "A02,1001"), baseKeys + "A01|1001", emptySet())
        val r2 = ExInOutSync.computeSync(csv(base), r1.updatedKeys, r1.updatedOutHistory)
        assertEquals(listOf(",1001"), r2.out3)
        // kedua kunci (A01|1001 & A02|1001) gugur bersamaan
        assertFalse(r2.updatedKeys.contains("A01|1001"))
        assertFalse(r2.updatedKeys.contains("A02|1001"))
        assertTrue(r2.updatedOutHistory.containsAll(setOf("A01|1001", "A02|1001")))
    }

    @Test
    fun `SKU yang muncul di kolom AH dianggap ACTIVE dan tidak di-OUT`() {
        val r = ExInOutSync.computeSync(
            csv(rowWithAh("Z00", "1", "1001")), baseKeys + "A01|1001", emptySet())
        assertFalse(r.foundOut)
        assertTrue(r.updatedKeys.contains("A01|1001"))   // tetap aktif di state
        assertTrue(r.log.any { it.contains("ACTIVE(tetap):1") })
    }

    @Test
    fun `SKU split ke 2 No Ctn tercatat IN untuk keduanya`() {
        val r = ExInOutSync.computeSync(csv(base, "A01,1001", "A02,1001"), baseKeys, emptySet())
        assertEquals(baseKeys + setOf("A01|1001", "A02|1001"), r.updatedKeys)
        assertEquals(2, r.out1.size)
    }

    @Test
    fun `Salah satu lokasi SKU split dihapus, SKU masih ada, TIDAK boleh OUT`() {
        val r = ExInOutSync.computeSync(csv(base, "A02,1001"),
            baseKeys + setOf("A01|1001", "A02|1001"), emptySet())
        assertFalse(r.foundOut)
    }

    // ── DUPLICATE ────────────────────────────────────────────────────────
    @Test
    fun `Kunci duplikat TIDAK di-IN sampai dibersihkan (seperti Python)`() {
        val r = ExInOutSync.computeSync(csv(base, "A01,1001", "A01,1001", "A01,1001"), baseKeys, emptySet())
        assertTrue(r.out1.isEmpty())
        assertFalse(r.updatedKeys.contains("A01|1001"))
        assertTrue(r.log.any { it.contains("DUPLICATE") })
    }

    @Test
    fun `Kunci aktif yang kebetulan terduplikasi TIDAK dianggap hilang (tidak OUT)`() {
        val r = ExInOutSync.computeSync(csv(base, "A01,1001", "A01,1001"),
            baseKeys + "A01|1001", emptySet())
        assertFalse(r.foundOut)
        assertTrue(r.updatedKeys.contains("A01|1001"))
    }

    // ── INVALID ──────────────────────────────────────────────────────────
    @Test
    fun `No Ctn kosong tapi SKU ada dicatat INVALID dan dilewati`() {
        val r = ExInOutSync.computeSync(csv(base, ",1001"), baseKeys, emptySet())
        assertTrue(r.out1.isEmpty())
        assertTrue(r.log.any { it.contains("INVALID") })
    }

    @Test
    fun `SKU bukan angka murni dicatat INVALID`() {
        val r = ExInOutSync.computeSync(csv(base, "A01,ABC123"), baseKeys, emptySet())
        assertTrue(r.out1.isEmpty())
        assertTrue(r.log.any { it.contains("INVALID") })
    }

    @Test
    fun `Baris kosong dua-duanya diabaikan tanpa dihitung INVALID`() {
        val r = ExInOutSync.computeSync(csv(base, ",", "A01,1001"), baseKeys, emptySet())
        assertEquals(1, r.out1.size)
        assertTrue(r.log.any { it.contains("INVALID:0") })
    }

    // ── Pengaman (_check_sync_guard) ─────────────────────────────────────
    @Test
    fun `Sheet kosong padahal state ada membatalkan sync, state tidak berubah`() {
        try {
            ExInOutSync.computeSync("", setOf("A01|1001", "A02|2002"), emptySet())
            fail("Seharusnya SyncGuardException")
        } catch (e: ExInOutSync.SyncGuardException) {
            assertTrue(e.message!!.contains("KOSONG"))
        }
    }

    @Test
    fun `OUT massal (lebih dari 50 persen dari 30+ data aktif) membatalkan sync`() {
        val oldKeys = (1..40).map { "A$it|100$it" }.toSet()
        val csv = (1..10).joinToString("\n") { "A$it,100$it" }
        try {
            ExInOutSync.computeSync(csv, oldKeys, emptySet())
            fail("Seharusnya SyncGuardException")
        } catch (e: ExInOutSync.SyncGuardException) {
            assertTrue(e.message!!.contains("OUT sekaligus"))
        }
        // dengan force = true pengaman dilewati
        val forced = ExInOutSync.computeSync(csv, oldKeys, emptySet(), force = true)
        assertEquals(30, forced.out3.size)
        assertTrue(forced.log.any { it.contains("Force Sync") })
    }

    @Test
    fun `OUT jumlah kecil pada populasi kecil TIDAK memicu pengaman`() {
        val r = ExInOutSync.computeSync(csv("A02,2002"), setOf("A01|1001", "A02|2002"), emptySet())
        assertEquals(1, r.out3.size)
    }

    // ── Pembacaan kedua (_merge_stable) ──────────────────────────────────
    @Test
    fun `Perubahan yang sama di dua pembacaan diproses`() {
        val c = csv(base, "A01,1001")
        val r = ExInOutSync.computeSync(c, baseKeys, emptySet(), secondRead = { c })
        assertEquals(listOf("A01,1001"), r.out1)
    }

    @Test
    fun `IN yang hilang di pembacaan kedua ditunda (belum stabil)`() {
        val r = ExInOutSync.computeSync(csv(base, "A01,1001"), baseKeys, emptySet(),
            secondRead = { csv(base) })
        assertTrue(r.out1.isEmpty())
        assertFalse(r.updatedKeys.contains("A01|1001"))
        assertTrue(r.log.any { it.contains("belum stabil") })
    }

    @Test
    fun `Pembacaan kedua tidak dipanggil kalau tidak ada perubahan`() {
        var called = false
        ExInOutSync.computeSync(csv(base), baseKeys, emptySet(), secondRead = { called = true; csv(base) })
        assertFalse(called)
    }

    // ── CSV ──────────────────────────────────────────────────────────────
    @Test
    fun `CSV parser menangani field dengan tanda kutip`() {
        val r = ExInOutSync.computeSync(csv(base, "\"A01\",\"1001\""), baseKeys, emptySet())
        assertTrue(r.updatedKeys.contains("A01|1001"))
    }

    @Test
    fun `CSV parser menangani sel multi-baris di dalam tanda kutip`() {
        val r = ExInOutSync.computeSync(csv(base, "A01,1001,\"baris1\nbaris2\"", "A02,2002"), baseKeys, emptySet())
        assertEquals(listOf("A01,1001", "A02,2002"), r.out1)
    }
}
