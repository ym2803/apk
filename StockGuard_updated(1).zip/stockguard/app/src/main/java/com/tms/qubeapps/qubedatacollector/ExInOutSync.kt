package com.tms.qubeapps.qubedatacollector

import java.net.HttpURLConnection
import java.net.URL

/**
 * ★ Sync IN/OUT Keep Stock — SELARAS dengan skrip Exiov2.py (`_build_plan`,
 * `_merge_stable`, `_check_sync_guard`, `sync_from_sheet`, `fetch_sheet_rows`).
 *
 * ═══════════════════════════════════════════════════════════════════════
 * ATURAN (sama dengan skrip Python)
 * ═══════════════════════════════════════════════════════════════════════
 * - Kunci   : (No Ctn kolom B, SKU kolom C) → "NoCtn|SKU".
 * - Valid   : No Ctn & SKU terisi, SKU angka murni. Satu sisi kosong / SKU bukan
 *             angka = INVALID (dilewati). Dua-duanya kosong = diabaikan.
 * - DUPLICATE: kunci yang muncul > 1x di sheet TIDAK di-IN sampai dibersihkan,
 *             tapi tetap dianggap "masih ada" (tidak boleh jadi OUT).
 * - IN / RE-IN: kunci valid (non-duplikat) yang belum aktif di state. RE-IN bila
 *             kunci itu pernah tercatat OUT.
 * - Kunci aktif di state yang tidak ada lagi di sheet → kandidat OUT:
 *     • SKU-nya muncul di kolom AH baris mana pun        → ACTIVE (tetap)
 *     • SKU-nya masih ada di No Ctn lain (kolom C)         → MOVE (tidak di-OUT)
 *     • selain itu                                         → OUT (1 baris per SKU)
 * - State TIDAK dibersihkan otomatis untuk MOVE/ACTIVE: kunci aktif hanya
 *   berkurang lewat OUT, persis seperti commit_in/commit_out di Python.
 * - PERTAMA KALI (state kosong total): semua data yang ada hanya dicatat
 *   sebagai BASELINE — tidak ada IN yang dicetak (FIRST_RUN_BASELINE).
 * - PEMBACAAN KEDUA: kalau ada perubahan IN/OUT, sheet dibaca ulang setelah
 *   [STABLE_READ_DELAY_MS] dan HANYA perubahan yang sama di kedua pembacaan
 *   yang diproses; sisanya ditunda ke sync berikutnya (mis. staf sedang cut-paste).
 * - PENGAMAN: sync dibatalkan ([SyncGuardException]) bila sheet terbaca kosong
 *   padahal sebelumnya ada data, atau OUT > 50% data aktif (dan data aktif >= 30).
 *   Bisa dilewati dengan parameter force = true (setara force_sync.flag di PC).
 * - Sheet diambil UTUH (tanpa batas baris), mulai baris 6 & kolom B, hanya sampai
 *   kolom BQ; CSV diparse sadar tanda kutip & sel multi-baris; retry 3x.
 *
 * Arsitektur Android (tidak berubah): computeSync()/computeSyncRows() = fungsi
 * murni (bisa di-unit-test di JVM), sync() = I/O (download + baca state),
 * commitState() dipanggil caller HANYA setelah file hasil sukses terkirim.
 */
object ExInOutSync {

    // ── Konstanta (nilainya sama dengan Exiov2.py) ───────────────────────
    private const val SHEET_FIRST_ROW = 6        // baris data pertama (1-based)
    private const val SHEET_FIRST_COL = 1        // kolom B (A=0)
    private const val B_COL_INDEX = 0            // setelah kolom A dibuang
    private const val C_COL_INDEX = 1
    private const val AH_COL_INDEX = 32
    private const val KEEP_COLS = 68             // sampai kolom BQ (BQ_COL_INDEX + 1)

    private const val FETCH_RETRIES = 3
    private const val FETCH_TIMEOUT_MS = 90_000
    private const val GUARD_MIN_ACTIVE = 30
    private const val GUARD_OUT_RATIO = 0.5
    private const val FIRST_RUN_BASELINE = true
    private const val STABLE_READ_DELAY_MS = 4000L   // 0 = matikan pembacaan kedua
    private const val MAX_DEAD_KEYS = 20000          // riwayat OUT (hanya untuk label RE-IN)

    /** Sync dibatalkan oleh pengaman (lihat [checkSyncGuard]). Bisa di-force ulang. */
    class SyncGuardException(message: String) : Exception(message)

    data class SyncResult(
        val store: String,
        val newInCount: Int,
        val outCount: Int,
        val file1: String, // EXCEL IN BOX.txt
        val file2: String, // +PRINT IN LABEL.txt
        val file3: String, // EXCEL OUT BOX.txt
        val file4: String, // -PRINT OUT LABEL.txt
        val hasNewIn: Boolean,
        val log: List<String>,
        // State hasil hitung dibawa di sini TAPI belum disimpan; baru dipersist lewat
        // commitState() setelah file1-4 SUKSES terkirim.
        val updatedKeys: Set<String>,
        val updatedOutHistory: Set<String>,
        /** true = sync pertama kali: data yang ada hanya dicatat sebagai baseline, tidak ada file dikirim. */
        val isBaseline: Boolean = false
    )

    /** Hasil computeSync() — dipakai sync() dan unit test (JVM murni). */
    data class SyncCompute(
        val out1: List<String>,
        val out2: List<String>,
        val out3: List<String>,
        val out4: List<String>,
        val foundNew: Boolean,
        val foundOut: Boolean,
        val updatedKeys: Set<String>,
        val updatedOutHistory: Set<String>,
        val log: List<String>,
        val isBaseline: Boolean = false
    )

    // ── Model rencana (port _build_plan) ─────────────────────────────────
    private class Stats(
        val inKeys: MutableList<String> = mutableListOf(),
        val reIn: MutableList<String> = mutableListOf(),
        val move: MutableList<String> = mutableListOf(),
        val active: MutableList<String> = mutableListOf(),
        val out: MutableList<String> = mutableListOf(),
        val duplicate: MutableList<String> = mutableListOf(),
        val invalid: MutableList<String> = mutableListOf()
    )
    private class InItem(val box: String, val label: String, val key: String)
    private class OutItem(val box: String, val label: String, val keys: MutableList<String>)
    private class Plan(
        val stats: Stats,
        val inItems: List<InItem>,
        val outItems: List<OutItem>,
        val presentKeys: Set<String>,
        val validCount: Int
    )

    // ═══════════════════════════════════════════════════════════════════
    // I/O
    // ═══════════════════════════════════════════════════════════════════

    /** Harus dipanggil dari Dispatchers.IO — download sheet + baca state lama (read-only).
     *  @param force true = lewati pengaman OUT massal / sheet kosong (sekali pakai). */
    fun sync(db: AppDatabase, store: String, spreadsheetId: String, gid: String,
             force: Boolean = false): SyncResult {
        val rows = fetchSheetRows(spreadsheetId, gid)
        val processedKeys = db.getExioKeys(store)      // Snapshot Lama (kunci aktif)
        val outHistory = db.getExioOutKeys(store)       // riwayat kunci yang pernah OUT

        val r = computeSyncRows(
            rows, processedKeys, outHistory,
            secondRead = {
                Thread.sleep(STABLE_READ_DELAY_MS)
                fetchSheetRows(spreadsheetId, gid)
            },
            force = force
        )
        return SyncResult(
            store = store,
            newInCount = r.out1.size,
            outCount = r.out3.size,
            file1 = r.out1.joinToString("\r\n"),
            file2 = r.out2.joinToString("\r\n"),
            file3 = r.out3.joinToString("\r\n"),
            file4 = r.out4.joinToString("\r\n"),
            hasNewIn = r.foundNew,
            log = r.log,
            updatedKeys = r.updatedKeys,
            updatedOutHistory = r.updatedOutHistory,
            isBaseline = r.isBaseline
        )
    }

    /** Persist state hasil sync() — WAJIB hanya setelah file1-4 sukses terkirim. */
    fun commitState(db: AppDatabase, result: SyncResult) {
        db.saveExioKeys(result.store, result.updatedKeys)
        db.saveExioOutKeys(result.store, result.updatedOutHistory)
    }

    // Outbox (staging sebelum upload; tahan force-close) — tidak berubah.
    fun saveOutboxPending(db: AppDatabase, result: SyncResult) { db.saveExioOutbox(result.store, result) }
    fun loadPendingOutbox(db: AppDatabase, store: String): SyncResult? = db.getExioOutbox(store)
    fun clearOutbox(db: AppDatabase, store: String) { db.deleteExioOutbox(store) }

    /**
     * Port fetch_sheet_rows(): ambil SELURUH sheet (tanpa batas baris), buang 5 baris
     * pertama & kolom A, simpan hanya sampai kolom BQ, buang baris kosong.
     * Retry 3x (jeda 2s, 4s) untuk error jaringan / 429 / 5xx; menolak halaman HTML.
     */
    private fun fetchSheetRows(spreadsheetId: String, gid: String): List<List<String>> {
        val url = "https://docs.google.com/spreadsheets/d/$spreadsheetId/export?format=csv&gid=$gid"
        var lastErr: Exception? = null
        for (attempt in 1..FETCH_RETRIES) {
            try {
                val text = httpGetText(url)
                val head = text.take(600).trimStart().lowercase()
                if (head.startsWith("<!doctype") || head.contains("<html")) {
                    throw Exception("Google mengembalikan halaman HTML, bukan CSV. Pastikan spreadsheet " +
                        "di-share (Anyone with the link) dan Spreadsheet ID/GID benar.")
                }
                if (text.isBlank()) throw Exception("Data CSV kosong. Cek Spreadsheet ID/GID toko ini.")
                val rows = parseCsvRecords(text)
                    .drop(SHEET_FIRST_ROW - 1)
                    .map { r -> r.drop(SHEET_FIRST_COL).take(KEEP_COLS).map { it.trim() } }
                    .filter { cols -> cols.any { it.isNotEmpty() } }
                if (rows.isEmpty()) throw Exception("Spreadsheet terbaca tetapi tidak ada isi data.")
                return rows
            } catch (e: FatalFetchException) {
                throw Exception(e.message)
            } catch (e: java.io.IOException) {
                lastErr = e
            } catch (e: RetryableFetchException) {
                lastErr = e
            }
            if (attempt < FETCH_RETRIES) Thread.sleep(2000L * attempt)
        }
        throw Exception("Gagal mengambil data setelah ${FETCH_RETRIES}x percobaan: ${lastErr?.message}")
    }

    private class FatalFetchException(msg: String) : Exception(msg)
    private class RetryableFetchException(msg: String) : Exception(msg)

    private fun httpGetText(url: String): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.requestMethod = "GET"
        conn.setRequestProperty("User-Agent", "Mozilla/5.0")
        conn.connectTimeout = 20000
        conn.readTimeout = FETCH_TIMEOUT_MS
        try {
            val code = conn.responseCode
            if (code in intArrayOf(400, 401, 403, 404)) {
                throw FatalFetchException("Spreadsheet tidak bisa diakses (HTTP $code). Cek Spreadsheet ID/GID dan izin share.")
            }
            if (code !in 200..299) throw RetryableFetchException("HTTP $code saat download CSV")
            return conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }

    // ═══════════════════════════════════════════════════════════════════
    // LOGIKA MURNI
    // ═══════════════════════════════════════════════════════════════════

    /**
     * Versi teks CSV (kolom B sebagai index 0, TANPA baris header) — dipakai unit test.
     * @param secondRead pembacaan kedua (hanya dipanggil bila ada perubahan IN/OUT); null = tanpa verifikasi.
     */
    fun computeSync(
        csvData: String,
        processedKeys: Set<String>,
        outHistory: Set<String>,
        secondRead: (() -> String)? = null,
        force: Boolean = false
    ): SyncCompute = computeSyncRows(
        parseBasedCsv(csvData), processedKeys, outHistory,
        secondRead = secondRead?.let { f -> { parseBasedCsv(f()) } },
        force = force
    )

    /** Port sync_from_sheet() (bagian perhitungan; tanpa menulis apa pun). */
    private fun computeSyncRows(
        rows: List<List<String>>,
        processedKeys: Set<String>,
        outHistory: Set<String>,
        secondRead: (() -> List<List<String>>)?,
        force: Boolean
    ): SyncCompute {
        val log = mutableListOf<String>()
        log.add("Total baris data terbaca: ${rows.size}")
        log.add("Snapshot lama: ${processedKeys.size} kunci aktif, ${outHistory.size} kunci pernah OUT (riwayat)")

        var plan = buildPlan(rows, processedKeys, outHistory)

        // ---- PEMAKAIAN PERTAMA: catat semua data yang ada sebagai baseline ----
        val isNew = processedKeys.isEmpty() && outHistory.isEmpty()
        if (isNew && FIRST_RUN_BASELINE && plan.presentKeys.isNotEmpty()) {
            log.add("PERTAMA KALI: ${plan.presentKeys.size} data yang sudah ada dicatat sebagai baseline " +
                "(TIDAK dicetak). Sync berikutnya hanya memproses data baru/keluar.")
            return SyncCompute(
                out1 = emptyList(), out2 = emptyList(), out3 = emptyList(), out4 = emptyList(),
                foundNew = false, foundOut = false,
                updatedKeys = LinkedHashSet(plan.presentKeys), updatedOutHistory = emptySet(),
                log = log, isBaseline = true
            )
        }

        // ---- VERIFIKASI: baca ulang bila ada perubahan, ambil yang stabil saja ----
        var unstable = 0
        if ((plan.inItems.isNotEmpty() || plan.outItems.isNotEmpty()) && secondRead != null) {
            log.add("Perubahan terdeteksi, verifikasi dengan pembacaan kedua...")
            val plan2 = buildPlan(secondRead(), processedKeys, outHistory)
            val merged = mergeStable(plan, plan2)
            plan = merged.first
            unstable = merged.second
            if (unstable > 0) {
                log.add("PERHATIAN: $unstable perubahan belum stabil (berubah di antara dua pembacaan, " +
                    "mungkin sedang diedit). Ditunda ke Sync berikutnya.")
            }
        }

        val stats = plan.stats
        stats.duplicate.forEach { log.add("  [DUPLICATE] $it") }
        stats.out.forEach { log.add("  [OUT] $it -> tidak ada relasi keluarga aktif tersisa") }

        // ---- Pengaman sebelum menghasilkan apa pun ----
        checkSyncGuard(processedKeys.size, stats.out.size, plan.validCount, force) { log.add(it) }

        val out1 = plan.inItems.map { it.box }
        val out2 = plan.inItems.map { it.label }
        val out3 = plan.outItems.map { it.box }
        val out4 = plan.outItems.map { it.label }
        val foundNew = plan.inItems.isNotEmpty()
        val foundOut = plan.outItems.isNotEmpty()

        plan.inItems.forEach { item ->
            log.add(if (item.key in outHistory) "  [${item.key}] RE-IN (sebelumnya pernah OUT, sekarang aktif lagi)"
                    else "  [${item.key}] IN (baru)")
        }
        if (foundNew) log.add("IN OK: ${out1.size} baris (baru: ${stats.inKeys.size}, RE-IN: ${stats.reIn.size})")
        else log.add("IN - tidak ada data baru, file dibiarkan")
        if (foundOut) log.add("OUT OK: ${out3.size} baris (kunci OUT: ${stats.out.size})")
        else log.add("OUT - tidak ada SKU yang benar-benar keluar, FILE3 & FILE4 dikosongkan")

        log.add("RINGKASAN -> IN:${stats.inKeys.size}  RE-IN:${stats.reIn.size}  MOVE:${stats.move.size}  " +
            "ACTIVE(tetap):${stats.active.size}  OUT:${stats.out.size}  DUPLICATE:${stats.duplicate.size}  " +
            "INVALID:${stats.invalid.size}  DITUNDA:$unstable")
        if (stats.duplicate.isNotEmpty())
            log.add("PERHATIAN: ${stats.duplicate.size} data DUPLICATE ditemukan, tidak di-IN sampai dibersihkan di spreadsheet.")
        if (stats.invalid.isNotEmpty())
            log.add("PERHATIAN: ${stats.invalid.size} baris INVALID (No Ctn/SKU kosong atau format salah) diabaikan.")

        // ---- State baru (setara commit_in / commit_out di Python) ----
        val updatedKeys = LinkedHashSet(processedKeys)
        plan.inItems.forEach { updatedKeys.add(it.key) }
        plan.outItems.forEach { updatedKeys.removeAll(it.keys.toSet()) }

        val dead = LinkedHashSet(outHistory)
        plan.inItems.forEach { dead.remove(it.key) }
        plan.outItems.forEach { item -> item.keys.forEach { k -> dead.remove(k); dead.add(k) } }
        while (dead.size > MAX_DEAD_KEYS) dead.remove(dead.first())

        log.add("State diperbarui: ${updatedKeys.size} kunci aktif, ${dead.size} riwayat OUT tersimpan")

        return SyncCompute(
            out1 = out1, out2 = out2, out3 = out3, out4 = out4,
            foundNew = foundNew, foundOut = foundOut,
            updatedKeys = updatedKeys, updatedOutHistory = dead,
            log = log
        )
    }

    /** Port _build_plan(): bandingkan isi sheet dengan state → rencana IN/OUT. */
    private fun buildPlan(rows: List<List<String>>, active: Set<String>, dead: Set<String>): Plan {
        val stats = Stats()
        class VRow(val b: String, val c: String, val ah: String, val key: String)

        val seenCount = LinkedHashMap<String, Int>()
        val valid = ArrayList<VRow>()
        for (cols in rows) {
            if (cols.size <= C_COL_INDEX) continue
            val b = cols[B_COL_INDEX].trim()
            val c = cols[C_COL_INDEX].trim()
            val ah = if (cols.size > AH_COL_INDEX) cols[AH_COL_INDEX].trim() else ""

            if (b.isEmpty() && c.isEmpty()) continue
            if (b.isEmpty() || c.isEmpty() || !c.all { it.isDigit() }) {
                stats.invalid.add("${b.ifEmpty { "(kosong)" }}|${c.ifEmpty { "(kosong)" }}")
                continue
            }
            val key = "$b|$c"
            seenCount[key] = (seenCount[key] ?: 0) + 1
            valid.add(VRow(b, c, ah, key))
        }

        val dupKeys = seenCount.filter { it.value > 1 }.keys
        stats.duplicate.addAll(dupKeys.sorted())

        // Semua kunci yang MASIH ADA di sheet (termasuk duplikat) → duplikat tidak boleh dianggap "hilang".
        val presentKeys = LinkedHashSet(seenCount.keys)

        val newActive = HashMap<String, Pair<String, String>>()   // key -> (b, c)
        val skuInSheet = HashSet<String>()
        val ahValues = HashSet<String>()
        for (r in valid) {
            skuInSheet.add(r.c)
            if (r.ah.isNotEmpty()) ahValues.add(r.ah)
            if (r.key in dupKeys) continue        // duplikat: tidak di-IN sampai dibersihkan
            newActive[r.key] = r.b to r.c
        }

        // ---- IN ----
        val inItems = ArrayList<InItem>()
        for (key in newActive.keys.sorted()) {
            if (key in active) continue
            val (b, c) = newActive[key]!!
            if (key in dead) stats.reIn.add(key) else stats.inKeys.add(key)
            inItems.add(InItem(box = "${b.take(4)},$c", label = "$c,1", key = key))
        }

        // ---- OUT / MOVE / ACTIVE ----
        val outItems = ArrayList<OutItem>()
        val outBySku = HashMap<String, OutItem>()
        for (key in (active - presentKeys).sorted()) {
            val idx = key.lastIndexOf('|')
            if (idx < 0) continue
            val cFromKey = key.substring(idx + 1)

            if (cFromKey in ahValues) { stats.active.add(key); continue }
            if (cFromKey in skuInSheet) { stats.move.add(key); continue }

            val item = outBySku.getOrPut(cFromKey) {
                OutItem(box = ",$cFromKey", label = "$cFromKey,3", keys = mutableListOf()).also { outItems.add(it) }
            }
            item.keys.add(key)
            stats.out.add(key)
        }
        return Plan(stats, inItems, outItems, presentKeys, valid.size)
    }

    /** Port _merge_stable(): hanya perubahan yang SAMA di dua pembacaan yang diproses. */
    private fun mergeStable(p1: Plan, p2: Plan): Pair<Plan, Int> {
        val in1 = p1.inItems.map { it.key }.toSet()
        val in2 = p2.inItems.map { it.key }.toSet()
        val inItems = p2.inItems.filter { it.key in in1 }
        var unstable = (in1 union in2).size - (in1 intersect in2).size

        val g1 = p1.outItems.associate { it.box to it.keys.toSet() }
        val g2 = p2.outItems.associate { it.box to it.keys.toSet() }
        val outItems = p2.outItems.filter { g1[it.box] == it.keys.toSet() }
        unstable += (g1.keys union g2.keys).count { g1[it] != g2[it] }

        val stableIn = inItems.map { it.key }.toSet()
        val stableOut = outItems.flatMap { it.keys }.toSet()
        val s = p2.stats
        val stats = Stats(
            inKeys = s.inKeys.filter { it in stableIn }.toMutableList(),
            reIn = s.reIn.filter { it in stableIn }.toMutableList(),
            move = s.move, active = s.active,
            out = s.out.filter { it in stableOut }.toMutableList(),
            duplicate = s.duplicate, invalid = s.invalid
        )
        return Plan(stats, inItems, outItems, p2.presentKeys, p2.validCount) to unstable
    }

    /** Port _check_sync_guard(): cegah OUT massal palsu. force = lewati (setara force_sync.flag). */
    private fun checkSyncGuard(prevActive: Int, outCount: Int, totalValid: Int,
                               force: Boolean, log: (String) -> Unit) {
        val reason: String? = when {
            prevActive > 0 && totalValid == 0 ->
                "spreadsheet terbaca KOSONG padahal sebelumnya ada data"
            prevActive >= GUARD_MIN_ACTIVE && outCount > prevActive * GUARD_OUT_RATIO ->
                "$outCount dari $prevActive data aktif akan dianggap OUT sekaligus (> ${(GUARD_OUT_RATIO * 100).toInt()}%)"
            else -> null
        }
        if (reason == null) return
        if (force) {
            log("Pengaman dilewati (Force Sync): $reason")
            return
        }
        throw SyncGuardException(
            "SYNC DIBATALKAN (pengaman): $reason.\n" +
            "Kemungkinan spreadsheet gagal terbaca penuh / banyak baris terhapus. Tidak ada data yang diubah."
        )
    }

    // ═══════════════════════════════════════════════════════════════════
    // CSV
    // ═══════════════════════════════════════════════════════════════════

    /** CSV teks (kolom B = index 0, tanpa header) → baris ter-trim; baris kosong dibuang. */
    private fun parseBasedCsv(text: String): List<List<String>> =
        parseCsvRecords(text)
            .map { r -> r.map { it.trim() } }
            .filter { cols -> cols.any { it.isNotEmpty() } }

    /**
     * Parser CSV bergaya modul `csv` Python: tanda kutip ganda ("" = kutip), koma / baris baru
     * di dalam kutip tetap satu field (sel multi-baris), kutip di tengah field tak berkutip = literal.
     * Setiap baris fisik dihitung satu record (baris kosong = record kosong), supaya pelewatan
     * 5 baris pertama konsisten dengan Python.
     */
    internal fun parseCsvRecords(raw: String): List<List<String>> {
        val text = raw.removePrefix("\uFEFF")
        val records = ArrayList<List<String>>()
        var fields = ArrayList<String>()
        val cur = StringBuilder()
        var inQuotes = false
        var i = 0
        val n = text.length

        fun endRecord() {
            fields.add(cur.toString())
            cur.setLength(0)
            records.add(fields)
            fields = ArrayList()
        }

        while (i < n) {
            val ch = text[i]
            if (inQuotes) {
                if (ch == '"') {
                    if (i + 1 < n && text[i + 1] == '"') { cur.append('"'); i++ } else inQuotes = false
                } else cur.append(ch)
            } else {
                when (ch) {
                    '"' -> if (cur.isEmpty()) inQuotes = true else cur.append(ch)
                    ',' -> { fields.add(cur.toString()); cur.setLength(0) }
                    '\r' -> { if (i + 1 < n && text[i + 1] == '\n') i++; endRecord() }
                    '\n' -> endRecord()
                    else -> cur.append(ch)
                }
            }
            i++
        }
        if (cur.isNotEmpty() || fields.isNotEmpty()) endRecord()
        return records
    }
}
