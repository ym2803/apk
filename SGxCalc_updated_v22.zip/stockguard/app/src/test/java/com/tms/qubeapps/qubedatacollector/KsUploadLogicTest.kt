package com.tms.qubeapps.qubedatacollector

import com.tms.qubeapps.qubedatacollector.KsUploadLogic.Item
import org.junit.Assert.*
import org.junit.Test
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

class KsUploadLogicTest {

    @Test fun batchFingerprint_ignoresOrderAndCase() {
        val a = KsUploadLogic.batchFingerprint("cgar", "a01", listOf(Item("111", "2"), Item("222", "5")))
        val b = KsUploadLogic.batchFingerprint(" CGAR ", "A01 ", listOf(Item("222", "5"), Item("111", "2")))
        assertEquals(a, b)
    }

    @Test fun batchFingerprint_differentQtyIsDifferent() {
        assertNotEquals(
            KsUploadLogic.batchFingerprint("CGAR", "A01", listOf(Item("111", "2"))),
            KsUploadLogic.batchFingerprint("CGAR", "A01", listOf(Item("111", "3"))))
    }

    @Test fun rowFingerprint_sameScanSameKey_rescanDifferentTime() {
        val a = KsUploadLogic.rowFingerprint("CGAR", "A01", "111", "2", "2026-11-20 10:00:00")
        assertEquals(a, KsUploadLogic.rowFingerprint("cgar", "a01", "111", " 2", "2026-11-20 10:00:00"))
        assertNotEquals(a, KsUploadLogic.rowFingerprint("CGAR", "A01", "111", "2", "2026-11-20 10:05:00"))
    }

    @Test fun aggregate_sumsSameSku() {
        val m = KsUploadLogic.aggregate(listOf(Item("111", "2"), Item("222", ""), Item("111", "3")))
        assertEquals(5.0, m["111"]!!, 0.0); assertEquals(1.0, m["222"]!!, 0.0)
        assertEquals(listOf("111", "222"), m.keys.toList())
    }

    @Test fun networkErrorsAreRetryable() {
        assertTrue(KsUploadLogic.isRetryable(UnknownHostException("x")))
        assertTrue(KsUploadLogic.isRetryable(SocketTimeoutException()))
        assertTrue(KsUploadLogic.isRetryable(RuntimeException("wrap", IOException("down"))))
        assertTrue(KsUploadLogic.isRetryable(IOException("Empty response (HTTP 503)")))
    }

    @Test fun serverRejectionsAreNotRetryable() {
        assertFalse(KsUploadLogic.isRetryable(IllegalStateException("Invalid token")))
        assertFalse(KsUploadLogic.isRetryableMessage("Invalid token"))
        assertFalse(KsUploadLogic.isRetryableMessage("Empty response (HTTP 403)"))
        assertTrue(KsUploadLogic.isRetryableMessage("Empty response (HTTP 500)"))
        assertTrue(KsUploadLogic.isRetryableMessage("Empty response (HTTP 429)"))
    }

    @Test fun percent_isClamped() {
        assertEquals(0, KsUploadLogic.percent(0, 0))
        assertEquals(50, KsUploadLogic.percent(1, 2))
        assertEquals(100, KsUploadLogic.percent(9, 3))
    }

    @Test fun alreadyApplied_detectsPriorSuccessfulSend() {
        // sheet punya 4, kirim +3 → kalau sekarang 7, kiriman sebelumnya sudah masuk
        assertTrue(KsUploadLogic.alreadyApplied(true, 4.0, 3.0, 7.0))
        assertFalse(KsUploadLogic.alreadyApplied(true, 4.0, 3.0, 4.0))     // belum masuk
        assertFalse(KsUploadLogic.alreadyApplied(false, 4.0, 3.0, 7.0))    // bukan kirim ulang
        assertTrue(KsUploadLogic.alreadyApplied(true, null, 2.0, 2.0))     // baris baru sudah ada
    }
}
