package com.tms.qubeapps.qubedatacollector

import android.content.Context
import com.tms.qubeapps.qubedatacollector.KsUploadLogic.Group
import com.tms.qubeapps.qubedatacollector.Prefs.exioGid
import com.tms.qubeapps.qubedatacollector.Prefs.exioSpreadsheetId
import com.tms.qubeapps.qubedatacollector.Prefs.ksApiToken
import com.tms.qubeapps.qubedatacollector.Prefs.ksWebAppUrl

/**
 * ★ FIX (baru): satu-satunya jalur kirim Add Box → Keep Stock (Google Sheets), dipakai oleh
 * Data Collector, Keep Stock → View Data → ADD, dan antrean offline (PendingKsQueue).
 *
 * Per No Ctn: SKU yang SUDAH ada di No Ctn itu → qty ditambahkan ke baris yang ada (updateRow),
 * sisanya addRows (aturan sama seperti sebelumnya). Panggil dari Dispatchers.IO.
 *
 * Gangguan jaringan TIDAK dianggap gagal: grup yang belum terkirim dikembalikan di [Outcome.retry]
 * (untuk diantrekan). Kesalahan dari Web App (ok=false) dikembalikan di [Outcome.failed].
 */
object KsUploadEngine {

    data class Outcome(
        val sent: List<Group>,
        val retry: List<Group>,
        val failed: List<Pair<Group, String>>,
        val retryMessage: String?
    ) {
        val ok: Boolean get() = retry.isEmpty() && failed.isEmpty()
    }

    fun run(
        ctx: Context, store: String, groups: List<Group>,
        onProgress: (done: Int, total: Int, message: String) -> Unit
    ): Outcome {
        val url = ctx.ksWebAppUrl; val token = ctx.ksApiToken
        if (url.isBlank()) {
            return Outcome(emptyList(), emptyList(),
                groups.map { it to "Web App URL belum diisi (menu Keep Stock → Setting)" }, null)
        }
        val total = 1 + groups.size
        onProgress(0, total, "Memeriksa data Keep Stock…")

        // Data sheet terkini (untuk menggabungkan qty & mendeteksi kiriman yang sebelumnya sudah masuk).
        val ssid = ctx.exioSpreadsheetId(store); val gid = ctx.exioGid(store)
        var live: List<KeepStockSheetReader.KsRow> = emptyList()
        if (ssid.isNotBlank() && gid.isNotBlank()) {
            try { live = KeepStockSheetReader.fetchRows(ssid, gid) }
            catch (e: Exception) {
                // Jaringan putus: JANGAN kirim buta (bisa dobel) — antrekan semuanya.
                if (KsUploadLogic.isRetryable(e)) return Outcome(emptyList(), groups, emptyList(), e.message ?: "Jaringan tidak tersedia")
                live = emptyList()   // gagal baca non-jaringan: perilaku lama (tetap kirim)
            }
        }
        onProgress(1, total, "Data Keep Stock dimuat")

        val sent = ArrayList<Group>(); val failed = ArrayList<Pair<Group, String>>()
        for ((idx, g) in groups.withIndex()) {
            onProgress(1 + idx, total, "Mengirim No Ctn ${g.noCtn} (${idx + 1}/${groups.size})…")
            val agg = KsUploadLogic.aggregate(g.items)
            val base = HashMap<String, Double>()
            var applied = 0
            try {
                val toAdd = mutableListOf<Pair<String, String>>()
                // Pass 1: tentukan aksi + catat qty awal tiap SKU (untuk kirim ulang yang aman).
                val merges = ArrayList<Pair<KeepStockSheetReader.KsRow, Double>>()
                agg.forEach { (sku, add) ->
                    val hits = live.filter { it.noCtn.trim().equals(g.noCtn.trim(), ignoreCase = true) && it.sku.trim() == sku }
                    val current = hits.sumOf { KeepStockAddGuard.qtyOf(it) }
                    if (hits.isNotEmpty()) base[sku] = current
                    if (KsUploadLogic.alreadyApplied(g.attempted, g.base[sku], add, current)) return@forEach  // sudah masuk
                    if (hits.isEmpty()) toAdd.add(sku to KeepStockAddGuard.fmt(add))
                    else merges.add(hits.first() to add)
                }
                for ((row, add) in merges) {
                    val r = KeepStockGasClient.updateRow(url, token, store, row.rowNumber, row.noCtn, row.sku,
                        KeepStockAddGuard.fmt(KeepStockAddGuard.qtyOf(row) + add))
                    requireOk(r); applied++
                }
                if (toAdd.isNotEmpty()) {
                    requireOk(KeepStockGasClient.addRows(url, token, store, g.noCtn, toAdd)); applied += toAdd.size
                }
                sent.add(g)
            } catch (e: Exception) {
                if (KsUploadLogic.isRetryable(e)) {
                    // Hasil kiriman terakhir tidak pasti → tandai attempted + qty awal; sisa grup ikut diantrekan.
                    val pending = ArrayList<Group>()
                    pending.add(g.copy(attempted = true, base = g.base + base))
                    pending.addAll(groups.drop(idx + 1))
                    return Outcome(sent, pending, failed, e.message ?: "Jaringan terputus")
                }
                val note = if (applied > 0) "\n(Sebagian SKU mungkin sudah masuk — cek data Keep Stock sebelum kirim ulang.)" else ""
                failed.add(g to "${g.noCtn}: ${e.message ?: e.javaClass.simpleName}$note")
            }
        }
        onProgress(total, total, "Selesai")
        return Outcome(sent, emptyList(), failed, null)
    }

    /** Lempar exception kalau respons Web App bukan ok (retryable bila HTTP 5xx/429/timeout). */
    private fun requireOk(r: org.json.JSONObject) {
        if (r.optBoolean("ok", false)) return
        val msg = r.optString("error", "Unknown error")
        if (KsUploadLogic.isRetryableMessage(msg)) throw java.io.IOException(msg)
        throw IllegalStateException(msg)
    }
}
