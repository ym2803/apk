package com.tms.qubeapps.qubedatacollector

import android.content.Context
import com.tms.qubeapps.qubedatacollector.Prefs.smbDomain
import com.tms.qubeapps.qubedatacollector.Prefs.smbPass
import com.tms.qubeapps.qubedatacollector.Prefs.smbUser
import org.json.JSONObject
import java.io.File

/**
 * ★ FIX (baru): antrean upload SMB yang tahan jaringan putus.
 *
 * SEBELUMNYA: kalau WiFi/server tidak terjangkau (mis. EHOSTUNREACH "No route to host"), Upload to PC langsung
 * menampilkan "Upload failed" dan user harus menekan ulang manual.
 * SEKARANG: untuk gangguan JARINGAN, file TXT disimpan dulu di penyimpanan internal aplikasi (folder "pending_smb"),
 * lalu dikirim otomatis begitu jaringan/server kembali terjangkau (lihat flush()).
 * Kesalahan KONFIGURASI (user/password salah, share tidak ada, path kosong) tetap langsung ditampilkan.
 *
 * Satu item = <id>.txt (isi, sudah dibersihkan) + <id>.json (tujuan SMB path & nama file). Password TIDAK disimpan;
 * saat kirim ulang dipakai user/password terbaru dari Setting. Aman bila aplikasi ditutup: file tetap ada.
 */
object PendingSmbQueue {

    data class FlushResult(val sent: Int, val remaining: Int, val lastError: String?)

    private val lock = Any()
    @Volatile private var flushing = false

    private fun dir(ctx: Context): File = File(ctx.filesDir, "pending_smb").apply { mkdirs() }

    private fun metaFiles(ctx: Context): List<File> =
        (dir(ctx).listFiles { f -> f.name.endsWith(".json") } ?: emptyArray()).sortedBy { it.name }

    fun count(ctx: Context): Int = metaFiles(ctx).size

    /** ★ FIX (baru): jumlah file pending untuk SATU mode Data Collector, dibaca dari kode di nama file
     *  (…_05_… = Shelf Record, …_04_… = Stock Take / Add Box) — supaya notice tidak muncul di menu lain. */
    fun countForMode(ctx: Context, mode: String): Int {
        val tag = if (mode == "SHELF_RECORD") "_05_" else "_04_"
        return metaFiles(ctx).count { m ->
            try { JSONObject(m.readText(Charsets.UTF_8)).optString("name").contains(tag) } catch (e: Exception) { false }
        }
    }

    /** Kesalahan yang berarti PENGATURAN salah (bukan jaringan) — jangan di-pending, tampilkan ke user. */
    fun isConfigError(e: Exception): Boolean {
        val m = e.message ?: return false
        return m.startsWith("Authentication failed") ||
               m.startsWith("Unable to access share") ||
               m.contains("SMB Path is not set") || m.contains("SMB Path is empty") ||
               m.contains("Invalid SMB") // salah format path
    }

    fun enqueue(ctx: Context, smbPath: String, fileName: String, content: String) {
        synchronized(lock) {
            val id = "${System.currentTimeMillis()}_${Integer.toHexString(fileName.hashCode())}"
            File(dir(ctx), "$id.txt").writeText(content, Charsets.UTF_8)
            // meta ditulis terakhir: item baru dianggap ada hanya bila meta sudah lengkap
            File(dir(ctx), "$id.json").writeText(
                JSONObject().put("path", smbPath).put("name", fileName).toString(), Charsets.UTF_8)
        }
    }

    /**
     * Kirim semua item pending (terlama dulu). Berhenti di kegagalan pertama karena jaringan masih bermasalah.
     * Panggil dari Dispatchers.IO. Aman dipanggil bersamaan: panggilan yang kedua langsung dilewati.
     */
    fun flush(ctx: Context): FlushResult {
        if (flushing) return FlushResult(0, count(ctx), null)
        synchronized(lock) {
            if (flushing) return FlushResult(0, count(ctx), null)
            flushing = true
        }
        var sent = 0; var lastError: String? = null
        try {
            for (meta in metaFiles(ctx)) {
                val txt = File(meta.parentFile, meta.name.removeSuffix(".json") + ".txt")
                try {
                    val j = JSONObject(meta.readText(Charsets.UTF_8))
                    if (!txt.exists()) { meta.delete(); continue }           // sisa rusak: buang
                    SmbUploader.upload(j.getString("path"), ctx.smbUser, ctx.smbPass,
                        j.getString("name"), txt.readText(Charsets.UTF_8), ctx.smbDomain)
                    txt.delete(); meta.delete(); sent++
                } catch (e: Exception) {
                    lastError = e.message ?: e.javaClass.simpleName
                    break                                                     // jaringan masih bermasalah: coba lagi nanti
                }
            }
        } finally { flushing = false }
        return FlushResult(sent, count(ctx), lastError)
    }
}
