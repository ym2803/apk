package com.tms.qubeapps.qubedatacollector

import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkRequest
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * ★ FIX (baru): auto-sync antrean upload Keep Stock. Selama layar terbuka & ada antrean:
 * kirim ulang otomatis begitu jaringan tersedia (NetworkCallback) + coba lagi tiap 20 detik.
 * [onChanged] dipanggil setelah tiap percobaan (perbarui banner / muat ulang data).
 */
class KsQueueWatcher(
    private val act: AppCompatActivity,
    private val onChanged: (PendingKsQueue.FlushResult?) -> Unit
) {
    private var job: Job? = null
    private var cb: ConnectivityManager.NetworkCallback? = null

    fun start() {
        if (PendingKsQueue.count(act) == 0) { onChanged(null); return }
        if (cb == null) {
            try {
                val cm = act.getSystemService(android.content.Context.CONNECTIVITY_SERVICE) as ConnectivityManager
                val c = object : ConnectivityManager.NetworkCallback() {
                    override fun onAvailable(network: Network) {
                        act.window?.decorView?.postDelayed({ if (!act.isFinishing && !act.isDestroyed) flushNow(false) }, 1500)
                    }
                }
                cm.registerNetworkCallback(
                    NetworkRequest.Builder().addCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET).build(), c)
                cb = c
            } catch (_: Exception) { /* tetap ada timer di bawah */ }
        }
        if (job?.isActive == true) return
        job = act.lifecycleScope.launch(Safe.handler) {
            while (isActive && PendingKsQueue.count(act) > 0) { delay(20_000); flushNow(false) }
            stop()
        }
    }

    fun stop() {
        job?.cancel(); job = null
        cb?.let { try { (act.getSystemService(android.content.Context.CONNECTIVITY_SERVICE) as ConnectivityManager).unregisterNetworkCallback(it) } catch (_: Exception) {} }
        cb = null
    }

    /** manual = dari tombol "Kirim sekarang": tampilkan progress dialog + hasilnya. */
    fun flushNow(manual: Boolean) {
        if (PendingKsQueue.count(act) == 0) { onChanged(null); return }
        val pd = if (manual) UploadProgressDialog(act, "Mengirim antrean Keep Stock").show() else null
        act.lifecycleScope.launch(Safe.handler) {
            val r = withContext(Dispatchers.IO) {
                PendingKsQueue.flush(act) { d, t, m -> pd?.update(KsUploadLogic.percent(d, t), m) }
            }
            onChanged(r)
            if (r.failures.isNotEmpty()) {
                val msg = r.failures.joinToString("\n\n")
                if (pd != null) pd.finish(UploadProgressDialog.State.FAILED, "Sebagian gagal", msg)
                else android.app.AlertDialog.Builder(act).setTitle("Upload Keep Stock gagal").setMessage(msg).setPositiveButton("OK", null).show()
            } else if (pd != null) {
                if (r.remaining == 0) pd.finish(UploadProgressDialog.State.SUCCESS, "Antrean terkirim", "${r.sentItems} antrean berhasil dikirim ke Google Sheets.")
                else pd.finish(UploadProgressDialog.State.QUEUED, "Belum terkirim",
                    "Jaringan/server belum terjangkau. ${r.remaining} antrean tetap tersimpan dan akan dicoba lagi otomatis.\n\n${r.lastError ?: ""}")
            } else if (r.sentItems > 0) {
                Toast.makeText(act, "${r.sentItems} upload tertunda terkirim ke Google Sheets" +
                    if (r.remaining > 0) " — ${r.remaining} masih menunggu" else "", Toast.LENGTH_LONG).show()
            }
        }
    }
}
