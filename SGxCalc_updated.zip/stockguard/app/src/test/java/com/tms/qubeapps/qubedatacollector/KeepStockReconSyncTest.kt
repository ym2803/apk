package com.tms.qubeapps.qubedatacollector

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Unit test mode STATUS SHEET (port reconcile_ks_master di Exiov2.py): kolom BM=63, BN=64, BQ=67. */
class KeepStockReconSyncTest {

    private fun row(sku: String, bn: String, status: String, width: Int = 68): List<String> =
        MutableList(width) { "" }.also { it[63] = sku; it[64] = bn; it[67] = status }

    private fun run(vararg rows: List<String>) = KeepStockReconSync.computeByStatus(rows.toList(), "TOKO")

    @Test
    fun `Belum Excel In menghasilkan BN4,SKU dan SKU,1`() {
        val r = run(row("1001", "A012345", "SKU Belum Excel In"))
        assertEquals("A012,1001", r.file1)
        assertEquals("1001,1", r.file2)
        assertEquals(1, r.belumExcelIn.size)
        assertEquals("A012345", r.belumExcelIn[0].noCtn)   // kode penuh untuk laporan
    }

    @Test
    fun `Belum Excel Out menghasilkan ,SKU dan SKU,3`() {
        val r = run(row("1001", "A01", "SKU Belum Excel Out"))
        assertEquals(",1001", r.file3)
        assertEquals("1001,3", r.file4)
        assertTrue(r.file1.isEmpty())
    }

    @Test
    fun `SKU di-uppercase dan duplikat BN dan SKU dibuang, BN berbeda tetap dihitung`() {
        val r = run(
            row("ab12", "A01", "SKU Belum Excel In"),
            row("AB12", "A01", "SKU Belum Excel In"),   // duplikat
            row("AB12", "A02", "SKU Belum Excel In")    // BN beda → tetap
        )
        assertEquals("A01,AB12\r\nA02,AB12", r.file1)
        assertEquals(2, r.belumExcelIn.size)
    }

    @Test
    fun `Status lain, SKU kosong, dan baris pendek diabaikan`() {
        val r = run(
            row("1001", "A01", "OK"),
            row("", "A01", "SKU Belum Excel In"),
            row("1002", "A01", ""),
            List(10) { "" }
        )
        assertTrue(r.file1.isEmpty() && r.file3.isEmpty())
        assertTrue(r.log.any { it.contains("diabaikan") })
    }

    @Test
    fun `Laporan memuat jumlah dan baris SKU`() {
        val r = run(row("1001", "A01", "SKU Belum Excel In"), row("2002", "B01", "SKU Belum Excel Out"))
        assertTrue(r.report.contains("[SKU BELUM EXCEL IN]  (total: 1)"))
        assertTrue(r.report.contains("[SKU BELUM EXCEL OUT]  (total: 1)"))
        assertTrue(r.report.contains("SKU: 1001"))
    }
}
