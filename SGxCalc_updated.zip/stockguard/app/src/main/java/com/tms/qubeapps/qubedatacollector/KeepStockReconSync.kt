package com.tms.qubeapps.qubedatacollector

/**
 * ★ FIX (Menu 4 — Keep Stock, Sync Recon): rekonsiliasi Data Keep Stock
 * (kolom B/C, dari Google Sheet) vs Data Master (dari lokal SQLite/02,
 * tabel T_CATALOG hasil download 02.txt), terpisah dari Sync Exio
 * (ExInOutSync.kt) tapi menghasilkan format file TXT yang SAMA, sehingga
 * bisa dipakai sebagai cara alternatif untuk menghasilkan 4 file yang sama
 * (EXCEL IN/OUT BOX, PRINT IN/OUT LABEL).
 *
 * ═══════════════════════════════════════════════════════════════════════
 * MAPPING KOLOM
 * ═══════════════════════════════════════════════════════════════════════
 *   Keep Stock (gsheet, relatif thd range fetch "B6:C2000", kolom B = index 0):
 *                No Ctn = kolom B (index 0), SKU = kolom C (index 1)
 *   Data Master (lokal SQLite/02, T_CATALOG — kolom FIXED 1-based dari 02.txt):
 *                SKU = kolom 1, Rack = kolom 2,
 *                No Ctn = kolom 22, Deskripsi = kolom 4
 *
 * ═══════════════════════════════════════════════════════════════════════
 * NORMALISASI
 * ═══════════════════════════════════════════════════════════════════════
 *   SKU   : toString().trim().toUpperCase()
 *   No Ctn: toString().trim().toUpperCase().substring(0, min(4, length))
 *
 * ═══════════════════════════════════════════════════════════════════════
 * VALIDASI
 * ═══════════════════════════════════════════════════════════════════════
 *   Baris dibuang kalau SKU kosong ATAU No Ctn kosong (setelah normalisasi).
 *
 * ═══════════════════════════════════════════════════════════════════════
 * STRUKTUR DATA (WAJIB O(n) — tanpa includes/filter berulang di loop besar)
 * ═══════════════════════════════════════════════════════════════════════
 *   keepKeySet, masterKeySet : Set<"SKU|NOCTN4">
 *   keepSkuMap, masterSkuMap : Map<SKU, Set<NOCTN4>>
 *   masterInfoMap            : Map<"SKU|NOCTN4", MasterInfo(rack, desc)>
 *
 * ═══════════════════════════════════════════════════════════════════════
 * LOGIKA REKONSILIASI
 * ═══════════════════════════════════════════════════════════════════════
 *   A. "SKU Belum Excel In" : KEY ada di Keep Stock, tidak ada di Master,
 *                             dan bukan bagian dari relasi "Pindah" (lihat C).
 *   B. "SKU Belum Excel Out": KEY ada di Master, tidak ada di Keep Stock,
 *                             DAN SKU-nya sudah tidak ada di No Ctn manapun
 *                             pada Keep Stock -> baru boleh masuk OUT.
 *                             Kalau SKU masih ada di Keep Stock (Ctn lain)
 *                             -> "SKU Aktif" atau "SKU Pindah No Ctn",
 *                             TIDAK masuk OUT.
 *   C. "SKU Pindah No Ctn"  : SKU ada di kedua data tapi No Ctn beda, dan
 *                             cuma ada 1 kandidat lokasi baru (1:1 move).
 *                             Kalau SKU sama muncul di >1 No Ctn Keep Stock
 *                             (ambigu, tidak jelas "pindah ke mana"), dipakai
 *                             label "SKU Aktif" sebagai fallback yang lebih
 *                             aman. Keduanya cuma informasi, TIDAK diexport.
 *
 * RULE FINAL: OUT hanya terjadi kalau KEY hilang dari Keep Stock DAN SKU
 * sudah tidak py relasi aktif di No Ctn manapun pada Keep Stock. Evaluasi
 * dari snapshot akhir (Keep Stock vs Master saat ini), bukan histori.
 */
object KeepStockReconSync {

    // ★ FIX: sheet sekarang diambil UTUH lewat ExInOutSync.fetchSheetRows() (tanpa batas 2000 baris,
    // retry, tanpa cache, CSV multi-baris) — baris sudah B-based (kolom B = index 0).

    // ── Mode STATUS SHEET (port reconcile_ks_master di Exiov2.py) ────────────
    private const val BM_COL_INDEX = 63   // SKU
    private const val BN_COL_INDEX = 64   // No Ctn / Box
    private const val BQ_COL_INDEX = 67   // Status rekonsiliasi
    const val STATUS_BELUM_IN = "SKU Belum Excel In"
    const val STATUS_BELUM_OUT = "SKU Belum Excel Out"

    // Index relatif terhadap kolom B (index 0) dalam CSV hasil fetch Keep Stock
    private const val KEEP_NOCTN_IDX   = 0   // B
    private const val KEEP_SKU_IDX     = 1   // C

    data class MasterInfo(val rack: String, val desc: String)

    data class ReconRecord(val sku: String, val noCtn: String, val note: String = "")

    data class ReconResult(
        val store: String,
        val belumExcelIn: List<ReconRecord>,
        val belumExcelOut: List<ReconRecord>,
        val pindahNoCtn: List<ReconRecord>,
        val skuAktif: List<ReconRecord>,
        val file1: String, // EXCEL IN BOX.txt
        val file2: String, // +PRINT IN LABEL.txt
        val file3: String, // EXCEL OUT BOX.txt
        val file4: String, // -PRINT OUT LABEL.txt
        val log: List<String>,
        /** Teks "RECON REPORT <toko>.txt" (hanya mode status sheet). Kosong = tidak ada. */
        val report: String = ""
    )

    /**
     * ★ MODE STATUS SHEET — port reconcile_ks_master() (Exiov2.py).
     * Membaca status per-baris yang SUDAH ada di sheet: kolom BM (SKU), BN (No Ctn/Box),
     * BQ (status). Tidak memakai data Master 02.
     *   BQ = "SKU Belum Excel In"  → EXCEL IN BOX "BN[0..4],SKU"  +  PRINT IN LABEL "SKU,1"
     *   BQ = "SKU Belum Excel Out" → EXCEL OUT BOX ",SKU"         +  PRINT OUT LABEL "SKU,3"
     * Duplikat (BN|SKU) per status dibuang; SKU di-uppercase; baris tanpa SKU/status dilewati.
     * Harus dipanggil dari Dispatchers.IO.
     */
    fun syncByStatus(spreadsheetId: String, gid: String, store: String,
                     onStatus: ((String) -> Unit)? = null): ReconResult {
        val rows = ExInOutSync.fetchSheetRows(spreadsheetId, gid, onStatus)
        return computeByStatus(rows, store)
    }

    /** Bagian murni (bisa di-unit-test): rows B-based dari fetchSheetRows(). */
    internal fun computeByStatus(rows: List<List<String>>, store: String): ReconResult {
        val log = mutableListOf("Total baris data terbaca: ${rows.size}")
        val out1 = mutableListOf<String>(); val out2 = mutableListOf<String>()
        val out3 = mutableListOf<String>(); val out4 = mutableListOf<String>()
        val seenIn = HashSet<String>(); val seenOut = HashSet<String>()
        val inList = mutableListOf<ReconRecord>(); val outList = mutableListOf<ReconRecord>()
        var skipped = 0

        for (cols in rows) {
            if (cols.size <= BQ_COL_INDEX) continue
            val bmRaw = cols[BM_COL_INDEX].trim()
            val bnRaw = cols[BN_COL_INDEX].trim()
            val bqRaw = cols[BQ_COL_INDEX].trim()
            val sku = bmRaw.uppercase()
            if (sku.isEmpty() || bqRaw.isEmpty()) {
                if (bmRaw.isNotEmpty() || bqRaw.isNotEmpty()) skipped++
                continue
            }
            when (bqRaw) {
                STATUS_BELUM_IN -> {
                    if (!seenIn.add("$bnRaw|$sku")) continue
                    out1.add("${bnRaw.take(4)},$sku"); out2.add("$sku,1")
                    inList.add(ReconRecord(sku, bnRaw))
                }
                STATUS_BELUM_OUT -> {
                    if (!seenOut.add("$bnRaw|$sku")) continue
                    out3.add(",$sku"); out4.add("$sku,3")
                    outList.add(ReconRecord(sku, bnRaw))
                }
            }
        }
        if (skipped > 0) log.add("Baris diabaikan (SKU/status kosong/tidak valid): $skipped")
        log.add(if (inList.isNotEmpty()) "RECON IN  OK: ${inList.size} SKU ('$STATUS_BELUM_IN')"
                else "RECON IN  - tidak ada SKU '$STATUS_BELUM_IN', FILE1 & FILE2 dikosongkan")
        log.add(if (outList.isNotEmpty()) "RECON OUT OK: ${outList.size} SKU ('$STATUS_BELUM_OUT')"
                else "RECON OUT - tidak ada SKU '$STATUS_BELUM_OUT', FILE3 & FILE4 dikosongkan")
        log.add("RINGKASAN RECON -> Belum Excel In:${inList.size}  Belum Excel Out:${outList.size}")

        return ReconResult(
            store = store,
            belumExcelIn = inList, belumExcelOut = outList,
            pindahNoCtn = emptyList(), skuAktif = emptyList(),
            file1 = out1.joinToString("\r\n"), file2 = out2.joinToString("\r\n"),
            file3 = out3.joinToString("\r\n"), file4 = out4.joinToString("\r\n"),
            log = log,
            report = buildReport(store, inList, outList)
        )
    }

    /** Port write_recon_report(): isi file "RECON REPORT <toko>.txt". */
    private fun buildReport(store: String, ins: List<ReconRecord>, outs: List<ReconRecord>): String {
        val sdf = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US)
        val lines = mutableListOf<String>()
        lines.add("=".repeat(70))
        lines.add("LAPORAN REKONSILIASI SYNC RECON (Kolom BM/BN/BQ) - $store")
        lines.add("Waktu: ${sdf.format(java.util.Date())}")
        lines.add("=".repeat(70))
        for ((title, items) in listOf("SKU BELUM EXCEL IN" to ins, "SKU BELUM EXCEL OUT" to outs)) {
            lines.add("")
            lines.add("[$title]  (total: ${items.size})")
            if (items.isEmpty()) lines.add("    (tidak ada)")
            else items.sortedWith(compareBy({ it.sku }, { it.noCtn })).forEach {
                lines.add("    SKU: ${it.sku.padEnd(12)} No Ctn/Box: ${it.noCtn.padEnd(10)}")
            }
        }
        lines.add("")
        lines.add("=".repeat(70))
        return lines.joinToString("\n")
    }

    /**
     * Harus dipanggil dari Dispatchers.IO — melakukan network call (Keep Stock,
     * gsheet) dan query lokal (Data Master, SQLite/02 — T_CATALOG).
     *
     * @param db AppDatabase lokal, sumber Data Master (menggantikan fetch
     *           Master dari Google Sheet). Mapping kolom: SKU=1, Rack=2,
     *           Deskripsi=4, No Ctn=22 (lihat AppDatabase.CatalogRow.masterRack/
     *           masterDesc/masterNoCtn, diisi oleh ShelfPriceEnquireActivity
     *           saat parsing 02.txt).
     */
    fun sync(db: AppDatabase, spreadsheetId: String, gid: String, store: String,
             onStatus: ((String) -> Unit)? = null): ReconResult {
        val log = mutableListOf<String>()
        fun logLine(s: String) { log.add(s) }

        // ── 1. Load Data Keep Stock (gsheet, kolom B/C) ──────────────────
        val keepRows = ExInOutSync.fetchSheetRows(spreadsheetId, gid, onStatus)
        logLine("Total baris Keep Stock (sheet): ${keepRows.size}")
        onStatus?.invoke("Reading Master data (02) from this phone...")

        // ── 2. Load Data Master (lokal SQLite/02 — T_CATALOG) ────────────
        val masterRows = db.getAllCatalogRows()
        logLine("Total baris Data Master (lokal 02): ${masterRows.size}")

        // ── 3. Normalisasi ────────────────────────────────────────────────
        fun normSku(v: String) = v.trim().uppercase()
        fun normCtn4(v: String): String {
            val t = v.trim().uppercase()
            return if (t.length <= 4) t else t.substring(0, 4)
        }

        // ── 5. Struktur data O(n) ────────────────────────────────────────
        val keepKeySet = HashSet<String>()
        val masterKeySet = HashSet<String>()
        val keepSkuMap = HashMap<String, LinkedHashSet<String>>()
        val masterSkuMap = HashMap<String, LinkedHashSet<String>>()
        val masterInfoMap = HashMap<String, MasterInfo>()

        var keepValid = 0; var keepInvalid = 0
        var masterValid = 0; var masterInvalid = 0

        // ── 4a. Keep Stock: buang row invalid + build Set/Map (1 pass) ────
        for (cols in keepRows) {
            // Keep Stock (B, C)
            val rawKeepCtn = cols.getOrNull(KEEP_NOCTN_IDX)?.trim().orEmpty()
            val rawKeepSku = cols.getOrNull(KEEP_SKU_IDX)?.trim().orEmpty()
            if (rawKeepSku.isBlank() || rawKeepCtn.isBlank()) {
                if (rawKeepSku.isNotBlank() || rawKeepCtn.isNotBlank()) keepInvalid++
            } else {
                val sku = normSku(rawKeepSku)
                val ctn4 = normCtn4(rawKeepCtn)
                keepKeySet.add("$sku|$ctn4")
                keepSkuMap.getOrPut(sku) { LinkedHashSet() }.add(ctn4)
                keepValid++
            }
        }

        // ── 4b. Data Master (lokal SQLite/02): SKU=kolom1, Rack=kolom2,
        //        Deskripsi=kolom4, No Ctn=kolom22 (field masterRack/masterDesc/
        //        masterNoCtn sudah diisi FIXED saat parsing 02.txt) ─────────
        for (row in masterRows) {
            val rawMasterSku = row.sku.trim()
            val rawMasterCtn = row.masterNoCtn.trim()
            if (rawMasterSku.isBlank() || rawMasterSku == "-" || rawMasterCtn.isBlank() || rawMasterCtn == "-") {
                if ((rawMasterSku.isNotBlank() && rawMasterSku != "-") ||
                    (rawMasterCtn.isNotBlank() && rawMasterCtn != "-")) masterInvalid++
            } else {
                val sku = normSku(rawMasterSku)
                val ctn4 = normCtn4(rawMasterCtn)
                val key = "$sku|$ctn4"
                masterKeySet.add(key)
                masterSkuMap.getOrPut(sku) { LinkedHashSet() }.add(ctn4)
                masterInfoMap[key] = MasterInfo(
                    rack = row.masterRack.trim(),
                    desc = row.masterDesc.trim()
                )
                masterValid++
            }
        }
        logLine("Keep Stock: $keepValid valid, $keepInvalid invalid dilewati")
        logLine("Master    : $masterValid valid, $masterInvalid invalid dilewati")

        // ── 6. Rekonsiliasi ────────────────────────────────────────────────
        val movedKeepKeys = HashSet<String>()   // key sisi Keep yg sudah dihitung sbg Pindah -> exclude dari "Belum Excel In"
        val belumInList = mutableListOf<ReconRecord>()
        val belumOutList = mutableListOf<ReconRecord>()
        val pindahList = mutableListOf<ReconRecord>()
        val aktifList = mutableListOf<ReconRecord>()
        val dedupeSeen = HashSet<String>() // ★ FIX (poin 7): STATUS|SKU|NOCTN

        // B & C: iterasi masterKeySet -> cari yang tidak match di keepKeySet
        for (mKey in masterKeySet) {
            if (mKey in keepKeySet) continue // exact match, tidak perlu diproses lebih lanjut
            val parts = mKey.split("|", limit = 2)
            if (parts.size != 2) continue
            val sku = parts[0]
            val masterCtn = parts[1]
            val keepCtnsForSku = keepSkuMap[sku]

            if (keepCtnsForSku.isNullOrEmpty()) {
                // Case B: SKU sudah tidak ada di No Ctn manapun pada Keep Stock -> OUT
                val dkey = "OUT|$sku|$masterCtn"
                if (dedupeSeen.add(dkey)) belumOutList.add(ReconRecord(sku, masterCtn))
            } else {
                // SKU masih ada di Keep Stock (Ctn lain) -> TIDAK boleh OUT
                movedKeepKeys.addAll(keepCtnsForSku.map { "$sku|$it" })
                if (keepCtnsForSku.size == 1) {
                    // Case C: 1:1 move -> "SKU Pindah No Ctn"
                    val toCtn = keepCtnsForSku.first()
                    val dkey = "PINDAH|$sku|$toCtn"
                    if (dedupeSeen.add(dkey)) pindahList.add(ReconRecord(sku, toCtn, "dari $masterCtn"))
                } else {
                    // SKU ada di >1 Ctn Keep Stock, ambigu -> "SKU Aktif" (tetap bukan OUT)
                    val dkey = "AKTIF|$sku|$masterCtn"
                    if (dedupeSeen.add(dkey)) aktifList.add(ReconRecord(sku, masterCtn, "aktif di: ${keepCtnsForSku.joinToString(",")}"))
                }
            }
        }

        // A: iterasi keepKeySet -> cari yang tidak match di masterKeySet, DAN bukan bagian dari Pindah
        for (kKey in keepKeySet) {
            if (kKey in masterKeySet) continue
            if (kKey in movedKeepKeys) continue
            val parts = kKey.split("|", limit = 2)
            if (parts.size != 2) continue
            val sku = parts[0]
            val ctn = parts[1]
            val dkey = "IN|$sku|$ctn"
            if (dedupeSeen.add(dkey)) belumInList.add(ReconRecord(sku, ctn))
        }

        logLine("SKU Belum Excel In : ${belumInList.size}")
        logLine("SKU Belum Excel Out: ${belumOutList.size}")
        logLine("SKU Pindah No Ctn  : ${pindahList.size} (info only, tidak diexport)")
        logLine("SKU Aktif          : ${aktifList.size} (info only, tidak diexport)")

        // ── 8. Export TXT (Set untuk unik SKU per file, format sama seperti Sync Exio) ──
        val inSkuSet = LinkedHashSet<String>()
        val out1 = mutableListOf<String>()
        val out2 = mutableListOf<String>()
        for (r in belumInList) {
            if (inSkuSet.add(r.sku)) {
                out1.add("${r.noCtn},${r.sku}")
                out2.add("${r.sku},1")
            }
        }

        val outSkuSet = LinkedHashSet<String>()
        val out3 = mutableListOf<String>()
        val out4 = mutableListOf<String>()
        for (r in belumOutList) {
            if (outSkuSet.add(r.sku)) {
                out3.add(",${r.sku}")
                out4.add("${r.sku},3")
            }
        }

        // ── 9. Return hasil rekonsiliasi ───────────────────────────────────
        return ReconResult(
            store = store,
            belumExcelIn = belumInList,
            belumExcelOut = belumOutList,
            pindahNoCtn = pindahList,
            skuAktif = aktifList,
            file1 = out1.joinToString("\r\n"),
            file2 = out2.joinToString("\r\n"),
            file3 = out3.joinToString("\r\n"),
            file4 = out4.joinToString("\r\n"),
            log = log
        )
    }
}
