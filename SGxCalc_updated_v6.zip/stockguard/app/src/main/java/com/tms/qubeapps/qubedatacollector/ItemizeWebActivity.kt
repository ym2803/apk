package com.tms.qubeapps.qubedatacollector

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.ContentValues
import android.content.Context
import android.content.IntentFilter
import android.widget.EditText
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.webkit.ServiceWorkerClientCompat
import androidx.webkit.ServiceWorkerControllerCompat
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewFeature
import com.tms.qubeapps.qubedatacollector.Prefs.itemizeApiUrl
import com.tms.qubeapps.qubedatacollector.Prefs.itemizeScanAction
import com.tms.qubeapps.qubedatacollector.Prefs.itemizeScanExtra
import java.io.File

/**
 * Menjalankan aplikasi web Itemized (assets/itemize/index.html + sw.js) di dalam WebView.
 * Halaman dimuat lewat WebViewAssetLoader (https://appassets.androidplatform.net) supaya
 * menjadi "secure context": kamera, service worker (offline) & localStorage berfungsi penuh.
 * Fungsi native yang dijembatani: URL Google Sheet, izin kamera, pilih file (upload Excel/CSV/TXT),
 * simpan hasil Excel/CSV ke Downloads, dan buka link Google Sheet di browser.
 */
class ItemizeWebActivity : BaseActivity() {

    private lateinit var web: WebView
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var pendingPerm: PermissionRequest? = null
    private var scanReceiver: BroadcastReceiver? = null

    /** Preset broadcast scanner populer: action -> daftar nama extra yang berisi teks barcode. */
    private val presetScan = linkedMapOf(
        "com.symbol.datawedge.RESULT" to listOf("com.symbol.datawedge.data_string"),
        "com.symbol.datawedge.api.RESULT_ACTION" to listOf("com.symbol.datawedge.data_string"),
        "android.intent.ACTION_DECODE_DATA" to listOf("barcode_string", "barcode"),
        "nlscan.action.SCANNER_RESULT" to listOf("SCAN_BARCODE1"),
        "com.honeywell.decode.intent.action.SCAN_RESULT" to listOf("data", "scanData"),
        "com.android.server.scannerservice.broadcast" to listOf("scannerdata"),
        "scan.rcv.message" to listOf("barocode", "barcode"),
        "com.rscja.scanner.action.SCANNER_RESULT" to listOf("SCAN_BARCODE1", "barcode"),
        "com.sunmi.scanner.ACTION_DATA_CODE_RECEIVED" to listOf("data"),
        "com.zebra.scan.RESULT" to listOf("com.symbol.datawedge.data_string")
    )
    private val genericExtras = listOf("data", "barcode", "barcode_string", "scandata", "scannerdata",
        "SCAN_BARCODE1", "scan_result", "result", "text", "com.symbol.datawedge.data_string")

    private val pickFile = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data
        val uris: Array<Uri>? = if (r.resultCode == RESULT_OK && data != null) {
            val clip = data.clipData
            when {
                clip != null -> Array(clip.itemCount) { clip.getItemAt(it).uri }
                data.data != null -> arrayOf(data.data!!)
                else -> null
            }
        } else null
        fileCallback?.onReceiveValue(uris); fileCallback = null
    }

    private val askCamera = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        val req = pendingPerm; pendingPerm = null
        if (req != null) {
            if (granted) req.grant(arrayOf(PermissionRequest.RESOURCE_VIDEO_CAPTURE)) else req.deny()
        }
        if (!granted) Toast.makeText(this, "Izin kamera ditolak. Scanner USB/Bluetooth dan ketik manual tetap bisa dipakai.", Toast.LENGTH_LONG).show()
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        web = WebView(this)
        web.isFocusable = true
        web.isFocusableInTouchMode = true
        setContentView(web)
        web.requestFocus()

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false
            allowContentAccess = false
            cacheMode = WebSettings.LOAD_DEFAULT
        }
        web.addJavascriptInterface(Bridge(), "AndroidItemize")

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url
                if (u.host == WebViewAssetLoader.DEFAULT_DOMAIN) return false
                // link luar (Google Sheet, WhatsApp, dll) dibuka di aplikasi/browser lain
                runCatching { startActivity(Intent(Intent.ACTION_VIEW, u)) }
                return true
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    if (!request.resources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE)) { request.deny(); return@runOnUiThread }
                    if (ContextCompat.checkSelfPermission(this@ItemizeWebActivity, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                        request.grant(arrayOf(PermissionRequest.RESOURCE_VIDEO_CAPTURE))
                    } else {
                        pendingPerm = request
                        askCamera.launch(Manifest.permission.CAMERA)
                    }
                }
            }

            override fun onShowFileChooser(w: WebView, cb: ValueCallback<Array<Uri>>, params: FileChooserParams): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = cb
                val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"   // .xlsx/.xls/.csv/.txt: tipe MIME tiap pabrikan HP berbeda-beda
                    putExtra(Intent.EXTRA_ALLOW_MULTIPLE, params.mode == FileChooserParams.MODE_OPEN_MULTIPLE)
                }
                return try { pickFile.launch(Intent.createChooser(intent, "Pilih file")); true }
                catch (e: Exception) { fileCallback = null; false }
            }
        }

        // Service worker (sw.js): offline cache halaman & pustaka kamera. Request-nya juga dilayani dari assets.
        if (WebViewFeature.isFeatureSupported(WebViewFeature.SERVICE_WORKER_BASIC_USAGE)) {
            ServiceWorkerControllerCompat.getInstance().setServiceWorkerClient(object : ServiceWorkerClientCompat() {
                override fun shouldInterceptRequest(request: WebResourceRequest): WebResourceResponse? =
                    loader.shouldInterceptRequest(request.url)
            })
        }

        if (itemizeApiUrl.isBlank())
            Toast.makeText(this, "Google Sheet belum diatur. Buka Itemize > Setting Google Sheet.", Toast.LENGTH_LONG).show()
        web.loadUrl("https://${WebViewAssetLoader.DEFAULT_DOMAIN}/assets/itemize/index.html")
        registerScanReceiver()
    }

    /** Terima hasil scan lewat broadcast (mode Broadcast scanner bawaan device) tanpa perlu kolom terfokus. */
    private fun registerScanReceiver() {
        unregisterScanReceiver()
        val custom = itemizeScanAction
        val filter = IntentFilter().apply {
            presetScan.keys.forEach { addAction(it) }
            if (custom.isNotBlank()) addAction(custom)
        }
        val r = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                val ex = i.extras ?: return
                val names = LinkedHashSet<String>()
                if (itemizeScanExtra.isNotBlank()) names.add(itemizeScanExtra)
                presetScan[i.action]?.let { names.addAll(it) }
                names.addAll(genericExtras)
                var code: String? = null
                for (n in names) {
                    @Suppress("DEPRECATION") val v = ex.get(n)
                    val s = when (v) { is String -> v; is ByteArray -> String(v); is CharSequence -> v.toString(); else -> null }
                    if (!s.isNullOrBlank()) { code = s.trim(); break }
                }
                if (code.isNullOrEmpty()) return
                val js = "window.onNativeScan && window.onNativeScan(" + org.json.JSONObject.quote(code) + ")"
                web.post { web.evaluateJavascript(js, null) }
            }
        }
        scanReceiver = r
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(r, filter, Context.RECEIVER_EXPORTED)
        else @Suppress("UnspecifiedRegisterReceiverFlag") registerReceiver(r, filter)
    }

    private fun unregisterScanReceiver() {
        scanReceiver?.let { runCatching { unregisterReceiver(it) } }
        scanReceiver = null
    }

    /** Dialog pengaturan broadcast scanner (kosongkan = pakai preset otomatis). */
    private fun showScanSettings() {
        val pad = (16 * resources.displayMetrics.density).toInt()
        val box = android.widget.LinearLayout(this).apply { orientation = android.widget.LinearLayout.VERTICAL; setPadding(pad, pad / 2, pad, 0) }
        val etA = EditText(this).apply { hint = "Action broadcast (opsional)"; setText(itemizeScanAction); setSingleLine() }
        val etE = EditText(this).apply { hint = "Nama extra barcode (opsional)"; setText(itemizeScanExtra); setSingleLine() }
        box.addView(etA); box.addView(etE)
        AlertDialog.Builder(this)
            .setTitle("Scanner mode Broadcast")
            .setMessage("Atur output scanner device ke Broadcast. Preset Zebra, Urovo, Honeywell, Newland, Chainway, dll aktif otomatis. Isi kolom di bawah hanya bila merek scanner Anda berbeda.")
            .setView(box)
            .setPositiveButton("Simpan") { _, _ ->
                itemizeScanAction = etA.text.toString(); itemizeScanExtra = etE.text.toString()
                registerScanReceiver()
                Toast.makeText(this, "Tersimpan", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Batal", null).show()
    }

    /** Jembatan JavaScript → Android (dipanggil dari index.html sebagai window.AndroidItemize). */
    inner class Bridge {
        @JavascriptInterface
        fun getApiUrl(): String = itemizeApiUrl

        @JavascriptInterface
        fun openScanSettings() { runOnUiThread { showScanSettings() } }

        @JavascriptInterface
        fun saveFile(name: String, mime: String, base64: String) {
            try {
                val bytes = Base64.decode(base64, Base64.DEFAULT)
                val safe = name.replace(Regex("[\\\\/:*?\"<>|]"), "_")
                val uri = writeToDownloads(safe, mime, bytes)
                runOnUiThread { savedDialog(safe, mime, uri) }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this@ItemizeWebActivity, "Gagal menyimpan: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }
    }

    /** Simpan ke folder Download publik (Android 10+ lewat MediaStore, di bawahnya ke folder app). */
    private fun writeToDownloads(name: String, mime: String, bytes: ByteArray): Uri {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val cv = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, mime)
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Itemize")
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
                ?: throw IllegalStateException("tidak bisa membuat file")
            contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
            return uri
        }
        val dir = File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "Itemize").apply { mkdirs() }
        val f = File(dir, name); f.writeBytes(bytes)
        return FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
    }

    private fun savedDialog(name: String, mime: String, uri: Uri) {
        if (isFinishing || isDestroyed) return
        AlertDialog.Builder(this)
            .setTitle("File tersimpan")
            .setMessage("$name\n\nDisimpan di Download/Itemize.")
            .setPositiveButton("Buka") { _, _ ->
                runCatching {
                    startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
                }.onFailure { Toast.makeText(this, "Tidak ada aplikasi untuk membuka file ini", Toast.LENGTH_LONG).show() }
            }
            .setNeutralButton("Bagikan") { _, _ ->
                runCatching {
                    startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                        type = mime; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }, "Bagikan"))
                }
            }
            .setNegativeButton("Tutup", null).show()
    }

    override fun onResume() { super.onResume(); web.onResume() }
    override fun onPause() { web.onPause(); super.onPause() }

    override fun onDestroy() {
        unregisterScanReceiver()
        web.removeJavascriptInterface("AndroidItemize")
        web.destroy()
        super.onDestroy()
    }
}
