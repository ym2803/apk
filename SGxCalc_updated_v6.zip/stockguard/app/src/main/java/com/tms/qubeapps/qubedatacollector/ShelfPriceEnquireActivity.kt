package com.tms.qubeapps.qubedatacollector

import android.app.AlertDialog
import android.app.ProgressDialog
import android.content.Intent
import androidx.activity.result.contract.ActivityResultContracts
import android.graphics.Paint
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.lifecycle.lifecycleScope
import com.tms.qubeapps.qubedatacollector.AppDatabase.Companion.C_PE_BALANCE
import com.tms.qubeapps.qubedatacollector.AppDatabase.Companion.C_PE_DESC
import com.tms.qubeapps.qubedatacollector.AppDatabase.Companion.C_PE_ID
import com.tms.qubeapps.qubedatacollector.AppDatabase.Companion.C_PE_PRICE
import com.tms.qubeapps.qubedatacollector.AppDatabase.Companion.C_PE_QTY
import com.tms.qubeapps.qubedatacollector.AppDatabase.Companion.C_PE_SHELF
import com.tms.qubeapps.qubedatacollector.AppDatabase.Companion.C_PE_SKU
import com.tms.qubeapps.qubedatacollector.AppDatabase.Companion.C_PE_TIME
import com.tms.qubeapps.qubedatacollector.AppDatabase.Companion.C_PE_UPLOADED
import com.tms.qubeapps.qubedatacollector.Prefs.catalogUpdatedTime
import com.tms.qubeapps.qubedatacollector.Prefs.qtyAddUpdatedTime
import com.tms.qubeapps.qubedatacollector.Prefs.qtySubtractUpdatedTime
import com.tms.qubeapps.qubedatacollector.Prefs.fileFormat
import com.tms.qubeapps.qubedatacollector.Prefs.outFileName
import com.tms.qubeapps.qubedatacollector.Prefs.smbUploadPathScanProcess
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

/**
 * ★ FIX (baru — pemisahan menu Scan Process jadi 2 menu):
 * Layar ini sekarang dipakai untuk 2 menu di halaman utama yang beda tampilan,
 * tapi berbagi data (tabel Price) & logika yang sama persis:
 *   1) "Shelf Price Enquire" (MODE_ENQUIRE, default) — scan SKU, tampilkan
 *      kartu RESULT saja. Tidak menampilkan daftar History. Tetap ada
 *      tombol Clear Data & Upload to PC (beroperasi ke seluruh data, sama
 *      seperti sebelumnya).
 *   2) "Stock Balance Check" (MODE_BALANCE) — tampilkan daftar HISTORY saja
 *      (tanpa input scan SKU / kartu Result). Tetap ada tombol Clear Data &
 *      Upload to PC, dan ikon ke Stock Comparison (yang datanya tetap
 *      diambil dari History/tabel Price yang sama, tidak berubah).
 * Data (tabel Price di AppDatabase) SAMA untuk kedua mode — cuma tampilan
 * yang dibedakan lewat EXTRA_MODE, supaya Stock Comparison (yang mengambil
 * dari History) tetap jalan seperti sebelumnya tanpa perlu diubah.
 */
class ShelfPriceEnquireActivity : BaseScanner() {

    companion object {
        const val EXTRA_MODE = "mode"
        const val MODE_ENQUIRE = "PRICE_ENQUIRE"
        const val MODE_BALANCE = "BALANCE_CHECK"
        /** ★ FIX (baru): dipakai Data Collector (mode Shelf Price Enquiry) untuk langsung memulai Download Latest Data. */
        const val EXTRA_AUTO_DOWNLOAD = "auto_download"
    }

    private var mode: String = MODE_ENQUIRE

    private lateinit var etSku          : EditText
    private lateinit var tvTotal        : TextView
    private lateinit var tvLastUpdate   : TextView
    // ★ FIX (baru — tampilan 1 kolom vertikal): dulu 2 container (kiri/kanan)
    // untuk grid 5x2, sekarang 1 container vertikal untuk 10/5 baris ke bawah.
    private lateinit var llResultAll    : LinearLayout
    private lateinit var layoutResult   : View
    private lateinit var tvHistoryCount : TextView
    private lateinit var lvHistory      : ListView

    private lateinit var db: AppDatabase
    // FIX (force close): katalog 02.txt TIDAK lagi ditahan di RAM sebagai Map besar.
    // Data langsung disimpan & dicari lewat SQLite (lihat AppDatabase.replaceCatalog/findCatalog).
    private var catalogCount = 0
    private var rawPreviewRow = ""
    private var detectedSep   = ","
    private var detectedCols  = 0

    private val historyRows = mutableListOf<Array<String>>()
    private lateinit var histAdapter: BaseAdapter

    // ★ FIX (dihapus — Result auto-close): auto-close 10 detik DIHAPUS karena
    // sudah ada tombol Close manual (btnResultClose) untuk menutup kartu Result.

    // ★ FIX (baru — History Scan gabung SKU sama): baris yang benar-benar
    // ditampilkan di lvHistory. historyRows (di atas) tetap berisi SEMUA baris
    // mentah dari DB (1 baris per kali scan) supaya data asli tidak berubah;
    // displayRows adalah hasil PENGGABUNGAN per SKU (qty dijumlahkan) khusus
    // untuk tampilan, jadi SKU yang di-scan berkali-kali cukup 1 baris.
    private data class HistoryDisplayRow(
        val ids: List<Int>, val sku: String, val desc: String, val shelf: String,
        val price: String, val balance: String, val time: String,
        val uploaded: String, val qty: Int, val isMerged: Boolean
    )
    private val displayRows = mutableListOf<HistoryDisplayRow>()

    // ★ FIX (baru — delete per SKU): posisi baris (di displayRows) yang lagi
    // menampilkan tombol delete (hasil long-press). null = tidak ada yang
    // sedang menampilkan tombol delete. Reset ke null tiap kali loadHistory()
    // dipanggil supaya tidak "nyangkut" saat data berubah.
    private var deleteModePos: Int? = null

    // ★ FIX (baru — 1. Pembeda Scan Baru): id record (C_PE_ID) hasil scan
    // PALING BARU di mode Stock Balance Check. Dipakai adapter History untuk
    // menandai baris yang baru saja masuk (highlight hijau + badge "NEW").
    // null = belum ada scan sejak layar ini dibuka / history baru dibersihkan.
    private var lastScannedId: Long? = null

    // ★ FIX (baru — Edit Shelf History Scan): hasil edit shelf (SKU → shelf baru),
    // disimpan lokal supaya tidak hilang saat layar ditutup, lalu dikirim ke PC
    // lewat menu titik-3 "Send Edited Shelf to PC" (output "Shelf,SKU", folder 05).
    private var shelfEdits: MutableMap<String, String> = LinkedHashMap()

    // ★ Mode Shelf / Scan SKU (khusus Stock Balance Check) + pencarian riwayat.
    private lateinit var switchShelfMode: android.widget.Switch
    private lateinit var etShelfInput   : EditText
    private lateinit var etHistorySearch: EditText
    /** Shelf aktif (hasil scan di Shelf mode). Dipakai untuk Not Yet Scanned & dicatat ke tiap SKU yang discan. */
    private var currentShelf = ""
    private var historySearch = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_shelf_price_enquire)

        mode = intent.getStringExtra(EXTRA_MODE) ?: MODE_ENQUIRE

        db             = AppDatabase(this)
        shelfEdits     = loadShelfEdits()
        etSku          = findViewById(R.id.etSkuCode)
        tvTotal        = findViewById(R.id.tvTotalItem)
        tvLastUpdate   = findViewById(R.id.tvLastUpdate)
        llResultAll    = findViewById(R.id.llResultAll)
        layoutResult   = findViewById(R.id.layoutResult)
        tvHistoryCount = findViewById(R.id.tvHistoryCount)
        lvHistory      = findViewById(R.id.lvHistory)

        switchShelfMode = findViewById(R.id.switchShelfMode)
        etShelfInput    = findViewById(R.id.etShelfInput)
        etHistorySearch = findViewById(R.id.etHistorySearch)

        initScanner(findViewById(R.id.scannerView))
        setupHistoryAdapter()
        refreshCatalogInfo()
        loadHistory()
        applyModeVisibility()

        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<View>(R.id.btnCamera).setOnClickListener { toggleCamera() }
        findViewById<View>(R.id.btnEnter).setOnClickListener { searchSku() }
        etSku.setOnKeyListener { _, keyCode, event ->
            if (keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN) {
                searchSku(); true
            } else false
        }
        // ★ FIX: Stock Comparison digabung ke Scan Process — diakses lewat ikon di header.
        findViewById<View>(R.id.btnStockComparison).setOnClickListener {
            startActivity(Intent(this, StockComparisonActivity::class.java))
        }
        // ★ FIX: Download Latest Data & View Downloaded Data dipindah ke menu titik-3 (⋮)
        // di header supaya baris tombol di bawah lebih ringkas/efisien.
        findViewById<View>(R.id.btnOverflowMenu).setOnClickListener { showOverflowMenu(it) }
        // ★ FIX: "SET COLUMNS" (btnColMapping) DIHAPUS dari sini — sekarang jadi
        // item menu titik-3 (⋮), khusus mode Stock Balance Check (lihat
        // showOverflowMenu()).
        // ★ FIX: ikon gear di kartu hasil -> buka layar custom posisi & judul field
        findViewById<View>(R.id.btnResultSettings).setOnClickListener {
            startActivity(Intent(this, ResultLayoutActivity::class.java))
        }
        // ★ FIX: tombol Close untuk menutup kartu Result secara manual (satu-satunya
        // cara kartu Result tertutup — tidak ada lagi auto-close otomatis).
        findViewById<View>(R.id.btnResultClose).setOnClickListener { hideResult() }

        // FIX: kolom Scan SKU langsung standby (tidak perlu diklik dulu)
        // supaya scanner bawaan device (hardware keyboard wedge) bisa langsung input.
        etSku.post { etSku.requestFocus() }
        if (intent.getBooleanExtra(EXTRA_AUTO_DOWNLOAD, false)) etSku.post { downloadPriceList() }

        findViewById<View>(R.id.btnUpload).setOnClickListener { doUpload() }
        findViewById<View>(R.id.btnDeleteAll).setOnClickListener { confirmClearAll() }

        // Restore autosave history: ikon langsung di samping ⋮
        findViewById<View>(R.id.btnRestoreHistory).setOnClickListener { restoreAutosaveHistory() }

        // Toggle Shelf mode: ON = tampil kolom isi Shelf + Not Yet Scanned; OFF = hanya Scan SKU.
        val sgPrefs = getSharedPreferences("sg_balance_check", MODE_PRIVATE)
        switchShelfMode.isChecked = sgPrefs.getBoolean("shelf_mode", false)
        applyShelfModeUi(focus = false)
        switchShelfMode.setOnCheckedChangeListener { _, on ->
            sgPrefs.edit().putBoolean("shelf_mode", on).apply()
            applyShelfModeUi(focus = true)
        }
        // Shelf: nilai dipakai langsung saat diketik/di-scan; Enter → pindah ke kolom Scan SKU.
        etShelfInput.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) { currentShelf = s?.toString()?.trim()?.uppercase().orEmpty() }
        })
        etShelfInput.setOnEditorActionListener { _, _, _ -> etSku.requestFocus(); true }
        etShelfInput.setOnKeyListener { _, keyCode, event ->
            if (keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN) { etSku.requestFocus(); true } else false
        }
        findViewById<View>(R.id.btnNotScanned).setOnClickListener { showNotScannedDialog() }

        // Cari riwayat scan
        findViewById<View>(R.id.btnHistorySearch).setOnClickListener { toggleHistorySearch() }
        etHistorySearch.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                historySearch = s?.toString()?.trim()?.lowercase().orEmpty()
                rebuildDisplayRows(); histAdapter.notifyDataSetChanged(); updateHistoryCount()
            }
        })
    }

    private fun shelfModeOn() = mode == MODE_BALANCE && switchShelfMode.isChecked

    private fun applyShelfModeUi(focus: Boolean) {
        val on = shelfModeOn()   // hanya berlaku di Stock Balance Check
        findViewById<View>(R.id.layoutShelfInput).visibility = if (on) View.VISIBLE else View.GONE
        findViewById<View>(R.id.btnNotScanned).visibility = if (on) View.VISIBLE else View.GONE
        if (focus) {
            if (on && etShelfInput.text.isNullOrBlank()) etShelfInput.post { etShelfInput.requestFocus() }
            else etSku.post { etSku.requestFocus() }
        }
    }

    private fun toggleHistorySearch() {
        if (etHistorySearch.visibility == View.VISIBLE) closeHistorySearch(refocus = true)
        else {
            etHistorySearch.visibility = View.VISIBLE
            etHistorySearch.post {
                etHistorySearch.requestFocus()
                (getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager)
                    .showSoftInput(etHistorySearch, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
            }
        }
    }

    private fun closeHistorySearch(refocus: Boolean) {
        if (etHistorySearch.visibility != View.VISIBLE) return
        etHistorySearch.setText("")
        etHistorySearch.visibility = View.GONE
        if (refocus) etSku.post { etSku.requestFocus() }
    }

    private fun updateHistoryCount() {
        val mergedCount = displayRows.count { it.isMerged }
        val allSku = historyRows.map { it[1] }.toSet().size
        tvHistoryCount.text = when {
            historySearch.isNotEmpty() -> "${displayRows.size} of $allSku SKU"
            mergedCount > 0 -> "${historyRows.size} scan  (${displayRows.size} SKU, $mergedCount merged)"
            else -> "${historyRows.size} scan"
        }
    }

    /** Daftar SKU ber-stok (balance > 0) di shelf aktif menurut katalog 02 yang BELUM discan
     *  (belum ada di History). Tap item → SKU masuk ke kolom scan (tinggal Enter). */
    private fun showNotScannedDialog() {
        val shelf = currentShelf.trim()
        if (shelf.isEmpty()) {
            Toast.makeText(this, "Fill in the Shelf first (Shelf mode is on)", Toast.LENGTH_LONG).show(); return
        }
        val items = db.getCatalogItemsByShelf(shelf)
        if (items.isEmpty()) {
            AlertDialog.Builder(this).setTitle("Not Yet Scanned — $shelf")
                .setMessage("This shelf was not found in catalog 02.")
                .setPositiveButton("OK", null).show()
            return
        }
        fun bal(m: Map<String, String>) = m["balance"]?.replace(",", "")?.toDoubleOrNull() ?: 0.0
        val scanned = historyRows.map { it[1].trim().uppercase() }.toSet()
        val stocked = items.filter { bal(it) > 0 }
        val missing = stocked.filter { m ->
            val sku = m["sku"].orEmpty().trim().uppercase()
            val lng = m["longSku"].orEmpty().trim().uppercase().takeIf { it.isNotBlank() && it != "-" }
            sku !in scanned && (lng == null || lng !in scanned)
        }
        val labels = ArrayList<String>()
        missing.forEach { m ->
            val b = bal(m)
            labels.add("${m["sku"]}  ${m["desc"].orEmpty().take(28)}  (Sys ${if (b % 1.0 == 0.0) b.toLong().toString() else b.toString()})")
        }
        val title = "$shelf — ${stocked.size} SKUs in stock, ${stocked.size - missing.size} scanned"
        if (missing.isEmpty()) {
            AlertDialog.Builder(this).setTitle(title).setMessage("All scanned ✔")
                .setPositiveButton("OK", null).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("$title\nNOT YET SCANNED (${missing.size}) — tap to input")
            .setItems(labels.toTypedArray()) { _, which ->
                etSku.setText(missing[which]["sku"].orEmpty().trim())
                etSku.post { etSku.requestFocus(); etSku.setSelection(etSku.text.length) }
            }
            .setPositiveButton("OK", null).show()
    }

    /**
     * ★ FIX (baru — pemisahan menu): sembunyikan/tampilkan bagian layar
     * sesuai mode ("Shelf Price Enquire" vs "Stock Balance Check").
     * ★ FIX (revisi): KEDUA mode sekarang sama-sama punya input scan SKU
     * sendiri-sendiri — cuma beda fungsi setelah scan:
     *   - Shelf Price Enquire: scan → tampilkan kartu RESULT (buat cek harga),
     *     History TIDAK ditampilkan di layar ini.
     *   - Stock Balance Check: scan → LANGSUNG masuk & tampil di daftar
     *     HISTORY (tanpa kartu Result), History ditampilkan di layar ini.
     * Data (tabel Price) tetap sama untuk kedua mode, jadi Stock Comparison
     * tetap ambil dari History seperti sebelumnya.
     * ★ FIX (baru): "SET COLUMNS" (dulu tombol di layar ini, khusus mode
     * Shelf Price Enquire) sekarang dipindah jadi item menu titik-3 (⋮),
     * khusus mode Stock Balance Check — lihat showOverflowMenu().
     */
    private fun applyModeVisibility() {
        val tvHeaderTitle    = findViewById<TextView>(R.id.tvHeaderTitle)
        val layoutHistoryHdr = findViewById<View>(R.id.layoutHistoryHeader)
        val btnStockComp     = findViewById<View>(R.id.btnStockComparison)
        val layoutBottomBtns = findViewById<View>(R.id.layoutBottomButtons)

        // ★ Input scan SKU (layoutEnquireInput) & scanner kamera SELALU
        // tampil di kedua mode — hanya bagian di bawahnya (Result vs
        // History) yang dibedakan.
        if (mode == MODE_BALANCE) {
            tvHeaderTitle.text = "Stock Balance Check"
            findViewById<View>(R.id.layoutShelfMode).visibility = View.VISIBLE
            findViewById<View>(R.id.btnRestoreHistory).visibility = View.VISIBLE
            layoutHistoryHdr.visibility = View.VISIBLE
            lvHistory.visibility = View.VISIBLE
            layoutResult.visibility = View.GONE
            // ★ Ikon Stock Comparison (yang datanya diambil dari History) ada
            // di sini karena History-nya tampil di layar ini.
            btnStockComp.visibility = View.VISIBLE
            // ★ Clear Data & Upload to PC tetap ada di mode ini (beroperasi ke History).
            layoutBottomBtns.visibility = View.VISIBLE
        } else {
            tvHeaderTitle.text = "Shelf Price Enquire"
            layoutHistoryHdr.visibility = View.GONE
            lvHistory.visibility = View.GONE
            btnStockComp.visibility = View.GONE
            // ★ FIX (baru): di mode Shelf Price Enquire, tombol Clear Data &
            // Upload to PC DIHAPUS/disembunyikan (menu ini murni untuk cek
            // harga, tidak menyimpan/mengelola riwayat).
            layoutBottomBtns.visibility = View.GONE
        }
    }

    override fun onResume() {
        super.onResume()
        refreshCatalogInfo()
        loadHistory()
        etSku.requestFocus()
    }

    override fun onPause() {
        super.onPause()
        if (mode == MODE_BALANCE) autosaveHistory()
    }

    /**
     * FIX (force close): dulu fungsi ini memuat SELURUH katalog dari
     * SharedPreferences ke Map di RAM setiap kali layar dibuka — untuk
     * katalog besar ini berat & bisa OOM. Sekarang hanya query ringan
     * (COUNT) + baca 1 timestamp, jadi cepat & aman untuk data besar.
     */
    private fun refreshCatalogInfo() {
        lifecycleScope.launch {
            val count = withContext(Dispatchers.IO) { db.countCatalog() }
            catalogCount = count
            tvTotal.text = "Total Item : $count"
            val ts = catalogUpdatedTime
            tvLastUpdate.text = if (ts > 0L)
                "Last Updated Date : " +
                    SimpleDateFormat("EEE MMM dd HH:mm:ss z yyyy", Locale.ENGLISH).format(Date(ts))
            else "Last Updated Date : -"
            val m = ColMappingPrefs.load(this@ShelfPriceEnquireActivity)
            rawPreviewRow = m.previewRow
            detectedSep   = m.separator
            detectedCols  = m.totalCols
        }
    }

    private fun searchSku() {
        val sku = etSku.text.toString().trim().uppercase()
        if (sku.isEmpty()) return
        // Shelf mode ON tapi Shelf belum diisi → minta isi Shelf dulu (SKU yang diketik tetap di kolom).
        if (shelfModeOn() && currentShelf.isBlank()) {
            Toast.makeText(this, "Fill in Shelf first", Toast.LENGTH_SHORT).show()
            etShelfInput.post { etShelfInput.requestFocus() }
            return
        }
        etSku.text.clear()

        lifecycleScope.launch {
            // FIX (force close): cari langsung ke SQLite (pakai index SKU),
            // bukan ke Map besar yang dulu ditahan penuh di memori.
            val data = withContext(Dispatchers.IO) { db.findCatalog(sku) }
            if (data != null) {
                // ★ SKU panjang (kolom 23) otomatis = SKU pendek (kolom 1): simpan & proses pakai SKU pendek.
                val sku = data["sku"]?.takeIf { it.isNotBlank() && it != "-" } ?: sku
                val desc    = data["desc"]    ?: "-"
                val shelf   = data["shelf"]   ?: "-"
                val price   = data["price"]   ?: "-"
                val balance = data["balance"] ?: "-"
                // ★ FIX (revisi — Stock Balance Check punya scan sendiri): kartu
                // Result cuma ditampilkan di mode Shelf Price Enquire. Di mode
                // Stock Balance Check, hasil scan LANGSUNG masuk & tampil di
                // History (lewat loadHistory() di bawah), tanpa kartu Result.
                if (mode == MODE_ENQUIRE) showResult(data)
                // ★ FIX (baru): mode Shelf Price Enquire TIDAK menyimpan hasil
                // scan ke History sama sekali (menu ini murni cek harga, tanpa
                // riwayat). Hanya mode Stock Balance Check yang menyimpan ke DB.
                if (mode == MODE_BALANCE) {
                    // ★ FIX: Qty (jumlah fisik untuk Stock Comparison) TIDAK diinput manual —
                    // otomatis diambil dari balance sistem saat scan. Kalau perlu dikoreksi,
                    // user tinggal tap baris history-nya (fungsi edit sudah ada).
                    val qty = balance.toIntOrNull() ?: 0
                    // ★ FIX (baru — 1. Pembeda Scan Baru): simpan id hasil insert supaya
                    // baris ini bisa ditandai "baru discan" di History.
                    lastScannedId = withContext(Dispatchers.IO) { db.insertPrice(sku, desc, shelf, price, balance, qty) }
                    // Shelf aktif (dari Shelf mode): catat shelf SKU ini. Kalau beda dengan shelf katalog → masuk
                    // daftar "Edited Shelf" (dikirim ke PC lewat menu ⋮); kalau sama → hapus edit lama.
                    if (shelfModeOn() && currentShelf.isNotBlank()) {
                        withContext(Dispatchers.IO) { db.updatePriceShelfBySku(sku, currentShelf) }
                        if (!currentShelf.equals(shelf.trim(), ignoreCase = true)) shelfEdits[sku] = currentShelf
                        else shelfEdits.remove(sku)
                        saveShelfEdits()
                    }
                }
            } else {
                val notFound = mapOf(
                    "sku" to sku, "desc" to "NOT FOUND", "shelf" to "-",
                    "price" to "0", "balance" to "0",
                    "discount" to "-", "discStart" to "-", "discEnd" to "-",
                    "longSku" to "-", "keepStock" to "-"
                )
                if (mode == MODE_ENQUIRE) showResult(notFound)
                if (mode == MODE_BALANCE) {
                    lastScannedId = withContext(Dispatchers.IO) { db.insertPrice(sku, "NOT FOUND", "-", "0", "0", 0) }
                }
                Toast.makeText(this@ShelfPriceEnquireActivity,
                    "SKU $sku not found", Toast.LENGTH_SHORT).show()
            }
            // FIX: loadHistory() (notifyDataSetChanged pada ListView) HARUS dijalankan
            // SEBELUM requestFocus(), kalau tidak ListView bisa "merebut" fokus lagi
            // setelah refresh sehingga field scan butuh diklik manual tiap data ke-2 dst.
            if (mode == MODE_BALANCE) closeHistorySearch(refocus = false)  // baris baru jangan tersembunyi filter
            loadHistory(autoOpenMulti = true)
            if (mode == MODE_BALANCE && ++historyScanCounter % 10 == 0) autosaveHistory()
            etSku.post { etSku.requestFocus() }
        }
    }

    /** ★ FIX (baru — 1.1/1.2): sama seperti ProductMasterActivity, coba
     *  beberapa format tanggal umum untuk kolom Discount End Date (kolom 15). */
    private val discEndDateFormats = listOf("dd/MM/yyyy", "MM/dd/yyyy", "yyyy-MM-dd", "dd-MM-yyyy")

    private fun parseDiscEndDate(dateStr: String?): Long? {
        val s = dateStr?.trim().orEmpty()
        if (s.isEmpty() || s == "-") return null
        for (fmt in discEndDateFormats) {
            try {
                val sdf = SimpleDateFormat(fmt, Locale.US)
                sdf.isLenient = false
                return sdf.parse(s)?.time
            } catch (e: Exception) {
                continue
            }
        }
        return null
    }

    /** Discount End Date dianggap "masih berlaku" kalau sama dengan hari ini atau
     *  lebih (belum lewat). Kalau kosong/tidak bisa di-parse, dianggap TIDAK aktif
     *  (aman/default: tidak dicoret) supaya data yang salah format tidak menyesatkan. */
    private fun isDiscountEndStillActive(discEndRaw: String?): Boolean {
        val endMillis = parseDiscEndDate(discEndRaw) ?: return false
        val startOfToday = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        return endMillis >= startOfToday
    }

    override fun onBarcodeScanned(barcode: String) {
        // Shelf mode ON & fokus di kolom Shelf → hasil scan jadi Shelf, lalu pindah ke Scan SKU.
        if (shelfModeOn() && etShelfInput.hasFocus()) {
            etShelfInput.setText(barcode.trim().uppercase()); etSku.requestFocus(); return
        }
        etSku.setText(barcode); searchSku()
    }

    /**
     * ★ FIX (baru — tampilan 1 kolom vertikal): kartu hasil dulu grid custom
     * 5x2 (5 baris kiri, 5 baris kanan), sekarang SATU kolom vertikal, 10
     * baris (atau 5 baris — diatur user di menu SET COLUMNS, lihat
     * ColMappingPrefs.resultRowCount) ke bawah supaya font tiap field bisa
     * dibuat lebih besar & jelas. Field mana yang tampil di tiap baris &
     * judulnya tetap diambil dari ResultLayoutPrefs (ikon gear ->
     * ResultLayoutActivity). Kalau user pilih 5 baris, hanya 5 slot pertama
     * (sesuai urutan ResultLayoutPrefs) yang ditampilkan, dengan font lebih
     * besar lagi supaya makin jelas terbaca.
     *
     * ★ FIX (baru — Balance & Discount):
     * - Slot "Balance" SELALU ditampilkan dengan font lebih besar & warna merah,
     *   TERLEPAS di posisi/baris mana pun user menaruhnya (1.3 & 1.4 — otomatis
     *   menyesuaikan kalau mapping/posisi diganti, karena style dicek dari
     *   fieldKey baris itu sendiri, bukan posisi tetap).
     * - Slot "Price" otomatis dicoret (strikethrough) kalau Discount > 0.
     *
     * ★ FIX (dihapus): auto-close 10 detik DIHAPUS — kartu Result sekarang
     * hanya tertutup lewat tombol Close manual (btnResultClose / hideResult()).
     */
    private fun showResult(data: Map<String, String>) {
        val allSlots  = ResultLayoutPrefs.load(this)
        val rowCount  = ColMappingPrefs.load(this).resultRowCount // 10 atau 5
        val slots     = allSlots.take(rowCount)
        llResultAll.removeAllViews()

        // ★ FIX: makin sedikit baris (5), makin besar fontnya supaya jelas —
        // KEDUANYA (label & value) tetap rata TENGAH sesuai layout item_result_line.xml.
        // ★ FIX (baru): skala font & jarak antar baris dari Result Display Settings.
        val fontScale = ResultLayoutPrefs.fontPct(this) / 100f
        val rowPadPx  = (ResultLayoutPrefs.rowPaddingDp(ResultLayoutPrefs.spacing(this)) *
                resources.displayMetrics.density).toInt()
        val labelSize   = (if (rowCount <= 5) 15f else 13f) * fontScale
        val valueSize   = (if (rowCount <= 5) 24f else 19f) * fontScale
        val balanceSize = (if (rowCount <= 5) 30f else 24f) * fontScale

        val discountValue = data["discount"]?.replace(",", "")?.trim()?.toDoubleOrNull() ?: 0.0
        // ★ FIX (baru — 1.1/1.2 tanggal): Price dicoret HANYA kalau Discount > 0
        // DAN Discount End Date (kolom 15) masih hari ini atau lebih (belum lewat).
        // Kalau Discount End Date sudah terlewat dari hari ini, Price TIDAK dicoret
        // lagi walau Discount masih terisi > 0.
        val discEndStillActive = isDiscountEndStillActive(data["discEnd"])
        val shouldStrikePrice = discountValue > 0.0 && discEndStillActive

        slots.forEach { slot ->
            val row = layoutInflater.inflate(R.layout.item_result_line, llResultAll, false)
            (row.findViewById<TextView>(R.id.tvFieldLabel).parent as View)
                .setPadding(0, rowPadPx, 0, rowPadPx)
            row.findViewById<TextView>(R.id.tvFieldLabel).apply {
                text = slot.label
                textSize = labelSize
            }
            val tvValue = row.findViewById<TextView>(R.id.tvFieldValue)
            tvValue.text = if (slot.fieldKey.isBlank()) "" else (data[slot.fieldKey] ?: "-")
            tvValue.textSize = valueSize

            when (slot.fieldKey) {
                // ★ 1.3/1.4: Balance — font lebih besar + merah, ikut field-nya
                // (bukan posisi), jadi otomatis menyesuaikan walau mapping diubah.
                "balance" -> {
                    tvValue.textSize = balanceSize
                    tvValue.setTextColor(0xFFE53935.toInt())
                    tvValue.setTypeface(tvValue.typeface, android.graphics.Typeface.BOLD)
                    tvValue.paintFlags = tvValue.paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()
                }
                // ★ 2.1/2.2: Price — dicoret kalau Discount > 0, normal kalau tidak.
                "price" -> {
                    tvValue.setTextColor(0xFF000000.toInt())
                    tvValue.setTypeface(tvValue.typeface, android.graphics.Typeface.NORMAL)
                    tvValue.paintFlags = if (shouldStrikePrice) {
                        tvValue.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
                    } else {
                        tvValue.paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()
                    }
                }
                else -> {
                    tvValue.setTextColor(0xFF000000.toInt())
                    tvValue.setTypeface(tvValue.typeface, android.graphics.Typeface.BOLD)
                    tvValue.paintFlags = tvValue.paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()
                }
            }
            llResultAll.addView(row)
        }
        layoutResult.visibility = View.VISIBLE
    }

    /** ★ FIX: tutup kartu Result — sekarang HANYA dipanggil dari tombol Close manual
     *  (btnResultClose), karena auto-close 10 detik sudah dihapus. */
    private fun hideResult() {
        layoutResult.visibility = View.GONE
    }

    /** ★ FIX: menu titik-3 (⋮) — gabungan Download Latest Data & View Downloaded Data.
     *  ★ FIX (baru): item "SMB Output Settings" DIHAPUS khusus untuk mode Shelf
     *  Price Enquire (menu ini tidak lagi Upload to PC, jadi setting SMB tidak
     *  relevan di sini). Tetap ada di mode Stock Balance Check.
     *  ★ FIX (baru — pindah menu): "Set Columns" (dulu tombol terpisah di layar
     *  Shelf Price Enquire) sekarang jadi item di sini, KHUSUS mode Stock
     *  Balance Check, diletakkan tepat di bawah "View Downloaded Data 02". */
    private fun showOverflowMenu(anchor: View) {
        val popup = android.widget.PopupMenu(this, anchor)
        val m = popup.menu
        // ★ FIX (dirapikan): item dikelompokkan dengan garis pemisah — Data / Kirim / Pengaturan / Hapus.
        // Subtract/Add Qty System pindah ke menu utama (kartu "Subtract/Add Qty"); setelan GSheet-nya
        // ada di dialog sumber data Qty.
        m.add(1, 1, 0, "Download the latest data from PC")
        m.add(1, 2, 1, "View the downloaded 02 data")
        if (mode == MODE_BALANCE) {
            m.add(2, 6, 2, "Send edited Shelf results to PC (${shelfEdits.size})")
            m.add(2, 5, 3, "Share scan history")
            m.add(3, 4, 4, "Set columns")
            m.add(3, 3, 5, "SMB output folder (Scan Process)")
            if (android.os.Build.VERSION.SDK_INT >= 28) m.setGroupDividerEnabled(true)
        }
        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> { downloadPriceList(); true }
                2 -> { startActivity(Intent(this, PriceCatalogViewActivity::class.java)); true }
                3 -> { showSmbOutputSettingsDialog(); true }
                4 -> { openColumnMapping(); true }
                5 -> { shareHistoryData(); true }
                6 -> { sendEditedShelfToPc(); true }
                else -> false
            }
        }
        popup.show()
    }

    /** Tombol kecil "Delete all" di kiri Upload to PC — langsung hapus tanpa konfirmasi. */
    private fun confirmClearAll() {
        if (db.getPriceHistoryGrouped().isEmpty() && shelfEdits.isEmpty()) {
            Toast.makeText(this, "No history to delete", Toast.LENGTH_SHORT).show(); return
        }
        autosaveHistory()   // snapshot terakhir sebelum dihapus → bisa di-restore dari menu ⋮
        db.clearPrice(); lastScannedId = null; shelfEdits.clear(); saveShelfEdits()
        layoutResult.visibility = View.GONE; loadHistory()
        Toast.makeText(this, "History deleted", Toast.LENGTH_SHORT).show()
    }

    // ── Autosave & Restore History Scan ───────────────────────────────────
    private var historyScanCounter = 0
    private fun historyAutosaveFile() = File(filesDir, "history_scan_autosave.json")

    /** Simpan seluruh History Scan (+ edit Shelf) ke file internal. Kalau history kosong,
     *  file lama TIDAK ditimpa supaya tetap bisa di-restore setelah Delete all. */
    private fun autosaveHistory() {
        runCatching {
            val arr = org.json.JSONArray()
            db.getAllPrice().use { c ->
                val iSku = c.getColumnIndexOrThrow(C_PE_SKU); val iDesc = c.getColumnIndexOrThrow(C_PE_DESC)
                val iShelf = c.getColumnIndexOrThrow(C_PE_SHELF); val iPrice = c.getColumnIndexOrThrow(C_PE_PRICE)
                val iBal = c.getColumnIndexOrThrow(C_PE_BALANCE); val iQty = c.getColumnIndexOrThrow(C_PE_QTY)
                val iTime = c.getColumnIndexOrThrow(C_PE_TIME); val iUp = c.getColumnIndexOrThrow(C_PE_UPLOADED)
                while (c.moveToNext()) {
                    arr.put(JSONObject().put("sku", c.getString(iSku) ?: "").put("desc", c.getString(iDesc) ?: "")
                        .put("shelf", c.getString(iShelf) ?: "").put("price", c.getString(iPrice) ?: "")
                        .put("balance", c.getString(iBal) ?: "").put("qty", c.getInt(iQty))
                        .put("time", c.getString(iTime) ?: "").put("uploaded", c.getInt(iUp)))
                }
            }
            if (arr.length() == 0) return
            // getAllPrice() urut terbaru→lama; simpan terbalik (lama→baru) agar urutan asli terjaga saat restore
            val ordered = org.json.JSONArray()
            for (i in arr.length() - 1 downTo 0) ordered.put(arr.get(i))
            val edits = JSONObject(); shelfEdits.forEach { (k, v) -> edits.put(k, v) }
            historyAutosaveFile().writeText(JSONObject().put("rows", ordered).put("shelfEdits", edits).toString())
        }
    }

    private fun restoreAutosaveHistory() {
        val f = historyAutosaveFile()
        val root = runCatching { JSONObject(f.readText()) }.getOrNull()
        val rowsJson = root?.optJSONArray("rows")
        if (rowsJson == null || rowsJson.length() == 0) {
            Toast.makeText(this, "No autosave history found", Toast.LENGTH_LONG).show(); return
        }
        val n = rowsJson.length()
        val existing = db.getPriceHistoryGrouped().size
        fun doRestore(replace: Boolean) {
            if (replace) { db.clearPrice(); shelfEdits.clear() }
            for (i in 0 until n) {
                val o = rowsJson.getJSONObject(i)
                db.insertPriceFull(o.optString("sku"), o.optString("desc"), o.optString("shelf"),
                    o.optString("price"), o.optString("balance"), o.optInt("qty", 1),
                    o.optString("time"), o.optInt("uploaded", 0))
            }
            root.optJSONObject("shelfEdits")?.let { e ->
                e.keys().forEach { k -> e.optString(k, "").takeIf { it.isNotBlank() }?.let { shelfEdits[k] = it } }
            }
            saveShelfEdits(); lastScannedId = null; layoutResult.visibility = View.GONE; loadHistory()
            Toast.makeText(this, "$n history record(s) restored", Toast.LENGTH_LONG).show()
        }
        val b = AlertDialog.Builder(this).setTitle("Restore autosave history")
        if (existing == 0) {
            b.setMessage("Restore $n scan record(s) from the autosave?")
                .setPositiveButton("Restore") { _, _ -> doRestore(false) }
        } else {
            b.setMessage("The autosave has $n record(s); the history currently has data too.")
                .setPositiveButton("Replace") { _, _ -> doRestore(true) }
                .setNeutralButton("Add to existing") { _, _ -> doRestore(false) }
        }
        b.setNegativeButton("Cancel", null).show()
    }

    /**
     * ★ FIX (baru — Share Data app-to-app): kirim isi History Scan (dikelompokkan
     * per Shelf+SKU, SAMA seperti sumber data "Import from History Scan" yang
     * sudah ada) ke aplikasi lain lewat share sheet Android — format CSV
     * "Shelf,SKU,Qty" per baris, ada header supaya jelas dibuka di aplikasi lain.
     */
    private fun shareHistoryData() {
        val groups = db.getPriceHistoryGrouped()
        if (groups.isEmpty()) {
            Toast.makeText(this, "No History Scan data to share yet", Toast.LENGTH_SHORT).show()
            return
        }
        val sb = StringBuilder("Shelf,SKU,Qty\n")
        groups.forEach { g -> sb.append(g.shelf).append(",").append(g.sku).append(",").append(g.qty).append("\n") }
        val fmt = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        ShareHelper.shareTextAsFile(this, "HistoryScan_$fmt.txt", sb.toString(), "Share History Scan Data")
    }

    /** ★ FIX (baru): dialog setting SMB Path output KHUSUS Scan Process —
     *  sengaja TIDAK ditaruh di layar Setting global, supaya menu ini punya
     *  folder tujuan Upload sendiri, terpisah dari menu lain (mis. Stock
     *  Comparison). User/Password/Domain SMB tetap pakai yang sudah diatur
     *  di Setting global (server PC biasanya sama). */
    private fun showSmbOutputSettingsDialog() {
        val et = EditText(this).apply {
            setText(smbUploadPathScanProcess)
            hint = "smb://HOSTNAME/share/subfolder"
        }
        val container = android.widget.FrameLayout(this).apply {
            val pad = (16 * resources.displayMetrics.density).toInt()
            setPadding(pad, 8, pad, 0); addView(et)
        }
        AlertDialog.Builder(this)
            .setTitle("SMB Output Settings — Scan Process")
            .setMessage("Dedicated SMB destination folder for Upload from this menu. Leave empty to use the path from global Settings.")
            .setView(container)
            .setPositiveButton("Save") { _, _ ->
                smbUploadPathScanProcess = et.text.toString().trim()
                Toast.makeText(this, "SMB Output setting saved", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun openColumnMapping() {
        if (rawPreviewRow.isBlank() && catalogCount == 0) {
            Toast.makeText(this, "Download 02.txt data first before setting columns", Toast.LENGTH_SHORT).show()
            return
        }
        colMapLauncher.launch(Intent(this, ColumnMappingActivity::class.java).apply {
            putExtra(ColumnMappingActivity.EXTRA_PREVIEW_ROW, rawPreviewRow)
            putExtra(ColumnMappingActivity.EXTRA_SEPARATOR,   detectedSep)
            putExtra(ColumnMappingActivity.EXTRA_TOTAL_COLS,  detectedCols)
        })
    }

    // ── ★ FIX (baru): ganti setting kolom → katalog LANGSUNG di-parse ulang dari salinan
    //    mentah 02.txt di HP, TANPA download ulang. Selisih Qty System hasil import
    //    (kurangi/tambah) dipasang kembali setelah parse. ─────────────────────────────
    private fun rawCatalogFile() = File(filesDir, "02_raw.txt")

    private val colMapLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
            if (res.resultCode == RESULT_OK) reparseCatalogFromRaw()
        }

    private fun reparseCatalogFromRaw() {
        val src = listOf(rawCatalogFile(),
            File(android.os.Environment.getExternalStorageDirectory(), "02/02.txt"))
            .firstOrNull { runCatching { it.exists() && it.length() > 0 }.getOrDefault(false) }
        if (src == null) {
            Toast.makeText(this, "02.txt copy not available yet — download 02.txt once first", Toast.LENGTH_LONG).show()
            return
        }
        val pd = ProgressDialog(this).apply {
            setMessage("Applying column settings…")
            setProgressStyle(ProgressDialog.STYLE_HORIZONTAL)
            max = 100; progress = 0; setProgressNumberFormat(null); setCancelable(false); show()
        }
        lifecycleScope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    val raw = src.readText(Charsets.UTF_8)
                    val r = parseAndStoreCatalog(raw) { done, total ->
                        runOnUiThread { pd.progress = (done.toLong() * 100 / maxOf(1, total)).toInt().coerceIn(0, 100) }
                    }
                    // pasang kembali selisih Qty System dari import sebelumnya
                    val st = QtyAdjustImporter.loadStore(this@ShelfPriceEnquireActivity)
                    if (st.deltas.isNotEmpty()) db.adjustCatalogBalance(st.deltas, 1, true)
                    r
                }
                rawPreviewRow = result.previewRow
                detectedSep = result.separator
                detectedCols = result.totalCols
                catalogCount = result.count
                tvTotal.text = "Total Item : ${result.count}"
                pd.dismiss()
                Toast.makeText(this@ShelfPriceEnquireActivity,
                    "Column settings applied — ${result.count} items (no re-download)", Toast.LENGTH_LONG).show()
                loadHistory()
            } catch (e: Exception) {
                pd.dismiss()
                AlertDialog.Builder(this@ShelfPriceEnquireActivity).setTitle("Failed to apply columns")
                    .setMessage(e.message ?: "Unknown error").setPositiveButton("OK", null).show()
            }
        }
    }

    private fun setupHistoryAdapter() {
        histAdapter = object : BaseAdapter() {
            override fun getCount()        = displayRows.size
            override fun getItem(p: Int)   = displayRows[p]
            override fun getItemId(p: Int) = p.toLong()

            override fun getView(pos: Int, convertView: View?, parent: ViewGroup): View {
                val v   = convertView ?: layoutInflater.inflate(R.layout.item_price_history, parent, false)
                val row = displayRows[pos]
                val mapping = ColMappingPrefs.load(this@ShelfPriceEnquireActivity)
                val order   = mapping.displayOrder.split(",").map { it.trim().uppercase() }
                val values  = mapOf("SKU" to row.sku, "DESC" to row.desc, "SHELF" to row.shelf,
                    "PRICE" to row.price, "BALANCE" to row.balance)

                v.findViewById<TextView>(R.id.tvRowSku).text  = order.getOrNull(0)?.let { values[it] } ?: row.sku
                // ★ FIX (baru — 2. Penyederhanaan Tampilan): dulu ditampilkan
                // "SHELF:AG04-10  PRICE:74500.00" dst (pakai label kolom).
                // Sekarang label dihapus — langsung nilainya saja, dipisah
                // bullet "•" supaya tetap gampang dibedakan tiap kolom.
                v.findViewById<TextView>(R.id.tvRowDesc).text = order.drop(1)
                    .mapNotNull { k -> values[k] }
                    .filter { it.isNotBlank() }
                    .joinToString("  •  ")
                v.findViewById<TextView>(R.id.tvRowTime).text  = row.time
                // FIX: yang di-bold merah di kanan atas sekarang BALANCE (bukan price)
                // — sudah langsung nilainya saja, tanpa label "Balance:".
                v.findViewById<TextView>(R.id.tvRowBalance).text = row.balance
                // ★ FIX: tampilkan Qty (jumlah fisik untuk Stock Comparison) — tap baris ini untuk edit.
                // ★ FIX (baru — gabung SKU sama): kalau baris ini hasil penggabungan
                // beberapa kali scan SKU yang sama, Qty yang tampil = TOTAL hasil
                // penjumlahan, dan ditandai "(Nx)" supaya kelihatan ini gabungan.
                v.findViewById<TextView>(R.id.tvRowQty).text =
                    if (row.isMerged) "Qty: ${row.qty}  (${row.ids.size}x merged)" else "Qty: ${row.qty}"
                val tvStatus = v.findViewById<TextView>(R.id.tvRowStatus)
                if (row.uploaded == "1") { tvStatus.text = "UPLOADED"; tvStatus.setTextColor(0xFF4CAF50.toInt()) }
                else                     { tvStatus.text = "PENDING";  tvStatus.setTextColor(0xFFFF9800.toInt()) }

                // ★ FIX (baru — 1. Pembeda Scan Baru): baris yang mengandung id
                // hasil scan PALING TERAKHIR ditandai dengan strip hijau di kiri
                // + badge "NEW" di sebelah SKU, supaya user langsung tahu data
                // mana yang baru saja masuk dari hasil scan barusan.
                // ★ isNewScan  = baris ini mengandung id hasil scan PALING TERAKHIR
                // ★ isMultiScan = sekaligus multi-scan (merged ≥ 2 record untuk SKU sama)
                val isNewScan   = lastScannedId != null && row.ids.contains(lastScannedId!!.toInt())
                val isMultiScan = isNewScan && row.isMerged

                val vIndicator = v.findViewById<View>(R.id.vNewIndicator)
                val tvBadge    = v.findViewById<TextView>(R.id.tvRowNewBadge)

                vIndicator.visibility = if (isNewScan) View.VISIBLE else View.GONE
                tvBadge.visibility    = if (isNewScan) View.VISIBLE else View.GONE

                if (isMultiScan) {
                    // Multi-scan: strip & badge berwarna pink
                    vIndicator.setBackgroundColor(0xFFE91E8C.toInt())
                    tvBadge.setBackgroundColor(0xFFE91E8C.toInt())
                } else if (isNewScan) {
                    // Scan baru biasa: strip & badge hijau (default dari layout)
                    vIndicator.setBackgroundColor(0xFF2E7D32.toInt())
                    tvBadge.setBackgroundColor(0xFF2E7D32.toInt())
                }

                v.setBackgroundColor(
                    when {
                        isMultiScan   -> 0xFFFCE4EC.toInt() // pink muda: baru discan + multi
                        isNewScan     -> 0xFFE8F5E9.toInt() // hijau muda: baru discan (single)
                        row.isMerged  -> 0xFFFFF3CD.toInt() // kuning: merged lama
                        else          -> 0xFFFFFFFF.toInt() // putih: normal
                    }
                )

                // ★ FIX (baru — hapus tanpa ikon merah kecil): dulu ivRowDelete cuma
                // tampil setelah baris di-long-press, lalu user harus tap ikon itu
                // lagi buat konfirmasi (2 langkah). Sekarang long-press LANGSUNG buka
                // dialog konfirmasi hapus (atau menu pilih-yang-mana kalau data
                // dobel/gabungan) — ivRowDelete sudah tidak dipakai lagi, disembunyikan
                // permanen (view-nya masih ada di layout, sengaja tidak dihapus dari
                // XML supaya tidak perlu ubah item_price_history.xml).
                v.findViewById<ImageView>(R.id.ivRowDelete).visibility = View.GONE
                return v
            }
        }
        lvHistory.adapter = histAdapter
        // ★ FIX (baru — hapus tanpa ikon merah kecil): long-press SEKARANG LANGSUNG
        // memunculkan notice/dialog konfirmasi hapus (confirmDeleteHistoryRow sudah
        // otomatis mengarah ke showMergedDeleteDialog kalau baris ini hasil gabungan
        // beberapa scan SKU yang sama — user tinggal pilih salah satu dari menu itu).
        lvHistory.setOnItemLongClickListener { _, _, pos, _ ->
            confirmDeleteHistoryRow(displayRows[pos])
            true
        }
        lvHistory.setOnItemClickListener { _, _, pos, _ ->
            val row = displayRows[pos]
            // ★ FIX: baris yang baru discan DAN multi-scan (merged) → langsung
            // buka showMergedRecordsDialog supaya user tahu data ini sudah
            // pernah discan sebelumnya dan bisa segera edit dari sini.
            if (row.isMerged) {
                showMergedRecordsDialog(row)
            } else {
                showEditQtyDialog(row.ids.first(), row.sku, row.qty.toString(), row.shelf, row.desc)
            }
        }
    }

    /** ★ FIX (baru — delete per SKU di History Stock Balance Check): minta
     *  konfirmasi lalu hapus record. Untuk baris tunggal (bukan gabungan),
     *  langsung konfirmasi hapus 1 record itu. Untuk baris gabungan (SKU sama
     *  discan berkali-kali), user pilih dulu SATU record scan mana yang mau
     *  dihapus (record scan lain untuk SKU yang sama TIDAK ikut terhapus) —
     *  sama pola dengan edit Qty pada baris gabungan. */
    private fun confirmDeleteHistoryRow(row: HistoryDisplayRow) {
        if (row.isMerged) {
            showMergedDeleteDialog(row)
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Delete SKU")
            .setMessage("Delete SKU ${row.sku} from history?")
            .setPositiveButton("Delete") { _, _ ->
                row.ids.forEach { db.deletePrice(it) }
                deleteModePos = null
                loadHistory()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    /** ★ FIX (baru — delete salah satu record di baris gabungan): daftar semua
     *  record scan asli di balik 1 baris gabungan (SKU sama), user pilih SATU
     *  record untuk dihapus. Tetap mensyaratkan baris sudah di-hold (long-press)
     *  dulu sebelum ikon delete muncul & dialog ini terbuka. */
    private fun showMergedDeleteDialog(row: HistoryDisplayRow) {
        val records = row.ids.mapNotNull { id -> historyRows.find { it[0].toIntOrNull() == id } }
        val labels = records.map { r ->
            val time = r[6]; val qty = r[8]
            "$time  —  Qty: $qty"
        }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("SKU ${row.sku} — choose scan to delete")
            .setItems(labels) { _, which ->
                val rec = records[which]
                AlertDialog.Builder(this)
                    .setTitle("Delete SKU")
                    .setMessage("Delete this scan of SKU ${row.sku} (${rec[6]}, Qty: ${rec[8]})?")
                    .setPositiveButton("Delete") { _, _ ->
                        db.deletePrice(rec[0].toInt())
                        deleteModePos = null
                        loadHistory()
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    /** ★ FIX (baru): daftar semua record scan asli di balik 1 baris gabungan
     *  (SKU sama, di-scan berkali-kali), supaya user bisa pilih SATU record
     *  spesifik untuk diedit — persis seperti alur edit data single, dan
     *  record scan lain untuk SKU yang sama TIDAK ikut berubah. */
    private fun showMergedRecordsDialog(row: HistoryDisplayRow) {
        // Ambil detail tiap record (waktu & qty) dari historyRows berdasarkan id,
        // urut sesuai historyRows (terbaru dulu).
        val records = row.ids.mapNotNull { id -> historyRows.find { it[0].toIntOrNull() == id } }
        val labels = records.map { r ->
            val time = r[6]; val qty = r[8]
            "$time  —  Qty: $qty"
        }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("SKU ${row.sku} — ${records.size} scans, choose one to edit")
            .setItems(labels) { _, which ->
                val rec = records[which]
                showEditQtyDialog(rec[0].toInt(), row.sku, rec[8], row.shelf, row.desc)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    /** ★ FIX (baru): gabungkan historyRows (1 baris per kali scan) menjadi
     *  displayRows (1 baris per SKU, Qty dijumlahkan) untuk ditampilkan di
     *  History Scan. SKU yang cuma discan 1x tetap tampil apa adanya (isMerged
     *  = false). Urutan mengikuti kemunculan pertama di historyRows (terbaru
     *  dulu, karena historyRows sudah diurutkan _id DESC), dan detail lain
     *  (desc/shelf/price/balance/waktu/status) diambil dari scan TERBARU. */
    private fun rebuildDisplayRows() {
        displayRows.clear()
        val groups = LinkedHashMap<String, MutableList<Array<String>>>()
        for (row in historyRows) {
            groups.getOrPut(row[1]) { mutableListOf() }.add(row)
        }
        groups.forEach { (sku, group) ->
            val latest    = group.first() // historyRows urutan _id DESC → yang pertama = terbaru
            if (historySearch.isNotEmpty()) {
                val hay = "$sku ${latest[2]} ${latest[3]} ${latest[4]} ${latest[5]}".lowercase()
                if (!hay.contains(historySearch)) return@forEach
            }
            val totalQty  = group.sumOf { it[8].toIntOrNull() ?: 0 }
            val allIds    = group.map { it[0].toInt() }
            displayRows.add(
                HistoryDisplayRow(
                    ids = allIds, sku = sku, desc = latest[2], shelf = latest[3],
                    price = latest[4], balance = latest[5], time = latest[6],
                    uploaded = latest[7], qty = totalQty, isMerged = group.size > 1
                )
            )
        }
    }

    /** ★ FIX: dialog edit Qty (jumlah fisik) dari history — dipakai fitur Menu 5 Stock Comparison.
     *  Sebelumnya ada input manual Qty di layar scan; sekarang qty otomatis = balance sistem
     *  saat scan, dan koreksi manual dilakukan lewat dialog ini (tap baris history). */
    private fun showEditQtyDialog(id: Int, sku: String, currentQty: String,
                                  currentShelf: String = "", desc: String = "") {
        val dp = resources.displayMetrics.density
        fun label(t: String) = TextView(this).apply { text = t; textSize = 12f; setPadding(0, (8 * dp).toInt(), 0, 0) }
        val etShelf = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                android.text.InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS or
                android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            setSingleLine(true)
            hint = "Shelf, mis. AG04-01"
            setText(currentShelf.takeIf { it != "-" } ?: "")
        }
        val et = EditText(this).apply {
            setText(currentQty)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            selectAll()
        }
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val pad = (16 * dp).toInt()
            setPadding(pad, 8, pad, 0)
            if (desc.isNotBlank()) addView(TextView(context).apply { text = desc; textSize = 13f })
            addView(label("Shelf")); addView(etShelf)
            addView(label("Qty (Physical Count)")); addView(et)
        }
        AlertDialog.Builder(this).setTitle("Edit — $sku").setView(container)
            .setPositiveButton("SAVE") { _, _ ->
                val v = et.text.toString().trim().toIntOrNull()
                if (v != null) db.updatePriceQty(id, v)
                // ★ FIX (baru — Edit Shelf): kalau shelf diubah, update semua record
                // History untuk SKU ini & catat sebagai hasil edit untuk dikirim ke PC.
                val newShelf = etShelf.text.toString().trim().uppercase()
                val shelfChanged = newShelf.isNotEmpty() &&
                    newShelf != currentShelf.trim().uppercase()
                if (shelfChanged) {
                    db.updatePriceShelfBySku(sku, newShelf)
                    shelfEdits[sku] = newShelf
                    saveShelfEdits()
                }
                loadHistory()   // tanpa auto-open: selesai SAVE langsung kembali ke layar awal
                etSku.post { etSku.requestFocus() }
                Toast.makeText(this,
                    buildString {
                        if (v != null) append("Qty: $v")
                        if (shelfChanged) { if (isNotEmpty()) append("  "); append("Shelf: $newShelf") }
                        if (isEmpty()) append("No changes")
                    }, Toast.LENGTH_SHORT).show()
            }.setNegativeButton("Cancel", null).show()
        et.postDelayed({
            et.requestFocus()
            (getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager)
                .showSoftInput(et, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
        }, 150)
    }

    // ── Edit Shelf: simpan lokal & kirim ke PC (folder 05, sama seperti NO SHELF) ──

    private fun shelfEditsFile() = File(filesDir, "history_scan_shelf_edits.json")

    private fun loadShelfEdits(): MutableMap<String, String> {
        val f = shelfEditsFile()
        val m = LinkedHashMap<String, String>()
        if (!f.exists()) return m
        runCatching {
            val root = JSONObject(f.readText())
            root.keys().forEach { k -> root.optString(k, "").takeIf { it.isNotBlank() }?.let { m[k] = it } }
        }
        return m
    }

    private fun saveShelfEdits() {
        runCatching {
            val root = JSONObject()
            shelfEdits.forEach { (k, v) -> root.put(k, v) }
            shelfEditsFile().writeText(root.toString())
        }
    }

    /**
     * Kirim SKU & Shelf hasil edit ke PC — isi file per baris "Shelf,SKU", diurutkan
     * shelf A→Z. Folder tujuan MENGIKUTI "SMB Output Settings" menu ini
     * (OutputModule.SCAN_PROCESS; kosong → Setting global) — tidak ada folder default.
     */
    private fun sendEditedShelfToPc() {
        if (shelfEdits.isEmpty()) {
            Toast.makeText(this, "No shelf has been edited yet. Tap a History row to edit the Shelf.",
                Toast.LENGTH_LONG).show()
            return
        }
        val items = shelfEdits.entries.sortedBy { it.value.lowercase() }
        // Nama file SAMA dengan Shelf Record (Data Collector): {fileFormat}_05_yyyyMMdd_HHmmss.txt
        val prefix = fileFormat.ifBlank { "YM" }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val fileName = "${prefix}_05_$stamp.txt"
        val content = items.joinToString("\n") { "${TxtClean.field(it.value)},${TxtClean.field(it.key)}" }
        AlertDialog.Builder(this)
            .setTitle("Send Edited Shelf to PC")
            .setMessage("Send ${items.size} SKUs with edited shelf (Shelf,SKU format) to the PC (per SMB Output Settings)?")
            .setPositiveButton("Send") { _, _ ->
                lifecycleScope.launch {
                    try {
                        val loc = withContext(Dispatchers.IO) {
                            OutputWriter.write(this@ShelfPriceEnquireActivity, fileName, content, OutputModule.SCAN_PROCESS)
                        }
                        AlertDialog.Builder(this@ShelfPriceEnquireActivity)
                            .setTitle("Send Successful")
                            .setMessage("${items.size} item(s)\nFile: $fileName\nLocation: $loc")
                            .setPositiveButton("OK", null).show()
                    } catch (e: Exception) {
                        AlertDialog.Builder(this@ShelfPriceEnquireActivity)
                            .setTitle("Send Failed").setMessage(e.message)
                            .setPositiveButton("OK", null).show()
                    }
                }
            }
            .setNegativeButton("Cancel", null).show()
    }

    /** Setelah loadHistory selesai, jika scan terakhir menghasilkan baris
     *  multi-scan (merged), langsung buka dialog edit supaya user langsung tahu. */
    private fun autoOpenIfMultiScan() {
        val id  = lastScannedId ?: return
        val row = displayRows.firstOrNull { it.ids.contains(id.toInt()) } ?: return
        if (row.isMerged) showMergedRecordsDialog(row)
    }

    /** [autoOpenMulti] hanya true setelah SCAN (supaya user tahu SKU itu dobel). Setelah edit/hapus/restore
     *  = false, jadi selesai SAVE langsung kembali ke layar awal (tidak membuka pilihan data lagi). */
    private fun loadHistory(autoOpenMulti: Boolean = false) {
        deleteModePos = null
        historyRows.clear()
        val cur = db.getAllPrice()
        if (cur.moveToFirst()) {
            do {
                historyRows.add(arrayOf(
                    cur.getInt(cur.getColumnIndexOrThrow(C_PE_ID)).toString(),
                    cur.getString(cur.getColumnIndexOrThrow(C_PE_SKU))     ?: "",
                    cur.getString(cur.getColumnIndexOrThrow(C_PE_DESC))    ?: "",
                    cur.getString(cur.getColumnIndexOrThrow(C_PE_SHELF))   ?: "",
                    cur.getString(cur.getColumnIndexOrThrow(C_PE_PRICE))   ?: "",
                    cur.getString(cur.getColumnIndexOrThrow(C_PE_BALANCE)) ?: "",
                    cur.getString(cur.getColumnIndexOrThrow(C_PE_TIME))    ?: "",
                    cur.getInt(cur.getColumnIndexOrThrow(C_PE_UPLOADED)).toString(),
                    // ★ FIX: kolom Qty (jumlah fisik untuk Stock Comparison)
                    cur.getInt(cur.getColumnIndexOrThrow(C_PE_QTY)).toString()
                ))
            } while (cur.moveToNext())
        }
        cur.close()
        rebuildDisplayRows()
        histAdapter.notifyDataSetChanged()
        // ★ FIX: kalau scan baru menghasilkan baris multi-scan, langsung buka edit
        if (autoOpenMulti && lastScannedId != null) autoOpenIfMultiScan()
        updateHistoryCount()
    }

    // ── Download & Parse 02.txt ─────────────────────────────────────────
    private fun downloadPriceList() {
        // ★ FIX (baru): progress bar + persen supaya user tahu lama prosesnya.
        // Bobot: download 0–40%, simpan salinan 40–45%, parse & simpan database 45–100%.
        val pd = ProgressDialog(this).apply {
            setMessage("Downloading 02.txt…")
            setProgressStyle(ProgressDialog.STYLE_HORIZONTAL)
            max = 100
            progress = 0
            setProgressNumberFormat(null)   // sembunyikan "x/100", sisakan persen
            setCancelable(false)
            show()
        }
        var lastPct = -1
        var lastPhase = ""
        val report: (String, Int) -> Unit = { phase, pct ->
            val p = pct.coerceIn(0, 100)
            if (p != lastPct || phase != lastPhase) {
                lastPct = p; lastPhase = phase
                runOnUiThread { pd.setMessage(phase); pd.progress = p }
            }
        }
        fun mb(b: Long) = String.format(Locale.US, "%.1f", b / 1048576.0)
        lifecycleScope.launch {
            try {
                // FIX (force close): baca + parse + simpan SEMUA di background thread,
                // dan disimpan streaming langsung ke SQLite (bukan ditampung penuh
                // sebagai Map besar di RAM lalu diserialisasi jadi 1 string raksasa).
                val result = withContext(Dispatchers.IO) {
                    val raw = OutputWriter.read(this@ShelfPriceEnquireActivity, "02.txt") { done, total ->
                        if (total > 0) report("Downloading 02.txt…  ${mb(done)} / ${mb(total)} MB",
                            (done * 40 / total).toInt())
                        else report("Downloading 02.txt…  ${mb(done)} MB", 20)
                    }
                    report("Saving a copy of 02.txt…", 40)
                    // ★ FIX (baru — simpan salinan mentah 02.txt ke penyimpanan device):
                    // dulu isi 02.txt yang di-download (SMB maupun LOCAL) cuma dipakai
                    // buat di-parse ke katalog SQLite, TIDAK PERNAH disimpan sebagai file
                    // fisik di HP kalau sumbernya SMB. Sekarang, begitu download selesai
                    // (apapun mode-nya), 1 salinan mentahnya SELALU disimpan ke
                    // /storage/emulated/0/02/02.txt — folder baru khusus "02", terpisah
                    // dari folder QubeOutput/QubeOutputUpload yang sudah ada. Kegagalan
                    // simpan salinan ini TIDAK boleh menggagalkan proses download/parse
                    // katalog utama, jadi dibungkus try/catch sendiri & didiamkan.
                    // ★ FIX (baru — ganti kolom tanpa download ulang): salinan mentah juga
                    // disimpan di penyimpanan PRIVAT app (selalu bisa ditulis, tanpa izin
                    // storage) → dipakai untuk parse ulang saat setting kolom diubah.
                    try { rawCatalogFile().writeText(raw, Charsets.UTF_8) } catch (e: Exception) { }
                    try {
                        val dir02 = java.io.File(android.os.Environment.getExternalStorageDirectory(), "02")
                        if (!dir02.exists()) dir02.mkdirs()
                        java.io.File(dir02, "02.txt").writeText(raw, Charsets.UTF_8)
                    } catch (copyErr: Exception) {
                        // Diam-diam — kegagalan simpan salinan lokal tidak menghentikan proses utama.
                    }
                    report("Reading & storing data…", 45)
                    parseAndStoreCatalog(raw) { done, total ->
                        report("Reading & storing data…  $done / $total rows",
                            45 + (done.toLong() * 54 / maxOf(1, total)).toInt())
                    }.also {
                        // Data 02.txt baru = qty system segar → selisih import lama dibuang.
                        QtyAdjustImporter.clearStore(this@ShelfPriceEnquireActivity)
                        // keterangan update Kurangi/Tambah ikut di-reset (selisihnya sudah dibuang)
                        this@ShelfPriceEnquireActivity.qtySubtractUpdatedTime = 0L
                        this@ShelfPriceEnquireActivity.qtyAddUpdatedTime = 0L
                    }
                }
                report("Finishing…", 100)
                rawPreviewRow = result.previewRow
                detectedSep   = result.separator
                detectedCols  = result.totalCols
                catalogCount  = result.count
                this@ShelfPriceEnquireActivity.catalogUpdatedTime = System.currentTimeMillis()

                // Simpan info separator & preview ke prefs
                val existing = ColMappingPrefs.load(this@ShelfPriceEnquireActivity)
                ColMappingPrefs.save(this@ShelfPriceEnquireActivity, existing.copy(
                    separator  = result.separator,
                    previewRow = result.previewRow,
                    totalCols  = result.totalCols
                ))

                tvTotal.text      = "Total Item : ${result.count}"
                tvLastUpdate.text = "Last Updated Date : " +
                    SimpleDateFormat("EEE MMM dd HH:mm:ss z yyyy", Locale.ENGLISH).format(Date())
                pd.dismiss()

                // Tampilkan mapping yang dipakai
                val m = ColMappingPrefs.load(this@ShelfPriceEnquireActivity)
                val mappingInfo = if (m.userSaved)
                    "Column mapping: using saved configuration\n" +
                    "SKU=col.${m.colSku}  Shelf=col.${m.colShelf}  Price=col.${m.colPrice}  Balance=col.${m.colBalance}  Desc=col.${m.colDesc}"
                else
                    "Column mapping: default\n" +
                    "SKU=col.${m.colSku}  Shelf=col.${m.colShelf}  Price=col.${m.colPrice}  Balance=col.${m.colBalance}  Desc=col.${m.colDesc}\n\n" +
                    "If the description is still empty, tap SET COLUMNS and set the Desc column to the correct column (see the row preview above)."

                // ★ FIX (baru): laporkan baris yang GAGAL dicocokkan pola (sangat
                // jarang) supaya bisa dicek manual, bukan diam-diam masuk salah.
                val suspiciousInfo = if (result.suspiciousCount > 0) {
                    "\n\n⚠ ${result.suspiciousCount} row(s) could not be matched with " +
                    "full confidence (unusual column layout) and may need manual review:\n" +
                    result.suspiciousSkus.joinToString(", ") +
                    if (result.suspiciousCount > result.suspiciousSkus.size) ", ..." else ""
                } else ""

                // ★ FIX (baru — ringkasan perbaikan data error, sama seperti log CheckDisc):
                val repairInfo = if (result.mergedLines + result.repairedRows + result.skippedRows > 0) {
                    "\n\n🔧 Data repair: ${result.mergedLines} broken line(s) merged, " +
                    "${result.repairedRows} row(s) repaired, ${result.skippedRows} row(s) skipped" +
                    (if (result.skippedSamples.isNotEmpty())
                        " (" + result.skippedSamples.joinToString(", ") +
                        (if (result.skippedRows > result.skippedSamples.size) ", ..." else "") + ")"
                    else "")
                } else ""

                AlertDialog.Builder(this@ShelfPriceEnquireActivity)
                    .setTitle("Download Complete — ${result.count} item(s)")
                    .setMessage("${result.totalCols} columns, separator: '${result.separator}'\n\n$mappingInfo$suspiciousInfo$repairInfo")
                    .setPositiveButton("SET COLUMNS") { _, _ -> openColumnMapping() }
                    .setNegativeButton("OK", null).show()

            } catch (e: Exception) {
                pd.dismiss()
                Toast.makeText(this@ShelfPriceEnquireActivity,
                    "Download failed: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    /**
     * Parse 02.txt lalu simpan ke SQLite (AppDatabase.replaceCatalog):
     * 1. Deteksi separator (pipe lebih prioritas jika jumlahnya >= koma)
     * 2. Jika user sudah save mapping manual → pakai itu
     * 3. Jika belum → auto-detect dari baris pertama & simpan ke prefs
     *
     * ★ FIX (Desc terpotong): kolom Description sering mengandung koma, tab,
     * dan enter MENTAH (tidak di-quote) di sumber datanya. Sebelum diproses
     * baris-per-baris, seluruh teks di-reassemble dulu lewat
     * ColMappingPrefs.reassembleRecords() supaya baris yang terpecah gara-gara
     * enter di tengah Desc digabung balik jadi 1 record utuh, dan setiap
     * baris di-split pakai splitLineSmart() supaya koma ekstra di dalam Desc
     * tidak menggeser kolom-kolom lain sesudahnya.
     *
     * FIX (force close): baris diproses satu-per-satu lewat Sequence dan
     * langsung di-insert ke SQLite dalam 1 transaction. Tidak pernah ada
     * Map/List besar berisi SELURUH katalog yang ditahan di RAM.
     * HARUS dipanggil dari background thread (Dispatchers.IO).
     */
    private fun parseAndStoreCatalog(raw: String,
                                     onProgress: ((done: Int, total: Int) -> Unit)? = null): ParseResult {
        val firstRawLine = raw.lineSequence().firstOrNull { it.isNotBlank() }
            ?: throw Exception("File 02.txt is empty")
        val commaCount = firstRawLine.count { it == ',' }
        val pipeCount  = firstRawLine.count { it == '|' }
        val sep        = if (pipeCount > 0 && pipeCount >= commaCount) "|" else ","

        // ★ FIX: gabungkan dulu baris-baris yang terpecah gara-gara enter mentah
        // di dalam Desc, baru diproses satu-per-satu (tetap streaming, tidak
        // menahan seluruh file di RAM — reassembleRecords() juga pakai Sequence).
        //
        // ★ FIX (baru — perbaikan data error ala ProdMast.py): kalau file bergaya
        // Data Master (koma, mayoritas baris >= 23 kolom), pakai alur perbaikan
        // yang sama dengan CheckDisc di ProdMast.py:
        //   1. cd_merge_broken_lines → CsvRowCleaner.reassembleBrokenLines()
        //   2. cd_repair_broken_row  → CsvRowCleaner.repairBrokenRow() (di cleanRow)
        //   3. baris < 23 kolom setelah digabung dilewati (dilaporkan ke user).
        // Format lain (pipe / kolom sedikit) tetap pakai alur lama.
        val repairStats = CsvRowCleaner.RepairStats()
        val sampleColCounts = raw.lineSequence().filter { it.isNotBlank() }.take(50)
            .map { it.trimEnd('\r', '\n', ' ').split(sep).size }.toList()
        val modeCols = sampleColCounts.groupingBy { it }.eachCount()
            .maxByOrNull { it.value }?.key ?: 0
        val strictRepair = sep == "," && modeCols >= CsvRowCleaner.MIN_VALID_COLUMNS
        val reassembled = if (strictRepair)
            CsvRowCleaner.reassembleBrokenLines(raw, sep, repairStats)
        else
            ColMappingPrefs.reassembleRecords(raw, sep)
        val lineIterator = reassembled.iterator()
        if (!lineIterator.hasNext()) throw Exception("File 02.txt is empty")
        val firstLine = lineIterator.next()

        // ★ FIX (baru — kolom rancu / Balance ikut geser): sebelumnya baris
        // di-split pakai splitLineSmart() yang menggabungkan koma ekstra ke
        // kolom Desc (posisi iDesc hasil auto-detect/setting user) dan
        // totalCols dihitung dari BARIS PERTAMA saja. Kalau baris lain
        // punya jumlah koma ekstra yang BEDA di dalam Desc (SKU tertentu
        // deskripsinya lebih banyak koma dari baris pertama), hasil gabung
        // jadi salah posisi → kolom-kolom sesudah Desc (termasuk Balance)
        // ikut BERGESER dan terbaca dari kolom yang salah (contoh: Balance
        // kebaca dari kolom ke-20, padahal harusnya kolom lain).
        //
        // Sekarang SETIAP baris dipaksa SELALU tepat 24 kolom lewat
        // CsvRowCleaner (format Data Master 02.txt memang FIXED 24 kolom):
        // kalau kolom > 24, kelebihannya digabung balik ke KOLOM KE-4
        // (index 3, tempat Desc mulai) — BUKAN ke posisi iDesc yang bisa
        // beda-beda tiap baris; kalau kolom < 24, dilengkapi "" di akhir.
        // Hasilnya array 24 kolom yang posisinya SELALU konsisten untuk
        // SEMUA baris, jadi kolom Balance/Discount/dst tidak lagi rancu.
        val sampleParts = CsvRowCleaner.normalize(ColMappingPrefs.splitLine(firstLine, sep), sep)
        val totalCols   = sampleParts.size

        // Tentukan mapping yang dipakai
        val existing = ColMappingPrefs.load(this)
        val mapping = if (existing.userSaved) {
            // User sudah setting manual → pakai itu
            existing
        } else {
            // ★ FIX: belum di-set manual → pakai mapping DEFAULT standar
            // (SKU=1, Balance=19, Shelf=2, Price=3, Desc=4, Discount=13, dst),
            // bukan auto-detect, supaya nomor kolom selalu sesuai default.
            val detected = ColMappingPrefs.Mapping()
            val newMapping = detected.copy(
                separator  = sep,
                previewRow = firstLine,
                totalCols  = totalCols,
                userSaved  = false
            )
            ColMappingPrefs.save(this, newMapping)
            newMapping
        }

        val iSku     = mapping.colSku
        val iBalance = mapping.colBalance
        val iShelf   = mapping.colShelf
        val iPrice   = mapping.colPrice
        val iDesc    = mapping.colDesc
        // ★ FIX: kolom tambahan (opsional) untuk keterangan hasil scan SKU
        val iDiscount  = mapping.colDiscount
        val iDiscStart = mapping.colDiscStart
        val iDiscEnd   = mapping.colDiscEnd
        val iLongSku   = mapping.colLongSku
        val iKeepStock = mapping.colKeepStock

        // ★ FIX (baru — laporan baris bermasalah): baris yang GAGAL dicocokkan
        // pola oleh CsvRowCleaner (sangat jarang) dicatat di sini supaya bisa
        // dilaporkan ke user setelah Download selesai, bukan diam-diam salah
        // masuk ke database.
        var suspiciousCount = 0
        val suspiciousSkus  = mutableListOf<String>()
        val MAX_SUSPICIOUS_SAMPLES = 10

        fun toRow(line: String): CatalogRow? {
            if (line.isBlank()) return null
            // ★ FIX (baru — ProdMast.py): baris < 23 kolom (setelah digabung)
            // = rusak/terpotong → dilewati, bukan di-pad jadi data salah.
            if (strictRepair &&
                line.trimEnd('\r', '\n').split(sep).size < CsvRowCleaner.MIN_VALID_COLUMNS) {
                val head = line.substringBefore(sep).take(20)
                if (head.isNotBlank() && !head.equals("SKU", true)) {
                    repairStats.skipped++
                    if (repairStats.skippedSamples.size < MAX_SUSPICIOUS_SAMPLES)
                        repairStats.skippedSamples.add(head)
                }
                return null
            }
            // ★ FIX (baru — anchor pola, bukan tebak index tetap): CsvRowCleaner
            // sekarang mencari titik potong Desc(kolom-4)/Master Desc(kolom-24)
            // dengan mencocokkan pola tetap kolom 5..23 (kode/tanggal/angka/
            // kosong), bukan cuma mengasumsikan semua kelebihan koma ada di
            // kolom-4. Ini yang membuat Balance & kolom-kolom lain sesudahnya
            // tidak lagi rancu/salah baca walau Desc MAUPUN Master Desc
            // sama-sama mengandung koma ekstra.
            //
            // Kalau suatu baris SANGAT jarang tidak cocok pola sama sekali
            // (data di luar 2 zona Desc yang diketahui), tetap dihasilkan 24
            // kolom (fallback aman, tidak pernah gagal insert), tapi SKU-nya
            // dicatat ke suspiciousSkus supaya dilaporkan ke user untuk
            // dicek manual — bukan diam-diam salah masuk ke database.
            val cleanResult = CsvRowCleaner.cleanRowWithConfidence(line, sep)
            val p   = cleanResult.columns
            if (cleanResult.repaired) repairStats.repaired++
            val sku = ColMappingPrefs.getCol(p, iSku).uppercase()
            if (sku.isBlank() || sku == "SKU" || sku == "BARCODE" || sku == "CODE") return null
            if (!cleanResult.confident && suspiciousSkus.size < MAX_SUSPICIOUS_SAMPLES) {
                suspiciousSkus.add(sku)
            }
            if (!cleanResult.confident) suspiciousCount++
            // ★ FIX: bersihkan sisa karakter tab yang mungkin masih ada di dalam
            // Desc (tidak memengaruhi split kolom, cuma kosmetik biar rapi).
            val descRaw = ColMappingPrefs.getCol(p, iDesc)
            // ★ FIX (Menu 4 — Keep Stock, Sync Recon: Data Master dari lokal SQLite/02):
            // kolom FIXED, TIDAK ikut ColMappingPrefs (yang bisa diubah user untuk
            // menu lain) — SELALU SKU=kolom 1, Rack=kolom 2, Deskripsi=kolom 4,
            // No Ctn=kolom 22, sesuai format Data Master 02.txt.
            val masterDescRaw = ColMappingPrefs.getCol(p, 4)
            return CatalogRow(
                sku       = sku,
                desc      = descRaw.replace('\t', ' ').replace(Regex("\\s+"), " ").trim(),
                shelf     = ColMappingPrefs.getCol(p, iShelf),
                price     = ColMappingPrefs.getCol(p, iPrice),
                balance   = ColMappingPrefs.getCol(p, iBalance),
                discount  = ColMappingPrefs.getCol(p, iDiscount),
                discStart = ColMappingPrefs.getCol(p, iDiscStart),
                discEnd   = ColMappingPrefs.getCol(p, iDiscEnd),
                longSku   = ColMappingPrefs.getCol(p, iLongSku),
                keepStock = ColMappingPrefs.getCol(p, iKeepStock),
                masterRack   = ColMappingPrefs.getCol(p, 2),
                masterDesc   = masterDescRaw.replace('\t', ' ').replace(Regex("\\s+"), " ").trim(),
                masterNoCtn  = ColMappingPrefs.getCol(p, 22)
            )
        }

        // Sequence: baris diproses satu-per-satu saat di-consume oleh replaceCatalog(),
        // bukan dikumpulkan dulu ke List besar.
        // ★ FIX (baru): estimasi total baris (jumlah newline) untuk persen progres;
        // dilaporkan tiap 500 baris supaya tidak membebani UI thread.
        val estTotal = if (onProgress != null) raw.count { it == '\n' } + 1 else 0
        var processed = 0
        val rowSequence = sequence {
            toRow(firstLine)?.let { yield(it) }
            while (lineIterator.hasNext()) {
                val row = toRow(lineIterator.next())
                processed++
                if (onProgress != null && processed % 500 == 0) onProgress(minOf(processed, estTotal), estTotal)
                row?.let { yield(it) }
            }
        }

        val count = db.replaceCatalog(rowSequence)
        return ParseResult(count, sep, totalCols, firstLine, suspiciousCount, suspiciousSkus,
            mergedLines = repairStats.merged, repairedRows = repairStats.repaired,
            skippedRows = repairStats.skipped, skippedSamples = repairStats.skippedSamples.toList())
    }

    private data class ParseResult(val count: Int, val separator: String,
        val totalCols: Int, val previewRow: String,
        // ★ FIX (baru): jumlah baris yang GAGAL dicocokkan pola oleh
        // CsvRowCleaner (fallback), + contoh SKU-nya (maks 10) untuk dilaporkan.
        val suspiciousCount: Int = 0, val suspiciousSkus: List<String> = emptyList(),
        // ★ FIX (baru — perbaikan data ala ProdMast.py): ringkasan hasil perbaikan.
        val mergedLines: Int = 0, val repairedRows: Int = 0,
        val skippedRows: Int = 0, val skippedSamples: List<String> = emptyList())

    // ── Upload ──────────────────────────────────────────────────────────
    private fun doUpload() {
        val count = db.countPrice()
        if (count == 0) { Toast.makeText(this, "No data", Toast.LENGTH_SHORT).show(); return }
        AlertDialog.Builder(this).setTitle("Upload").setMessage("Upload $count records to the server?")
            .setPositiveButton("Yes") { _, _ ->
                val pd = ProgressDialog(this).apply { setMessage("Uploading..."); show() }
                lifecycleScope.launch {
                    try {
                        // ★ FIX (baru — Upload to PC, 2 file output):
                        // File 1: "SKU,scan result/qty,system" — satu baris per record
                        //   (qty = hasil scan/fisik, balance = qty sistem/system).
                        // File 2 ("1. Print Result.txt"): "SKU,1" — satu baris per SKU
                        //   unik (untuk keperluan print label per SKU).
                        val cur       = db.getPriceUnuploaded()
                        val sb        = StringBuilder()
                        val skuPrintSet = LinkedHashSet<String>()
                        val ids       = mutableListOf<Int>()
                        if (cur.moveToFirst()) {
                            do {
                                val id  = cur.getInt(cur.getColumnIndexOrThrow(C_PE_ID))
                                val sku = cur.getString(cur.getColumnIndexOrThrow(C_PE_SKU))     ?: ""
                                val bal = cur.getString(cur.getColumnIndexOrThrow(C_PE_BALANCE)) ?: ""
                                val qty = cur.getInt(cur.getColumnIndexOrThrow(C_PE_QTY))
                                sb.appendLine("${TxtClean.field(sku)},$qty,${TxtClean.field(bal)}")
                                if (sku.isNotBlank()) skuPrintSet.add(TxtClean.field(sku))
                                ids.add(id)
                            } while (cur.moveToNext())
                        }
                        cur.close()
                        val printSb = StringBuilder()
                        skuPrintSet.forEach { sku -> printSb.appendLine("$sku,1") }

                        val fname      = outFileName(this@ShelfPriceEnquireActivity, "PRICEENQ")
                        // ★ FIX: nama file "1. Print Result.txt" ditambah tanggal di ujung
                        // (format ddMMyy) supaya tiap upload menghasilkan file histori
                        // yang berbeda dan tidak saling menimpa file upload hari lain.
                        val printDateStr = SimpleDateFormat("ddMMyy", Locale.getDefault()).format(Date())
                        val printFname = "1. Print Result $printDateStr.txt"
                        val location = withContext(Dispatchers.IO) {
                            OutputWriter.write(this@ShelfPriceEnquireActivity, fname, sb.toString(), OutputModule.SCAN_PROCESS)
                            OutputWriter.write(this@ShelfPriceEnquireActivity, printFname, printSb.toString(), OutputModule.SCAN_PROCESS)
                        }
                        ids.forEach { db.markPriceUploaded(it) }
                        loadHistory(); pd.dismiss()
                        AlertDialog.Builder(this@ShelfPriceEnquireActivity)
                            .setTitle("Upload Successful")
                            .setMessage("File: $fname\nFile: $printFname\nLocation: $location")
                            .setPositiveButton("OK", null).show()
                    } catch (e: Exception) {
                        pd.dismiss()
                        AlertDialog.Builder(this@ShelfPriceEnquireActivity)
                            .setTitle("Upload Failed").setMessage(e.message)
                            .setPositiveButton("OK", null).show()
                    }
                }
            }.setNegativeButton("Cancel", null).show()
    }
}
