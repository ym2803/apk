plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.tms.qubeapps.qubedatacollector"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.tms.qubeapps.stockbalancecheck"
        minSdk = 21
        targetSdk = 34
        versionCode = 8
        versionName = "1.0.4.0"

        // Buang terjemahan library (Material/AppCompat) selain bahasa yang dipakai → APK lebih kecil
        resourceConfigurations += listOf("en", "id")
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    buildFeatures {
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
    kotlinOptions {
        jvmTarget = "1.8"
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
            excludes += "/META-INF/LICENSE"
            excludes += "/META-INF/LICENSE.txt"
            excludes += "/META-INF/NOTICE"
            excludes += "/META-INF/NOTICE.txt"
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")

    // ── Barcode scanner: ZXing (pengganti ZBar, tersedia di JitPack) ──
    implementation("com.journeyapps:zxing-android-embedded:4.3.0")
    implementation("com.google.zxing:core:3.5.2")

    // ── SMB: smbj (pengganti jcifs, tersedia di Maven Central) ────────
    implementation("com.hierynomus:smbj:0.13.0")

    // ── FIX: smbj TIDAK bisa resolve nama komputer Windows (NetBIOS name),
    // hanya IP/DNS. Ini penyebab utama "SMB selalu gagal" walau 1 jaringan
    // & folder sudah di-share — Windows otomatis resolve NetBIOS, Android tidak.
    // jcifs-ng dipakai KHUSUS untuk resolusi nama → IP (lihat SmbUploader.resolveHost).
    // FIX (build gagal "Tag mismatch" saat download bcprov-jdk18on): jcifs-ng
    // secara default menarik Bouncy Castle sebagai dependency untuk fitur
    // enkripsi SMB3 yang TIDAK kita pakai (kita cuma pakai NbtAddress untuk
    // resolusi nama). Di-exclude supaya tidak perlu didownload sama sekali —
    // sekaligus menghindari masalah network/proxy saat download library itu.
    implementation("eu.agno3.jcifs:jcifs-ng:2.1.10") {
        exclude(group = "org.bouncycastle")
    }

    // ── Coroutines ────────────────────────────────────────────────────
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.7.0")

    // ── FIX: server HTTP built-in di HP (ganti skrip Python di PC) ─────
    implementation("org.nanohttpd:nanohttpd:2.3.1")

    // ── ★ FIX (baru): unit test murni JVM untuk ExInOutSync.computeSync() —
    // tanpa emulator/Robolectric, karena computeSync() sudah dipisah dari
    // Android/network (lihat app/src/test/.../ExInOutSyncTest.kt). ──────
    testImplementation("junit:junit:4.13.2")
}
