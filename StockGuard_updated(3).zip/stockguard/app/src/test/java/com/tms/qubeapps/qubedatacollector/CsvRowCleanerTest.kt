package com.tms.qubeapps.qubedatacollector

import org.junit.Assert.assertEquals
import org.junit.Test

/**
 * ★ Unit test murni JVM untuk CsvRowCleaner — memastikan SETIAP baris yang
 * dibersihkan SELALU tepat 24 kolom, sesuai aturan:
 *  - > 24 kolom  -> gabung elemen berlebih ke kolom ke-4 (index 3)
 *  - < 24 kolom  -> pad "" di akhir
 *  - = 24 kolom  -> tidak berubah
 */
class CsvRowCleanerTest {

    /** Baris "normal", dipakai sebagai basis contoh kasus dengan total kolom fleksibel. */
    private fun baseParts(col4: List<String>, totalCols: Int): List<String> {
        val before = listOf("SKU001", "A01-01", "SHELF1") // index 0,1,2
        val remainingAfterCol4 = totalCols - before.size - col4.size
        require(remainingAfterCol4 >= 0) { "totalCols terlalu kecil untuk col4 yang diberikan" }
        val after = (0 until remainingAfterCol4).map { "C$it" }
        return before + col4 + after
    }

    @Test
    fun `contoh kasus resmi - kolom ke-4 pecah jadi 3 akibat koma di deskripsi`() {
        // Susun baris 26 kolom, meniru contoh dari soal:
        // ...,79500.00,WOMEN EVA SANDAL BL,PK,PP P2055803W,F004,...
        val parts = mutableListOf<String>().apply {
            add("SKU001")            // 0
            add("A01-01")            // 1
            add("79500.00")          // 2
            add("WOMEN EVA SANDAL BL") // 3 <- mulai kolom-4 (index 3)
            add("PK")                 // 4
            add("PP P2055803W")       // 5
            add("F004")               // 6
            addAll((7 until 26).map { "C$it" }) // lengkapi sampai 26 kolom total
        }
        assertEquals(26, parts.size)

        val result = CsvRowCleaner.normalize(parts)

        assertEquals(24, result.size)
        assertEquals("SKU001", result[0])
        assertEquals("A01-01", result[1])
        assertEquals("79500.00", result[2])
        // ★ Hasil gabung kolom ke-4 sesuai contoh di soal:
        assertEquals("WOMEN EVA SANDAL BL,PK,PP P2055803W", result[3])
        assertEquals("F004", result[4]) // kolom sesudahnya mundur ke index 4
    }

    @Test
    fun `lebih dari 24 kolom - excess digabung ke kolom ke-4 dengan separator koma`() {
        // 26 kolom -> excess = 2 -> gabung index 3..5 (3 elemen jadi 1)
        val parts = baseParts(listOf("Desc Part A", "Desc Part B", "Desc Part C"), totalCols = 26)
        assertEquals(26, parts.size)

        val result = CsvRowCleaner.normalize(parts)

        assertEquals(24, result.size)
        assertEquals("Desc Part A,Desc Part B,Desc Part C", result[3])
        assertEquals("C0", result[4])  // elemen pertama setelah area merge, mundur ke index 4
        assertEquals("C19", result[23]) // elemen terakhir
    }

    @Test
    fun `pas 24 kolom - tidak berubah sama sekali`() {
        val parts = baseParts(listOf("Desc Normal"), totalCols = 24)
        assertEquals(24, parts.size)

        val result = CsvRowCleaner.normalize(parts)

        assertEquals(parts, result)
        assertEquals(24, result.size)
    }

    @Test
    fun `kurang dari 24 kolom - ditambah string kosong di akhir`() {
        val parts = listOf("SKU001", "A01-01", "PK", "79500.00", "WOMEN EVA SANDAL")
        assertEquals(5, parts.size)

        val result = CsvRowCleaner.normalize(parts)

        assertEquals(24, result.size)
        // 5 elemen asli tetap di posisi awal, sisanya "" sampai index 23
        assertEquals(parts, result.subList(0, 5))
        (5 until 24).forEach { i -> assertEquals("", result[i]) }
    }

    @Test
    fun `cleanRow - split dari baris mentah string dengan pemisah koma`() {
        val line = "SKU002,A02-02,PK,120000.00,GIRLS SHOES PINK,BEAUTIFUL,SIZE 30,F010"
        // 8 kolom -> harus di-pad jadi 24
        val result = CsvRowCleaner.cleanRow(line)
        assertEquals(24, result.size)
        assertEquals("SKU002", result[0])
        assertEquals("F010", result[7])
        assertEquals("", result[23])
    }

    @Test
    fun `cleanRow - baris dengan CRLF di ujung tidak ikut menempel ke elemen terakhir`() {
        val line = "A,B,C,D,E\r\n"
        val result = CsvRowCleaner.cleanRow(line)
        assertEquals(24, result.size)
        assertEquals("E", result[4]) // bukan "E\r\n" atau "E\r"
    }

    @Test
    fun `cleanLine - hasil digabung kembali jadi 1 string 24 kolom`() {
        val line = "SKU003,A03-03,PK,50000.00,DESC"
        val result = CsvRowCleaner.cleanLine(line)
        val cols = result.split(",")
        assertEquals(24, cols.size)
        assertEquals(line + ",".repeat(19), result) // 5 elemen asli + 19 kolom kosong
    }

    @Test
    fun `cleanText - banyak baris sekaligus, baris kosong dilewati`() {
        val raw = """
            SKU001,A,B,C,D
            
            SKU002,X,Y,Z
        """.trimIndent()
        val rows = CsvRowCleaner.cleanText(raw)
        assertEquals(2, rows.size)
        rows.forEach { assertEquals(24, it.split(",").size) }
    }

    @Test
    fun `excess sangat besar tetap menghasilkan tepat 24 kolom`() {
        // 40 kolom -> excess = 16, digabung index 3..19 (17 elemen jadi 1)
        val before = listOf("S", "R", "P")
        val excessPart = (0 until 17).map { "D$it" }
        val after = (0 until 20).map { "A$it" }
        val parts = before + excessPart + after
        assertEquals(40, parts.size)

        val result = CsvRowCleaner.normalize(parts)

        assertEquals(24, result.size)
        assertEquals(excessPart.joinToString(","), result[3])
        assertEquals("A0", result[4])
        assertEquals("A19", result[23])
    }

    // ─────────────────────────────────────────────────────────────────
    // ★ FIX (baru — anchor pola): kasus NYATA dari data mentah 02.txt di
    // mana koma ekstra muncul di DUA tempat sekaligus — kolom-4 (Desc) DAN
    // kolom-24 (Master Desc di akhir baris) — bukan cuma satu tempat.
    // Algoritma harus mencari titik potong yang benar lewat pencocokan
    // pola kolom 5..23 (kode/tanggal/angka/kosong yang selalu tetap),
    // bukan asumsi "semua kelebihan ada di kolom-4".
    // ─────────────────────────────────────────────────────────────────

    @Test
    fun `anchor pola - excess di Desc DAN Master Desc sekaligus tetap benar`() {
        val line = "9038565,AG04-11,74500.00,MEN EVA SANDAL BL,PK,PP P2055522M,F004,DIY001,903,UGF001,901,4A1,,,52000.00,18/12/2025,31/03/2026,0.00,04/08/2021,04/08/2021,7,,24/06/2026,,9038565,MEN EVA SANDAL BL,PK"

        val result = CsvRowCleaner.cleanRowWithConfidence(line)

        assertEquals(24, result.columns.size)
        assertEquals(true, result.confident) // harus YAKIN (cocok pola), bukan fallback
        assertEquals("9038565", result.columns[0])
        assertEquals("AG04-11", result.columns[1])
        assertEquals("74500.00", result.columns[2])
        // Desc (kolom-4) utuh, tidak menelan F004 dkk sesudahnya:
        assertEquals("MEN EVA SANDAL BL,PK,PP P2055522M", result.columns[3])
        assertEquals("F004", result.columns[4])
        assertEquals("DIY001", result.columns[5])
        assertEquals("903", result.columns[6])
        assertEquals("UGF001", result.columns[7])
        assertEquals("901", result.columns[8])
        assertEquals("4A1", result.columns[9])
        assertEquals("", result.columns[10])
        assertEquals("", result.columns[11])
        // Discount (kolom-15/index14) TIDAK KOSONG DAN TIDAK RANCU:
        assertEquals("52000.00", result.columns[14])
        assertEquals("18/12/2025", result.columns[15])
        assertEquals("31/03/2026", result.columns[16])
        assertEquals("0.00", result.columns[17])
        assertEquals("7", result.columns[20]) // kolom Balance-like, tidak lagi geser
        assertEquals("24/06/2026", result.columns[22])
        // Master Desc (kolom-24) utuh walau ada koma ekstra:
        assertEquals("MEN EVA SANDAL BL,PK", result.columns[23])
    }

    @Test
    fun `anchor pola - semua contoh baris error dari user menghasilkan 24 kolom yakin`() {
        val lines = listOf(
            "9038565,AG04-11,74500.00,MEN EVA SANDAL BL,PK,PP P2055522M,F004,DIY001,903,UGF001,901,4A1,,,52000.00,18/12/2025,31/03/2026,0.00,04/08/2021,04/08/2021,7,,24/06/2026,,9038565,MEN EVA SANDAL BL,PK",
            "9038566,-,74500.00,MEN EVA SANDAL GR,DGY,BR P2055523M,F004,DIY001,903,ZZZ,901,Z,,,0.00,04/08/2021,04/08/2021,0.00,04/08/2021,04/08/2021,0,,14/05/2025,,9038566,MEN EVA SANDAL GR,DG",
            "9038564,AG04-11,79500.00,WOMEN EVA SANDAL BL,PK,PP P2055803W,F004,DIY001,903,ZZZ1,901,C2,,,48000.00,22/10/2025,21/10/2035,0.00,04/08/2021,04/08/2021,1,,21/10/2025,,9038564,WOMEN EVA SANDAL BL,",
            "9034949,-,27000.00,CAP 19626,19627,19628#*VS,F006,Z,903,ZNI,901,Z,,,2000.00,17/04/2024,17/04/2034,17500.00,15/06/2020,30/06/2020,0,,14/05/2025,,9034949,CAP 19626,19627,1962"
        )
        val expectedDesc = listOf(
            "MEN EVA SANDAL BL,PK,PP P2055522M",
            "MEN EVA SANDAL GR,DGY,BR P2055523M",
            "WOMEN EVA SANDAL BL,PK,PP P2055803W",
            "CAP 19626,19627,19628#*VS"
        )
        lines.forEachIndexed { i, line ->
            val result = CsvRowCleaner.cleanRowWithConfidence(line)
            assertEquals(24, result.columns.size)
            assertEquals("baris ke-${i + 1} harus yakin (cocok pola)", true, result.confident)
            assertEquals("baris ke-${i + 1}", expectedDesc[i], result.columns[3])
        }
    }

    @Test
    fun `anchor pola - baris yang bersih (tanpa koma ekstra) tidak berubah`() {
        val line = "2000001,-,0.00,SPRAY 7F HY1020,W004,DIY001,907,ZLS,901,Z,,,0.00,01/01/1980,01/01/1980,0.00,01/01/1980,01/01/1980,0,,30/03/2026,,2000001,SPRAY 7F HY1020"
        val result = CsvRowCleaner.cleanRowWithConfidence(line)
        assertEquals(24, result.columns.size)
        assertEquals(true, result.confident)
        assertEquals("SPRAY 7F HY1020", result.columns[3])
        assertEquals("SPRAY 7F HY1020", result.columns[23])
    }

    @Test
    fun `anchor pola - baris di luar 2 pola dikenal tetap 24 kolom walau ditandai tidak yakin`() {
        // Kasus langka: kolom yang biasanya kosong (offset 6/7) justru berisi
        // data ber-koma. Algoritma harus tetap menghasilkan 24 kolom (fallback
        // aman) dan menandai confident = false supaya bisa dilaporkan.
        val line = "8900807,-,86500.00,INDOOR SLIPPER MEN 2688-2# @PA5,F004,DIY001,903N,ZZZ,901,3N,LSX.43, K3L,,0.00,24/03/2025,24/03/2025,0.00,24/03/2025,24/03/2025,0,,05/07/2026,,8900807,INDOOR SLIPPER MEN 2"
        val result = CsvRowCleaner.cleanRowWithConfidence(line)
        assertEquals(24, result.columns.size) // tetap 24, tidak pernah gagal/crash
        assertEquals(false, result.confident)  // tapi ditandai untuk dicek manual
    }

    // ── Perbaikan data ala ProdMast.py ────────────────────────────────────

    /** Baris 24 kolom normal dengan blok tengah sesuai CD_ROW_MID_PATTERN. */
    private fun midBlock() =
        ",,,52000.00,01/01/2026,31/01/2026,0.00,01/01/2026,02/01/2026,5,,03/01/2026,,"

    @Test
    fun `repairBrokenRow - koma di desc diganti titik koma dan master desc dipotong 20`() {
        val line = "1234567,AG01-01,79500.00,MEN EVA SANDAL BL,PK,PP,K1,K2,K3,K4,K5,K6" +
            midBlock() + "1234567,MEN EVA SANDAL BL,PK"
        val r = CsvRowCleaner.repairBrokenRow(line)
        assertEquals(true, r != null)
        assertEquals(24, r!!.size)
        assertEquals("1234567", r[0])
        assertEquals("MEN EVA SANDAL BL;PK;PP", r[3])
        assertEquals("52000.00", r[12])
        assertEquals("1234567", r[22])
        assertEquals(true, r[23].length <= 20)
    }

    @Test
    fun `repairBrokenRow - tanpa pola tengah mengembalikan null`() {
        assertEquals(null, CsvRowCleaner.repairBrokenRow("a,b,c,d"))
    }

    @Test
    fun `reassembleBrokenLines - baris terpotong disambung dan baris SKU baru tidak ikut`() {
        val full1 = (listOf("1000001", "A1", "100.00", "DESC PART1") + (4 until 24).map { "x$it" })
        val head = full1.take(6).joinToString(",")          // < 23 kolom
        val tail = full1.drop(6).joinToString(",")          // sambungan (tanpa pemisah di join)
        val row2 = (listOf("1000002", "A2", "200.00", "DESC2") + (4 until 24).map { "y$it" }).joinToString(",")
        val raw = head + "\n" + "," + tail + "\n" + row2 + "\n"
        val stats = CsvRowCleaner.RepairStats()
        val out = CsvRowCleaner.reassembleBrokenLines(raw, ",", stats).toList()
        assertEquals(2, out.size)
        assertEquals(1, stats.merged)
        assertEquals(24, out[0].split(",").size)
        assertEquals(row2, out[1])
    }
}
