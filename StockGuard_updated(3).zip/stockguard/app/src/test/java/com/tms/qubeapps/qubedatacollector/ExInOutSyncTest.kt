package com.tms.qubeapps.qubedatacollector

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * ★ FIX (baru): unit test murni JVM (tanpa emulator/Robolectric) untuk
 * ExInOutSync.computeSync() — logika inti Sync IN/OUT Keep Stock.
 *
 * Karena computeSync() adalah fungsi murni (tidak ada network call / akses
 * AppDatabase), setiap test di sini menyiapkan CSV + state lama secara
 * manual, lalu mengecek hasil hitungnya persis sesuai aturan yang
 * didokumentasikan di ExInOutSync.kt. Kalau ada perubahan logika di masa
 * depan yang tidak sengaja merusak salah satu aturan ini, test yang
 * relevan akan GAGAL — jadi bug ketahuan sebelum sempat dipakai di toko.
 *
 * Format baris CSV yang dipakai di semua test: "NoCtn,SKU" (kolom B, C —
 * kolom lain setelahnya tidak relevan untuk logika sync, jadi tidak
 * disertakan).
 */
class ExInOutSyncTest {

    private fun csv(vararg rows: String): String = rows.joinToString("\n")

    // ═══════════════════════════════════════════════════════════════════
    // IN — kombinasi (No Ctn, SKU) baru & belum pernah OUT
    // ═══════════════════════════════════════════════════════════════════
    @Test
    fun `SKU baru pada No Ctn baru terdeteksi IN`() {
        val result = ExInOutSync.computeSync(
            csvData = csv("A01,1001"),
            processedKeys = emptySet(),
            outHistory = emptySet()
        )
        assertTrue(result.foundNew)
        assertEquals(listOf("A01,1001"), result.out1)
        assertEquals(listOf("1001,1"), result.out2)
        assertEquals(setOf("A01|1001"), result.updatedKeys)
        assertTrue(result.out3.isEmpty())
    }

    // ═══════════════════════════════════════════════════════════════════
    // RE-IN — kunci baru muncul lagi, SKU-nya pernah tercatat OUT
    // ═══════════════════════════════════════════════════════════════════
    @Test
    fun `SKU yang pernah OUT lalu muncul lagi terdeteksi RE-IN, bukan IN biasa`() {
        val result = ExInOutSync.computeSync(
            csvData = csv("A01,1001"),
            processedKeys = emptySet(),
            outHistory = setOf("A01|1001")   // pernah OUT dengan kunci yang sama
        )
        assertTrue(result.foundNew)
        assertEquals(setOf("A01|1001"), result.updatedKeys)
        // RE-IN harus menghapus entry dari outHistory (bukan tetap tersimpan)
        assertFalse(result.updatedOutHistory.contains("A01|1001"))
        assertTrue(result.log.any { it.contains("RE-IN") })
    }

    // ═══════════════════════════════════════════════════════════════════
    // OUT — kunci hilang DAN SKU sudah tidak ada di No Ctn manapun
    // ═══════════════════════════════════════════════════════════════════
    @Test
    fun `SKU hilang total dari snapshot terdeteksi OUT`() {
        val result = ExInOutSync.computeSync(
            csvData = csv("A02,2002"),   // A01|1001 sudah tidak ada di CSV sama sekali
            processedKeys = setOf("A01|1001"),
            outHistory = emptySet()
        )
        assertTrue(result.foundOut)
        assertEquals(listOf(",1001"), result.out3)
        assertEquals(listOf("1001,3"), result.out4)
        assertFalse(result.updatedKeys.contains("A01|1001"))
        assertTrue(result.updatedOutHistory.contains("A01|1001"))
    }

    // ═══════════════════════════════════════════════════════════════════
    // ACTIVE/MOVE — kunci hilang TAPI SKU masih aktif di No Ctn lain
    // ═══════════════════════════════════════════════════════════════════
    @Test
    fun `SKU pindah No Ctn TIDAK boleh ter-OUT, dan kunci baru harus IN`() {
        // Simulasi: SKU 1001 pindah dari A01 ke A02
        val result = ExInOutSync.computeSync(
            csvData = csv("A02,1001"),
            processedKeys = setOf("A01|1001"),
            outHistory = emptySet()
        )
        // TIDAK boleh ada entry OUT untuk SKU yang cuma pindah lokasi
        assertFalse(result.foundOut)
        assertTrue(result.out3.isEmpty())
        // Kunci baru (No Ctn baru) harus tercatat sebagai IN
        assertTrue(result.foundNew)
        assertEquals(setOf("A02|1001"), result.updatedKeys)
        // Kunci lama HARUS SUDAH TIDAK ADA di state — bukan sekadar tidak nge-OUT
        assertFalse(result.updatedKeys.contains("A01|1001"))
    }

    @Test
    fun `Kunci lama hasil MOVE tidak boleh nyangkut lintas beberapa kali sync (regression test)`() {
        // Sync #1: SKU 1001 pindah dari A01 ke A02
        val r1 = ExInOutSync.computeSync(
            csvData = csv("A02,1001"),
            processedKeys = setOf("A01|1001"),
            outHistory = emptySet()
        )
        assertEquals(setOf("A02|1001"), r1.updatedKeys)

        // Sync #2: data di CSV sama persis (tidak ada perubahan apa pun).
        // Kalau bug lama masih ada (kunci "A01|1001" nyangkut di state),
        // baris ini akan salah terdeteksi "hilang lagi" & diproses ulang
        // sebagai ACTIVE/MOVE terus-menerus. Setelah fix, state sync #1
        // sudah bersih (hanya A02|1001), jadi sync #2 seharusnya TIDAK ada
        // perubahan sama sekali (tidak ada IN, tidak ada OUT, tidak ada log
        // MOVE lagi).
        val r2 = ExInOutSync.computeSync(
            csvData = csv("A02,1001"),
            processedKeys = r1.updatedKeys,
            outHistory = r1.updatedOutHistory
        )
        assertFalse(r2.foundNew)
        assertFalse(r2.foundOut)
        assertTrue(r2.log.none { it.contains("MOVE") })
        assertEquals(setOf("A02|1001"), r2.updatedKeys)
    }

    @Test
    fun `SKU yang pindah lalu benar-benar OUT tidak boleh tercetak dobel di file OUT`() {
        // Sync #1: SKU 1001 pindah dari A01 ke A02 (MOVE)
        val r1 = ExInOutSync.computeSync(
            csvData = csv("A02,1001"),
            processedKeys = setOf("A01|1001"),
            outHistory = emptySet()
        )
        // Sync #2: SKU 1001 benar-benar hilang total dari CSV (OUT sungguhan)
        val r2 = ExInOutSync.computeSync(
            csvData = csv("A03,9999"),   // baris lain, 1001 tidak ada lagi
            processedKeys = r1.updatedKeys,
            outHistory = r1.updatedOutHistory
        )
        // SKU 1001 cuma boleh muncul SATU KALI di file OUT, bukan 2x
        val out3For1001 = r2.out3.filter { it.contains("1001") }
        assertEquals(1, out3For1001.size)
    }

    // ═══════════════════════════════════════════════════════════════════
    // Split — SKU sama ditambahkan ke 2 No Ctn berbeda sekaligus
    // ═══════════════════════════════════════════════════════════════════
    @Test
    fun `SKU yang di-split ke 2 No Ctn sekaligus tercatat IN untuk keduanya`() {
        val result = ExInOutSync.computeSync(
            csvData = csv("A01,1001", "A02,1001"),
            processedKeys = emptySet(),
            outHistory = emptySet()
        )
        assertEquals(setOf("A01|1001", "A02|1001"), result.updatedKeys)
        assertEquals(2, result.out1.size)
    }

    @Test
    fun `Salah satu lokasi SKU split dihapus, SKU lain masih ada, TIDAK boleh OUT`() {
        // State: SKU 1001 ada di A01 dan A02
        val result = ExInOutSync.computeSync(
            csvData = csv("A02,1001"),   // A01 dihapus, A02 tetap ada
            processedKeys = setOf("A01|1001", "A02|1001"),
            outHistory = emptySet()
        )
        assertFalse(result.foundOut)
        assertEquals(setOf("A02|1001"), result.updatedKeys)
    }

    // ═══════════════════════════════════════════════════════════════════
    // DUPLICATE — kombinasi (No Ctn, SKU) sama muncul >1x dalam 1 snapshot
    // ═══════════════════════════════════════════════════════════════════
    @Test
    fun `Baris duplikat persis dalam 1 snapshot hanya diproses sekali`() {
        val result = ExInOutSync.computeSync(
            csvData = csv("A01,1001", "A01,1001", "A01,1001"),
            processedKeys = emptySet(),
            outHistory = emptySet()
        )
        assertEquals(1, result.out1.size)
        assertTrue(result.log.any { it.contains("DUPLICATE") })
    }

    // ═══════════════════════════════════════════════════════════════════
    // INVALID — No Ctn/SKU kosong sebelah, atau SKU bukan angka murni
    // ═══════════════════════════════════════════════════════════════════
    @Test
    fun `No Ctn kosong tapi SKU ada dicatat INVALID dan dilewati`() {
        val result = ExInOutSync.computeSync(
            csvData = csv(",1001"),
            processedKeys = emptySet(),
            outHistory = emptySet()
        )
        assertTrue(result.out1.isEmpty())
        assertTrue(result.log.any { it.contains("INVALID") })
    }

    @Test
    fun `SKU bukan angka murni dicatat INVALID`() {
        val result = ExInOutSync.computeSync(
            csvData = csv("A01,ABC123"),
            processedKeys = emptySet(),
            outHistory = emptySet()
        )
        assertTrue(result.out1.isEmpty())
        assertTrue(result.log.any { it.contains("INVALID") })
    }

    @Test
    fun `Baris kosong dua-duanya diabaikan tanpa log INVALID`() {
        val result = ExInOutSync.computeSync(
            csvData = csv(",", "A01,1001"),
            processedKeys = emptySet(),
            outHistory = emptySet()
        )
        assertEquals(1, result.out1.size)
        assertFalse(result.log.any { it.contains("INVALID") })
    }

    // ═══════════════════════════════════════════════════════════════════
    // Snapshot baru kosong — state lama TIDAK BOLEH ikut ter-OUT-kan
    // (proteksi kalau sheet kosong sesaat/sedang di-edit)
    // ═══════════════════════════════════════════════════════════════════
    @Test
    fun `CSV kosong sama sekali tidak boleh meng-OUT-kan semua state lama`() {
        val result = ExInOutSync.computeSync(
            csvData = "",
            processedKeys = setOf("A01|1001", "A02|2002"),
            outHistory = emptySet()
        )
        assertFalse(result.foundOut)
        assertTrue(result.out3.isEmpty())
        // state lama dipertahankan utuh
        assertEquals(setOf("A01|1001", "A02|2002"), result.updatedKeys)
    }

    // ═══════════════════════════════════════════════════════════════════
    // CSV parser — kutip & koma di dalam field
    // ═══════════════════════════════════════════════════════════════════
    @Test
    fun `CSV parser menangani field dengan tanda kutip`() {
        val result = ExInOutSync.computeSync(
            csvData = csv("\"A01\",\"1001\""),
            processedKeys = emptySet(),
            outHistory = emptySet()
        )
        assertEquals(setOf("A01|1001"), result.updatedKeys)
    }

    // ═══════════════════════════════════════════════════════════════════
    // ★ FIX (baru) — Sanity check Mass OUT
    // ═══════════════════════════════════════════════════════════════════
    @Test
    fun `OUT masif memicu WARNING di log tapi tetap diproses (tidak diblokir)`() {
        // 25 kunci lama, snapshot baru kosong -> bukan skenario ini (CSV kosong
        // memang sengaja tidak diproses OUT sama sekali, lihat test di atas).
        // Simulasikan lewat 1 SKU valid tersisa + 25 SKU lain hilang total.
        val oldKeys = (1..25).map { "A$it|100$it" }.toSet() + setOf("B01|9999")
        val result = ExInOutSync.computeSync(
            csvData = csv("B01,9999"),   // hanya 1 yang bertahan, 25 lainnya OUT
            processedKeys = oldKeys,
            outHistory = emptySet()
        )
        assertEquals(25, result.out3.size)
        assertTrue(result.log.any { it.contains("WARNING") })
        // tetap diproses normal, tidak diblokir/dikosongkan
        assertTrue(result.foundOut)
    }

    @Test
    fun `OUT jumlah kecil dan wajar TIDAK memicu WARNING (populasi kecil, rasio tinggi tapi wajar)`() {
        val result = ExInOutSync.computeSync(
            csvData = csv("A02,2002"),
            processedKeys = setOf("A01|1001", "A02|2002"),   // cuma 2 kunci -> rasio 50% tapi wajar
            outHistory = emptySet()
        )
        assertEquals(1, result.out3.size)
        assertFalse(result.log.any { it.contains("WARNING") })
    }
}
