package com.tms.qubeapps.qubedatacollector

import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * ★ FIX (baru — Export Excel di Stock Comparison / Compare Sistem vs Stock
 * Take): selain Export PDF, sekarang tersedia juga Export Excel (.xlsx),
 * dipakai di StockComparisonActivity (menu Stock Balance Check) & juga bisa
 * dipakai StockTakeCompareActivity (menu Data Collector).
 *
 * Ditulis TANPA library pihak ketiga (tidak pakai Apache POI, dsb — supaya
 * tidak menambah ukuran APK/dependency baru) — file .xlsx pada dasarnya
 * cuma ZIP berisi beberapa file XML (format Office Open XML/SpreadsheetML),
 * jadi bisa dibuat langsung pakai java.util.zip yang sudah tersedia di
 * Android. Isi kolom SAMA PERSIS dengan Export PDF (lihat PdfExporter):
 * SKU, Shelf, Description, Balance, Keep Stock, System Balance, Difference,
 * 2nd Check, Remark (2 kolom terakhir dikosongkan untuk diisi manual).
 */
object ExcelExporter {

    private val headers = listOf(
        "SKU", "Shelf", "Description", "Balance", "Keep Stock",
        "System Balance", "Difference", "2nd Check", "Remark"
    )

    /**
     * Urutan baris SAMA dengan PdfExporter.generate(): yang sudah di-scan
     * diurutkan berdasarkan waktu scan (paling lama di atas), baris yang
     * belum discan selalu di paling bawah.
     */
    fun generate(rows: List<ComparisonRow>, title: String = "Stock Comparison Report"): ByteArray {
        val sortedRows = rows.sortedWith(compareBy({ !it.scanned }, { it.firstScanId }))
        val dateStr = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())

        val sheetXml = buildSheetXml(sortedRows, title, dateStr)

        val out = ByteArrayOutputStream()
        ZipOutputStream(out).use { zip ->
            writeEntry(zip, "[Content_Types].xml", CONTENT_TYPES_XML)
            writeEntry(zip, "_rels/.rels", RELS_XML)
            writeEntry(zip, "xl/workbook.xml", WORKBOOK_XML)
            writeEntry(zip, "xl/_rels/workbook.xml.rels", WORKBOOK_RELS_XML)
            writeEntry(zip, "xl/styles.xml", STYLES_XML)
            writeEntry(zip, "xl/worksheets/sheet1.xml", sheetXml)
        }
        return out.toByteArray()
    }

    private fun writeEntry(zip: ZipOutputStream, name: String, content: String) {
        zip.putNextEntry(ZipEntry(name))
        zip.write(content.toByteArray(Charsets.UTF_8))
        zip.closeEntry()
    }

    /** Escape teks untuk konten XML (cell inline string / title / dsb). */
    private fun esc(s: String): String = s
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace("\"", "&quot;")
        .replace("'", "&apos;")

    private fun inlineStrCell(ref: String, value: String, styleIdx: Int = 0): String {
        val styleAttr = if (styleIdx > 0) " s=\"$styleIdx\"" else ""
        return "<c r=\"$ref\" t=\"inlineStr\"$styleAttr><is><t xml:space=\"preserve\">${esc(value)}</t></is></c>"
    }

    private fun numberCell(ref: String, value: Int, styleIdx: Int = 0): String {
        val styleAttr = if (styleIdx > 0) " s=\"$styleIdx\"" else ""
        return "<c r=\"$ref\"$styleAttr><v>$value</v></c>"
    }

    private fun colRef(colIdx: Int): String {
        // 0-based column index -> Excel column letter (A, B, ..., Z, AA, ...)
        var n = colIdx + 1
        val sb = StringBuilder()
        while (n > 0) {
            val rem = (n - 1) % 26
            sb.insert(0, ('A' + rem))
            n = (n - 1) / 26
        }
        return sb.toString()
    }

    private fun buildSheetXml(rows: List<ComparisonRow>, title: String, dateStr: String): String {
        val sb = StringBuilder()
        sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>")
        sb.append("<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">")
        sb.append("<sheetData>")

        var r = 1
        // Baris 1: judul laporan
        sb.append("<row r=\"$r\">")
        sb.append(inlineStrCell("A$r", title, styleIdx = 2))
        sb.append("</row>")
        r++
        // Baris 2: info cetak (tanggal + total SKU)
        sb.append("<row r=\"$r\">")
        sb.append(inlineStrCell("A$r", "Printed: $dateStr   |   Total SKU: ${rows.size}"))
        sb.append("</row>")
        r++
        // Baris 3: catatan cara hitung Result
        sb.append("<row r=\"$r\">")
        sb.append(inlineStrCell("A$r", "*Result = (Scan Result + Keep Stock) - System"))
        sb.append("</row>")
        r++
        r++ // baris kosong pemisah

        // Baris header kolom
        sb.append("<row r=\"$r\">")
        headers.forEachIndexed { i, h -> sb.append(inlineStrCell("${colRef(i)}$r", h, styleIdx = 1)) }
        sb.append("</row>")
        r++

        // Baris data
        for (row in rows) {
            sb.append("<row r=\"$r\">")
            sb.append(inlineStrCell("${colRef(0)}$r", row.sku))
            sb.append(inlineStrCell("${colRef(1)}$r", row.shelf))
            sb.append(inlineStrCell("${colRef(2)}$r", row.desc))
            if (row.scanned) {
                sb.append(numberCell("${colRef(3)}$r", row.historyBalance))
                sb.append(numberCell("${colRef(4)}$r", row.keepStock))
                sb.append(numberCell("${colRef(5)}$r", row.systemBalance))
                val diffText = if (row.difference > 0) "+${row.difference}" else row.difference.toString()
                sb.append(inlineStrCell("${colRef(6)}$r", diffText))
            } else {
                sb.append(inlineStrCell("${colRef(3)}$r", "-"))
                sb.append(numberCell("${colRef(4)}$r", row.keepStock))
                sb.append(numberCell("${colRef(5)}$r", row.systemBalance))
                sb.append(inlineStrCell("${colRef(6)}$r", "NOT SCANNED"))
            }
            sb.append(inlineStrCell("${colRef(7)}$r", "")) // 2nd Check (kosong, diisi manual)
            sb.append(inlineStrCell("${colRef(8)}$r", "")) // Remark (kosong, diisi manual)
            sb.append("</row>")
            r++
        }

        sb.append("</sheetData>")
        sb.append("</worksheet>")
        return sb.toString()
    }

    private const val CONTENT_TYPES_XML = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
</Types>"""

    private const val RELS_XML = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>"""

    private const val WORKBOOK_XML = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
<sheets><sheet name="Stock Comparison" sheetId="1" r:id="rId1"/></sheets>
</workbook>"""

    private const val WORKBOOK_RELS_XML = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>"""

    // Style index 0 = default, 1 = bold (header), 2 = bold+bigger (title)
    private const val STYLES_XML = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<fonts count="3">
<font><sz val="10"/><name val="Calibri"/></font>
<font><b/><sz val="10"/><name val="Calibri"/></font>
<font><b/><sz val="13"/><name val="Calibri"/></font>
</fonts>
<fills count="1"><fill><patternFill patternType="none"/></fill></fills>
<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>
<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
<cellXfs count="3">
<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
<xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/>
<xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1"/>
</cellXfs>
</styleSheet>"""

    /**
     * ★ FIX (baru — Export Denah Custom, gaya tabel yang sama dengan Stock
     * Comparison): generator tabel generik buat data selain ComparisonRow
     * (mis. daftar No Ctn + posisi + status dari menu Denah Custom).
     */
    fun generateGenericTable(title: String, headers: List<String>, rows: List<List<String>>, subtitle: String? = null): ByteArray {
        val dateStr = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())
        val sb = StringBuilder()
        sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>")
        sb.append("<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">")
        sb.append("<sheetData>")

        var r = 1
        sb.append("<row r=\"$r\">").append(inlineStrCell("A$r", title, styleIdx = 2)).append("</row>"); r++
        sb.append("<row r=\"$r\">").append(inlineStrCell("A$r", "Printed: $dateStr   |   Total: ${rows.size}")).append("</row>"); r++
        if (!subtitle.isNullOrBlank()) { sb.append("<row r=\"$r\">").append(inlineStrCell("A$r", subtitle)).append("</row>"); r++ }
        r++

        sb.append("<row r=\"$r\">")
        headers.forEachIndexed { i, h -> sb.append(inlineStrCell("${colRef(i)}$r", h, styleIdx = 1)) }
        sb.append("</row>"); r++

        for (row in rows) {
            sb.append("<row r=\"$r\">")
            row.forEachIndexed { i, v -> sb.append(inlineStrCell("${colRef(i)}$r", v)) }
            sb.append("</row>"); r++
        }

        sb.append("</sheetData>")
        sb.append("</worksheet>")

        val out = ByteArrayOutputStream()
        ZipOutputStream(out).use { zip ->
            writeEntry(zip, "[Content_Types].xml", CONTENT_TYPES_XML)
            writeEntry(zip, "_rels/.rels", RELS_XML)
            writeEntry(zip, "xl/workbook.xml", WORKBOOK_XML)
            writeEntry(zip, "xl/_rels/workbook.xml.rels", WORKBOOK_RELS_XML)
            writeEntry(zip, "xl/styles.xml", STYLES_XML)
            writeEntry(zip, "xl/worksheets/sheet1.xml", sb.toString())
        }
        return out.toByteArray()
    }
}
