package com.tms.qubeapps.qubedatacollector

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings

/**
 * Helper untuk minta izin "All files access" yang dibutuhkan
 * untuk baca/tulis langsung ke /storage/emulated/0/... di Android 11+.
 */
object StoragePermissionHelper {

    fun hasPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Environment.isExternalStorageManager()
        } else {
            true // Android 10 ke bawah cukup pakai WRITE_EXTERNAL_STORAGE runtime permission
        }
    }

    /** Buka halaman Setting sistem untuk user kasih izin "All files access" */
    fun requestPermission(activity: Activity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
                intent.data = Uri.parse("package:${activity.packageName}")
                activity.startActivity(intent)
            } catch (e: Exception) {
                val intent = Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)
                activity.startActivity(intent)
            }
        }
    }
}
