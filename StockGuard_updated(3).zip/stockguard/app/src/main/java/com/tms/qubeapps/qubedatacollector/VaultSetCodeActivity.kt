package com.tms.qubeapps.qubedatacollector

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog

/**
 * Layar untuk mengganti kode buka Vault.
 * Dibuka dari kalkulator dengan mengetik "282828" lalu "=".
 */
class VaultSetCodeActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_vault_set_code)

        val tvCurrent  = findViewById<TextView>(R.id.tvCurrentVaultCode)
        val etNew      = findViewById<EditText>(R.id.etNewVaultCode)
        val etConfirm  = findViewById<EditText>(R.id.etConfirmVaultCode)
        val btnSave    = findViewById<Button>(R.id.btnSaveVaultCode)
        val btnBack    = findViewById<TextView>(R.id.btnVaultSetBack)

        val cur = VaultPrefs.getCode(this)
        tvCurrent.text = "Kode aktif: ${"●".repeat(cur.length)}"

        btnBack.setOnClickListener { finish() }

        btnSave.setOnClickListener {
            val newCode  = etNew.text.toString().trim()
            val confirm  = etConfirm.text.toString().trim()
            val reserved = setOf("2026", "282828")
            when {
                newCode.length < 4       -> toast("Minimal 4 angka")
                !newCode.all { it.isDigit() } -> toast("Hanya angka")
                newCode in reserved      -> toast("Kode tersebut sudah dipakai sistem")
                newCode != confirm       -> toast("Kode tidak cocok")
                else -> AlertDialog.Builder(this)
                    .setTitle("Ganti kode vault?")
                    .setMessage("Kode baru: $newCode")
                    .setPositiveButton("Simpan") { _, _ ->
                        VaultPrefs.setCode(this, newCode)
                        toast("Kode vault berhasil diubah")
                        finish()
                    }
                    .setNegativeButton("Batal", null)
                    .show()
            }
        }
    }

    private fun toast(msg: String) =
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
