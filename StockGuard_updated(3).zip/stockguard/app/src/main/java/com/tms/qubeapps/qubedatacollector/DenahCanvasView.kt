package com.tms.qubeapps.qubedatacollector

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import kotlin.math.abs

/**
 * ★ FIX (baru — Denah Custom per No Ctn): kanvas freeform buat gambar "peta"
 * lokasi box (No Ctn) & banner label (RECEIVING/CASHIER/dst), mirip contoh
 * gambar denah Excel yang dikasih user. Ditulis manual pakai Canvas (bukan
 * GridView/TableLayout) supaya posisi & ukuran tiap kotak bisa BEBAS, bukan
 * baris/kolom kaku — sama seperti tata letak toko aslinya.
 *
 * Koordinat tile (Tile.x/y/w/h) dalam SATUAN GRID (bukan px), dikonversi ke
 * px pakai gridUnitPx * scaleFactor saat digambar. Ini bikin snap-to-grid
 * gampang: posisi akhir tile SELALU bilangan bulat grid.
 *
 * Interaksi (1 jari, tanpa nested ScrollView, supaya drag & pan tidak
 * konflik dengan scroll parent):
 *  - Mode VIEW  : drag di area kosong = geser kanvas (pan). Tap di kotak
 *                 (tanpa geser signifikan) = onTileTap(tile).
 *  - Mode EDIT  : drag TEPAT DI ATAS kotak = pindahkan kotak itu (snap ke
 *                 grid saat lepas jari). Drag di area kosong = pan kanvas.
 *                 Tap kotak = onTileTap (buka dialog edit). Pinch 2 jari =
 *                 zoom in/out (scaleFactor 0.5x - 3x).
 */
class DenahCanvasView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    var editable: Boolean = false
    var tiles: MutableList<DenahLayoutPrefs.Tile> = mutableListOf()
        set(value) { field = value; invalidate() }

    /** noCtn -> true kalau ada SKU dengan qty > 0 di data KeepStock sekarang (dipakai buat warna mode VIEW). */
    var occupancy: Map<String, Boolean> = emptyMap()
        set(value) { field = value; invalidate() }

    /** Highlight tile yang cocok dengan search box (opsional). */
    var highlightNoCtn: String? = null
        set(value) { field = value; invalidate() }

    /**
     * ★ FIX (baru — Gridlines + nomor baris/abjad kolom seperti Excel):
     * kalau true, digambar garis grid tipis di tiap batas kotak + strip
     * nomor baris (kiri) & abjad kolom (atas, A/B/.../Z/AA/AB/...) mengikuti
     * koordinat grid tile (Tile.x/y) yang sebenarnya. Bisa dimatikan lewat
     * tombol toggle di layar (lihat DenahLayoutActivity).
     */
    var showGridLines: Boolean = true
        set(value) { field = value; invalidate() }

    var onTileTap: ((DenahLayoutPrefs.Tile) -> Unit)? = null
    /** newOffsetX/newOffsetY: pergeseran halus (grid unit, boleh pecahan) — lihat Tile.offsetX/offsetY. */
    var onTileMoved: ((DenahLayoutPrefs.Tile, newX: Int, newY: Int, newOffsetX: Float, newOffsetY: Float) -> Unit)? = null
    var onCanvasBoundsChanged: (() -> Unit)? = null

    /**
     * ★ FIX (baru — Fase 3 "Drag Bebas / Snap-to-Grid opsional"):
     * - true  (default, SAMA seperti perilaku sebelum Fase 3): box selalu
     *   nempel ke sel grid terdekat waktu dilepas jari.
     * - false : box bisa dilepas di posisi bebas mana saja (tidak nempel
     *   grid) — disimpan lewat Tile.offsetX/offsetY, x/y (sel acuan) tidak
     *   berubah.
     */
    var snapEnabled: Boolean = true

    /** Ukuran pembulatan grid waktu snapEnabled=true, dalam satuan SEL (1/5/10/25/50 sesuai spesifikasi). */
    var snapGridSize: Int = 1

    // ── ★ FIX (baru — Blok Pilih Banyak Box: pindahkan beberapa box sekaligus) ──
    /**
     * Kalau true (& editable=true), jalur sentuh BERALIH TOTAL ke mode seleksi:
     * drag di area kosong/box belum-terpilih = gambar kotak seleksi (rubber-band),
     * tap box = pilih/batal satu-satu, drag box yang SUDAH terpilih = pindahkan
     * SEMUA box terpilih bersama-sama. Default false supaya perilaku drag/pan
     * biasa (1 box per drag) TIDAK BERUBAH SAMA SEKALI kalau fitur ini tidak dipakai.
     */
    var selectionMode: Boolean = false
        set(value) {
            field = value
            if (!value) { selectedTileIds.clear(); onSelectionChanged?.invoke(0) }
            invalidate()
        }

    /** Kumpulan id Tile yang lagi terpilih (blok) — publik, dibaca Activity kalau perlu. */
    val selectedTileIds: MutableSet<String> = mutableSetOf()
    var onSelectionChanged: ((Int) -> Unit)? = null

    /** Hasil 1 box dalam operasi group-move — dipakai [onTilesGroupMoved]. */
    data class GroupMoveResult(val tileId: String, val newX: Int, val newY: Int, val newOffsetX: Float, val newOffsetY: Float)
    /** Dipanggil SEKALI per operasi drag-blok (bukan per-box), supaya Activity cukup 1x pushUndoSnapshot(). */
    var onTilesGroupMoved: ((List<GroupMoveResult>) -> Unit)? = null

    /** Batalkan seleksi tanpa keluar dari selectionMode (mis. tombol "Batal Pilih"). */
    fun clearSelection() {
        selectedTileIds.clear()
        onSelectionChanged?.invoke(0)
        invalidate()
    }

    private var gridUnitPx = 90f
    private var scaleFactor = 1f
    private var offsetX = 0f
    private var offsetY = 0f

    private var draggingTile: DenahLayoutPrefs.Tile? = null
    private var dragStartRawX = 0f
    private var dragStartRawY = 0f
    private var dragTileStartX = 0f // px, pre-snap
    private var dragTileStartY = 0f
    private var didDragMove = false
    private var isPanning = false
    private var panLastX = 0f
    private var panLastY = 0f

    // ── ★ FIX (baru — Blok Pilih Banyak Box) ──
    private var isSelecting = false
    private var selectStartX = 0f
    private var selectStartY = 0f
    private var selectCurX = 0f
    private var selectCurY = 0f
    private var selectTouchedTile: DenahLayoutPrefs.Tile? = null
    private var isGroupDragging = false
    private var groupDragDx = 0f
    private var groupDragDy = 0f

    private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            scaleFactor = (scaleFactor * detector.scaleFactor).coerceIn(0.5f, 3f)
            invalidate()
            return true
        }
    })

    private val fillPaintOccupied = Paint().apply { color = Color.parseColor("#F5A623"); isAntiAlias = true }
    private val fillPaintEmpty = Paint().apply { color = Color.parseColor("#F2F2F2"); isAntiAlias = true }
    private val fillPaintHighlight = Paint().apply { color = Color.parseColor("#4CAF50"); isAntiAlias = true }
    // ★ FIX (baru): warna khusus SLOT KOSONG (belum ada No Ctn) — putih bersih, sesuai contoh denah user.
    private val fillPaintSlotEmpty = Paint().apply { color = Color.parseColor("#FFFFFF"); isAntiAlias = true }
    private val strokePaint = Paint().apply { color = Color.parseColor("#888888"); style = Paint.Style.STROKE; strokeWidth = 2f; isAntiAlias = true }
    private val dragStrokePaint = Paint().apply { color = Color.parseColor("#2B5A8A"); style = Paint.Style.STROKE; strokeWidth = 5f; isAntiAlias = true }
    private val textPaint = Paint().apply { color = Color.BLACK; isAntiAlias = true; textAlign = Paint.Align.CENTER }
    private val labelTextPaint = Paint().apply { color = Color.WHITE; isAntiAlias = true; textAlign = Paint.Align.CENTER; isFakeBoldText = true }

    // ── Gridlines + header (row number kiri, kolom abjad atas ala Excel) ──
    private val gridLinePaint = Paint().apply { color = Color.parseColor("#DADADA"); style = Paint.Style.STROKE; strokeWidth = 1f; isAntiAlias = true }
    private val headerBgPaint = Paint().apply { color = Color.parseColor("#EDEDED"); isAntiAlias = true }
    private val headerBorderPaint = Paint().apply { color = Color.parseColor("#BBBBBB"); style = Paint.Style.STROKE; strokeWidth = 1.5f; isAntiAlias = true }
    private val headerTextPaint = Paint().apply { color = Color.parseColor("#444444"); isAntiAlias = true; textAlign = Paint.Align.CENTER; textSize = 22f }
    private var colHeaderHeightPx = 0f
    private var rowHeaderWidthPx = 0f

    // ── Ruler/dimension guide (garis panah + angka, anotasi ukuran cluster) ──
    private val rulerLinePaint = Paint().apply { color = Color.parseColor("#333333"); style = Paint.Style.STROKE; strokeWidth = 3f; isAntiAlias = true }
    private val rulerTextPaint = Paint().apply { color = Color.parseColor("#333333"); isAntiAlias = true; textAlign = Paint.Align.CENTER; isFakeBoldText = true }

    // ★ FIX (baru — Fase 4 "Object Editor"): paint tambahan untuk WALL/AREA/ARROW/DOOR/TEXT.
    private val lockedStrokePaint = Paint().apply {
        color = Color.parseColor("#1565C0"); style = Paint.Style.STROKE; strokeWidth = 3f; isAntiAlias = true
        pathEffect = android.graphics.DashPathEffect(floatArrayOf(10f, 6f), 0f) // garis putus-putus = penanda "dikunci"
    }
    private val areaBorderPaint = Paint().apply { color = Color.parseColor("#5E35B1"); style = Paint.Style.STROKE; strokeWidth = 2.5f; isAntiAlias = true }
    private val areaTextPaint = Paint().apply { color = Color.parseColor("#311B92"); isAntiAlias = true; textAlign = Paint.Align.CENTER; isFakeBoldText = true }

    // ── ★ FIX (baru — Blok Pilih Banyak Box): paint kotak seleksi (rubber-band) + border box terpilih ──
    private val selectionRectPaint = Paint().apply { color = Color.parseColor("#4433B5E5"); style = Paint.Style.FILL; isAntiAlias = true }
    private val selectionRectBorderPaint = Paint().apply { color = Color.parseColor("#2196F3"); style = Paint.Style.STROKE; strokeWidth = 2.5f; isAntiAlias = true }
    private val selectedTileStrokePaint = Paint().apply { color = Color.parseColor("#2196F3"); style = Paint.Style.STROKE; strokeWidth = 5f; isAntiAlias = true }

    /** Gambar [block] dengan rotasi [rotationDeg] derajat di sekitar titik tengah [r]. */
    private inline fun drawRotated(canvas: Canvas, r: RectF, rotationDeg: Float, block: () -> Unit) {
        if (rotationDeg == 0f) { block(); return }
        canvas.save()
        canvas.rotate(rotationDeg, r.centerX(), r.centerY())
        block()
        canvas.restore()
    }

    /** Gambar 1 kepala panah segitiga kecil di titik ([tipX],[tipY]), menghadap ke arah [angleDeg] (0=kanan, 90=bawah, 180=kiri, 270=atas). */
    private fun drawArrowHead(canvas: Canvas, tipX: Float, tipY: Float, angleDeg: Float) {
        val size = 16f
        val rad = Math.toRadians(angleDeg.toDouble())
        val backX = tipX - size * Math.cos(rad).toFloat()
        val backY = tipY - size * Math.sin(rad).toFloat()
        val perp = rad + Math.PI / 2
        val leftX = backX + (size * 0.5f) * Math.cos(perp).toFloat()
        val leftY = backY + (size * 0.5f) * Math.sin(perp).toFloat()
        val rightX = backX - (size * 0.5f) * Math.cos(perp).toFloat()
        val rightY = backY - (size * 0.5f) * Math.sin(perp).toFloat()
        val path = Path().apply {
            moveTo(tipX, tipY); lineTo(leftX, leftY); lineTo(rightX, rightY); close()
        }
        canvas.drawPath(path, Paint(rulerLinePaint).apply { style = Paint.Style.FILL })
    }

    /** Ubah index kolom 0-based jadi abjad ala Excel: 0->A, 1->B, ..., 25->Z, 26->AA, dst. */
    private fun columnLetters(index0: Int): String {
        var n = index0
        val sb = StringBuilder()
        while (true) {
            sb.insert(0, ('A' + (n % 26)))
            n = n / 26 - 1
            if (n < 0) break
        }
        return sb.toString()
    }

    /** Grid unit dasar (dp) sebelum di-scale — dipakai buat konversi px<->grid. */
    fun setBaseGridUnitDp(dp: Int) {
        gridUnitPx = dp * resources.displayMetrics.density
        invalidate()
    }

    fun resetView() {
        scaleFactor = 1f; offsetX = 0f; offsetY = 0f
        invalidate()
    }

    /**
     * ★ FIX (baru — Fase 8 "Search", spesifikasi poin 18): zoom + pan supaya
     * [tile] persis ada di tengah layar, dan nyalakan highlight (hijau) —
     * highlightNoCtn sendiri sudah lama ada infrastrukturnya, cuma belum
     * ada pemicu UI-nya sampai sekarang (lihat DenahLayoutActivity.performSearch()).
     */
    fun focusOnTile(tile: DenahLayoutPrefs.Tile) {
        if (scaleFactor < 1.2f) scaleFactor = 1.5f
        val c = cellPx()
        val cx = (tile.x + tile.offsetX + tile.w / 2f) * c
        val cy = (tile.y + tile.offsetY + tile.h / 2f) * c
        offsetX = width / 2f - cx
        offsetY = height / 2f - cy
        highlightNoCtn = tile.noCtn
        invalidate()
    }

    private fun cellPx(): Float = gridUnitPx * scaleFactor

    private fun tileRectPx(t: DenahLayoutPrefs.Tile): RectF {
        val c = cellPx()
        // ★ FIX (baru — Fase 3): posisi layar sebenarnya = (x + offsetX, y + offsetY), bukan
        // cuma x/y — offsetX/Y menampung pergeseran halus hasil drag bebas (Snap OFF).
        val left = offsetX + (t.x + t.offsetX) * c
        val top = offsetY + (t.y + t.offsetY) * c
        return RectF(left, top, left + t.w * c, top + t.h * c)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val c = cellPx()

        if (showGridLines) {
            colHeaderHeightPx = 28f * resources.displayMetrics.density
            rowHeaderWidthPx = 34f * resources.displayMetrics.density
            drawGridLines(canvas, c)
        } else {
            colHeaderHeightPx = 0f
            rowHeaderWidthPx = 0f
        }

        for (t in tiles) {
            // ★ FIX (baru — Fase 4, Object Editor): objek dengan visible=false disembunyikan total
            // (tetap ada di data, cuma tidak digambar) — dipakai buat "layer" yang lagi tidak dipakai.
            if (!t.visible) continue
            val r = tileRectPxDrag(t)
            // Skip kalau di luar layar (optimasi ringan untuk denah besar)
            if (r.right < 0 || r.bottom < 0 || r.left > width || r.top > height) continue

            when (t.type) {
                "LABEL" -> {
                    val paint = Paint().apply {
                        color = try { Color.parseColor(t.colorHex ?: "#F5A623") } catch (e: Exception) { Color.parseColor("#F5A623") }
                        isAntiAlias = true
                    }
                    canvas.drawRoundRect(r, 6f, 6f, paint)
                    canvas.drawRoundRect(r, 6f, 6f, strokePaint)
                    labelTextPaint.textSize = (c * 0.28f).coerceIn(18f, 42f)
                    canvas.drawText(t.label ?: "", r.centerX(), r.centerY() + labelTextPaint.textSize / 3, labelTextPaint)
                }
                "RULER" -> {
                    // ★ FIX (baru — Ruler/dimension guide): garis panah + angka, anotasi ukuran
                    // cluster (mis. "36"/"38" di contoh denah user). Tidak ikut hitungan isi/kosong.
                    val isH = t.dir != "V"
                    val label = t.label?.takeIf { it.isNotBlank() } ?: (if (isH) t.w else t.h).toString()
                    rulerTextPaint.textSize = (c * 0.24f).coerceIn(16f, 30f)
                    if (isH) {
                        val y = r.centerY()
                        canvas.drawLine(r.left, y, r.right, y, rulerLinePaint)
                        drawArrowHead(canvas, r.left, y, 180f)
                        drawArrowHead(canvas, r.right, y, 0f)
                        canvas.drawText(label, r.centerX(), y - 12f, rulerTextPaint)
                    } else {
                        val x = r.centerX()
                        canvas.drawLine(x, r.top, x, r.bottom, rulerLinePaint)
                        drawArrowHead(canvas, x, r.top, 270f)
                        drawArrowHead(canvas, x, r.bottom, 90f)
                        canvas.save()
                        canvas.rotate(-90f, x - 16f, r.centerY())
                        canvas.drawText(label, x - 16f, r.centerY(), rulerTextPaint)
                        canvas.restore()
                    }
                }
                // ★ FIX (baru — Fase 4 "Object Editor"): 5 tipe objek statis baru sesuai
                // spesifikasi poin 16 (WALL/TEXT/AREA/ARROW/DOOR). Semua ikut rotation
                // (diputar di sekitar titik tengah objek) & locked (garis putus-putus biru
                // sebagai penanda visual kalau dikunci, supaya user tahu kenapa tidak bisa digeser).
                "WALL" -> drawRotated(canvas, r, t.rotation) {
                    val paint = Paint().apply { color = Color.parseColor(t.colorHex ?: "#424242"); isAntiAlias = true }
                    canvas.drawRect(r, paint)
                    if (t.locked) canvas.drawRect(r, lockedStrokePaint)
                }
                "AREA" -> drawRotated(canvas, r, t.rotation) {
                    val fillHex = t.colorHex ?: "#7E57C2"
                    val paint = Paint().apply {
                        color = try { Color.parseColor(fillHex) } catch (e: Exception) { Color.parseColor("#7E57C2") }
                        alpha = 90; isAntiAlias = true
                    }
                    canvas.drawRect(r, paint)
                    canvas.drawRect(r, if (t.locked) lockedStrokePaint else areaBorderPaint)
                    if (!t.label.isNullOrBlank()) {
                        areaTextPaint.textSize = (c * 0.22f).coerceIn(14f, 26f)
                        canvas.drawText(t.label, r.centerX(), r.centerY(), areaTextPaint)
                    }
                }
                "ARROW" -> drawRotated(canvas, r, t.rotation) {
                    val y = r.centerY()
                    canvas.drawLine(r.left, y, r.right, y, rulerLinePaint)
                    drawArrowHead(canvas, r.right, y, 0f)
                    if (!t.label.isNullOrBlank()) {
                        rulerTextPaint.textSize = (c * 0.22f).coerceIn(14f, 26f)
                        canvas.drawText(t.label, r.centerX(), y - 12f, rulerTextPaint)
                    }
                }
                "DOOR" -> drawRotated(canvas, r, t.rotation) {
                    val paint = Paint().apply { color = Color.parseColor(t.colorHex ?: "#8D6E63"); isAntiAlias = true }
                    canvas.drawRect(r, paint)
                    canvas.drawRect(r, if (t.locked) lockedStrokePaint else strokePaint)
                    // Garis lengkung tipis = simbol ayunan pintu (door swing), sekadar penanda visual.
                    val sweepPaint = Paint().apply { color = Color.parseColor("#5D4037"); style = Paint.Style.STROKE; strokeWidth = 2f; isAntiAlias = true }
                    canvas.drawArc(RectF(r.left, r.top, r.left + r.width() * 2, r.top + r.height() * 2), 180f, 90f, false, sweepPaint)
                }
                "TEXT" -> {
                    // Teks bebas, tanpa kotak/background — cuma anotasi tulisan di kanvas.
                    val paint = Paint().apply {
                        color = try { Color.parseColor(t.colorHex ?: "#000000") } catch (e: Exception) { Color.BLACK }
                        isAntiAlias = true; textAlign = Paint.Align.LEFT
                        textSize = (c * 0.3f).coerceIn(18f, 44f)
                    }
                    canvas.save()
                    if (t.rotation != 0f) canvas.rotate(t.rotation, r.left, r.top)
                    canvas.drawText(t.label ?: "", r.left, r.top + paint.textSize, paint)
                    canvas.restore()
                }
                else -> { // CTN
                    val isHighlight = highlightNoCtn != null && t.noCtn?.equals(highlightNoCtn, ignoreCase = true) == true
                    val isFilled = occupancy[t.noCtn?.trim()?.uppercase()] == true
                    val isEmptySlot = t.noCtn.isNullOrBlank()
                    val paint = when {
                        // ★ FIX (baru): colorHex (slot kosong=putih, perlu-review=merah, dst) SELALU menang
                        // dulu field ini diset tapi tidak pernah dipakai render CTN — sekarang diprioritaskan.
                        t.colorHex != null -> Paint().apply {
                            color = try { Color.parseColor(t.colorHex) } catch (e: Exception) { Color.parseColor("#FFFFFF") }
                            isAntiAlias = true
                        }
                        isHighlight -> fillPaintHighlight
                        isEmptySlot -> fillPaintSlotEmpty
                        isFilled -> fillPaintOccupied
                        else -> fillPaintEmpty
                    }
                    canvas.drawRect(r, paint)
                    canvas.drawRect(r, if (draggingTile?.id == t.id) dragStrokePaint else strokePaint)
                    // ★ FIX (baru — Blok Pilih Banyak Box): border biru tebal kalau box ini lagi terpilih.
                    if (selectedTileIds.contains(t.id)) canvas.drawRect(r, selectedTileStrokePaint)
                    textPaint.textSize = (c * 0.26f).coerceIn(16f, 34f)
                    // ★ FIX (baru — Nomor Slot Fisik): kalau slot kosong (noCtn null/blank), tampilkan
                    // nomor slot fisik (permanen, independen dari No Ctn) bukan "-".
                    val displayText = if (isEmptySlot) (t.slotNo?.toString() ?: "") else t.noCtn!!
                    canvas.drawText(displayText, r.centerX(), r.centerY() + textPaint.textSize / 3, textPaint)
                }
            }
        }

        if (showGridLines) drawHeaders(canvas, c)

        // ★ FIX (baru — Blok Pilih Banyak Box): gambar kotak seleksi (rubber-band) di atas semua tile.
        if (isSelecting) {
            val rect = RectF(
                minOf(selectStartX, selectCurX), minOf(selectStartY, selectCurY),
                maxOf(selectStartX, selectCurX), maxOf(selectStartY, selectCurY)
            )
            canvas.drawRect(rect, selectionRectPaint)
            canvas.drawRect(rect, selectionRectBorderPaint)
        }
    }

    /** Garis grid tipis di tiap batas kotak, mengikuti pan/zoom kanvas saat ini. */
    private fun drawGridLines(canvas: Canvas, c: Float) {
        if (c <= 1f) return
        var x = offsetX % c
        while (x < width) { canvas.drawLine(x, 0f, x, height.toFloat(), gridLinePaint); x += c }
        var y = offsetY % c
        while (y < height) { canvas.drawLine(0f, y, width.toFloat(), y, gridLinePaint); y += c }
    }

    /** Strip nomor baris (kiri, fixed-x mengikuti scroll vertikal) + abjad kolom (atas, fixed-y mengikuti scroll horizontal), ala Excel. */
    private fun drawHeaders(canvas: Canvas, c: Float) {
        if (c <= 1f) return
        headerTextPaint.textSize = (c * 0.22f).coerceIn(16f, 26f)

        // Strip abjad kolom (atas)
        canvas.drawRect(0f, 0f, width.toFloat(), colHeaderHeightPx, headerBgPaint)
        var startCol = Math.floor(((-offsetX) / c).toDouble()).toInt() - 1
        var xPx = offsetX + startCol * c
        while (xPx < width) {
            if (xPx + c >= 0f) {
                canvas.drawText(columnLetters(startCol), xPx + c / 2f, colHeaderHeightPx * 0.68f, headerTextPaint)
            }
            xPx += c; startCol++
        }
        canvas.drawLine(0f, colHeaderHeightPx, width.toFloat(), colHeaderHeightPx, headerBorderPaint)

        // Strip nomor baris (kiri)
        canvas.drawRect(0f, 0f, rowHeaderWidthPx, height.toFloat(), headerBgPaint)
        var startRow = Math.floor(((-offsetY) / c).toDouble()).toInt() - 1
        var yPx = offsetY + startRow * c
        while (yPx < height) {
            if (yPx + c >= 0f) {
                canvas.drawText((startRow + 1).toString(), rowHeaderWidthPx / 2f, yPx + c / 2f + headerTextPaint.textSize / 3f, headerTextPaint)
            }
            yPx += c; startRow++
        }
        canvas.drawLine(rowHeaderWidthPx, 0f, rowHeaderWidthPx, height.toFloat(), headerBorderPaint)

        // Kotak sudut kiri-atas (tumpang tindih 2 strip)
        canvas.drawRect(0f, 0f, rowHeaderWidthPx, colHeaderHeightPx, headerBgPaint)
        canvas.drawLine(0f, colHeaderHeightPx, rowHeaderWidthPx, colHeaderHeightPx, headerBorderPaint)
        canvas.drawLine(rowHeaderWidthPx, 0f, rowHeaderWidthPx, colHeaderHeightPx, headerBorderPaint)
    }

    private fun findTileAt(px: Float, py: Float): DenahLayoutPrefs.Tile? {
        // Iterasi terbalik supaya tile yang digambar belakangan (di atas) yang duluan ke-detect.
        for (i in tiles.indices.reversed()) {
            val t = tiles[i]
            if (!t.visible) continue // ★ FIX (baru — Fase 4): objek disembunyikan (visible=false) tidak bisa di-tap
            if (tileRectPx(t).contains(px, py)) return t
        }
        return null
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)
        if (scaleDetector.isInProgress) return true

        // ★ FIX (baru — Blok Pilih Banyak Box): kalau selectionMode aktif, jalur sentuh
        // SAMA SEKALI TERPISAH dari drag/pan/tap biasa di bawah — supaya perilaku lama
        // (mode Edit biasa, selectionMode OFF/default) TIDAK BERUBAH SEDIKITPUN.
        if (editable && selectionMode) {
            return handleSelectionTouch(event)
        }

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                didDragMove = false
                val tile = findTileAt(event.x, event.y)
                if (editable && tile != null) {
                    draggingTile = tile
                    dragStartRawX = event.x; dragStartRawY = event.y
                    val r = tileRectPx(tile)
                    dragTileStartX = r.left; dragTileStartY = r.top
                } else {
                    isPanning = true
                    panLastX = event.x; panLastY = event.y
                    // simpan tile (kalau ada) buat deteksi TAP di mode VIEW / non-drag tap di mode EDIT
                    draggingTile = if (!editable) tile else null
                    dragStartRawX = event.x; dragStartRawY = event.y
                }
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.x - dragStartRawX
                val dy = event.y - dragStartRawY
                if (abs(dx) > 8 || abs(dy) > 8) didDragMove = true

                if (editable && draggingTile != null && !isPanning) {
                    invalidate() // posisi digambar ulang tiap frame lewat draggingTile override di bawah
                    dragPreviewDx = dx; dragPreviewDy = dy
                } else if (isPanning) {
                    offsetX += event.x - panLastX
                    offsetY += event.y - panLastY
                    panLastX = event.x; panLastY = event.y
                    invalidate()
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (editable && draggingTile != null && !isPanning) {
                    val t = draggingTile!!
                    val c = cellPx()
                    val newPxLeft = dragTileStartX + dragPreviewDx
                    val newPxTop = dragTileStartY + dragPreviewDy
                    // ★ FIX (baru — Fase 3): posisi absolut hasil drag, dalam satuan grid (boleh pecahan).
                    val absGridX = (newPxLeft - offsetX) / c
                    val absGridY = (newPxTop - offsetY) / c
                    val newX: Int
                    val newY: Int
                    val newOffsetX: Float
                    val newOffsetY: Float
                    if (snapEnabled) {
                        // Perilaku lama: selalu bulat ke kelipatan snapGridSize sel terdekat, offset balik ke 0.
                        val grid = snapGridSize.coerceAtLeast(1)
                        newX = (Math.round(absGridX / grid) * grid).let { if (it < 0) 0 else it }
                        newY = (Math.round(absGridY / grid) * grid).let { if (it < 0) 0 else it }
                        newOffsetX = 0f
                        newOffsetY = 0f
                    } else {
                        // ★ FIX (baru): Snap OFF — x/y (sel acuan) TIDAK berubah, sisa pergeseran
                        // halus (boleh berapa saja, boleh negatif) ditampung di offsetX/offsetY,
                        // supaya box kelihatan bebas digeser kemana saja tanpa nempel grid.
                        newX = t.x
                        newY = t.y
                        newOffsetX = absGridX - t.x
                        newOffsetY = absGridY - t.y
                    }
                    if (didDragMove) {
                        // ★ FIX (baru — Fase 4): objek yang di-lock TIDAK BOLEH digeser sama sekali —
                        // abaikan hasil drag-nya (posisi kembali seperti semula lewat invalidate di
                        // bawah), user tetap bisa tap objek ini untuk buka dialog edit (unlock dsb).
                        if (!t.locked) {
                            onTileMoved?.invoke(t, newX, newY, newOffsetX, newOffsetY)
                        }
                    } else {
                        onTileTap?.invoke(t)
                    }
                    dragPreviewDx = 0f; dragPreviewDy = 0f
                } else if (!editable && draggingTile != null && !didDragMove) {
                    onTileTap?.invoke(draggingTile!!)
                }
                draggingTile = null
                isPanning = false
                invalidate()
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    private var dragPreviewDx = 0f
    private var dragPreviewDy = 0f

    // ── ★ FIX (baru — Blok Pilih Banyak Box): jalur sentuh mode seleksi, terpisah total
    // dari onTouchEvent biasa di atas (dipanggil hanya kalau editable && selectionMode). ──
    private fun handleSelectionTouch(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                didDragMove = false
                dragStartRawX = event.x; dragStartRawY = event.y
                val tile = findTileAt(event.x, event.y)
                if (tile != null && tile.type == "CTN" && selectedTileIds.contains(tile.id)) {
                    // Tap/drag di atas box yang SUDAH terpilih -> mulai GROUP DRAG (pindahkan semua bersama).
                    isGroupDragging = true
                    groupDragDx = 0f; groupDragDy = 0f
                } else {
                    // Mulai rubber-band selection. Kalau ternyata cuma tap (bukan drag beneran),
                    // ACTION_UP di bawah akan urus toggle-select 1 box / clear semua.
                    isSelecting = true
                    selectStartX = event.x; selectStartY = event.y
                    selectCurX = event.x; selectCurY = event.y
                    selectTouchedTile = tile
                }
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.x - dragStartRawX
                val dy = event.y - dragStartRawY
                if (abs(dx) > 8 || abs(dy) > 8) didDragMove = true
                if (isGroupDragging) {
                    groupDragDx = dx; groupDragDy = dy
                    invalidate()
                } else if (isSelecting) {
                    selectCurX = event.x; selectCurY = event.y
                    invalidate()
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (isGroupDragging) {
                    if (didDragMove) commitGroupDrag()
                } else if (isSelecting) {
                    if (didDragMove) {
                        applyRubberBandSelection()
                    } else {
                        // Tap biasa (bukan drag): tile -> toggle pilih/batal 1 box. Area kosong -> batal semua.
                        val t = selectTouchedTile
                        if (t != null && t.type == "CTN") {
                            if (!selectedTileIds.add(t.id)) selectedTileIds.remove(t.id)
                        } else {
                            selectedTileIds.clear()
                        }
                        onSelectionChanged?.invoke(selectedTileIds.size)
                    }
                }
                isGroupDragging = false
                isSelecting = false
                selectTouchedTile = null
                groupDragDx = 0f; groupDragDy = 0f
                invalidate()
                return true
            }
        }
        return true
    }

    /** Semua box dalam kotak seleksi (rubber-band) yang baru digambar -> masuk selectedTileIds. */
    private fun applyRubberBandSelection() {
        val rect = RectF(
            minOf(selectStartX, selectCurX), minOf(selectStartY, selectCurY),
            maxOf(selectStartX, selectCurX), maxOf(selectStartY, selectCurY)
        )
        tiles.forEach { t ->
            if (t.type == "CTN" && t.visible && RectF.intersects(rect, tileRectPx(t))) {
                selectedTileIds.add(t.id)
            }
        }
        onSelectionChanged?.invoke(selectedTileIds.size)
    }

    /** Hitung posisi akhir SEMUA box terpilih setelah drag-blok, lalu kirim SEKALIGUS lewat [onTilesGroupMoved]. */
    private fun commitGroupDrag() {
        val c = cellPx()
        val results = mutableListOf<GroupMoveResult>()
        selectedTileIds.forEach { id ->
            val t = tiles.firstOrNull { it.id == id } ?: return@forEach
            if (t.locked) return@forEach // ★ FIX: box terkunci ikut dilewati, sama seperti drag satuan.
            val base = tileRectPx(t)
            val newPxLeft = base.left + groupDragDx
            val newPxTop = base.top + groupDragDy
            val absGridX = (newPxLeft - offsetX) / c
            val absGridY = (newPxTop - offsetY) / c
            val newX: Int; val newY: Int; val newOffX: Float; val newOffY: Float
            if (snapEnabled) {
                val grid = snapGridSize.coerceAtLeast(1)
                newX = (Math.round(absGridX / grid) * grid).let { if (it < 0) 0 else it }
                newY = (Math.round(absGridY / grid) * grid).let { if (it < 0) 0 else it }
                newOffX = 0f; newOffY = 0f
            } else {
                newX = t.x
                newY = t.y
                newOffX = absGridX - t.x
                newOffY = absGridY - t.y
            }
            results.add(GroupMoveResult(t.id, newX, newY, newOffX, newOffY))
        }
        if (results.isNotEmpty()) onTilesGroupMoved?.invoke(results)
    }

    // Override tileRectPx untuk tile yang lagi di-drag supaya ikut preview posisi real-time.
    private fun tileRectPxDrag(t: DenahLayoutPrefs.Tile): RectF {
        // ★ FIX (baru — Blok Pilih Banyak Box): preview drag-blok — box terpilih ikut geser bareng.
        if (isGroupDragging && selectedTileIds.contains(t.id)) {
            val base = tileRectPx(t)
            return RectF(base.left + groupDragDx, base.top + groupDragDy, base.right + groupDragDx, base.bottom + groupDragDy)
        }
        val base = tileRectPx(t)
        return if (draggingTile?.id == t.id && !isPanning) {
            RectF(base.left + dragPreviewDx, base.top + dragPreviewDy, base.right + dragPreviewDx, base.bottom + dragPreviewDy)
        } else base
    }
}
