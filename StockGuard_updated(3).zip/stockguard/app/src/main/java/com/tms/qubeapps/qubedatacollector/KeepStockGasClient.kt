package com.tms.qubeapps.qubedatacollector

import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

/**
 * ★ FIX (Menu 4 — Keep Stock): client HTTP terpusat untuk semua operasi ke
 * Google Apps Script Web App (ADD, EDIT, PINDAH SKU, DELETE), dipakai oleh
 * layar View & Edit Data (Menu 4).
 *
 * PENTING: action "updateRow" di bawah ini BARU dan BELUM ADA di GAS Web App
 * lama (yang sebelumnya cuma support action "addRows" untuk fitur ADD DATA).
 * Web App di Google Apps Script harus ditambah 1 handler baru untuk action
 * "updateRow" — lihat file GAS_KS_addon_UPDATE.gs.txt yang disertakan
 * terpisah untuk kode lengkap yang perlu ditambahkan ke script kamu.
 *
 * Satu handler "updateRow" ini dipakai untuk 3 keperluan sekaligus:
 *  - EDIT      : kirim noCtn/sku/qty baru untuk baris tsb.
 *  - PINDAH SKU: kirim noCtn baru, sku & qty tetap sama seperti asal.
 *  - DELETE    : kirim noCtn/sku/qty semuanya string kosong ("") untuk
 *                mengosongkan baris tsb (bukan menghapus baris fisik, supaya
 *                kolom lain di kanan - E s/d AI, dipakai fitur Sync IN/OUT -
 *                tidak ikut bergeser/rusak).
 */
object KeepStockGasClient {

    /** ★ FIX: tambah BEBERAPA SKU/QTY sekaligus untuk 1 NO CTN yang sama (dulu cuma 1 SKU per submit). */
    fun addRows(webAppUrl: String, token: String, store: String, noCtn: String, items: List<Pair<String, String>>): JSONObject {
        val rowsArray = JSONArray()
        items.forEach { (sku, qty) ->
            rowsArray.put(JSONObject().apply {
                put("noCtn", noCtn)
                put("sku", sku)
                put("qty", qty.ifBlank { "1" })
            })
        }
        val body = JSONObject().apply {
            put("token", token)
            put("action", "addRows")
            put("sheet", store)
            put("rows", rowsArray)
        }
        return postJson(webAppUrl, body)
    }

    /** Update 1 baris (nomor baris asli di sheet) — dipakai untuk EDIT & PINDAH SKU. */
    fun updateRow(webAppUrl: String, token: String, store: String, row: Int, noCtn: String, sku: String, qty: String): JSONObject {
        val body = JSONObject().apply {
            put("token", token)
            put("action", "updateRow")
            put("sheet", store)
            put("row", row)
            put("noCtn", noCtn)
            put("sku", sku)
            put("qty", qty)
        }
        return postJson(webAppUrl, body)
    }

    /** Hapus (kosongkan) 1 baris — dipakai untuk DELETE ketiga kolom (NO CTN/SKU/QTY) sekaligus. */
    fun deleteRow(webAppUrl: String, token: String, store: String, row: Int): JSONObject =
        updateRow(webAppUrl, token, store, row, "", "", "")

    /**
     * ★ FIX (baru — Denah Custom): simpan/ambil layout denah (JSON blob) per
     * toko ke Web App yang sama. Web App HARUS ditambah 2 handler baru:
     * "saveLayout" & "getLayout" — lihat GAS_KS_addon_LAYOUT.gs.txt di root
     * project untuk kode Apps Script lengkap yang perlu ditambahkan (disimpan
     * di sheet tab terpisah, tidak mengganggu data KeepStock yang sudah ada).
     */
    fun saveLayout(webAppUrl: String, token: String, store: String, layoutJson: JSONObject): JSONObject {
        val body = JSONObject().apply {
            put("token", token)
            put("action", "saveLayout")
            put("store", store)
            put("layout", layoutJson)
        }
        return postJson(webAppUrl, body)
    }

    /** Return JSONObject dengan field "layout" (JSON layout, atau null kalau belum pernah disimpan). */
    fun getLayout(webAppUrl: String, token: String, store: String): JSONObject {
        val body = JSONObject().apply {
            put("token", token)
            put("action", "getLayout")
            put("store", store)
        }
        return postJson(webAppUrl, body)
    }

    /**
     * ★ FIX (baru — Fase 2 "Layout Editor" — skema ternormalisasi, GANTI
     * pendekatan 1 JSON blob per toko): simpan/ambil POSISI BOX (per No Ctn)
     * dari sheet terpisah "BOX_POSITION" — kolom OBJECT_ID, STORE_CODE,
     * NO_CTN, X, Y, WIDTH, HEIGHT, ROTATION, LOCKED, VISIBLE, UPDATED_AT,
     * UPDATED_BY. Upsert per baris berdasarkan STORE_CODE+NO_CTN. Lihat
     * GAS_KS_addon_LAYOUT_V2.gs.txt untuk kode Apps Script lengkapnya.
     *
     * PENTING (kompatibilitas mundur — TIDAK menghapus apapun yang sudah
     * ada): saveLayout/getLayout (blob) di atas TETAP DIPAKAI sebagai jalur
     * utama & fallback. Fungsi2 di bawah ini dipanggil SECARA TERPISAH,
     * best-effort, dari DenahLayoutActivity — kalau Web App belum di-update
     * dengan addon V2 ini, panggilan akan gagal dengan aman (response error
     * biasa / exception network) dan TIDAK mempengaruhi hasil save/load
     * blob yang sudah berjalan seperti biasa.
     */
    fun getBoxPositions(webAppUrl: String, token: String, store: String): JSONObject {
        val body = JSONObject().apply {
            put("token", token)
            put("action", "getBoxPositions")
            put("store", store)
        }
        return postJson(webAppUrl, body)
    }

    /** Simpan BANYAK posisi box sekaligus (batch upsert) — dipanggil saat SAVE di Layout Editor. */
    fun saveBoxPositions(webAppUrl: String, token: String, store: String, positions: List<JSONObject>, updatedBy: String): JSONObject {
        val arr = JSONArray()
        positions.forEach { arr.put(it) }
        val body = JSONObject().apply {
            put("token", token)
            put("action", "saveBoxPositions")
            put("store", store)
            put("positions", arr)
            put("updatedBy", updatedBy)
        }
        return postJson(webAppUrl, body)
    }

    /**
     * ★ FIX (baru — Fase 2): simpan/ambil OBJEK STATIS denah (WALL/TEXT/
     * AREA/ARROW/DOOR/dll — BUKAN box No Ctn) dari sheet terpisah
     * "LAYOUT_OBJECT". Disiapkan untuk Object Editor bebas-posisi di fase
     * berikutnya; LABEL & RULER yang sudah ada sekarang tetap ikut
     * tersimpan lewat saveLayout (blob) seperti biasa untuk kompatibilitas
     * mundur, jadi TIDAK ADA fitur existing yang hilang/berubah.
     */
    fun getLayoutObjects(webAppUrl: String, token: String, store: String): JSONObject {
        val body = JSONObject().apply {
            put("token", token)
            put("action", "getLayoutObjects")
            put("store", store)
        }
        return postJson(webAppUrl, body)
    }

    fun saveLayoutObject(webAppUrl: String, token: String, store: String, obj: JSONObject): JSONObject {
        val body = JSONObject().apply {
            put("token", token)
            put("action", "saveLayoutObject")
            put("store", store)
            put("object", obj)
        }
        return postJson(webAppUrl, body)
    }

    fun updateLayoutObject(webAppUrl: String, token: String, store: String, objectId: String, obj: JSONObject): JSONObject {
        val body = JSONObject().apply {
            put("token", token)
            put("action", "updateLayoutObject")
            put("store", store)
            put("objectId", objectId)
            put("object", obj)
        }
        return postJson(webAppUrl, body)
    }

    fun deleteLayoutObject(webAppUrl: String, token: String, store: String, objectId: String): JSONObject {
        val body = JSONObject().apply {
            put("token", token)
            put("action", "deleteLayoutObject")
            put("store", store)
            put("objectId", objectId)
        }
        return postJson(webAppUrl, body)
    }

    /**
     * ★ FIX (Menu 5 — Stock Comparison, Export > Google Sheets / 2nd Check):
     * kirim hasil 2nd check ke Web App Google Apps Script tujuan (URL diisi
     * bebas oleh user di dialog Export — lihat StockComparisonActivity).
     * Web App HARUS ditambah 1 handler baru untuk action "appendSecondCheck"
     * — lihat file GAS_ADDON_SECOND_CHECK.gs.txt yang disertakan terpisah.
     * Data SELALU di-APPEND ke baris paling bawah (tidak pernah overwrite).
     * token boleh dikosongkan kalau Web App tujuan tidak memvalidasi token.
     */
    fun appendSecondCheckRows(webAppUrl: String, token: String, rows: List<JSONObject>): JSONObject {
        val rowsArray = JSONArray()
        rows.forEach { rowsArray.put(it) }
        val body = JSONObject().apply {
            put("token", token)
            put("action", "appendSecondCheck")
            put("rows", rowsArray)
        }
        return postJson(webAppUrl, body)
    }

    /**
     * ★ FIX (baru — Menu 5 — Stock Comparison, Export > Google Sheets / All
     * Filtered Data): kirim SEMUA baris hasil compare yang sedang lolos
     * filter di layar (sama persis dengan isi Export PDF/Excel — lihat
     * StockComparisonActivity.buildExportRows()), BUKAN cuma baris yang
     * sudah di-2nd-check. Web App HARUS ditambah 1 handler baru untuk
     * action "appendComparisonExport" — lihat file
     * GAS_ADDON_COMPARISON_EXPORT.gs.txt yang disertakan terpisah.
     * Data SELALU di-APPEND ke baris paling bawah (tidak pernah overwrite).
     * token boleh dikosongkan kalau Web App tujuan tidak memvalidasi token.
     */
    fun appendComparisonExportRows(webAppUrl: String, token: String, rows: List<JSONObject>): JSONObject {
        val rowsArray = JSONArray()
        rows.forEach { rowsArray.put(it) }
        val body = JSONObject().apply {
            put("token", token)
            put("action", "appendComparisonExport")
            put("rows", rowsArray)
        }
        return postJson(webAppUrl, body)
    }

    private fun postJson(urlStr: String, body: JSONObject): JSONObject {
        val conn = URL(urlStr).openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.doOutput = true
        conn.instanceFollowRedirects = true
        conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
        conn.connectTimeout = 20000
        conn.readTimeout = 30000
        try {
            OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body.toString()) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (text.isBlank()) return JSONObject().apply { put("ok", false); put("error", "Empty response (HTTP $code)") }
            return JSONObject(text)
        } finally {
            conn.disconnect()
        }
    }
}
