package com.tms.qubeapps.qubedatacollector

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.animation.DecelerateInterpolator

/**
 * ★ FIX: layar pembuka (splash) yang tampil saat aplikasi dibuka, menampilkan
 * logo StockGuard PNG transparan (tanpa kotak/background di belakangnya) +
 * nama aplikasi di bawahnya, dengan animasi Fade In + Scale In, lalu
 * otomatis lanjut ke menu utama.
 */
class SplashActivity : BaseActivity() {

    private val splashDurationMs = 1800L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        // ★ FIX (baru): animasi Fade In + Scale In — logo membesar dari 80%
        // ke 100% sambil muncul (fade), teks nama app & tagline menyusul
        // (fade in sedikit lebih lambat) supaya terasa modern & tidak kaku.
        val logo = findViewById<android.view.View>(R.id.ivSplashLogo)
        val appName = findViewById<android.view.View>(R.id.tvSplashAppName)
        val tagline = findViewById<android.view.View>(R.id.tvSplashTagline)
        logo.scaleX = 0.8f
        logo.scaleY = 0.8f

        val logoFade  = ObjectAnimator.ofFloat(logo, "alpha", 0f, 1f).setDuration(500)
        val logoScaleX = ObjectAnimator.ofFloat(logo, "scaleX", 0.8f, 1f).setDuration(500)
        val logoScaleY = ObjectAnimator.ofFloat(logo, "scaleY", 0.8f, 1f).setDuration(500)
        val textFade   = ObjectAnimator.ofFloat(appName, "alpha", 0f, 1f).setDuration(450).apply { startDelay = 250 }
        val taglineFade = ObjectAnimator.ofFloat(tagline, "alpha", 0f, 1f).setDuration(450).apply { startDelay = 350 }

        AnimatorSet().apply {
            playTogether(logoFade, logoScaleX, logoScaleY, textFade, taglineFade)
            interpolator = DecelerateInterpolator()
            start()
        }

        Handler(Looper.getMainLooper()).postDelayed({
            startActivity(Intent(this, MenuModuleActivity::class.java))
            finish()
        }, splashDurationMs)
    }
}
