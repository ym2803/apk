package com.tms.qubeapps.qubedatacollector

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioGroup
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/**
 * ★ FIX: layar baru untuk custom posisi & judul field yang tampil di kartu
 * hasil scan SKU (grid 5x2 — 5 baris kiri, 5 baris kanan). User bisa memilih
 * field apa yang muncul di tiap slot, dan mengganti judul tampilannya bebas.
 */
class ResultLayoutActivity : BaseActivity() {

    private data class SlotRow(val spinner: Spinner, val etLabel: EditText)

    private val fieldLabels get() = ResultLayoutPrefs.availableFields.map { it.second }
    private val fieldKeys   get() = ResultLayoutPrefs.availableFields.map { it.first }

    private val leftRows  = mutableListOf<SlotRow>()
    private val rightRows = mutableListOf<SlotRow>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_result_layout)

        val containerLeft  = findViewById<LinearLayout>(R.id.containerLeft)
        val containerRight = findViewById<LinearLayout>(R.id.containerRight)

        val slots = ResultLayoutPrefs.load(this)
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, fieldLabels).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }

        for (i in 0 until 5) {
            leftRows.add(buildSlotRow(containerLeft, adapter, i, "Left, row ${i + 1}", slots[i]))
        }
        for (i in 5 until 10) {
            rightRows.add(buildSlotRow(containerRight, adapter, i, "Right, row ${i - 4}", slots[i]))
        }

        // ★ FIX (baru): muat pilihan font size & row spacing
        val rgFont    = findViewById<RadioGroup>(R.id.rgFontSize)
        val rgSpacing = findViewById<RadioGroup>(R.id.rgRowSpacing)
        rgFont.check(when (ResultLayoutPrefs.fontPct(this)) {
            80 -> R.id.rbFontSmall; 120 -> R.id.rbFontLarge; 140 -> R.id.rbFontXLarge; else -> R.id.rbFontNormal
        })
        rgSpacing.check(when (ResultLayoutPrefs.spacing(this)) {
            0 -> R.id.rbSpaceTight; 2 -> R.id.rbSpaceLoose; else -> R.id.rbSpaceNormal
        })

        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }

        findViewById<View>(R.id.btnResetDefault).setOnClickListener {
            ResultLayoutPrefs.resetToDefault(this)
            Toast.makeText(this, "Reset to default. Reloading screen...", Toast.LENGTH_SHORT).show()
            recreate()
        }

        findViewById<View>(R.id.btnSaveLayout).setOnClickListener { saveAndExit() }
    }

    private fun buildSlotRow(
        container: LinearLayout, adapter: ArrayAdapter<String>,
        slotIndex: Int, positionLabel: String, current: ResultLayoutPrefs.Slot
    ): SlotRow {
        val view = LayoutInflater.from(this).inflate(R.layout.item_result_layout_slot, container, false)
        container.addView(view)

        view.findViewById<TextView>(R.id.tvSlotNumber).text = "Slot ${slotIndex + 1} ($positionLabel)"

        val sp = view.findViewById<Spinner>(R.id.spFieldKey)
        sp.adapter = adapter
        val idx = fieldKeys.indexOf(current.fieldKey).let { if (it >= 0) it else 0 }
        sp.setSelection(idx)

        val et = view.findViewById<EditText>(R.id.etSlotLabel)
        et.setText(current.label)

        return SlotRow(sp, et)
    }

    private fun saveAndExit() {
        val allRows = leftRows + rightRows
        val slots = allRows.map { row ->
            val fieldKey = fieldKeys.getOrElse(row.spinner.selectedItemPosition) { "" }
            val label = row.etLabel.text.toString().trim().ifBlank { ResultLayoutPrefs.labelFor(fieldKey) }
            ResultLayoutPrefs.Slot(fieldKey, label)
        }
        ResultLayoutPrefs.save(this, slots)
        val fontPct = when (findViewById<RadioGroup>(R.id.rgFontSize).checkedRadioButtonId) {
            R.id.rbFontSmall -> 80; R.id.rbFontLarge -> 120; R.id.rbFontXLarge -> 140; else -> 100
        }
        val spacing = when (findViewById<RadioGroup>(R.id.rgRowSpacing).checkedRadioButtonId) {
            R.id.rbSpaceTight -> 0; R.id.rbSpaceLoose -> 2; else -> 1
        }
        ResultLayoutPrefs.saveDisplayStyle(this, fontPct, spacing)
        Toast.makeText(this, "Layout preview saved", Toast.LENGTH_SHORT).show()
        finish()
    }
}
