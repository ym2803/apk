package com.tms.qubeapps.qubedatacollector

import android.app.AlertDialog
import android.app.ProgressDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import com.tms.qubeapps.qubedatacollector.Prefs.outFileName
import com.tms.qubeapps.qubedatacollector.Prefs.uploadMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * ★ FIX (baru — Compare Sistem vs Scan untuk Stock Take/Add Box):
 * porting fitur halaman web "Compare Sistem vs Scan" (stock-opname.html) ke
 * dalam aplikasi, dengan pendekatan ala aplikasi — TANPA upload/tempel file
 * sama sekali. Data "Data Sistem" & "Data Scan" pada versi web digantikan
 * LANGSUNG oleh data yang SUDAH ADA di SQLite lokal:
 *  - Data Sistem → tabel price_catalog (hasil download 02.txt, menu Setting)
 *  - Data Scan   → tabel data_collect, hanya baris mode Stock Take/Add Box
 *                  (Menu Data Collector)
 *
 * Logika perbandingan (grouping per Shelf, status Sesuai/Selisih/Belum
 * Discan/Alamat Tidak Sesuai/Tidak Terdaftar, effectiveScan = qty scan +
 * Keep Stock) mengikuti PERSIS logika `computeGroups()` di versi web — lihat
 * AppDatabase.getStockTakeCompareRows() untuk detail implementasinya.
 *
 * Hasil ditampilkan lewat model ComparisonRow yang SAMA dengan Menu 5 (Stock
 * Comparison) supaya bisa langsung reuse PdfExporter untuk Export PDF, tanpa
 * perlu membuat exporter baru.
 */
class StockTakeCompareActivity : BaseActivity() {

    private lateinit var db: AppDatabase
    private lateinit var lvCompareResult: ListView
    private lateinit var tvCompareEmpty: TextView
    private lateinit var adapter: BaseAdapter
    private var rows: List<ComparisonRow> = emptyList()

    // ★ FIX (perf/crash — Compare Sistem vs Scan): query getStockTakeCompareRows()
    // membaca SELURUH tabel price_catalog + data_collect lalu diproses di memori.
    // Kalau dijalankan di main thread, menu ini bisa nge-lag lama saat dibuka dan
    // trigger ANR/crash (khususnya kalau katalog besar). isLoading mencegah
    // dua proses load jalan bersamaan (onCreate + onResume dobel, atau user
    // mash tombol Refresh berkali-kali).
    private var isLoading = false
    private var hasLoadedOnce = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_stock_take_compare)
        db = AppDatabase(this)

        lvCompareResult = findViewById(R.id.lvCompareResult)
        tvCompareEmpty = findViewById(R.id.tvCompareEmpty)

        adapter = object : BaseAdapter() {
            override fun getCount() = rows.size
            override fun getItem(position: Int) = rows[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val v = convertView ?: layoutInflater.inflate(R.layout.item_comparison_row, parent, false)
                val row = rows[position]
                v.findViewById<TextView>(R.id.tvCompSku).text = row.sku
                v.findViewById<TextView>(R.id.tvCompShelf).text = "Shelf: ${row.shelf}"
                v.findViewById<TextView>(R.id.tvCompDesc).text = row.desc
                val tvHistory = v.findViewById<TextView>(R.id.tvCompHistory)
                val tvDiff = v.findViewById<TextView>(R.id.tvCompDiff)
                v.findViewById<TextView>(R.id.tvCompSystem).text = "System: ${row.systemBalance}"
                v.findViewById<TextView>(R.id.tvCompKeepStock).text =
                    "Keep Stock: ${row.keepStock}   |   Hasil = (Scan + Keep Stock) - System"

                when {
                    !row.scanned -> {
                        tvHistory.text = "Scan: Not scanned"
                        tvDiff.text = "Not Scanned"
                        tvDiff.setTextColor(Color.rgb(176, 57, 44)) // merah
                    }
                    row.desc.startsWith("[WRONG SHELF") -> {
                        tvHistory.text = "Scan: ${row.historyBalance}"
                        tvDiff.text = "Wrong Shelf"
                        tvDiff.setTextColor(Color.rgb(122, 58, 173)) // ungu
                    }
                    row.desc.startsWith("[NOT REGISTERED") -> {
                        tvHistory.text = "Scan: ${row.historyBalance}"
                        tvDiff.text = "Not Registered"
                        tvDiff.setTextColor(Color.rgb(43, 90, 138)) // biru
                    }
                    else -> {
                        tvHistory.text = "Scan: ${row.historyBalance}"
                        val diffText = if (row.difference > 0) "+${row.difference}" else row.difference.toString()
                        tvDiff.text = "Difference: $diffText"
                        tvDiff.setTextColor(
                            when {
                                row.difference == 0 -> Color.rgb(47, 122, 77)   // hijau = sesuai
                                row.difference > 0  -> Color.rgb(201, 130, 26)  // amber = lebih
                                else                -> Color.rgb(176, 57, 44)  // merah = kurang
                            }
                        )
                    }
                }
                return v
            }
        }
        lvCompareResult.adapter = adapter

        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<View>(R.id.btnRefreshCompare).setOnClickListener { loadComparison() }
        // ★ FIX (baru): Export sekarang bisa pilih format — PDF atau Excel
        // (.xlsx), sama seperti menu Stock Comparison (Stock Balance Check).
        findViewById<View>(R.id.btnExportComparePdf).setOnClickListener { showExportFormatDialog() }

        // ★ FIX: cukup load sekali di onCreate. onResume() akan otomatis
        // dipanggil setelah onCreate() setiap kali Activity ini dibuka, jadi
        // memanggil loadComparison() di dua-duanya bikin query berat jalan
        // 2x setiap buka menu (salah satu penyebab lag/crash).
        loadComparison()
    }

    override fun onResume() {
        super.onResume()
        // ★ FIX: hanya reload kalau ini BUKAN pembukaan pertama (data sudah
        // pernah di-load lewat onCreate). Ini menjaga refresh data saat balik
        // dari Activity lain (misal habis nambah scan baru), tanpa dobel load
        // saat pertama kali menu dibuka.
        if (!isLoading && hasLoadedOnce) {
            loadComparison()
        }
    }

    private fun loadComparison() {
        // ★ FIX: cegah beberapa proses load berjalan bersamaan (misal user
        // tap tombol Refresh berkali-kali dengan cepat).
        if (isLoading) return
        isLoading = true
        hasLoadedOnce = true

        tvCompareEmpty.text = "Loading comparison…"
        tvCompareEmpty.visibility = View.VISIBLE
        lvCompareResult.visibility = View.GONE

        // ★ FIX (utama — penyebab crash/lag): getStockTakeCompareRows() query
        // + proses SELURUH tabel price_catalog & data_collect di memori. Ini
        // WAJIB dijalankan di background thread (Dispatchers.IO), bukan di
        // main/UI thread, supaya tidak ANR/crash dan menu tidak "lama masuk".
        lifecycleScope.launch {
            try {
                val loadedRows = withContext(Dispatchers.IO) {
                    db.getStockTakeCompareRows()
                }
                rows = loadedRows

                val match = loadedRows.count { it.scanned && it.difference == 0 && !it.desc.startsWith("[") }
                val diff = loadedRows.count { it.scanned && it.difference != 0 && !it.desc.startsWith("[") }
                val notScan = loadedRows.count { !it.scanned }
                val wrongShelf = loadedRows.count { it.desc.startsWith("[WRONG SHELF") }
                val extra = loadedRows.count { it.desc.startsWith("[NOT REGISTERED") }

                findViewById<TextView>(R.id.tvCountMatch).text = match.toString()
                findViewById<TextView>(R.id.tvCountDiff).text = diff.toString()
                findViewById<TextView>(R.id.tvCountNotScan).text = notScan.toString()
                findViewById<TextView>(R.id.tvCountWrongShelf).text = wrongShelf.toString()
                findViewById<TextView>(R.id.tvCountExtra).text = extra.toString()

                val empty = loadedRows.isEmpty()
                tvCompareEmpty.text = "No Stock Take/Add Box data yet to compare.\nScan some items in Data Collector (Stock Take/Add Box) first."
                tvCompareEmpty.visibility = if (empty) View.VISIBLE else View.GONE
                lvCompareResult.visibility = if (empty) View.GONE else View.VISIBLE
                adapter.notifyDataSetChanged()
            } catch (e: Exception) {
                tvCompareEmpty.text = "Failed to load comparison: ${e.message}"
                tvCompareEmpty.visibility = View.VISIBLE
                lvCompareResult.visibility = View.GONE
            } finally {
                isLoading = false
            }
        }
    }

    /** ★ FIX (baru): pilih format export — PDF (siap cetak) atau Excel (.xlsx). */
    private fun showExportFormatDialog() {
        if (rows.isEmpty()) {
            Toast.makeText(this, "No data to export yet", Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Export As")
            .setItems(arrayOf("PDF", "Excel (.xlsx)")) { _, which ->
                if (which == 0) exportPdf() else exportExcel()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun exportPdf() {
        if (rows.isEmpty()) {
            Toast.makeText(this, "No data to export yet", Toast.LENGTH_SHORT).show()
            return
        }
        val pd = ProgressDialog(this).apply { setMessage("Generating PDF..."); show() }
        lifecycleScope.launch {
            try {
                val fileName = outFileName(this@StockTakeCompareActivity, "STOCKTAKE_COMPARE").removeSuffix(".txt") + ".pdf"
                val savedPath = withContext(Dispatchers.IO) {
                    val bytes = PdfExporter.generate(rows, "System vs Stock Take/Add Box Comparison")
                    OutputWriter.writeBytes(this@StockTakeCompareActivity, fileName, bytes)
                }
                pd.dismissSafely()
                showExportSuccessDialog(savedPath, "PDF", "application/pdf")
            } catch (e: Exception) {
                pd.dismissSafely()
                AlertDialog.Builder(this@StockTakeCompareActivity)
                    .setTitle("Export PDF Failed")
                    .setMessage(e.message)
                    .setPositiveButton("OK", null).showSafely()
            }
        }
    }

    /** ★ FIX (baru): Export Excel (.xlsx) — kolom & urutan data SAMA dengan
     *  Export PDF, lihat ExcelExporter.generate(). */
    private fun exportExcel() {
        if (rows.isEmpty()) {
            Toast.makeText(this, "No data to export yet", Toast.LENGTH_SHORT).show()
            return
        }
        val pd = ProgressDialog(this).apply { setMessage("Generating Excel..."); show() }
        lifecycleScope.launch {
            try {
                val fileName = outFileName(this@StockTakeCompareActivity, "STOCKTAKE_COMPARE").removeSuffix(".txt") + ".xlsx"
                val savedPath = withContext(Dispatchers.IO) {
                    val bytes = ExcelExporter.generate(rows, "System vs Stock Take/Add Box Comparison")
                    OutputWriter.writeBytes(this@StockTakeCompareActivity, fileName, bytes)
                }
                pd.dismissSafely()
                showExportSuccessDialog(
                    savedPath, "Excel",
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                )
            } catch (e: Exception) {
                pd.dismissSafely()
                AlertDialog.Builder(this@StockTakeCompareActivity)
                    .setTitle("Export Excel Failed")
                    .setMessage(e.message)
                    .setPositiveButton("OK", null).showSafely()
            }
        }
    }

    private fun showExportSuccessDialog(savedPath: String, formatLabel: String, mimeType: String) {
        val mode = uploadMode
        val msg = "$formatLabel saved ($mode):\n$savedPath"
        val builder = AlertDialog.Builder(this)
            .setTitle("Export $formatLabel Successful")
            .setMessage(msg)
            .setNegativeButton("Close", null)
        if (mode == "LOCAL" || mode == "HTTP") {
            builder.setPositiveButton("Open $formatLabel") { _, _ -> openLocalFile(savedPath, mimeType) }
        }
        builder.showSafely()
    }

    private fun openLocalFile(path: String, mimeType: String) {
        try {
            val file = File(path)
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, mimeType)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Unable to open file: ${e.message}. The file is still saved at:\n$path", Toast.LENGTH_LONG).show()
        }
    }
}
