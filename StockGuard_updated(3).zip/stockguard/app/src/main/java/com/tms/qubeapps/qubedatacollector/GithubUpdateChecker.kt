package com.tms.qubeapps.qubedatacollector

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Checks GitHub Releases for app updates.
 *
 * Repo disamakan dengan sumber APK Download (lihat
 * OutputWriter.APK_GITHUB_URL), yaitu "ym2803/apk".
 */
object GithubUpdateChecker {

    /** Repo GitHub yang sama dengan yang dipakai untuk APK Download. */
    const val REPO = "ym2803/apk"

    data class ReleaseInfo(
        val tagName: String,
        val name: String,
        val body: String,
        val htmlUrl: String,
        val apkDownloadUrl: String?,
        val publishedAt: String
    )

    /** Fetches the latest published release from GitHub. Throws on network/parse errors. */
    fun fetchLatestRelease(): ReleaseInfo {
        val url = "https://api.github.com/repos/$REPO/releases/latest"
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.requestMethod = "GET"
        conn.setRequestProperty("Accept", "application/vnd.github+json")
        conn.connectTimeout = 15000
        conn.readTimeout = 20000
        try {
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (text.isBlank()) throw Exception("Empty response from GitHub (HTTP $code)")
            if (code !in 200..299) {
                val err = try { JSONObject(text).optString("message", "") } catch (e: Exception) { "" }
                throw Exception("GitHub returned HTTP $code${if (err.isNotBlank()) ": $err" else ""}")
            }
            val json = JSONObject(text)
            val assets: JSONArray = json.optJSONArray("assets") ?: JSONArray()
            var apkUrl: String? = null
            for (i in 0 until assets.length()) {
                val a = assets.getJSONObject(i)
                val name = a.optString("name", "")
                if (name.endsWith(".apk", ignoreCase = true)) {
                    apkUrl = a.optString("browser_download_url", null)
                    break
                }
            }
            return ReleaseInfo(
                tagName = json.optString("tag_name", ""),
                name = json.optString("name", json.optString("tag_name", "")),
                body = json.optString("body", ""),
                htmlUrl = json.optString("html_url", "https://github.com/$REPO/releases"),
                apkDownloadUrl = apkUrl,
                publishedAt = json.optString("published_at", "")
            )
        } finally {
            conn.disconnect()
        }
    }

    /**
     * Compares two version strings like "1.0.4.0" vs "1.0.5" or a tag like "v1.0.5".
     * Returns true if [latest] is newer than [current].
     */
    fun isNewer(latest: String, current: String): Boolean {
        val l = normalize(latest)
        val c = normalize(current)
        val maxLen = maxOf(l.size, c.size)
        for (i in 0 until maxLen) {
            val lv = l.getOrElse(i) { 0 }
            val cv = c.getOrElse(i) { 0 }
            if (lv != cv) return lv > cv
        }
        return false
    }

    private fun normalize(version: String): List<Int> =
        version.trim()
            .removePrefix("v").removePrefix("V")
            .split(".", "-", "+")
            .mapNotNull { it.filter { ch -> ch.isDigit() }.toIntOrNull() }
}
