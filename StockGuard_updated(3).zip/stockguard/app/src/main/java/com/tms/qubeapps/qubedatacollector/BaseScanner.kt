package com.tms.qubeapps.qubedatacollector

import android.Manifest
import android.content.pm.PackageManager
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.zxing.BarcodeFormat
import com.google.zxing.DecodeHintType
import com.journeyapps.barcodescanner.BarcodeCallback
import com.journeyapps.barcodescanner.BarcodeResult
import com.journeyapps.barcodescanner.DecoratedBarcodeView
import com.journeyapps.barcodescanner.camera.CameraSettings
import com.journeyapps.barcodescanner.DefaultDecoderFactory

/**
 * Base class: handles kamera permission + ZXing scanner lifecycle.
 * Subclass override onBarcodeScanned(barcode: String).
 *
 * Pakai DecoratedBarcodeView dari zxing-android-embedded.
 * Di layout XML ganti ZBarScannerView dengan:
 *   com.journeyapps.barcodescanner.DecoratedBarcodeView
 *
 * ★ FIX (baru — Modernisasi Scan Mode): decoder di-set eksplisit supaya
 * mengenali SEMUA jenis barcode (1D: CODE_128/39/93, EAN_13/8, UPC_A/E,
 * ITF, CODABAR, RSS + 2D: QR_CODE, DATA_MATRIX, PDF_417, AZTEC) dalam satu
 * sesi scan, tanpa perlu ganti mode manual. Kamera dikonfigurasi continuous
 * auto-focus + auto white balance/exposure supaya fokus lebih cepat &
 * akurat (termasuk barcode kecil/rusak), TETAP ringan karena tidak menambah
 * library baru — hanya memanfaatkan fitur zxing-android-embedded yang sudah
 * ada. TryHarder di-aktifkan supaya deteksi lebih presisi tanpa menambah
 * beban berarti (resolusi preview tetap default/auto).
 */
abstract class BaseScanner : BaseActivity() {

    protected lateinit var barcodeView: DecoratedBarcodeView
    private var scannerActive = false
    private var torchOn = false
    private val CAM_PERM = 1001

    /** Semua format barcode yang wajib dikenali (1D + 2D) supaya scan mode
     *  "universal" — tidak perlu tahu dulu jenis barcode-nya apa. */
    private val ALL_SUPPORTED_FORMATS = listOf(
        BarcodeFormat.CODE_128, BarcodeFormat.CODE_39, BarcodeFormat.CODE_93,
        BarcodeFormat.EAN_13, BarcodeFormat.EAN_8,
        BarcodeFormat.UPC_A, BarcodeFormat.UPC_E,
        BarcodeFormat.ITF, BarcodeFormat.CODABAR,
        BarcodeFormat.RSS_14, BarcodeFormat.RSS_EXPANDED,
        BarcodeFormat.QR_CODE, BarcodeFormat.DATA_MATRIX,
        BarcodeFormat.PDF_417, BarcodeFormat.AZTEC
    )

    protected fun initScanner(view: DecoratedBarcodeView) {
        barcodeView = view

        // ★ Decoder: kenali semua format sekaligus + TRY_HARDER untuk hasil
        // lebih akurat pada barcode kecil/blur/miring, tanpa mengubah resolusi
        // kamera (tetap ringan).
        val hints = mapOf(DecodeHintType.TRY_HARDER to true)
        val decoderFactory = DefaultDecoderFactory(ALL_SUPPORTED_FORMATS, hints, null, 0)
        barcodeView.barcodeView.decoderFactory = decoderFactory

        // ★ Kamera: continuous auto-focus + auto exposure/white-balance supaya
        // fokus cepat mengunci ke barcode yang bergerak/berjarak dekat, dan
        // resolusi preview otomatis (tidak dipaksa tinggi) supaya tetap ringan.
        val cameraSettings = CameraSettings().apply {
            isAutoFocusEnabled = true
            isContinuousFocusEnabled = true
            focusMode = CameraSettings.FocusMode.CONTINUOUS
            isAutoTorchEnabled = false
            isExposureEnabled = true
            isMeteringEnabled = true
        }
        barcodeView.barcodeView.cameraSettings = cameraSettings

        barcodeView.decodeContinuous(object : BarcodeCallback {
            override fun barcodeResult(result: BarcodeResult?) {
                result?.let {
                    val text = it.text?.trim() ?: return
                    if (text.isNotEmpty()) {
                        stopCamera()
                        onBarcodeScanned(text)
                    }
                }
            }
        })
    }

    protected fun toggleCamera() {
        if (!scannerActive) startCamera() else stopCamera()
    }

    /** ★ FIX (baru): toggle senter — membantu scan cepat & akurat di gudang
     *  yang gelap/minim cahaya, tanpa dependency tambahan. */
    protected fun toggleTorch() {
        if (!scannerActive) return
        torchOn = !torchOn
        if (torchOn) barcodeView.setTorchOn() else barcodeView.setTorchOff()
    }

    protected fun startCamera() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), CAM_PERM)
            return
        }
        scannerActive = true
        barcodeView.visibility = android.view.View.VISIBLE
        barcodeView.resume()
    }

    protected fun stopCamera() {
        scannerActive = false
        torchOn = false
        barcodeView.pause()
        barcodeView.visibility = android.view.View.GONE
    }

    abstract fun onBarcodeScanned(barcode: String)

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == CAM_PERM && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        }
    }

    override fun onResume() {
        super.onResume()
        if (scannerActive) barcodeView.resume()
    }

    override fun onPause() {
        super.onPause()
        if (scannerActive) barcodeView.pause()
    }
}
