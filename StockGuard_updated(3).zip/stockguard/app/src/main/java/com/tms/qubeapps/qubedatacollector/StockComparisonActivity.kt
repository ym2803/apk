package com.tms.qubeapps.qubedatacollector

import android.app.AlertDialog
import android.app.ProgressDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import com.tms.qubeapps.qubedatacollector.Prefs.outFileName
import com.tms.qubeapps.qubedatacollector.Prefs.uploadMode
import com.tms.qubeapps.qubedatacollector.Prefs.ksLastStore
import com.tms.qubeapps.qubedatacollector.Prefs.ksLastPic
import com.tms.qubeapps.qubedatacollector.Prefs.exioSpreadsheetId
import com.tms.qubeapps.qubedatacollector.Prefs.exioGid
import com.tms.qubeapps.qubedatacollector.Prefs.KEEP_STOCK_STORES
import com.tms.qubeapps.qubedatacollector.Prefs.secondCheckSheetUrl
import com.tms.qubeapps.qubedatacollector.Prefs.secondCheckSheetToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File

/**
 * ★ FIX (Menu 5 — Stock Comparison): membandingkan hasil scan/hitung fisik
 * (history Scan Process, di-SUM per SKU) dengan balance sistem
 * (katalog hasil download 02.txt), lalu bisa di-export ke PDF siap cetak
 * lewat SMB / HTTP / Local (sama seperti jalur export lain di aplikasi).
 *
 * Logika difference = historyBalance (hasil scan, di-sum kalau SKU sama
 * di-scan berkali-kali) - systemBalance (dari sistem):
 *   > 0 → hasil scan LEBIH banyak dari sistem
 *   < 0 → hasil scan KURANG dari sistem
 *   = 0 → sama persis
 *
 * ★ FIX: filter Shelf, Qty & Difference — all three are checklist dropdowns
 * (multi-select). If any filter has a selection, the list shown AND the PDF
 * export only include rows that match the selected filters.
 *
 * ★ FIX: kalau filter Shelf diisi, SEMUA SKU sistem di shelf itu ikut
 * ditampilkan walau belum pernah discan — supaya kelihatan item mana saja
 * yang "Belum" discan. Untuk baris begini, kolom Selisih ditandai "BELUM".
 */
class StockComparisonActivity : BaseActivity() {

    private lateinit var db: AppDatabase
    private lateinit var lvComparison: ListView
    private lateinit var tvSummary: TextView
    private lateinit var tvEmpty: TextView
    private lateinit var btnFilterShelf: TextView
    private lateinit var btnFilterQty: TextView
    private lateinit var btnFilterSystem: TextView
    private lateinit var btnFilterDiff: TextView
    // ★ FIX (baru — Export PDF filter by Time): dropdown Filter Time, KHUSUS
    // dipakai untuk logika Export PDF pada data 'Scan Result' (lihat exportPdf()).
    private lateinit var btnFilterTime: TextView
    // ★ FIX (baru — Keep Stock dari GSheet live)
    private lateinit var btnKeepStockStore: TextView
    private lateinit var btnKeepStockMatch: View
    // ★ FIX (baru — Minimize/Maximize menu filter): container isi filter yang
    // bisa disembunyikan/ditampilkan, supaya area List (lvComparison) dapat
    // ruang lebih luas waktu edit Difference (keyboard sering menutupi layar).
    private lateinit var llFilterToggleBar: View
    private lateinit var llFilterContent: View
    private lateinit var ivFilterToggleArrow: View
    private lateinit var tvFilterToggleLabel: TextView
    private var filterExpanded = false
    // Hasil fetch GSheet PALING TERAKHIR (selalu di-refresh tiap loadComparison()
    // dijalankan — bukan cache jangka panjang, cuma dipakai supaya tombol
    // "MATCH RESULT" tidak perlu fetch dobel kalau baru saja di-refresh).
    private var lastKeepStockMap: Map<String, Int> = emptyMap()

    // Data hasil query (sudah termasuk ekspansi shelf kalau filter Shelf aktif),
    // dan data final setelah filter Qty & Difference diterapkan (dipakai tampilan + export).
    private var queriedRows: List<ComparisonRow> = emptyList()
    private var rows: List<ComparisonRow> = emptyList()
    private lateinit var adapter: BaseAdapter

    // ★ FIX: semua filter sekarang checklist dropdown (multi-select).
    // Set kosong = tidak ada filter aktif untuk kategori itu (tampilkan semua).
    private var selectedShelves: MutableSet<String> = mutableSetOf()
    private var selectedQty: MutableSet<Int> = mutableSetOf()
    private var selectedSystem: MutableSet<Int> = mutableSetOf()
    private var selectedDiff: MutableSet<String> = mutableSetOf() // MORE / LESS / SAME / NOT_SCANNED
    // ★ FIX (baru — Export PDF filter by Time): tanggal (format "dd/MM/yy",
    // diambil dari firstScanTime) yang dipilih untuk memfilter data 'Scan
    // Result' KHUSUS pada saat Export PDF. Kosong = semua tanggal ikut export.
    private var selectedTime: MutableSet<String> = mutableSetOf()

    private val diffOptionCodes = listOf("MORE", "LESS", "SAME", "NOT_SCANNED")
    private val diffOptionLabels = listOf("More", "Less", "Same", "Not Scanned")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_stock_comparison)

        db = AppDatabase(this)
        lvComparison   = findViewById(R.id.lvComparison)
        tvSummary      = findViewById(R.id.tvCompSummary)
        tvEmpty        = findViewById(R.id.tvCompEmpty)
        btnFilterShelf = findViewById(R.id.btnFilterShelf)
        btnFilterQty   = findViewById(R.id.btnFilterQty)
        btnFilterSystem = findViewById(R.id.btnFilterSystem)
        btnFilterDiff  = findViewById(R.id.btnFilterDiff)
        btnFilterTime  = findViewById(R.id.btnFilterTime)
        btnKeepStockStore = findViewById(R.id.btnKeepStockStore)
        btnKeepStockMatch = findViewById(R.id.btnKeepStockMatch)
        btnKeepStockStore.text = currentKsStore()
        btnKeepStockStore.setOnClickListener { showKeepStockStoreDialog() }
        btnKeepStockMatch.setOnClickListener { showKeepStockMatchResult() }

        // ★ FIX (baru — Minimize/Maximize menu filter)
        llFilterToggleBar = findViewById(R.id.llFilterToggleBar)
        llFilterContent = findViewById(R.id.llFilterContent)
        ivFilterToggleArrow = findViewById(R.id.ivFilterToggleArrow)
        tvFilterToggleLabel = findViewById(R.id.tvFilterToggleLabel)
        llFilterToggleBar.setOnClickListener { setFilterExpanded(!filterExpanded) }
        setFilterExpanded(filterExpanded)

        adapter = object : BaseAdapter() {
            override fun getCount() = rows.size
            override fun getItem(position: Int) = rows[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val v = convertView ?: layoutInflater.inflate(R.layout.item_comparison_row, parent, false)
                val row = rows[position]
                v.findViewById<TextView>(R.id.tvCompSku).text   = row.sku
                v.findViewById<TextView>(R.id.tvCompShelf).text = "Shelf: ${row.shelf}"
                v.findViewById<TextView>(R.id.tvCompDesc).text  = row.desc
                val tvHistory = v.findViewById<TextView>(R.id.tvCompHistory)
                val tvDiff = v.findViewById<TextView>(R.id.tvCompDiff)
                v.findViewById<TextView>(R.id.tvCompSystem).text = "System: ${row.systemBalance}"
                // ★ FIX (baru): tampilkan Keep Stock qty & System sebelum dikurangi.
                v.findViewById<TextView>(R.id.tvCompKeepStock).text =
                    "Keep Stock: ${row.keepStock}   |   Hasil = (Scan + Keep Stock) - System"
                if (!row.scanned) {
                    // ★ FIX: SKU ini belum pernah di-scan sama sekali (ditambahkan
                    // karena satu shelf dengan filter Shelf yang aktif)
                    tvHistory.text = "Scan Result: Not scanned"
                    tvDiff.text = "Difference: NOT SCANNED"
                    tvDiff.setTextColor(Color.rgb(245, 124, 0)) // oranye = belum
                } else {
                    tvHistory.text = "Scan Result: ${row.historyBalance}"
                    val diffText = if (row.difference > 0) "+${row.difference}" else row.difference.toString()
                    tvDiff.text = "Difference: $diffText"
                    tvDiff.setTextColor(
                        when {
                            row.difference > 0 -> Color.rgb(46, 125, 50)   // hijau = lebih
                            row.difference < 0 -> Color.rgb(198, 40, 40)   // merah = kurang
                            else -> Color.BLACK
                        }
                    )
                }

                // ★ FIX (baru — Fitur Edit Langsung / 2nd Check): badge penanda
                // visual kalau SKU ini sudah pernah di-2nd-check.
                val tvBadge = v.findViewById<TextView>(R.id.tvSecondCheckBadge)
                if (row.secondChecked) {
                    tvBadge.visibility = View.VISIBLE
                    tvBadge.text = "✔ 2nd Check by ${row.secondCheckUser} — ${row.secondCheckTime}"
                } else {
                    tvBadge.visibility = View.GONE
                }

                // ★ FIX (baru — mengganti Inline Edit di dalam baris ListView dengan
                // Dialog sederhana, format SAMA seperti "Edit Qty" di History Scan
                // Stock Balance Check): dulu field edit (Shelf/System/Balance) selalu
                // ada di dalam baris ListView, jadi rawan ke-reset/error kalau ada
                // refresh data background (mis. auto-fetch Keep Stock timeout) yang
                // memicu notifyDataSetChanged() di tengah-tengah user ngetik — apa yang
                // sedang diketik hilang begitu saja. Sekarang cukup 1 tombol "Edit / 2nd
                // Check" yang membuka AlertDialog terpisah (lihat showSecondCheckEditDialog)
                // — dialog TIDAK ikut ke-refresh/reset walau list di baliknya diperbarui.
                val editable = (!row.scanned) || (row.scanned && row.difference != 0)
                val btnToggle = v.findViewById<TextView>(R.id.btnToggleSecondCheck)
                val llEdit = v.findViewById<LinearLayout>(R.id.llSecondCheckEdit)
                llEdit.visibility = View.GONE // sudah tidak dipakai lagi, edit sekarang lewat dialog

                if (!editable) {
                    btnToggle.visibility = View.GONE
                } else {
                    btnToggle.visibility = View.VISIBLE
                    btnToggle.text = "✎ Edit / 2nd Check"
                    btnToggle.setOnClickListener { showSecondCheckEditDialog(row) }
                }

                return v
            }
        }
        lvComparison.adapter = adapter

        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<View>(R.id.btnRefreshComparison).setOnClickListener { loadComparison() }
        // ★ FIX (baru): Export sekarang bisa pilih format — PDF (siap cetak)
        // atau Excel (.xlsx, buat diolah lebih lanjut di komputer). Kolom &
        // urutan data SAMA PERSIS di kedua format (lihat ExcelExporter).
        findViewById<View>(R.id.btnExportPdf).setOnClickListener { showExportFormatDialog() }
        findViewById<View>(R.id.btnClearHistoryComp).setOnClickListener { confirmClearHistory() }
        findViewById<View>(R.id.btnResetFilter).setOnClickListener {
            selectedShelves.clear(); selectedQty.clear(); selectedSystem.clear(); selectedDiff.clear()
            selectedTime.clear()
            updateFilterButtonLabels()
            loadComparison()
        }

        // ★ FIX: Filter Shelf — checklist dropdown, opsinya diambil dari daftar
        // shelf unik di katalog sistem. Butuh query ulang ke DB (untuk ekspansi
        // shelf yang belum discan), jadi pakai loadComparison().
        btnFilterShelf.setOnClickListener { showShelfFilterDialog() }

        // ★ FIX: Filter Qty — checklist dropdown, opsinya diambil dari nilai Hasil
        // Scan (historyBalance) yang ada pada data saat ini. Cukup filter di
        // memori, tidak perlu query ulang ke DB.
        btnFilterQty.setOnClickListener { showQtyFilterDialog() }

        // ★ FIX (baru): Filter System — checklist dropdown berdasarkan Balance
        // sistem (systemBalance) yang ada pada data saat ini. Difilter di
        // memori, tidak perlu query ulang ke DB.
        btnFilterSystem.setOnClickListener { showSystemFilterDialog() }

        // ★ FIX (baru): Filter Selisih (Difference) — checklist dropdown dengan
        // 4 opsi: More / Less / Same / Not Scanned.
        btnFilterDiff.setOnClickListener { showDiffFilterDialog() }

        // ★ FIX (baru — Export PDF filter by Time): checklist dropdown tanggal
        // scan, KHUSUS dipakai untuk memfilter data 'Scan Result' pada Export PDF.
        btnFilterTime.setOnClickListener { showTimeFilterDialog() }

        loadComparison()
    }

    /** ★ FIX (baru — Minimize/Maximize menu filter): toggle visibility seluruh
     *  isi menu filter (llFilterContent). Saat MINIMIZED, area List hasil
     *  compare (lvComparison) otomatis dapat ruang lebih luas untuk di-scroll
     *  dan di-edit — penting waktu keyboard muncul untuk edit Difference. */
    private fun setFilterExpanded(expanded: Boolean) {
        filterExpanded = expanded
        llFilterContent.visibility = if (expanded) View.VISIBLE else View.GONE
        ivFilterToggleArrow.rotation = if (expanded) 180f else 0f
        tvFilterToggleLabel.text = if (expanded)
            "Filters & Options (tap to minimize)"
        else
            "Filters & Options (tap to expand)"
    }

    private fun updateFilterButtonLabels() {
        btnFilterShelf.text = if (selectedShelves.isEmpty()) "All" else selectedShelves.sorted().joinToString(", ")
        btnFilterQty.text = if (selectedQty.isEmpty()) "All" else selectedQty.sorted().joinToString(", ")
        btnFilterSystem.text = if (selectedSystem.isEmpty()) "All" else selectedSystem.sorted().joinToString(", ")
        btnFilterDiff.text = if (selectedDiff.isEmpty()) "All" else
            selectedDiff.map { code -> diffOptionLabels[diffOptionCodes.indexOf(code)] }.joinToString(", ")
        btnFilterTime.text = if (selectedTime.isEmpty()) "All" else selectedTime.sorted().joinToString(", ")
    }

    /** ★ FIX (baru — Export PDF filter by Time): ambil bagian tanggal saja
     *  (format "dd/MM/yy") dari string firstScanTime ("dd/MM/yy HH:mm:ss"). */
    private fun dateOnly(scanTime: String): String = scanTime.trim().substringBefore(" ")

    /** ★ FIX: dialog checklist multi-select generik untuk semua filter di layar ini.
     *  Baris pertama "Select All" dipakai untuk ceklis/uncek semua opsi sekaligus,
     *  jadi tidak perlu ceklis satu-satu kalau opsinya banyak. */
    private fun showMultiChoiceDialog(
        title: String,
        options: List<String>,
        selected: MutableSet<String>,
        onApplied: () -> Unit
    ) {
        if (options.isEmpty()) {
            Toast.makeText(this, "No options available for $title", Toast.LENGTH_SHORT).show()
            return
        }
        val displayOptions = listOf("Select All") + options
        val checked = BooleanArray(displayOptions.size)
        for (i in options.indices) checked[i + 1] = selected.contains(options[i])
        checked[0] = options.all { selected.contains(it) }
        val tempSelected = selected.toMutableSet()

        val dialog = AlertDialog.Builder(this)
            .setTitle(title)
            .setMultiChoiceItems(displayOptions.toTypedArray(), checked) { d, which, isChecked ->
                val lv = (d as AlertDialog).listView
                if (which == 0) {
                    // ★ FIX: toggle "Select All" → ceklis/uncek semua opsi lainnya sekaligus
                    for (i in options.indices) {
                        lv.setItemChecked(i + 1, isChecked)
                        if (isChecked) tempSelected.add(options[i]) else tempSelected.remove(options[i])
                    }
                } else {
                    val opt = options[which - 1]
                    if (isChecked) tempSelected.add(opt) else tempSelected.remove(opt)
                    lv.setItemChecked(0, options.all { tempSelected.contains(it) })
                }
            }
            .setPositiveButton("OK") { _, _ ->
                selected.clear(); selected.addAll(tempSelected)
                updateFilterButtonLabels()
                onApplied()
            }
            .setNeutralButton("Clear") { _, _ ->
                selected.clear()
                updateFilterButtonLabels()
                onApplied()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showShelfFilterDialog() {
        val options = db.getDistinctShelves()
        showMultiChoiceDialog("Filter Shelf", options, selectedShelves) { loadComparison() }
    }

    private fun showQtyFilterDialog() {
        val options = queriedRows.map { it.historyBalance }.distinct().sorted().map { it.toString() }
        val selectedAsStr = selectedQty.map { it.toString() }.toMutableSet()
        showMultiChoiceDialog("Filter Scan Result", options, selectedAsStr) {
            selectedQty = selectedAsStr.mapNotNull { it.toIntOrNull() }.toMutableSet()
            applyFilters()
        }
    }

    private fun showSystemFilterDialog() {
        val options = queriedRows.map { it.systemBalance }.distinct().sorted().map { it.toString() }
        val selectedAsStr = selectedSystem.map { it.toString() }.toMutableSet()
        showMultiChoiceDialog("Filter System", options, selectedAsStr) {
            selectedSystem = selectedAsStr.mapNotNull { it.toIntOrNull() }.toMutableSet()
            applyFilters()
        }
    }

    /** ★ FIX (baru — Menu 5): checklist dropdown untuk filter Selisih (Difference),
     *  dengan baris "Select All" juga supaya bisa ceklis semua sekaligus. */
    private fun showDiffFilterDialog() {
        val displayLabels = listOf("Select All") + diffOptionLabels
        val checked = BooleanArray(displayLabels.size)
        for (i in diffOptionCodes.indices) checked[i + 1] = selectedDiff.contains(diffOptionCodes[i])
        checked[0] = diffOptionCodes.all { selectedDiff.contains(it) }
        val temp = selectedDiff.toMutableSet()

        AlertDialog.Builder(this)
            .setTitle("Filter Difference")
            .setMultiChoiceItems(displayLabels.toTypedArray(), checked) { d, which, isChecked ->
                val lv = (d as AlertDialog).listView
                if (which == 0) {
                    for (i in diffOptionCodes.indices) {
                        lv.setItemChecked(i + 1, isChecked)
                        if (isChecked) temp.add(diffOptionCodes[i]) else temp.remove(diffOptionCodes[i])
                    }
                } else {
                    val code = diffOptionCodes[which - 1]
                    if (isChecked) temp.add(code) else temp.remove(code)
                    lv.setItemChecked(0, diffOptionCodes.all { temp.contains(it) })
                }
            }
            .setPositiveButton("OK") { _, _ ->
                selectedDiff.clear(); selectedDiff.addAll(temp)
                updateFilterButtonLabels()
                applyFilters()
            }
            .setNeutralButton("Clear") { _, _ ->
                selectedDiff.clear()
                updateFilterButtonLabels()
                applyFilters()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    /** ★ FIX (baru — Export PDF filter by Time): checklist dropdown tanggal
     *  scan (diambil dari firstScanTime baris yang sudah discan). Filter ini
     *  TIDAK memengaruhi tampilan list di layar (rows/applyFilters) — hanya
     *  dipakai di exportPdf() untuk menyaring data 'Scan Result'. */
    private fun showTimeFilterDialog() {
        val options = queriedRows.filter { it.scanned }
            .map { dateOnly(it.firstScanTime) }
            .filter { it.isNotBlank() && it != "-" }
            .distinct().sorted()
        showMultiChoiceDialog("Filter Time (Export PDF - Scan Result)", options, selectedTime) {
            // Filter Time tidak memicu query ulang / applyFilters() tampilan —
            // cuma dipakai saat tombol Export PDF ditekan.
        }
    }

    override fun onResume() {
        super.onResume()
        loadComparison()
    }

    private fun loadComparison() {
        lifecycleScope.launch {
            // ★ FIX (baru — Keep Stock HARUS dari GSheet live): fetch fresh
            // tiap kali loadComparison() dipanggil (buka layar, Refresh, ganti
            // filter Shelf, ganti store Keep Stock) — TIDAK ada cache lokal
            // yang dipakai ulang di sini supaya data selalu yang terbaru.
            val ksMap = try {
                fetchKeepStockMapFresh()
            } catch (e: Exception) {
                Toast.makeText(this@StockComparisonActivity,
                    "Failed to fetch Keep Stock data from GSheet: ${e.message}\nSystem Balance is shown without Keep Stock deduction.",
                    Toast.LENGTH_LONG).show()
                emptyMap()
            }
            lastKeepStockMap = ksMap
            queriedRows = withContext(Dispatchers.IO) { db.getComparisonData(selectedShelves.toList(), ksMap) }
            applyFilters()
        }
    }

    /** ★ FIX (baru): toko Keep Stock (GSheet) yang aktif dipakai di Stock
     *  Comparison — reuse `ksLastStore` (toko yang sama dengan sesi login
     *  Menu Keep Stock terakhir), supaya konsisten dan tidak perlu setting
     *  terpisah. Fallback ke toko pertama kalau belum pernah login/pilih. */
    private fun currentKsStore(): String = ksLastStore.ifBlank { KEEP_STOCK_STORES.first() }

    /** ★ FIX (baru): ambil data Keep Stock TERBARU langsung dari Google
     *  Sheets (bukan data lokal/cache), lalu SKU digabung & Qty dijumlahkan
     *  per SKU (SKU sebagai key utama). Spreadsheet ID & GID diambil dari
     *  konfigurasi toko yang sama dipakai Menu Keep Stock
     *  (`exioSpreadsheetId`/`exioGid`, diatur lewat gear icon di Menu Keep
     *  Stock). Kalau belum dikonfigurasi, return map kosong (tidak error). */
    private suspend fun fetchKeepStockMapFresh(): Map<String, Int> {
        val store = currentKsStore()
        val ssid = exioSpreadsheetId(store)
        val gid = exioGid(store)
        if (ssid.isBlank() || gid.isBlank()) return emptyMap()
        return withContext(Dispatchers.IO) {
            val raw = KeepStockSheetReader.fetchRows(ssid, gid)
            val map = LinkedHashMap<String, Int>()
            raw.forEach { r ->
                val sku = r.sku.trim()
                if (sku.isBlank()) return@forEach
                val qty = r.qty.trim().toIntOrNull() ?: 0
                map[sku] = (map[sku] ?: 0) + qty
            }
            map
        }
    }

    /** ★ FIX (baru): dialog pilih toko Keep Stock (GSheet) yang mau dipakai
     *  untuk Stock Comparison. Ganti toko langsung memicu reload dengan data
     *  Keep Stock TERBARU dari toko yang baru dipilih. */
    private fun showKeepStockStoreDialog() {
        val current = currentKsStore()
        val idx = KEEP_STOCK_STORES.indexOf(current).coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle("Select Keep Stock Store (GSheet)")
            .setSingleChoiceItems(KEEP_STOCK_STORES.toTypedArray(), idx) { dialog, which ->
                val store = KEEP_STOCK_STORES[which]
                ksLastStore = store
                btnKeepStockStore.text = store
                dialog.dismiss()
                loadComparison()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    /**
     * ★ FIX (baru): tombol "MATCH RESULT" — cocokkan SKU & Qty Keep Stock
     * (GSheet, di-fetch FRESH lagi di sini supaya benar-benar data terbaru
     * saat tombol ditekan, bukan cache dari loadComparison() sebelumnya)
     * dengan "data pembanding" (hasil Scan Process yang sedang ditampilkan
     * di Stock Comparison). Pencocokan pakai SKU sebagai key utama, lalu
     * Qty kedua sumber dibandingkan. Hasil dikelompokkan jadi 4 kategori:
     *   1. SKU yang sesuai (Qty sama persis)
     *   2. SKU dengan Qty berbeda
     *   3. SKU yang HANYA ada di Keep Stock (tidak ada di data pembanding)
     *   4. SKU yang HANYA ada di data pembanding (tidak ada di Keep Stock)
     */
    private fun showKeepStockMatchResult() {
        val pd = ProgressDialog(this).apply {
            setMessage("Mengambil data Keep Stock terbaru dari GSheet..."); setCancelable(false); show()
        }
        lifecycleScope.launch {
            val ksMap = try {
                fetchKeepStockMapFresh()
            } catch (e: Exception) {
                pd.dismissSafely()
                AlertDialog.Builder(this@StockComparisonActivity)
                    .setTitle("Failed to fetch GSheet data")
                    .setMessage(e.message ?: "Unknown error")
                    .setPositiveButton("OK", null).showSafely()
                return@launch
            }
            pd.dismissSafely()
            if (ksMap.isEmpty()) {
                AlertDialog.Builder(this@StockComparisonActivity)
                    .setTitle("Keep Stock empty / not configured")
                    .setMessage("Store '${currentKsStore()}' has no Keep Stock data in GSheet yet, or the Spreadsheet ID/GID has not been set (gear icon in the Keep Stock menu).")
                    .setPositiveButton("OK", null).showSafely()
                return@launch
            }
            lastKeepStockMap = ksMap
            // "Data pembanding" = SKU + Qty hasil Scan Process yang lagi
            // ditampilkan di Stock Comparison (baris yang scanned = true).
            val comparisonMap = queriedRows.filter { it.scanned }.associate { it.sku to it.historyBalance }

            val allSkus = (ksMap.keys + comparisonMap.keys).toSortedSet()
            val matched = mutableListOf<String>()
            val different = mutableListOf<String>()
            val onlyKeepStock = mutableListOf<String>()
            val onlyComparison = mutableListOf<String>()
            for (sku in allSkus) {
                val ks = ksMap[sku]
                val comp = comparisonMap[sku]
                when {
                    ks != null && comp != null && ks == comp -> matched.add("$sku  →  Qty: $ks")
                    ks != null && comp != null -> different.add("$sku  →  Keep Stock: $ks  |  Scan: $comp")
                    ks != null -> onlyKeepStock.add("$sku  →  Keep Stock Qty: $ks")
                    comp != null -> onlyComparison.add("$sku  →  Scan Qty: $comp")
                }
            }

            val sb = StringBuilder()
            sb.append("Store: ${currentKsStore()}   |   Total SKU Keep Stock: ${ksMap.size}\n\n")
            sb.append("✔ SKU SESUAI (${matched.size})\n")
            sb.append(if (matched.isEmpty()) "  -\n" else matched.joinToString("\n") { "  $it" } + "\n")
            sb.append("\n✘ QTY BERBEDA (${different.size})\n")
            sb.append(if (different.isEmpty()) "  -\n" else different.joinToString("\n") { "  $it" } + "\n")
            sb.append("\n⬤ HANYA DI KEEP STOCK (${onlyKeepStock.size})\n")
            sb.append(if (onlyKeepStock.isEmpty()) "  -\n" else onlyKeepStock.joinToString("\n") { "  $it" } + "\n")
            sb.append("\n⬤ HANYA DI DATA PEMBANDING / SCAN (${onlyComparison.size})\n")
            sb.append(if (onlyComparison.isEmpty()) "  -\n" else onlyComparison.joinToString("\n") { "  $it" } + "\n")

            val scroll = android.widget.ScrollView(this@StockComparisonActivity)
            val tv = TextView(this@StockComparisonActivity).apply {
                text = sb.toString()
                textSize = 12f
                setPadding(32, 24, 32, 24)
                setTextIsSelectable(true)
            }
            scroll.addView(tv)
            AlertDialog.Builder(this@StockComparisonActivity)
                .setTitle("Keep Stock Match Result (GSheet, live)")
                .setView(scroll)
                .setPositiveButton("Close", null)
                .showSafely()
        }
    }

    /**
     * ★ FIX: terapkan filter Qty, System & Difference (checklist dropdown,
     * multi-select) di atas queriedRows (yang sudah termasuk ekspansi shelf
     * kalau filter Shelf aktif). Dipanggil terpisah dari loadComparison()
     * supaya memilih filter Qty/System/Difference tidak perlu query ulang ke DB.
     */
    /** ★ FIX (baru): predikat filter Qty/System/Difference — dipakai bareng
     *  oleh applyFilters() (tampilan layar) & exportPdf() (isi PDF), supaya
     *  keduanya SELALU konsisten. Sebelumnya PDF punya logika filter sendiri
     *  yang mengabaikan filter Qty/System/Difference dari layar (bug: baris
     *  Difference = 0 tetap ikut ter-export meski sudah difilter). */
    private fun passesScreenFilters(row: ComparisonRow): Boolean {
        // kalau hasil Scan LEBIH BESAR dari System, baris ini tetap lolos
        // apa pun filter yang aktif (Qty/System/Difference).
        val scanExceedsSystem = row.scanned && row.historyBalance > row.systemBalance
        if (scanExceedsSystem) return true
        val qtyOk = selectedQty.isEmpty() || selectedQty.contains(row.historyBalance)
        val systemOk = selectedSystem.isEmpty() || selectedSystem.contains(row.systemBalance)
        val diffOk = selectedDiff.isEmpty() || selectedDiff.any { code ->
            when (code) {
                "MORE" -> row.scanned && row.difference > 0
                "LESS" -> row.scanned && row.difference < 0
                "SAME" -> row.scanned && row.difference == 0
                "NOT_SCANNED" -> !row.scanned
                else -> true
            }
        }
        return qtyOk && systemOk && diffOk
    }

    private fun applyFilters() {
        // ★ FIX (baru — tampilan default dikelompokkan per Shelf, bukan SKU):
        // sebelum user pakai Filter & Options, layar otomatis menampilkan barang
        // yang rak-nya sama mengelompok jadi satu (Shelf ASC, SKU sbg tie-breaker)
        // — BUKAN lagi urut SKU polos. Grup "sudah discan" tetap didahulukan dari
        // "belum discan" (urutan asli dari queriedRows/getComparisonData), cuma
        // urutan DI DALAM tiap grup yang diubah. Export PDF/Excel/Google Sheets
        // (buildExportRows) TIDAK terpengaruh — tetap pakai urutan SKU asli seperti
        // sebelumnya, supaya format laporan tidak berubah.
        val filtered = queriedRows.filter { passesScreenFilters(it) }
        val scannedSorted = filtered.filter { it.scanned }
            .sortedWith(compareBy({ it.shelf.trim().lowercase() }, { it.sku }))
        val notScannedSorted = filtered.filter { !it.scanned }
            .sortedWith(compareBy({ it.shelf.trim().lowercase() }, { it.sku }))
        rows = scannedSorted + notScannedSorted
        adapter.notifyDataSetChanged()

        val lebih = rows.count { it.scanned && it.difference > 0 }
        val kurang = rows.count { it.scanned && it.difference < 0 }
        val sama = rows.count { it.scanned && it.difference == 0 }
        val belum = rows.count { !it.scanned }
        val filterActive = selectedShelves.isNotEmpty() || selectedQty.isNotEmpty() || selectedSystem.isNotEmpty() || selectedDiff.isNotEmpty()
        val filterNote = if (filterActive) " (filter active)" else ""
        val belumNote = if (belum > 0) "   |   Not scanned: $belum" else ""
        tvSummary.text = "Total SKU: ${rows.size}$filterNote   |   More: $lebih   |   Less: $kurang   |   Same: $sama$belumNote"

        tvEmpty.visibility = if (rows.isEmpty()) View.VISIBLE else View.GONE
        lvComparison.visibility = if (rows.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun confirmClearHistory() {
        AlertDialog.Builder(this)
            .setTitle("Delete Scan History?")
            .setMessage("All scan history in Scan Process will be deleted. The system catalog data is NOT affected. Continue?")
            .setPositiveButton("Delete") { _, _ ->
                lifecycleScope.launch {
                    withContext(Dispatchers.IO) { db.clearPrice() }
                    Toast.makeText(this@StockComparisonActivity, "Scan history deleted", Toast.LENGTH_SHORT).show()
                    loadComparison()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    /**
     * ★ FIX (revisi — konsisten dengan filter di layar): isi PDF sekarang
     * SELALU mengikuti filter Qty/System/Difference yang sedang aktif di
     * layar (passesScreenFilters), sama seperti `rows` yang tampil di List.
     * Ditambah 1 filter khusus PDF, Filter Time, yang HANYA berlaku untuk
     * data 'Scan Result' (scanned = true):
     *   - Data 'Not Scanning' (scanned = false): sudah otomatis sesuai Filter
     *     Shelf (baris ini hanya muncul di queriedRows kalau Filter Shelf aktif).
     *   - Data 'Scan Result': difilter juga berdasarkan Filter Time (tanggal
     *     scan pertama). Kalau Filter Time kosong, semua Scan Result yang lolos
     *     filter Qty/System/Difference tetap ikut export.
     */
    /** ★ FIX (baru): baris final yang mau di-export, dipakai bareng oleh
     *  Export PDF maupun Export Excel supaya isi & urutan datanya SELALU
     *  konsisten di kedua format. */
    private fun buildExportRows(): List<ComparisonRow> {
        val filteredRows = queriedRows.filter { row ->
            if (!passesScreenFilters(row)) return@filter false
            if (row.scanned) {
                selectedTime.isEmpty() || selectedTime.contains(dateOnly(row.firstScanTime))
            } else {
                true
            }
        }
        // Data 'Scan Result' (scanned) tetap pakai urutan asli (by SKU).
        // Data 'Not Scanning' diurutkan by Shelf (lalu SKU sbg secondary sort),
        // supaya baris NOT SCANNED terkelompok per Shelf di PDF/Excel.
        val scannedRows = filteredRows.filter { it.scanned }
        val notScannedRows = filteredRows.filter { !it.scanned }
            .sortedWith(compareBy({ it.shelf.trim().lowercase() }, { it.sku }))
        return scannedRows + notScannedRows
    }

    /** ★ FIX (baru): pilih format export — PDF (siap cetak), Excel (.xlsx),
     *  Google Sheets (SEMUA data hasil filter, sama seperti PDF/Excel — lihat
     *  exportComparisonToGoogleSheets), atau Google Sheets khusus hasil 2nd
     *  Check saja (lihat exportSecondCheckToGoogleSheets). */
    private fun showExportFormatDialog() {
        AlertDialog.Builder(this)
            .setTitle("Export As")
            .setItems(
                arrayOf(
                    "PDF",
                    "Excel (.xlsx)",
                    "Google Sheets (All Filtered Data)",
                    "Google Sheets (2nd Check Only)"
                )
            ) { _, which ->
                when (which) {
                    0 -> exportPdf()
                    1 -> exportExcel()
                    2 -> exportComparisonToGoogleSheets()
                    3 -> exportSecondCheckToGoogleSheets()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ══════════════════════════════════════════════════════════════════
    // ★ FIX (baru — Export ke Google Sheets, SEMUA data hasil filter):
    // sama seperti Export PDF/Excel — pakai buildExportRows() supaya isi &
    // urutan data konsisten dengan 2 format lain, BUKAN cuma baris yang
    // sudah di-2nd-check saja (beda dengan exportSecondCheckToGoogleSheets
    // di bawah, yang cuma kirim baris ter-edit/unsynced).
    // ══════════════════════════════════════════════════════════════════

    private fun exportComparisonToGoogleSheets() {
        val exportRows = buildExportRows()
        if (exportRows.isEmpty()) {
            Toast.makeText(this, "No data to export yet", Toast.LENGTH_SHORT).show()
            return
        }

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 24, 48, 8)
        }
        val etUrl = EditText(this).apply {
            hint = "Google Sheets Web App URL (…/exec)"
            setText(secondCheckSheetUrl)
        }
        val etToken = EditText(this).apply {
            hint = "Token (optional)"
            setText(secondCheckSheetToken)
        }
        val tvInfo = TextView(this).apply {
            text = "${exportRows.size} row(s) ready to send (follows current filters, same data as PDF/Excel):\n" +
                "SKU | Shelf | Description | Scan Result | Keep Stock | System | Difference\n\n" +
                exportRows.take(20).joinToString("\n") { r ->
                    val diffLabel = if (!r.scanned) "NOT SCANNED" else if (r.difference > 0) "+${r.difference}" else r.difference.toString()
                    "${r.sku} | ${r.shelf} | Scan:${if (r.scanned) r.historyBalance else "-"} | KS:${r.keepStock} | Sys:${r.systemBalance} | Diff:$diffLabel"
                } + if (exportRows.size > 20) "\n… and ${exportRows.size - 20} more" else ""
            textSize = 12f
            setPadding(0, 24, 0, 0)
            setTextIsSelectable(true)
        }
        container.addView(etUrl)
        container.addView(etToken)
        container.addView(android.widget.ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 500
            )
            addView(tvInfo)
        })

        AlertDialog.Builder(this)
            .setTitle("Review & Submit — Google Sheets (All Filtered Data)")
            .setView(container)
            .setPositiveButton("Submit") { _, _ ->
                val url = etUrl.text.toString().trim()
                val token = etToken.text.toString().trim()
                if (url.isBlank()) {
                    Toast.makeText(this, "Google Sheets URL is required", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                secondCheckSheetUrl = url
                secondCheckSheetToken = token
                submitComparisonExportRows(url, token, exportRows)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun submitComparisonExportRows(url: String, token: String, exportRows: List<ComparisonRow>) {
        val pd = ProgressDialog(this).apply { setMessage("Sending ${exportRows.size} row(s) to Google Sheets..."); setCancelable(false); show() }
        lifecycleScope.launch {
            try {
                val jsonRows = exportRows.map { r ->
                    JSONObject().apply {
                        put("sku", r.sku)
                        put("shelf", r.shelf)
                        put("description", r.desc)
                        put("scanned", r.scanned)
                        put("scanResult", if (r.scanned) r.historyBalance else "")
                        put("keepStock", r.keepStock)
                        put("systemBalance", r.systemBalance)
                        put("difference", if (r.scanned) r.difference.toString() else "NOT SCANNED")
                    }
                }
                val response = withContext(Dispatchers.IO) {
                    KeepStockGasClient.appendComparisonExportRows(url, token, jsonRows)
                }
                pd.dismissSafely()
                if (response.optBoolean("ok", false)) {
                    Toast.makeText(this@StockComparisonActivity, "${exportRows.size} row(s) sent to Google Sheets", Toast.LENGTH_LONG).show()
                } else {
                    AlertDialog.Builder(this@StockComparisonActivity)
                        .setTitle("Export Failed")
                        .setMessage(response.optString("error", "Unknown error"))
                        .setPositiveButton("OK", null).showSafely()
                }
            } catch (e: Exception) {
                pd.dismissSafely()
                AlertDialog.Builder(this@StockComparisonActivity)
                    .setTitle("Export Failed")
                    .setMessage(e.message)
                    .setPositiveButton("OK", null).showSafely()
            }
        }
    }

    // ══════════════════════════════════════════════════════════════════
    // ★ FIX (baru — Fitur Edit Langsung / 2nd Check): simpan hasil inline
    // edit (Shelf/System/Balance), sinkron ke History Scan & Katalog, dan
    // catat audit trail (User ID + Waktu Edit).
    // ══════════════════════════════════════════════════════════════════

    private fun currentUserId(): String = ksLastPic.ifBlank { "" }

    /** Kalau belum pernah isi nama/ID (dipakai bersama Menu Keep Stock,
     *  field `ksLastPic`), minta isi dulu sekali sebelum menyimpan edit,
     *  supaya audit trail selalu punya User ID yang jelas. */
    private fun ensureUserIdThen(onReady: (String) -> Unit) {
        val existing = currentUserId()
        if (existing.isNotBlank()) { onReady(existing); return }
        val et = EditText(this).apply {
            hint = "Name / User ID"
            setPadding(40, 24, 40, 24)
        }
        AlertDialog.Builder(this)
            .setTitle("Your Name / User ID")
            .setMessage("Needed once for the 2nd Check audit trail (who edited & when).")
            .setView(et)
            .setPositiveButton("OK") { _, _ ->
                val name = et.text.toString().trim().ifBlank { "-" }
                ksLastPic = name
                onReady(name)
            }
            .setCancelable(false)
            .show()
    }

    /**
     * ★ FIX (baru — format edit "biasa" sama seperti "Edit Qty" di History
     * Scan/Stock Balance Check): dialog terpisah (bukan field inline di
     * dalam baris ListView) untuk edit Shelf/System/Balance (2nd Check).
     * Karena ini AlertDialog berdiri sendiri (bukan bagian dari row yang
     * di-recycle ListView), field ini AMAN dari reset/error kalau ada
     * refresh data di belakang layar (mis. auto-fetch Keep Stock timeout)
     * — apa yang sedang diketik tidak akan hilang.
     */
    private fun showSecondCheckEditDialog(row: ComparisonRow) {
        val pad = (16 * resources.displayMetrics.density).toInt()
        fun label(text: String) = TextView(this).apply { this.text = text; textSize = 12f; setPadding(0, 12, 0, 2) }

        val etShelf = EditText(this).apply { setText(row.shelf) }
        val etSystem = EditText(this).apply {
            setText(row.systemBalance.toString())
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }
        val etBalance = EditText(this).apply {
            setText(row.historyBalance.toString())
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            selectAll()
        }

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, 8, pad, 0)
            addView(label("Shelf")); addView(etShelf)
            addView(label("System")); addView(etSystem)
            addView(label("Balance (fisik)")); addView(etBalance)
            addView(
                TextView(this@StockComparisonActivity).apply {
                    text = "Keep Stock: ${row.keepStock}  |  Difference = (Balance + Keep Stock) - System"
                    textSize = 11f
                    setPadding(0, 12, 0, 0)
                }
            )
        }

        AlertDialog.Builder(this)
            .setTitle("Edit / 2nd Check — ${row.sku}")
            .setView(container)
            .setPositiveButton("SAVE") { _, _ ->
                val newShelf = etShelf.text.toString().trim().ifBlank { row.shelf }
                val newSystem = etSystem.text.toString().trim().toIntOrNull()
                val newBalance = etBalance.text.toString().trim().toIntOrNull()
                if (newSystem == null || newBalance == null || newSystem < 0 || newBalance < 0) {
                    Toast.makeText(this, "System & Balance must be a valid non-negative number", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                saveSecondCheckEdit(row, newShelf, newSystem, newBalance)
            }
            .setNegativeButton("Cancel", null)
            .show()

        etBalance.postDelayed({
            etBalance.requestFocus()
            (getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager)
                .showSoftInput(etBalance, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
        }, 150)
    }

    private fun saveSecondCheckEdit(row: ComparisonRow, newShelf: String, newSystem: Int, newBalance: Int) {
        ensureUserIdThen { userId ->
            val newDiff = (newBalance + row.keepStock) - newSystem
            lifecycleScope.launch {
                withContext(Dispatchers.IO) {
                    // ★ FIX: Balance (fisik) hasil 2nd check otomatis update
                    // data utama di menu History Scan (T_PRICE), dan System
                    // update ke katalog — supaya Stock Comparison berikutnya
                    // (& menu lain yang baca katalog/history) ikut konsisten.
                    db.applySecondCheckToHistory(row.sku, newShelf, newBalance)
                    db.updateCatalogSystemBalance(row.sku, newSystem)
                    db.updateCatalogShelfBySku(row.sku, newShelf)
                    db.saveSecondCheck(
                        SecondCheckRow(
                            sku = row.sku, shelf = newShelf, desc = row.desc,
                            systemBalance = newSystem, keepStock = row.keepStock,
                            balance = newBalance, difference = newDiff,
                            userId = userId, editTime = nowStrLocal()
                        )
                    )
                }
                Toast.makeText(
                    this@StockComparisonActivity,
                    "2nd Check saved for ${row.sku} (by $userId)",
                    Toast.LENGTH_SHORT
                ).show()
                loadComparison()
            }
        }
    }

    private fun nowStrLocal(): String =
        java.text.SimpleDateFormat("dd/MM/yy HH:mm:ss", java.util.Locale.getDefault())
            .format(java.util.Date())

    // ══════════════════════════════════════════════════════════════════
    // ★ FIX (baru — Export ke Google Sheets, hasil 2nd Check): Custom Link
    // Input (URL Web App GAS bebas) + Review & Submit sebelum data dikirim.
    // Data selalu di-APPEND ke baris paling bawah (lihat KeepStockGasClient
    // .appendSecondCheckRows & GAS_ADDON_SECOND_CHECK.gs.txt).
    // ══════════════════════════════════════════════════════════════════

    private fun exportSecondCheckToGoogleSheets() {
        lifecycleScope.launch {
            val unsynced = withContext(Dispatchers.IO) { db.getUnsyncedSecondCheckRows() }
            if (unsynced.isEmpty()) {
                AlertDialog.Builder(this@StockComparisonActivity)
                    .setTitle("No 2nd Check data yet")
                    .setMessage("Do an inline edit (2nd Check) on a Difference (+)/(-) or Not Scanned row first, then export.")
                    .setPositiveButton("OK", null).showSafely()
                return@launch
            }

            val container = LinearLayout(this@StockComparisonActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(48, 24, 48, 8)
            }
            val etUrl = EditText(this@StockComparisonActivity).apply {
                hint = "Google Sheets Web App URL (…/exec)"
                setText(secondCheckSheetUrl)
            }
            val etToken = EditText(this@StockComparisonActivity).apply {
                hint = "Token (optional)"
                setText(secondCheckSheetToken)
            }
            val tvInfo = TextView(this@StockComparisonActivity).apply {
                text = "${unsynced.size} row(s) ready to append:\nSKU | Shelf | Description | Balance | Keep Stock | System Balance | Difference | Timestamp\n\n" +
                    unsynced.take(20).joinToString("\n") {
                        "${it.sku} | ${it.shelf} | Bal:${it.balance} | Sys:${it.systemBalance} | Diff:${it.difference}"
                    } + if (unsynced.size > 20) "\n… and ${unsynced.size - 20} more" else ""
                textSize = 12f
                setPadding(0, 24, 0, 0)
                setTextIsSelectable(true)
            }
            container.addView(etUrl)
            container.addView(etToken)
            container.addView(android.widget.ScrollView(this@StockComparisonActivity).apply {
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, 500
                )
                addView(tvInfo)
            })

            AlertDialog.Builder(this@StockComparisonActivity)
                .setTitle("Review & Submit — Google Sheets")
                .setView(container)
                .setPositiveButton("Submit") { _, _ ->
                    val url = etUrl.text.toString().trim()
                    val token = etToken.text.toString().trim()
                    if (url.isBlank()) {
                        Toast.makeText(this@StockComparisonActivity, "Google Sheets URL is required", Toast.LENGTH_SHORT).show()
                        return@setPositiveButton
                    }
                    secondCheckSheetUrl = url
                    secondCheckSheetToken = token
                    submitSecondCheckRows(url, token, unsynced)
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    private fun submitSecondCheckRows(url: String, token: String, rows: List<SecondCheckRow>) {
        val pd = ProgressDialog(this).apply { setMessage("Sending ${rows.size} row(s) to Google Sheets..."); setCancelable(false); show() }
        lifecycleScope.launch {
            try {
                val jsonRows = rows.map { r ->
                    JSONObject().apply {
                        put("sku", r.sku)
                        put("shelf", r.shelf)
                        put("description", r.desc)
                        put("balance", r.balance)
                        put("keepStock", r.keepStock)
                        put("systemBalance", r.systemBalance)
                        put("difference", r.difference)
                        put("timestamp", r.editTime)
                    }
                }
                val response = withContext(Dispatchers.IO) {
                    KeepStockGasClient.appendSecondCheckRows(url, token, jsonRows)
                }
                pd.dismissSafely()
                if (response.optBoolean("ok", false)) {
                    withContext(Dispatchers.IO) { db.markSecondCheckSynced(rows.map { it.sku }) }
                    Toast.makeText(this@StockComparisonActivity, "${rows.size} row(s) appended to Google Sheets", Toast.LENGTH_LONG).show()
                } else {
                    AlertDialog.Builder(this@StockComparisonActivity)
                        .setTitle("Export Failed")
                        .setMessage(response.optString("error", "Unknown error"))
                        .setPositiveButton("OK", null).showSafely()
                }
            } catch (e: Exception) {
                pd.dismissSafely()
                AlertDialog.Builder(this@StockComparisonActivity)
                    .setTitle("Export Failed")
                    .setMessage(e.message)
                    .setPositiveButton("OK", null).showSafely()
            }
        }
    }

    private fun exportPdf() {
        val exportRows = buildExportRows()
        if (exportRows.isEmpty()) {
            Toast.makeText(this, "No data to export yet", Toast.LENGTH_SHORT).show()
            return
        }
        val pd = ProgressDialog(this).apply { setMessage("Generating PDF..."); show() }
        lifecycleScope.launch {
            try {
                val fileName = outFileName(this@StockComparisonActivity, "STOCK_COMPARISON").removeSuffix(".txt") + ".pdf"
                val savedPath = withContext(Dispatchers.IO) {
                    val bytes = PdfExporter.generate(exportRows, "Stock Comparison Report")
                    OutputWriter.writeBytes(this@StockComparisonActivity, fileName, bytes)
                }
                pd.dismissSafely()
                showExportSuccessDialog(savedPath, "PDF", "application/pdf")
            } catch (e: Exception) {
                pd.dismissSafely()
                AlertDialog.Builder(this@StockComparisonActivity)
                    .setTitle("Export PDF Failed")
                    .setMessage(e.message)
                    .setPositiveButton("OK", null).showSafely()
            }
        }
    }

    /** ★ FIX (baru): Export Excel (.xlsx) — kolom & urutan data SAMA dengan
     *  Export PDF, lihat ExcelExporter.generate(). */
    private fun exportExcel() {
        val exportRows = buildExportRows()
        if (exportRows.isEmpty()) {
            Toast.makeText(this, "No data to export yet", Toast.LENGTH_SHORT).show()
            return
        }
        val pd = ProgressDialog(this).apply { setMessage("Generating Excel..."); show() }
        lifecycleScope.launch {
            try {
                val fileName = outFileName(this@StockComparisonActivity, "STOCK_COMPARISON").removeSuffix(".txt") + ".xlsx"
                val savedPath = withContext(Dispatchers.IO) {
                    val bytes = ExcelExporter.generate(exportRows, "Stock Comparison Report")
                    OutputWriter.writeBytes(this@StockComparisonActivity, fileName, bytes)
                }
                pd.dismissSafely()
                showExportSuccessDialog(
                    savedPath, "Excel",
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                )
            } catch (e: Exception) {
                pd.dismissSafely()
                AlertDialog.Builder(this@StockComparisonActivity)
                    .setTitle("Export Excel Failed")
                    .setMessage(e.message)
                    .setPositiveButton("OK", null).showSafely()
            }
        }
    }

    private fun showExportSuccessDialog(savedPath: String, formatLabel: String, mimeType: String) {
        val mode = uploadMode
        val msg = "$formatLabel saved ($mode):\n$savedPath"
        val builder = AlertDialog.Builder(this)
            .setTitle("Export $formatLabel Successful")
            .setMessage(msg)
            .setNegativeButton("Close", null)
        // Untuk mode LOCAL/HTTP file-nya ada langsung di HP, jadi bisa langsung dibuka.
        if (mode == "LOCAL" || mode == "HTTP") {
            builder.setPositiveButton("Open $formatLabel") { _, _ -> openLocalFile(savedPath, mimeType) }
        }
        builder.showSafely()
    }

    private fun openLocalFile(path: String, mimeType: String) {
        try {
            val file = File(path)
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, mimeType)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Unable to open file: ${e.message}. The file is still saved at:\n$path", Toast.LENGTH_LONG).show()
        }
    }
}
