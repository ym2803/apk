package com.tms.qubeapps.qubedatacollector

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/**
 * Penyimpanan konfigurasi dan metadata Vault:
 *  - kode buka vault (SharedPreferences)
 *  - daftar app yang disembunyikan (SharedPreferences)
 *  - indeks file tersembunyi (JSON di direktori privat app)
 */
object VaultPrefs {

    private const val NAME      = "vault_prefs"
    private const val KEY_CODE  = "vault_code"
    private const val KEY_APPS  = "hidden_apps"

    /** Kode default saat pertama kali pakai (sebelum diubah). */
    const val DEFAULT_CODE = "9999"

    // ── Kode vault ───────────────────────────────────────────────────────
    fun getCode(ctx: Context): String =
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE)
            .getString(KEY_CODE, DEFAULT_CODE) ?: DEFAULT_CODE

    fun setCode(ctx: Context, code: String) =
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE)
            .edit().putString(KEY_CODE, code).apply()

    // ── Hidden apps ──────────────────────────────────────────────────────
    fun getHiddenApps(ctx: Context): MutableSet<String> =
        (ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE)
            .getStringSet(KEY_APPS, mutableSetOf()) ?: mutableSetOf()).toMutableSet()

    fun saveHiddenApps(ctx: Context, apps: Set<String>) =
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE)
            .edit().putStringSet(KEY_APPS, apps).apply()

    // ── Direktori privat vault ────────────────────────────────────────────
    fun vaultDir(ctx: Context)  = File(ctx.filesDir, "vault").also { it.mkdirs() }
    fun mediaDir(ctx: Context)  = File(vaultDir(ctx), "media").also { it.mkdirs() }
    fun docsDir(ctx: Context)   = File(vaultDir(ctx), "docs").also { it.mkdirs() }

    fun storedFile(ctx: Context, stored: String, type: String): File {
        val dir = if (type == "file") docsDir(ctx) else mediaDir(ctx)
        return File(dir, stored)
    }

    // ── Index file tersembunyi ────────────────────────────────────────────
    private fun indexFile(ctx: Context) = File(vaultDir(ctx), "index.json")

    fun loadIndex(ctx: Context): JSONArray {
        val f = indexFile(ctx)
        return runCatching { if (f.exists()) JSONArray(f.readText()) else JSONArray() }
            .getOrDefault(JSONArray())
    }

    fun saveIndex(ctx: Context, arr: JSONArray) = indexFile(ctx).writeText(arr.toString())

    /** type: "image" | "video" | "file" */
    fun addEntry(ctx: Context, origName: String, stored: String, type: String, size: Long) {
        val arr = loadIndex(ctx)
        arr.put(JSONObject().apply {
            put("orig",   origName)
            put("stored", stored)
            put("type",   type)
            put("size",   size)
            put("date",   System.currentTimeMillis())
        })
        saveIndex(ctx, arr)
    }

    fun removeEntry(ctx: Context, stored: String) {
        val arr = loadIndex(ctx)
        val out = JSONArray()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.getString("stored") != stored) out.put(o)
        }
        saveIndex(ctx, out)
    }

    /** UUID + ekstensi asli supaya tidak bisa ditebak. */
    fun newStoredName(origName: String): String {
        val ext = origName.substringAfterLast('.', "")
        return UUID.randomUUID().toString() + if (ext.isNotEmpty()) ".$ext" else ""
    }
}
