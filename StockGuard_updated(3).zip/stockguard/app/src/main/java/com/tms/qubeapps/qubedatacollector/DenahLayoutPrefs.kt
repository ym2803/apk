package com.tms.qubeapps.qubedatacollector

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * ★ FIX (baru — Denah Custom per No Ctn, menu Keep Stock > View & Edit Data):
 * model data + penyimpanan untuk "denah" (peta lokasi box) freeform, mirip
 * contoh gambar yang diberikan user (kotak2 No Ctn ditaruh bebas di kanvas,
 * plus banner label seperti RECEIVING/CASHIER).
 *
 * Layout disimpan PER TOKO (bukan per HP) — semua user yang login ke toko
 * yang sama lihat & edit denah yang SAMA. Supaya bisa dipakai bareng-bareng
 * lintas HP, layout di-sync ke Google Apps Script Web App yang SAMA dipakai
 * fitur Keep Stock lain (lihat KeepStockGasClient.saveLayout/getLayout, dan
 * GAS_KS_addon_LAYOUT.gs.txt di root project untuk kode Apps Script yang
 * perlu ditambahkan).
 *
 * Cache lokal (SharedPreferences) dipakai supaya:
 *  - Layout tetap bisa DILIHAT walau lagi offline (pakai data terakhir yang
 *    berhasil di-sync).
 *  - Tampilan langsung muncul instan tanpa nunggu network saat buka menu.
 */
object DenahLayoutPrefs {

    private const val NAME = "QubeDenahLayout"

    /** Satu kotak/tile di kanvas. Posisi & ukuran dalam satuan grid (bukan px/dp langsung). */
    data class Tile(
        val id: String,
        val type: String,      // "CTN", "LABEL", atau "RULER"
        val noCtn: String? = null,   // CTN: null/blank = SLOT KOSONG (belum ada box, cuma nomor urut slot)
        val label: String? = null,   // LABEL: teks banner (mis. "RECEIVING"). RULER: override angka manual (opsional)
        val x: Int,
        val y: Int,
        val w: Int = 1,
        val h: Int = 1,
        val colorHex: String? = null, // LABEL: warna banner. CTN: override warna (mis. putih=slot kosong, merah=perlu dicek)
        /**
         * ★ FIX (baru — Nomor Slot Fisik, terpisah dari No Ctn): nomor urut
         * posisi FISIK kotak di grid (1,2,3,...), ditetapkan SEKALI saat
         * grid dibuat & TIDAK PERNAH berubah walau No Ctn di slot itu
         * berubah/kosong/dipindah — persis seperti contoh denah user (kotak
         * putih bernomor 1..129 independen dari kode A058 dsb yang
         * "menimpa" sebagian slot). null = tile ini tidak masuk sistem
         * penomoran slot (mis. box lepas hasil +BOX manual di luar grid).
         */
        val slotNo: Int? = null,
        /**
         * ★ FIX (baru): true kalau box ini butuh dicek manual — dipakai
         * untuk box yang "kalah" tabrakan posisi & dipindah otomatis ke
         * BOX N/A (lihat DenahLayoutActivity.resolveOverlapsAndFillGaps).
         * Digambar merah di kanvas (lihat colorHex) sebagai penanda visual.
         */
        val needsReview: Boolean = false,
        /**
         * ★ FIX (baru — Ruler/dimension guide): dipakai HANYA untuk
         * type == "RULER". "H" = garis panah horizontal sepanjang [w] sel,
         * "V" = garis panah vertikal sepanjang [h] sel — anotasi ukuran
         * cluster, persis label "36"/"38" + panah di contoh denah user.
         */
        val dir: String? = null,
        /**
         * ★ FIX (baru — Fase 1 "Layout Editor" sesuai spesifikasi baru:
         * Android sebagai editor koordinat X/Y): field TAMBAHAN yang belum
         * dipakai aktif di UI (ditambah sekarang biar model data & format
         * simpan/load SUDAH siap, tanpa mengubah cara kerja grid yang
         * sekarang jalan — supaya tidak ada resiko error di tengah migrasi
         * bertahap). Rencana pemakaian di fase berikutnya:
         *  - rotation: sudut rotasi box/objek (derajat), untuk Object Editor.
         *  - locked  : true = tidak bisa digeser/dihapus lewat drag biasa.
         *  - visible : true = ditampilkan di kanvas (bisa disembunyikan
         *              tanpa dihapus, mis. layer yang lagi tidak dipakai).
         */
        val rotation: Float = 0f,
        val locked: Boolean = false,
        val visible: Boolean = true,
        /**
         * ★ FIX (baru — Fase 3 "Drag Bebas / Snap-to-Grid opsional"):
         * pergeseran HALUS (dalam satuan grid, boleh pecahan & boleh negatif)
         * di ATAS posisi grid [x]/[y] — TIDAK menggantikan x/y. Posisi layar
         * sebenarnya = (x + offsetX, y + offsetY). Sengaja dibuat begini
         * (bukan mengubah x/y jadi Float) supaya SEMUA logika grid yang
         * sudah ada (Auto-Generate, resolveOverlapsAndFillGaps/Only, kolom
         * BOX N/A, slotNo, Ruler) TETAP jalan apa adanya berdasarkan x/y —
         * offset ini murni kosmetik/posisi visual tambahan, tidak ikut
         * dipakai logika tabrakan/gap-fill/batas box.
         *
         * - SNAP ON  (default, perilaku sama seperti sebelum Fase 3): drag
         *   selalu membulatkan ke sel grid terdekat -> x/y (Int) berubah,
         *   offsetX/offsetY selalu 0 setelah lepas jari.
         * - SNAP OFF: drag TIDAK dibulatkan -> x/y (Int, "sel acuan") tetap,
         *   offsetX/offsetY menampung sisa pergeseran halus (boleh besar,
         *   boleh lewat beberapa sel) -> box kelihatan bebas digeser kemana
         *   saja, walau "alamat sel"-nya di data tidak berubah.
         */
        val offsetX: Float = 0f,
        val offsetY: Float = 0f,
        /**
         * ★ FIX (baru — Fase 6 "Orphan Box", spesifikasi poin 14): true kalau
         * No Ctn box ini SUDAH TIDAK ADA lagi di data Keep Stock (terdeteksi
         * lewat Update Layout), TAPI belum diputuskan user mau di-REMOVE
         * atau di-KEEP. Box TIDAK langsung dihapus/dikosongkan otomatis —
         * cuma ditandai (warna kuning/amber di kanvas) sampai user memutuskan
         * lewat dialog "Orphan Box" (lihat DenahLayoutActivity.
         * showOrphanBoxDialog()).
         */
        val orphan: Boolean = false
    )

    data class Layout(
        val store: String,
        val gridUnitDp: Int = 32,
        val tiles: List<Tile> = emptyList(),
        val aliases: List<Alias> = emptyList(),
        val updatedAt: Long = 0L
    )

    /**
     * ★ FIX (baru — Auto-Generate Denah, suffix A-Z): "alias" No Ctn yang
     * TIDAK punya kotak sendiri di kanvas — dia cuma "menumpang" posisi
     * kotak (base) yang lain. Ini dipakai untuk kode dengan akhiran huruf
     * (mis. A001A, A001B, ... A001Z) yang menurut logika toko posisinya =
     * posisi kode dasar ke-(index+offset huruf) dalam urutan yang sama.
     *
     * Sengaja TIDAK disimpan sebagai Tile terpisah (supaya kanvas tidak
     * numpuk ribuan kotak yang saling tindih persis di posisi yang sama) —
     * cukup jadi lookup table: alias code -> No Ctn kotak aslinya (base).
     * Dipakai saat: cek isi/kosong (occupancy), tap detail box, dan search.
     */
    data class Alias(val code: String, val baseNoCtn: String)

    fun toJson(layout: Layout): JSONObject = JSONObject().apply {
        put("store", layout.store)
        put("gridUnitDp", layout.gridUnitDp)
        put("updatedAt", layout.updatedAt)
        val arr = JSONArray()
        layout.tiles.forEach { t ->
            arr.put(JSONObject().apply {
                put("id", t.id)
                put("type", t.type)
                put("noCtn", t.noCtn ?: "")
                put("label", t.label ?: "")
                put("x", t.x); put("y", t.y); put("w", t.w); put("h", t.h)
                put("colorHex", t.colorHex ?: "")
                put("slotNo", t.slotNo ?: -1)
                put("needsReview", t.needsReview)
                put("dir", t.dir ?: "")
                put("rotation", t.rotation)
                put("locked", t.locked)
                put("visible", t.visible)
                put("offsetX", t.offsetX)
                put("offsetY", t.offsetY)
                put("orphan", t.orphan)
            })
        }
        put("tiles", arr)
        val aliasArr = JSONArray()
        layout.aliases.forEach { a ->
            aliasArr.put(JSONObject().apply { put("code", a.code); put("baseNoCtn", a.baseNoCtn) })
        }
        put("aliases", aliasArr)
    }

    fun fromJson(json: JSONObject): Layout {
        val store = json.optString("store", "")
        val gridUnitDp = json.optInt("gridUnitDp", 32)
        val updatedAt = json.optLong("updatedAt", 0L)
        val tiles = mutableListOf<Tile>()
        val arr = json.optJSONArray("tiles") ?: JSONArray()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            tiles.add(
                Tile(
                    id = o.optString("id", "t$i"),
                    type = o.optString("type", "CTN"),
                    noCtn = o.optString("noCtn", "").ifBlank { null },
                    label = o.optString("label", "").ifBlank { null },
                    x = o.optInt("x", 0),
                    y = o.optInt("y", 0),
                    w = o.optInt("w", 1),
                    h = o.optInt("h", 1),
                    colorHex = o.optString("colorHex", "").ifBlank { null },
                    slotNo = o.optInt("slotNo", -1).let { if (it < 0) null else it },
                    needsReview = o.optBoolean("needsReview", false),
                    dir = o.optString("dir", "").ifBlank { null },
                    // ★ FIX (baru — Fase 1): field baru, default aman kalau baca layout LAMA
                    // yang belum punya kolom ini (optDouble/optBoolean dengan default).
                    rotation = o.optDouble("rotation", 0.0).toFloat(),
                    locked = o.optBoolean("locked", false),
                    visible = o.optBoolean("visible", true),
                    // ★ FIX (baru — Fase 3): default 0f kalau layout LAMA belum punya kolom ini.
                    offsetX = o.optDouble("offsetX", 0.0).toFloat(),
                    offsetY = o.optDouble("offsetY", 0.0).toFloat(),
                    orphan = o.optBoolean("orphan", false)
                )
            )
        }
        val aliases = mutableListOf<Alias>()
        val aliasArr = json.optJSONArray("aliases") ?: JSONArray()
        for (i in 0 until aliasArr.length()) {
            val o = aliasArr.getJSONObject(i)
            val code = o.optString("code", "")
            val baseNoCtn = o.optString("baseNoCtn", "")
            if (code.isNotBlank() && baseNoCtn.isNotBlank()) aliases.add(Alias(code, baseNoCtn))
        }
        return Layout(store, gridUnitDp, tiles, aliases, updatedAt)
    }

    /** Cache lokal supaya bisa lihat denah walau offline / sebelum sync selesai. */
    fun loadCached(ctx: Context, store: String): Layout? {
        val sp = ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE)
        val raw = sp.getString(key(store), null) ?: return null
        return try { fromJson(JSONObject(raw)) } catch (e: Exception) { null }
    }

    fun saveCached(ctx: Context, layout: Layout) {
        val sp = ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE)
        sp.edit().putString(key(layout.store), toJson(layout).toString()).apply()
    }

    /**
     * ★ FIX (baru — Fase 7 "Offline / PENDING SYNC", spesifikasi poin 19):
     * flag PERSISTEN (bertahan walau app ditutup-buka lagi) yang menandai
     * layout toko ini PUNYA PERUBAHAN LOKAL yang BELUM berhasil terkirim ke
     * server (mis. karena offline waktu SAVE ditekan). UI (DenahLayoutActivity)
     * menampilkan badge "PENDING SYNC" selama flag ini true, dan flag
     * dilepas otomatis begitu SAVE berhasil kirim ke server.
     */
    fun setPendingSync(ctx: Context, store: String, pending: Boolean) {
        val sp = ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE)
        sp.edit().putBoolean(pendingKey(store), pending).apply()
    }

    fun isPendingSync(ctx: Context, store: String): Boolean {
        val sp = ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE)
        return sp.getBoolean(pendingKey(store), false)
    }

    private fun pendingKey(store: String) = "layout_pending_sync_$store"

    private fun key(store: String) = "layout_$store"
}
