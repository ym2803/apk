package com.tms.qubeapps.qubedatacollector

import android.database.Cursor
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.ViewGroup
import android.widget.CursorAdapter
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.Spinner
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.tms.qubeapps.qubedatacollector.AppDatabase.Companion.C_CAT_BALANCE
import com.tms.qubeapps.qubedatacollector.AppDatabase.Companion.C_CAT_DESC
import com.tms.qubeapps.qubedatacollector.AppDatabase.Companion.C_CAT_PRICE
import com.tms.qubeapps.qubedatacollector.AppDatabase.Companion.C_CAT_SHELF
import com.tms.qubeapps.qubedatacollector.AppDatabase.Companion.C_CAT_SKU
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Layar "LIHAT DATA DOWNLOAD 02" — menampilkan seluruh katalog hasil
 * download 02.txt yang tersimpan di SQLite (lihat AppDatabase.getCatalogCursor).
 *
 * FIX (force close): pakai CursorAdapter, BUKAN memuat semua baris ke List
 * di Kotlin lalu ditampilkan lewat BaseAdapter biasa. CursorAdapter hanya
 * membaca baris yang sedang tampil di layar dari SQLite (windowed cursor),
 * jadi katalog dengan puluhan/ratusan ribu SKU tetap ringan dibuka.
 */
class PriceCatalogViewActivity : BaseActivity() {

    private lateinit var db: AppDatabase
    private lateinit var etSearch: EditText
    private lateinit var tvCount: TextView
    private lateinit var lvCatalog: ListView
    private lateinit var etFilterShelf: EditText
    private lateinit var spFilterBalance: Spinner
    private var adapter: CatalogCursorAdapter? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_price_catalog_view)

        db        = AppDatabase(this)
        etSearch  = findViewById(R.id.etCatalogSearch)
        tvCount   = findViewById(R.id.tvCatalogCount)
        lvCatalog = findViewById(R.id.lvCatalog)
        etFilterShelf   = findViewById(R.id.etFilterShelf)
        spFilterBalance = findViewById(R.id.spFilterBalance)

        // ★ FIX (baru): filter Balance — All / > 0 / = 0 / < 0
        spFilterBalance.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item,
            listOf("Balance: All", "Balance > 0", "Balance = 0", "Balance < 0")
        )

        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }

        // ★ FIX: tap & tahan (long-click) 1 baris -> data-nya otomatis disalin ke clipboard
        lvCatalog.setOnItemLongClickListener { _, _, position, _ ->
            copyRowToClipboard(position)
            true
        }

        loadCatalog()

        val watcher = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) { loadCatalog() }
        }
        etSearch.addTextChangedListener(watcher)
        etFilterShelf.addTextChangedListener(watcher)
        spFilterBalance.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { loadCatalog() }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
    }

    /**
     * ★ FIX: copy SKU saja (tanpa Desc/Shelf/Price/Balance) ke clipboard begitu
     * baris di-tap & tahan, supaya bisa langsung paste ke WhatsApp/Excel/dsb.
     */
    private fun copyRowToClipboard(position: Int) {
        val cursor = adapter?.cursor ?: return
        if (!cursor.moveToPosition(position)) return
        val sku = cursor.getString(cursor.getColumnIndexOrThrow(C_CAT_SKU)) ?: return

        val cm = getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        cm.setPrimaryClip(android.content.ClipData.newPlainText("SKU", sku))
        android.widget.Toast.makeText(this, "Disalin: $sku", android.widget.Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        // Tutup cursor lama supaya tidak bocor memori/file handle.
        adapter?.swapCursor(null)?.close()
        super.onDestroy()
    }

    private fun loadCatalog() {
        val filter  = etSearch.text?.toString()?.trim() ?: ""
        val shelf   = etFilterShelf.text?.toString()?.trim() ?: ""
        val balMode = spFilterBalance.selectedItemPosition.coerceAtLeast(0)
        lifecycleScope.launch {
            val cursor = withContext(Dispatchers.IO) { db.getCatalogCursor(filter, shelf, balMode) }
            val count  = cursor.count
            tvCount.text = "$count item"
            if (adapter == null) {
                adapter = CatalogCursorAdapter(this@PriceCatalogViewActivity, cursor)
                lvCatalog.adapter = adapter
            } else {
                val old = adapter!!.swapCursor(cursor)
                old?.close()
            }
        }
    }

    private class CatalogCursorAdapter(
        context: android.content.Context,
        cursor: Cursor
    ) : CursorAdapter(context, cursor, false) {

        override fun newView(context: android.content.Context, cursor: Cursor, parent: ViewGroup): View {
            return android.view.LayoutInflater.from(context)
                .inflate(R.layout.item_price_catalog, parent, false)
        }

        override fun bindView(view: View, context: android.content.Context, cursor: Cursor) {
            view.findViewById<TextView>(R.id.tvCatSku).text =
                cursor.getString(cursor.getColumnIndexOrThrow(C_CAT_SKU)) ?: "-"
            view.findViewById<TextView>(R.id.tvCatDesc).text =
                cursor.getString(cursor.getColumnIndexOrThrow(C_CAT_DESC)) ?: "-"
            view.findViewById<TextView>(R.id.tvCatShelf).text =
                "Shelf: " + (cursor.getString(cursor.getColumnIndexOrThrow(C_CAT_SHELF)) ?: "-")
            view.findViewById<TextView>(R.id.tvCatPrice).text =
                cursor.getString(cursor.getColumnIndexOrThrow(C_CAT_PRICE)) ?: "-"
            view.findViewById<TextView>(R.id.tvCatBalance).text =
                "Bal: " + (cursor.getString(cursor.getColumnIndexOrThrow(C_CAT_BALANCE)) ?: "-")
        }
    }
}
