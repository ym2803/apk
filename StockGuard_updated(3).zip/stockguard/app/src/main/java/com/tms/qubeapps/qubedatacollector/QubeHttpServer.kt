package com.tms.qubeapps.qubedatacollector

import android.content.Context
import fi.iki.elonen.NanoHTTPD
import java.io.File

/**
 * FIX: dulu mode HTTP mengharuskan PC menjalankan script Python (server)
 * supaya HP bisa POST data ke situ. Sekarang dibalik — HP sendiri yang
 * jadi server (pakai NanoHTTPD). PC tidak perlu install/jalankan apa pun,
 * tinggal buka browser dan ketik alamat IP lokal HP (ditampilkan di
 * Setting) untuk:
 *
 *  • Download  → lihat & download file hasil scan (DOIB/Stock/Shelf) yang
 *                sudah tersimpan di folder lokal HP.
 *  • Upload    → upload file (misalnya 02.txt) langsung dari browser PC
 *                ke folder lokal HP, supaya bisa dibaca fitur "Download
 *                data 02" di menu Scan Process.
 *
 * Folder yang dipakai SAMA dengan folder mode LOCAL (lihat OutputWriter),
 * jadi mode HTTP ini sebenarnya = mode LOCAL + server bawaan supaya PC
 * bisa akses folder itu lewat WiFi tanpa kabel/tanpa script tambahan.
 */
object QubeHttpServer {

    const val PORT = 8080
    private var server: InternalServer? = null

    fun isRunning(): Boolean = server != null

    fun start(ctx: Context) {
        if (server != null) return
        val dir = OutputWriter.resolveLocalDirPublic(ctx)
        server = InternalServer(dir).apply { start(NanoHTTPD.SOCKET_READ_TIMEOUT, false) }
    }

    fun stop() {
        server?.stop()
        server = null
    }

    /** Alamat IP lokal HP di jaringan WiFi saat ini, atau null kalau tidak ketemu. */
    fun getLocalIpAddress(ctx: Context): String? {
        try {
            val wifiManager = ctx.applicationContext
                .getSystemService(Context.WIFI_SERVICE) as android.net.wifi.WifiManager
            @Suppress("DEPRECATION")
            val ip = wifiManager.connectionInfo?.ipAddress ?: 0
            if (ip != 0) {
                return String.format(
                    "%d.%d.%d.%d",
                    ip and 0xff, ip shr 8 and 0xff, ip shr 16 and 0xff, ip shr 24 and 0xff
                )
            }
        } catch (_: Exception) { /* fallback di bawah */ }

        try {
            val interfaces = java.net.NetworkInterface.getNetworkInterfaces()
            for (intf in interfaces) {
                for (addr in intf.inetAddresses) {
                    if (!addr.isLoopbackAddress && addr is java.net.Inet4Address) {
                        return addr.hostAddress
                    }
                }
            }
        } catch (_: Exception) { }
        return null
    }

    private class InternalServer(private val dir: File) : NanoHTTPD(PORT) {

        override fun serve(session: IHTTPSession): Response {
            return try {
                when {
                    session.method == Method.GET && session.uri == "/" -> indexPage()
                    session.method == Method.GET && session.uri.startsWith("/files/") ->
                        serveFile(session.uri.removePrefix("/files/"))
                    session.method == Method.POST && session.uri == "/upload" -> handleUpload(session)
                    else -> newFixedLengthResponse(
                        Response.Status.NOT_FOUND, "text/plain", "Not found"
                    )
                }
            } catch (e: Exception) {
                newFixedLengthResponse(
                    Response.Status.INTERNAL_ERROR, "text/plain", "Error: ${e.message}"
                )
            }
        }

        private fun indexPage(): Response {
            if (!dir.exists()) dir.mkdirs()
            val files = dir.listFiles()?.sortedByDescending { it.lastModified() } ?: emptyList()
            val rows = if (files.isEmpty())
                "<li><i>No files yet</i></li>"
            else
                files.joinToString("\n") {
                    "<li><a href=\"/files/${it.name}\">${it.name}</a> — ${it.length()} bytes</li>"
                }
            val html = """
                <html>
                <head>
                    <title>StockGuard</title>
                    <meta name="viewport" content="width=device-width, initial-scale=1">
                    <style>
                        body{font-family:sans-serif;padding:16px;max-width:600px;margin:auto;}
                        h2{color:#5E35B1;} h3{margin-top:28px;}
                        input[type=file]{margin:8px 0;} input[type=text]{padding:6px;width:160px;}
                        input[type=submit]{background:#5E35B1;color:#fff;border:none;padding:8px 16px;border-radius:4px;}
                        li{margin:4px 0;} a{color:#1976D2;text-decoration:none;}
                    </style>
                </head>
                <body>
                <h2>StockGuard — Server Lokal</h2>
                <h3>⬆ Upload file ke HP</h3>
                <form method="POST" action="/upload" enctype="multipart/form-data">
                    <input type="file" name="file" required /><br/>
                    Save as: <input type="text" name="target" value="02.txt" /><br/><br/>
                    <input type="submit" value="Upload to Device" />
                </form>
                <h3>⬇ Download file dari HP</h3>
                <ul>$rows</ul>
                </body></html>
            """.trimIndent()
            return newFixedLengthResponse(Response.Status.OK, "text/html", html)
        }

        private fun serveFile(name: String): Response {
            val f = File(dir, name)
            if (!f.exists() || f.isDirectory) {
                return newFixedLengthResponse(Response.Status.NOT_FOUND, "text/plain", "File not found")
            }
            val mime = if (name.endsWith(".apk")) "application/vnd.android.package-archive"
                       else "application/octet-stream"
            val resp = newFixedLengthResponse(Response.Status.OK, mime, f.inputStream(), f.length())
            resp.addHeader("Content-Disposition", "attachment; filename=\"${f.name}\"")
            return resp
        }

        private fun handleUpload(session: IHTTPSession): Response {
            val tmpFiles = HashMap<String, String>()
            session.parseBody(tmpFiles) // parse multipart -> tmp path + isi session.parameters untuk field teks

            val tmpPath = tmpFiles["file"]
                ?: return newFixedLengthResponse(Response.Status.BAD_REQUEST, "text/html",
                    "<html><body>No file selected. <a href=\"/\">Back</a></body></html>")

            val target = session.parameters["target"]?.firstOrNull()?.trim()?.ifBlank { "02.txt" } ?: "02.txt"
            if (!dir.exists()) dir.mkdirs()
            val destFile = File(dir, target)
            File(tmpPath).copyTo(destFile, overwrite = true)

            return newFixedLengthResponse(Response.Status.OK, "text/html",
                "<html><body>✅ Upload successful: <b>$target</b><br/><br/>" +
                    "<a href=\"/\">Back</a></body></html>")
        }
    }
}
