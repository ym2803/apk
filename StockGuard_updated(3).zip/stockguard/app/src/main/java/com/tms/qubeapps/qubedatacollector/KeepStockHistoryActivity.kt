package com.tms.qubeapps.qubedatacollector

import android.app.AlertDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/**
 * ★ FIX (Menu 4 — Keep Stock, Edit History): menampilkan riwayat aksi
 * Add/Edit/Move/Delete (per SKU maupun per NO CTN) — tanggal, toko, PIC,
 * data sebelum/sesudah. Disimpan lokal di SQLite (per HP).
 *
 * ★ FIX baru: tombol hapus per baris riwayat + "Clear All" di header
 * untuk membersihkan seluruh riwayat toko ini.
 */
class KeepStockHistoryActivity : AppCompatActivity() {

    private lateinit var db: AppDatabase
    private lateinit var store: String
    private lateinit var listView: ListView
    private lateinit var tvEmpty: TextView
    private var entries: MutableList<AppDatabase.KsHistoryEntry> = mutableListOf()
    private lateinit var adapter: HistoryAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_keep_stock_history)

        db = AppDatabase(this)
        store = intent.getStringExtra(KeepStockLoginActivity.EXTRA_STORE) ?: ""

        findViewById<View>(R.id.btnBackHistory).setOnClickListener { finish() }
        findViewById<TextView>(R.id.tvHistoryTitle).text = "EDIT HISTORY — $store"
        findViewById<View>(R.id.btnClearAllHistory).setOnClickListener { confirmClearAll() }

        listView = findViewById(R.id.lvHistory)
        tvEmpty = findViewById(R.id.tvHistoryEmpty)
        adapter = HistoryAdapter()
        listView.adapter = adapter

        loadHistory()
    }

    private fun loadHistory() {
        entries = db.getKsHistory(store).toMutableList()
        if (entries.isEmpty()) {
            tvEmpty.visibility = View.VISIBLE
            listView.visibility = View.GONE
        } else {
            tvEmpty.visibility = View.GONE
            listView.visibility = View.VISIBLE
        }
        adapter.notifyDataSetChanged()
    }

    private fun confirmClearAll() {
        if (entries.isEmpty()) return
        AlertDialog.Builder(this)
            .setTitle("Clear All History")
            .setMessage("Delete all ${entries.size} history entries for $store? This cannot be undone.")
            .setPositiveButton("DELETE ALL") { _, _ ->
                db.deleteAllKsHistory(store)
                loadHistory()
                Toast.makeText(this, "History cleared", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun confirmDeleteOne(entry: AppDatabase.KsHistoryEntry) {
        AlertDialog.Builder(this)
            .setTitle("Delete This Entry")
            .setMessage("Delete this history entry (${entry.action} — ${entry.time})?")
            .setPositiveButton("DELETE") { _, _ ->
                db.deleteKsHistoryEntry(entry.id)
                loadHistory()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private inner class HistoryAdapter : BaseAdapter() {
        override fun getCount() = entries.size
        override fun getItem(position: Int) = entries[position]
        override fun getItemId(position: Int) = entries[position].id.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val v = convertView ?: LayoutInflater.from(parent!!.context).inflate(R.layout.item_ks_history, parent, false)
            val e = entries[position]

            v.findViewById<TextView>(R.id.tvHistTime).text = e.time
            v.findViewById<TextView>(R.id.tvHistAction).text = e.action
            v.findViewById<TextView>(R.id.tvHistPic).text = "PIC: ${e.pic}"

            val before = "${e.noCtnBefore.ifBlank { "-" }} / ${e.skuBefore.ifBlank { "-" }} / ${e.qtyBefore.ifBlank { "-" }}"
            val after = "${e.noCtnAfter.ifBlank { "-" }} / ${e.skuAfter.ifBlank { "-" }} / ${e.qtyAfter.ifBlank { "-" }}"
            v.findViewById<TextView>(R.id.tvHistBefore).text = "Before (Ctn/SKU/Qty): $before"
            v.findViewById<TextView>(R.id.tvHistAfter).text = "After  (Ctn/SKU/Qty): $after"

            val tvAction = v.findViewById<TextView>(R.id.tvHistAction)
            tvAction.setTextColor(
                when (e.action) {
                    "ADD" -> 0xFF00B894.toInt()
                    "EDIT" -> 0xFF0984E3.toInt()
                    "MOVE" -> 0xFFE17055.toInt()
                    "DELETE" -> 0xFFD63031.toInt()
                    "MOVE_CTN" -> 0xFFE17055.toInt()
                    "DELETE_CTN" -> 0xFFD63031.toInt()
                    else -> 0xFF888888.toInt()
                }
            )

            v.findViewById<View>(R.id.btnDeleteHistItem).setOnClickListener { confirmDeleteOne(e) }
            return v
        }
    }
}
