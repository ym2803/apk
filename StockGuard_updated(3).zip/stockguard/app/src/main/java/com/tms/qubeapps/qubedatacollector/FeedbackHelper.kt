package com.tms.qubeapps.qubedatacollector

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.appcompat.app.AlertDialog

/**
 * ★ FIX (baru): "Feedback" dipindahkan dari header Setting ke bottom
 * navigation bar (di sebelah menu Credits). Logic dialognya sekarang di
 * satu tempat supaya bisa dipanggil dari mana saja.
 */
object FeedbackHelper {

    private const val WA_NUMBER = "6282115303443" // Yayang / 082115303443

    fun showFeedbackDialog(activity: Activity) {
        AlertDialog.Builder(activity)
            .setTitle("Feedback & Suggestions")
            .setMessage("Have feedback, suggestions, or issues using this app?\n\n" +
                "Contact Yayang via WhatsApp:\n082115303443")
            .setPositiveButton("Chat on WhatsApp") { _, _ ->
                try {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$WA_NUMBER"))
                    activity.startActivity(intent)
                } catch (e: Exception) {
                    Toast.makeText(activity, "WhatsApp is not installed on this device", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Close", null).show()
    }
}
