package com.tms.qubeapps.qubedatacollector

import android.app.AlertDialog
import android.app.ProgressDialog
import android.content.Context
import androidx.appcompat.app.AppCompatActivity

/**
 * All activities in the app extend this instead of AppCompatActivity directly,
 * so the language chosen in Settings ("System Default" or "English") is applied
 * consistently everywhere.
 */
abstract class BaseActivity : AppCompatActivity() {
    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(LocaleHelper.wrap(newBase))
    }

    /**
     * ★ FIX (crash — WindowManager.BadTokenException): dialog di-show() dari
     * dalam coroutine SETELAH suatu proses async (mis. sync SMB/GSheet di
     * withContext(Dispatchers.IO)) bisa nyasar dieksekusi walau user sudah
     * pindah/menutup activity itu (mis. tekan Back di tengah proses).
     * Window token activity yang sudah destroyed jadi tidak valid lagi ->
     * crash BadTokenException saat AlertDialog/ProgressDialog dipaksa show().
     *
     * showSafely()/dismissSafely() jadi pengganti wajib untuk SEMUA dialog
     * yang di-show()/dismiss() SETELAH sebuah suspend function (withContext,
     * delay, dsb) di dalam lifecycleScope.launch — cek dulu activity masih
     * hidup (belum finishing/destroyed) SEBELUM show(), dan bungkus dismiss()
     * dengan try/catch (window bisa saja sudah hilang duluan di sistem walau
     * flag isFinishing/isDestroyed belum sempat ke-update).
     */
    protected fun AlertDialog.Builder.showSafely(): AlertDialog? {
        if (isFinishing || isDestroyed) return null
        return try { show() } catch (e: Exception) { null }
    }

    protected fun ProgressDialog.dismissSafely() {
        try {
            if (isShowing) dismiss()
        } catch (e: Exception) {
            // window sudah tidak valid (activity destroyed) — aman diabaikan
        }
    }
}
