package com.tms.qubeapps.qubedatacollector

import android.app.AlertDialog
import android.content.Context
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.CheckBox
import android.text.InputType
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.lifecycleScope
import com.tms.qubeapps.qubedatacollector.Prefs.catalogUpdatedTime
import com.tms.qubeapps.qubedatacollector.Prefs.smbUploadPathExpiredDiscount
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Product Master — port dari TAHAP 2 (CheckDisc) pada ProdMast.py.
 *
 * Fungsi utama:
 *  1. Baca data katalog (02) yang sudah di-download → tampil di 7 tab:
 *       PRICE CHANGE · PRICE ADJUSTMENT · CHANGE DESCRIPTION · NO SHELF ·
 *       QTY MINUS · ACTIVE DISCOUNTS · EXPIRED DISCOUNTS.
 *  2. Bandingkan dengan snapshot harga + deskripsi sebelumnya
 *     (product_master_history.json di filesDir) — SATU kali per download katalog
 *     (hasilnya di-cache, jadi buka/refresh layar tidak menghapus daftar perubahan).
 *  3. Cari SKU (kotak pencarian) dan urutkan A→Z / Z→A berdasarkan
 *     SKU, Shelf, Start Discount, End Discount di SEMUA tab.
 *  4. Tab NO SHELF: tap item untuk EDIT shelf (disimpan lokal); hasil edit
 *     di-export lewat tombol di bar bawah layar (2 file: PRINT NO SHELF "SKU,1" dan EXCEL IN NO SHELF "SHELF,SKU").
 *  5. SEMUA export diurutkan shelf A→Z; kalau user sudah upload SKU_ORDER.csv
 *     (Shelf,SKU,NomorUrut — sama seperti cd_load_sku_order di ProdMast.py),
 *     urutan di dalam satu shelf mengikuti NomorUrut (tanpa nomor → paling akhir).
 *  6. Export ACTIVE / EXPIRED DISCOUNTS: pilih tanggal end discount, daftar
 *     dimulai dari tanggal yang paling dekat dengan hari ini.
 *  7. Export via menu ▼ ke 5 output sesuai CheckDisc di ProdMast.py:
 *       PRICE CHANGE       – SKU yang harga-nya berubah (vs snapshot), balance > 0.
 *       CHANGE DESCRIPTION – SKU yang deskripsi-nya berubah, balance > 0.
 *       NO SHELF           – balance > 0 tapi shelf kosong / "-" / berupa angka.
 *       QTY MINUS          – balance (qty system) < 0 → "SKU,qty" (qty positif).
 *       PRICE ADJUSTMENT   – promo baru berakhir (≤ LOOKBACK_DAYS) ATAU baru mulai.
 */
class ProductMasterActivity : BaseActivity() {

    // ── Constants ─────────────────────────────────────────────────────────
    companion object {
        /** Rentang "baru berakhir" → ikut PRICE ADJUSTMENT (hari). */
        private const val EXPIRED_LOOKBACK_DAYS = 1L
        /** Rentang "baru mulai"   → ikut PRICE ADJUSTMENT (hari). */
        private const val START_LOOKBACK_DAYS   = 1L
        private const val DAY_MS        = 86_400_000L
        /** end_date berlaku sampai akhir hari (23:59:59). */
        private const val END_OF_DAY_MS = (23 * 3600 + 59 * 60 + 59) * 1000L
    }

    private enum class Tab(val label: String) {
        PRICE_CHANGE("Price Change"),
        PRICE_ADJUSTMENT("Price Adjustment"),
        CHANGE_DESCRIPTION("Change Description"),
        NO_SHELF("No Shelf"),
        QTY_MINUS("Qty Minus"),
        ACTIVE("Active Discounts"),
        EXPIRED("Expired Discounts")
    }

    private enum class SortField(val label: String) {
        DEFAULT("Urutan default"),
        SKU("SKU"),
        SHELF("Shelf"),
        START("Start Discount"),
        END("End Discount")
    }

    // ── Data model ────────────────────────────────────────────────────────
    data class ProdItem(
        val sku: String, val shelf: String, val desc: String,
        val price: String, val discount: String,
        val discStart: String, val discEnd: String,
        val balanceNum: Double, val endDateMillis: Long?,
        val startDateMillis: Long?,
        val masterRack: String,
        /** Keep Stock (kolom hasil mapping di 02.txt). */
        val keepStock: String = "-"
    )

    /** Hasil perbandingan snapshot: SKU → nilai LAMA. */
    private class ChangeSet(
        val inc: Map<String, Double>,
        val dec: Map<String, Double>,
        val desc: Map<String, String>
    )

    /** Semua daftar khusus ala CheckDisc (dihitung sekali per load). */
    private data class SpecialLists(
        val priceChange: List<ProdItem>,
        val priceAdjustment: List<ProdItem>,
        val descChange: List<ProdItem>,
        val noShelf: List<ProdItem>,
        val qtyMinus: List<ProdItem>,
        val oldPrice: Map<String, Double>,
        val oldDesc: Map<String, String>,
        /** NO SHELF asli (belum di-overlay hasil edit shelf). */
        val noShelfBase: List<ProdItem> = emptyList()
    ) {
        companion object {
            val EMPTY = SpecialLists(emptyList(), emptyList(), emptyList(), emptyList(),
                emptyList(), emptyMap(), emptyMap())
        }
    }

    // ── Views ─────────────────────────────────────────────────────────────
    private lateinit var db: AppDatabase
    private lateinit var lvDiscount: ListView
    private lateinit var tvSummary: TextView
    private lateinit var tvEmpty: TextView
    private lateinit var chkBalancePositive: CheckBox
    private lateinit var etSearch: EditText
    private lateinit var spSortField: Spinner
    private lateinit var btnSortDir: Button
    private lateinit var tabScroll: HorizontalScrollView
    private lateinit var bottomBarShelfEdit: View
    private lateinit var tvShelfEditInfo: TextView
    private lateinit var btnExportShelfEdits: Button
    private val tabViews = LinkedHashMap<Tab, TextView>()

    // ── State ─────────────────────────────────────────────────────────────
    private var allItems: List<ProdItem>     = emptyList()
    private var activeItems: List<ProdItem>  = emptyList()
    private var expiredItems: List<ProdItem> = emptyList()
    private var special: SpecialLists        = SpecialLists.EMPTY
    private var currentTab   = Tab.ACTIVE
    private var sortField    = SortField.DEFAULT
    private var sortAsc      = true
    private var displayedRows: List<ProdItem> = emptyList()
    private lateinit var adapter: BaseAdapter

    /** Urutan posisi SKU dari SKU_ORDER.csv: key "shelf|sku" → nomor urut. Kosong = tidak ada file. */
    @Volatile private var skuOrder: Map<String, Double> = emptyMap()
    /** Hasil edit shelf di tab NO SHELF: SKU → shelf baru (disimpan lokal). */
    private var shelfEdits: MutableMap<String, String> = LinkedHashMap()

    /** Upload manual SKU_ORDER.csv oleh user (file picker). */
    private val pickSkuOrder = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) importSkuOrder(uri)
    }

    private val dateFormats = listOf("dd/MM/yyyy","MM/dd/yyyy","yyyy-MM-dd","dd-MM-yyyy")

    // ── Lifecycle ─────────────────────────────────────────────────────────
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_product_master)

        db               = AppDatabase(this)
        lvDiscount       = findViewById(R.id.lvDiscount)
        tvSummary        = findViewById(R.id.tvDiscSummary)
        tvEmpty          = findViewById(R.id.tvDiscEmpty)
        chkBalancePositive = findViewById(R.id.chkBalancePositive)
        etSearch         = findViewById(R.id.etSearchSku)
        spSortField      = findViewById(R.id.spSortField)
        btnSortDir       = findViewById(R.id.btnSortDir)
        tabScroll        = findViewById(R.id.tabScroll)
        bottomBarShelfEdit  = findViewById(R.id.bottomBarShelfEdit)
        tvShelfEditInfo     = findViewById(R.id.tvShelfEditInfo)
        btnExportShelfEdits = findViewById(R.id.btnExportShelfEdits)

        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<View>(R.id.btnRefreshDiscount).setOnClickListener { loadData() }
        findViewById<View>(R.id.btnExportMenu).setOnClickListener  { showExportMenu() }
        findViewById<View>(R.id.btnSmbOutputSettings).setOnClickListener { showSmbOutputSettingsDialog() }

        chkBalancePositive.setOnCheckedChangeListener { _, _ -> classifyAndRender() }
        btnExportShelfEdits.setOnClickListener { exportShelfEdits() }

        buildTabs()
        setupSearchAndSort()

        adapter = object : BaseAdapter() {
            override fun getCount()              = displayedRows.size
            override fun getItem(p: Int)         = displayedRows[p]
            override fun getItemId(p: Int)       = p.toLong()
            override fun getView(pos: Int, cv: View?, parent: ViewGroup): View {
                val v = cv ?: LayoutInflater.from(this@ProductMasterActivity)
                    .inflate(R.layout.item_discount_row, parent, false)
                val item = displayedRows[pos]
                v.findViewById<TextView>(R.id.tvDiscSku).text    = item.sku
                v.findViewById<TextView>(R.id.tvDiscShelf).text  = "Shelf: ${item.shelf}"
                v.findViewById<TextView>(R.id.tvDiscDesc).text   = item.desc
                v.findViewById<TextView>(R.id.tvDiscPrice).text  = "Price: ${item.price}"
                v.findViewById<TextView>(R.id.tvDiscAmount).text = "Discount: ${item.discount}"
                v.findViewById<TextView>(R.id.tvDiscStart).text  = "Start: ${item.discStart.ifBlank{"-"}}"
                v.findViewById<TextView>(R.id.tvDiscEnd).text    = "End: ${item.discEnd.ifBlank{"-"}}"
                // QTY system (balance) & Keep Stock — tampil di SEMUA tab
                val tvQty = v.findViewById<TextView>(R.id.tvDiscQty)
                tvQty.text = "Qty System: ${fmtNum(item.balanceNum)}"
                tvQty.setTextColor(if (item.balanceNum < 0) 0xFFC0392B.toInt() else 0xFF2C3E50.toInt())
                v.findViewById<TextView>(R.id.tvDiscKeep).text = "Keep Stock: ${item.keepStock.ifBlank { "-" }}"

                // Catatan tambahan sesuai tab (harga lama / deskripsi lama / qty minus)
                val note: String? = when (currentTab) {
                    Tab.PRICE_CHANGE -> special.oldPrice[item.sku]?.let {
                        "Harga lama: ${fmtNum(it)}  →  baru: ${item.price}"
                    }
                    Tab.CHANGE_DESCRIPTION -> special.oldDesc[item.sku]?.let { "Deskripsi lama: $it" }
                    Tab.NO_SHELF -> shelfEdits[item.sku]?.let { "✎ Shelf diedit: $it   (tap untuk ubah)" }
                        ?: "Tap untuk edit shelf"
                    else -> null
                }
                val tvNote = v.findViewById<TextView>(R.id.tvDiscNote)
                if (note == null) tvNote.visibility = View.GONE
                else { tvNote.text = note; tvNote.visibility = View.VISIBLE }
                return v
            }
        }
        lvDiscount.adapter = adapter
        lvDiscount.setOnItemClickListener { _, _, pos, _ ->
            if (currentTab == Tab.NO_SHELF && pos in displayedRows.indices) showEditShelfDialog(displayedRows[pos])
        }
        styleTabs()
        loadData()
    }

    // ── Tabs ──────────────────────────────────────────────────────────────
    private fun buildTabs() {
        val container = findViewById<LinearLayout>(R.id.tabContainer)
        val pad = (14 * resources.displayMetrics.density).toInt()
        Tab.values().forEach { tab ->
            val tv = TextView(this).apply {
                text = tab.label
                textSize = 13f
                gravity = Gravity.CENTER
                setPadding(pad, 0, pad, 0)
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT)
                setOnClickListener { switchTab(tab) }
            }
            tabViews[tab] = tv
            container.addView(tv)
        }
    }

    private fun styleTabs() {
        tabViews.forEach { (tab, tv) ->
            if (tab == currentTab) {
                tv.background = androidx.core.content.ContextCompat.getDrawable(this, R.drawable.bg_header_gradient)
                tv.setTextColor(getColorCompat(R.color.white))
                tv.setTypeface(null, Typeface.BOLD)
            } else {
                tv.setBackgroundColor(getColorCompat(R.color.white))
                tv.setTextColor(0xFF888888.toInt())
                tv.setTypeface(null, Typeface.NORMAL)
            }
        }
    }

    private fun updateTabLabels() {
        tabViews.forEach { (tab, tv) -> tv.text = "${tab.label} (${sourceFor(tab).size})" }
    }

    private fun switchTab(tab: Tab) {
        currentTab = tab
        styleTabs()
        tabViews[tab]?.let { tv ->
            tabScroll.post { tabScroll.smoothScrollTo(maxOf(0, tv.left - tabScroll.width / 4), 0) }
        }
        renderCurrentTab()
    }

    private fun getColorCompat(id: Int) = androidx.core.content.ContextCompat.getColor(this, id)

    private fun sourceFor(tab: Tab): List<ProdItem> = when (tab) {
        Tab.PRICE_CHANGE       -> special.priceChange
        Tab.PRICE_ADJUSTMENT   -> special.priceAdjustment
        Tab.CHANGE_DESCRIPTION -> special.descChange
        Tab.NO_SHELF           -> special.noShelf
        Tab.QTY_MINUS          -> special.qtyMinus
        Tab.ACTIVE             -> activeItems
        Tab.EXPIRED            -> expiredItems
    }

    // ── Search SKU + Sort A-Z ─────────────────────────────────────────────
    private fun setupSearchAndSort() {
        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { renderCurrentTab() }
        })
        etSearch.setOnEditorActionListener { v, _, _ ->
            (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                .hideSoftInputFromWindow(v.windowToken, 0)
            true
        }

        val sortAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item,
            SortField.values().map { it.label })
        sortAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spSortField.adapter = sortAdapter
        spSortField.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                sortField = SortField.values()[position]
                renderCurrentTab()
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        btnSortDir.setOnClickListener {
            sortAsc = !sortAsc
            btnSortDir.text = if (sortAsc) "A→Z" else "Z→A"
            renderCurrentTab()
        }
    }

    private fun sortRows(rows: List<ProdItem>): List<ProdItem> = when (sortField) {
        SortField.DEFAULT -> rows
        SortField.SKU     -> sortNatural(rows) { it.sku }
        SortField.SHELF   -> sortNatural(rows) { it.shelf }
        SortField.START   -> sortByDate(rows) { it.startDateMillis }
        SortField.END     -> sortByDate(rows) { it.endDateMillis }
    }

    private fun sortNatural(rows: List<ProdItem>, key: (ProdItem) -> String): List<ProdItem> {
        val cmp = Comparator<ProdItem> { a, b -> naturalCompare(key(a).trim(), key(b).trim()) }
        return rows.sortedWith(if (sortAsc) cmp else cmp.reversed())
    }

    /** Urut berdasarkan tanggal sebenarnya (bukan teks); yang tanpa tanggal selalu di paling bawah. */
    private fun sortByDate(rows: List<ProdItem>, key: (ProdItem) -> Long?): List<ProdItem> {
        val (withDate, noDate) = rows.partition { key(it) != null }
        val sorted = if (sortAsc) withDate.sortedBy { key(it) } else withDate.sortedByDescending { key(it) }
        return sorted + noDate
    }

    /** Natural order, tidak peka huruf besar/kecil: "AG2" < "AG10", "00123" == "123". */
    private fun naturalCompare(a: String, b: String): Int {
        var i = 0
        var j = 0
        while (i < a.length && j < b.length) {
            val ca = a[i]
            val cb = b[j]
            if (ca.isDigit() && cb.isDigit()) {
                var si = i; while (si < a.length && a[si] == '0') si++
                var sj = j; while (sj < b.length && b[sj] == '0') sj++
                var ei = si; while (ei < a.length && a[ei].isDigit()) ei++
                var ej = sj; while (ej < b.length && b[ej].isDigit()) ej++
                val la = ei - si
                val lb = ej - sj
                if (la != lb) return la.compareTo(lb)
                val c = a.substring(si, ei).compareTo(b.substring(sj, ej))
                if (c != 0) return c
                i = ei
                j = ej
            } else {
                val c = ca.lowercaseChar().compareTo(cb.lowercaseChar())
                if (c != 0) return c
                i++
                j++
            }
        }
        return (a.length - i).compareTo(b.length - j)
    }

    // ── Load & classify ───────────────────────────────────────────────────
    private fun loadData() {
        lifecycleScope.launch {
            val (items, lists) = withContext(Dispatchers.IO) {
                skuOrder = loadSkuOrderFile()
                shelfEdits = loadShelfEdits()
                val deduped = dedupBySku(db.getAllCatalogRows())
                deduped to computeSpecialLists(deduped)
            }
            allItems = items
            special  = lists
            classifyAndRender()
        }
    }

    /**
     * Dedup berdasarkan SKU (sama seperti cd_deduplicate_by_sku di ProdMast.py).
     * Berbeda dari versi lama yang dedup by desc — per Python logic, dedup by SKU.
     */
    private fun dedupBySku(catalog: List<CatalogRow>): List<ProdItem> {
        val seen = LinkedHashSet<String>()
        val result = mutableListOf<ProdItem>()
        for (row in catalog) {
            if (seen.add(row.sku)) result.add(toProdItem(row))
        }
        return result
    }

    private fun toProdItem(row: CatalogRow): ProdItem {
        val bal = row.balance.trim().replace(",", ".").toDoubleOrNull() ?: 0.0
        return ProdItem(
            sku = row.sku, shelf = row.shelf, desc = row.desc,
            price = row.price, discount = row.discount,
            discStart = row.discStart, discEnd = row.discEnd,
            balanceNum = bal,
            endDateMillis   = parseDate(row.discEnd),
            startDateMillis = parseDate(row.discStart),
            masterRack = row.masterRack,
            keepStock = row.keepStock
        )
    }

    private fun parseDate(s: String): Long? {
        val str = s.trim()
        if (str.isEmpty() || str == "-") return null
        for (fmt in dateFormats) {
            try {
                val sdf = SimpleDateFormat(fmt, Locale.US); sdf.isLenient = false
                return sdf.parse(str)?.time
            } catch (_: Exception) {}
        }
        return null
    }

    private fun classifyAndRender() {
        val filterBal = chkBalancePositive.isChecked
        val base = if (filterBal) allItems.filter { it.balanceNum > 0 } else allItems
        val now  = System.currentTimeMillis()
        val active = mutableListOf<ProdItem>()
        val expired= mutableListOf<ProdItem>()
        for (item in base) {
            val end = item.endDateMillis
            if (end == null) { expired.add(item) }
            else {
                if (end + END_OF_DAY_MS >= now) active.add(item)
                else expired.add(item)
            }
        }
        activeItems  = active
        expiredItems = expired
        updateTabLabels()
        renderCurrentTab()
    }

    private fun updateSummary() {
        tvSummary.text = "Total: ${allItems.size}   |   Active: ${activeItems.size}   |   " +
            "Expired: ${expiredItems.size}   |   Balance=0: ${allItems.count { it.balanceNum <= 0 }}" +
            "   |   Tampil: ${displayedRows.size}"
    }

    private fun renderCurrentTab() {
        var rows = sourceFor(currentTab)
        val q = etSearch.text.toString().trim()
        if (q.isNotEmpty()) rows = rows.filter { it.sku.contains(q, ignoreCase = true) }
        displayedRows = sortRows(rows)
        adapter.notifyDataSetChanged()
        tvEmpty.text = when {
            allItems.isEmpty() -> "No data yet. Make sure catalog data (02) has been downloaded, then tap REFRESH."
            q.isNotEmpty()     -> "SKU \"$q\" tidak ditemukan di tab ${currentTab.label}."
            else               -> "Tidak ada item di tab ${currentTab.label}."
        }
        tvEmpty.visibility    = if (displayedRows.isEmpty()) View.VISIBLE else View.GONE
        lvDiscount.visibility = if (displayedRows.isEmpty()) View.GONE    else View.VISIBLE
        updateBottomBar()
        updateSummary()
    }

    // ── Special lists (logic dari ProdMast.py / CheckDisc) ────────────────

    /**
     * Hitung PRICE CHANGE, PRICE ADJUSTMENT, CHANGE DESCRIPTION, NO SHELF,
     * QTY MINUS — mengikuti stage_checkdisc di ProdMast.py (aturan balance > 0
     * berlaku tetap, tidak tergantung checkbox "Balance > 0"; QTY MINUS justru
     * mencari balance < 0). HARUS dipanggil dari background thread.
     */
    private fun computeSpecialLists(items: List<ProdItem>): SpecialLists {
        if (items.isEmpty()) return SpecialLists.EMPTY
        val eligible = items.filter { it.balanceNum > 0 }

        // ── Price & Desc change (cd_check_data_changes) ───────────────────
        val changes = loadOrComputeChanges(items)
        val bySku = items.associateBy { it.sku }
        val priceInc = changes.inc.keys.mapNotNull { bySku[it] }
        val priceDec = changes.dec.keys.mapNotNull { bySku[it] }
        val descChange = changes.desc.keys.mapNotNull { bySku[it] }
        val oldPrice = HashMap<String, Double>().apply { putAll(changes.inc); putAll(changes.dec) }

        // ── NO SHELF (cd_export_shelf_kosong) ─────────────────────────────
        val noShelfBase = eligible.filter { isShelfEmpty(it.shelf) }
        pruneShelfEdits(items)
        val noShelf = overlayShelfEdits(noShelfBase)

        // ── QTY MINUS (cd_export_qty_minus) ───────────────────────────────
        val qtyMinus = items.filter { it.balanceNum < 0 }

        // ── PRICE ADJUSTMENT (cd_export_price_adjustment) ─────────────────
        val now = System.currentTimeMillis()
        // a) baru berakhir (<= EXPIRED_LOOKBACK_DAYS hari yang lalu)
        val recentExpired = eligible.filter { item ->
            val end = item.endDateMillis ?: return@filter false
            val endOfDay = end + END_OF_DAY_MS
            endOfDay < now && (now - endOfDay) < EXPIRED_LOOKBACK_DAYS * DAY_MS
        }
        // b) baru mulai (cd_get_recent_start_items: start <= akhir hari ini DAN < lookback hari)
        val todayEnd = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59)
            set(Calendar.SECOND, 59); set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        val recentStart = eligible.filter { item ->
            val st = item.startDateMillis ?: return@filter false
            st <= todayEnd && (now - st) < START_LOOKBACK_DAYS * DAY_MS
        }
        val adjMap = LinkedHashMap<String, ProdItem>()
        recentExpired.forEach { adjMap[it.sku] = it }
        recentStart.forEach   { adjMap.putIfAbsent(it.sku, it) }

        return SpecialLists(
            priceChange     = sortByShelf(priceInc + priceDec),
            priceAdjustment = sortByShelf(adjMap.values.toList()),
            descChange      = sortByShelf(descChange),
            noShelf         = noShelf,
            qtyMinus        = sortByShelf(qtyMinus),
            oldPrice        = oldPrice,
            oldDesc         = changes.desc,
            noShelfBase     = noShelfBase
        )
    }

    /**
     * Bandingkan katalog sekarang dengan snapshot sebelumnya (cd_check_data_changes).
     * Snapshot di-update SEKALI per download katalog (dikunci pakai
     * catalogUpdatedTime) dan hasil perbandingannya di-cache, sehingga
     * membuka layar / REFRESH berulang kali tidak "menghabiskan" daftar
     * perubahan dan daftar di tab tetap konsisten dengan hasil export.
     */
    private fun loadOrComputeChanges(items: List<ProdItem>): ChangeSet {
        val stamp = catalogUpdatedTime
        readChangesCache(stamp)?.let { return it }

        val oldHistory = loadPriceHistory()
        val newHistory = mutableMapOf<String, JSONObject>()
        val inc  = LinkedHashMap<String, Double>()
        val dec  = LinkedHashMap<String, Double>()
        val desc = LinkedHashMap<String, String>()

        for (item in items) {
            val newPrice = parsePrice(item.price)
            val newDesc  = item.desc.trim()
            newHistory[item.sku] = JSONObject().put("price", newPrice).put("desc", newDesc)

            val old = oldHistory[item.sku] ?: continue
            val oldPrice = if (old.has("price") && !old.isNull("price"))
                old.optDouble("price", Double.NaN) else Double.NaN
            val oldDesc  = old.optString("desc", "")
            val eligible = item.balanceNum > 0

            if (eligible && !oldPrice.isNaN() && newPrice != oldPrice) {
                if (newPrice > oldPrice) inc[item.sku] = oldPrice else dec[item.sku] = oldPrice
            }
            if (eligible && oldDesc.isNotEmpty() && newDesc != oldDesc) {
                desc[item.sku] = oldDesc
            }
        }
        savePriceHistory(newHistory)
        val result = ChangeSet(inc, dec, desc)
        writeChangesCache(stamp, result)
        return result
    }

    /** cd_parse_price: koma → titik, dibulatkan 2 desimal. */
    private fun parsePrice(s: String): Double {
        val v = s.trim().replace(",", ".").toDoubleOrNull() ?: return 0.0
        return Math.round(v * 100.0) / 100.0
    }

    /** Shelf kosong = "", "-", "0", atau string yang seluruhnya digit
     *  (sama seperti cd_is_shelf_kosong di ProdMast.py). */
    private fun isShelfEmpty(shelf: String): Boolean {
        val v = shelf.trim()
        return v.isEmpty() || v == "-" || v == "0" || v.all { it.isDigit() }
    }

    /**
     * Port cd_sort_by_shelf (ProdMast.py): urut shelf A→Z, lalu — kalau
     * SKU_ORDER.csv sudah di-upload — urut NomorUrut SKU di dalam shelf itu.
     * SKU tanpa nomor urut ditaruh paling akhir di shelf-nya (sort stabil).
     * Tanpa file SKU_ORDER → hanya urut shelf. Dipakai SEMUA export.
     */
    private fun sortByShelf(data: List<ProdItem>): List<ProdItem> {
        val order = skuOrder
        return data.sortedWith(compareBy<ProdItem>(
            { it.shelf.trim().lowercase() },
            { order[orderKey(it.shelf, it.sku)] ?: Double.POSITIVE_INFINITY }
        ))
    }

    private fun orderKey(shelf: String, sku: String) = "${shelf.trim().lowercase()}|${sku.trim()}"

    private fun fmtNum(d: Double): String =
        if (d == Math.floor(d) && Math.abs(d) < 1e15) d.toLong().toString() else d.toString()

    // ── Price history & cache hasil perubahan (JSON di filesDir) ──────────

    private fun historyFile() = File(filesDir, "product_master_history.json")
    private fun changesFile() = File(filesDir, "product_master_changes.json")

    private fun loadPriceHistory(): Map<String, JSONObject> {
        val f = historyFile()
        if (!f.exists()) return emptyMap()
        return runCatching {
            val root = JSONObject(f.readText())
            buildMap { root.keys().forEach { k -> put(k, root.getJSONObject(k)) } }
        }.getOrDefault(emptyMap())
    }

    private fun savePriceHistory(map: Map<String, JSONObject>) {
        runCatching {
            val root = JSONObject()
            map.forEach { (k, v) -> root.put(k, v) }
            historyFile().writeText(root.toString())
        }
    }

    private fun readChangesCache(stamp: Long): ChangeSet? {
        val f = changesFile()
        if (!f.exists()) return null
        return runCatching {
            val root = JSONObject(f.readText())
            if (root.optLong("stamp", -1L) != stamp) return@runCatching null
            fun numMap(name: String): Map<String, Double> {
                val o = root.optJSONObject(name) ?: return emptyMap()
                val m = LinkedHashMap<String, Double>()
                o.keys().forEach { k -> m[k] = o.optDouble(k, 0.0) }
                return m
            }
            val descObj = root.optJSONObject("desc")
            val desc = LinkedHashMap<String, String>()
            descObj?.keys()?.forEach { k -> desc[k] = descObj.optString(k, "") }
            ChangeSet(numMap("inc"), numMap("dec"), desc)
        }.getOrNull()
    }

    private fun writeChangesCache(stamp: Long, cs: ChangeSet) {
        runCatching {
            val root = JSONObject().put("stamp", stamp)
            root.put("inc",  JSONObject().also { o -> cs.inc.forEach  { (k, v) -> o.put(k, v) } })
            root.put("dec",  JSONObject().also { o -> cs.dec.forEach  { (k, v) -> o.put(k, v) } })
            root.put("desc", JSONObject().also { o -> cs.desc.forEach { (k, v) -> o.put(k, v) } })
            changesFile().writeText(root.toString())
        }
    }

    // ── Export menu ───────────────────────────────────────────────────────

    /**
     * Tampilkan menu pilihan export (5 output sesuai CheckDisc di ProdMast.py).
     * Memakai daftar yang SUDAH dihitung saat load (tidak menghitung ulang,
     * jadi snapshot harga/deskripsi tidak ikut tertimpa).
     */
    private fun showExportMenu() {
        if (allItems.isEmpty()) {
            toast("Data kosong. Tap REFRESH dahulu."); return
        }
        val s = special
        val entries = mutableListOf<Pair<String, () -> Unit>>()
        entries += "PRICE CHANGE         (${s.priceChange.size} item)" to
            { runExport("PRICE CHANGE", s.priceChange) }
        entries += "CHANGE DESCRIPTION   (${s.descChange.size} item)" to
            { runExport("CHANGE DESCRIPTION", s.descChange) }
        entries += "NO SHELF             (${s.noShelf.size} item)" to
            { runExport("NO SHELF", s.noShelf) }
        entries += "QTY MINUS            (${s.qtyMinus.size} item)" to
            { runExport("QTY MINUS", s.qtyMinus) { "${it.sku},${fmtQty(it.balanceNum)}" } }
        entries += "PRICE ADJUSTMENT     (${s.priceAdjustment.size} item)" to
            { runExport("PRICE ADJUSTMENT", s.priceAdjustment) }
        entries += "ACTIVE DISCOUNTS     (${activeItems.size} item) — pilih tanggal" to
            { showDateExportDialog(isActive = true) }
        entries += "EXPIRED DISCOUNTS    (${expiredItems.size} item) — pilih tanggal" to
            { showDateExportDialog(isActive = false) }
        val orderInfo = if (skuOrder.isEmpty()) "belum ada — urut shelf saja" else "aktif: ${skuOrder.size} SKU"
        entries += "📂 UPLOAD SKU ORDER (CSV)  [$orderInfo]" to
            { pickSkuOrder.launch("*/*") }
        if (skuOrder.isNotEmpty()) {
            entries += "🗑 HAPUS SKU ORDER" to { deleteSkuOrder() }
        }
        AlertDialog.Builder(this)
            .setTitle("Export Output (urut shelf A→Z)")
            .setItems(entries.map { it.first }.toTypedArray()) { _, which -> entries[which].second() }
            .setNegativeButton("Batal", null)
            .show()
    }

    // ── Export ACTIVE / EXPIRED DISCOUNTS per tanggal end discount ────────

    /**
     * Pilih tanggal End Discount. Daftar dimulai dari tanggal yang PALING DEKAT
     * dengan hari ini (ACTIVE: hari ini → ke depan; EXPIRED: kemarin → ke
     * belakang) dan tanggal terdekat langsung tercentang. Item tanpa tanggal
     * (hanya ada di EXPIRED) ditaruh paling bawah.
     */
    private fun showDateExportDialog(isActive: Boolean) {
        val src = if (isActive) activeItems else expiredItems
        val title = if (isActive) "ACTIVE DISCOUNTS" else "EXPIRED DISCOUNTS"
        if (src.isEmpty()) { toast("$title: tidak ada item."); return }

        val groups = src.groupBy { it.endDateMillis }
        val dated = groups.keys.filterNotNull()
            .let { if (isActive) it.sorted() else it.sortedDescending() }
        val keys: List<Long?> = dated.toMutableList<Long?>().apply { if (groups.containsKey(null)) add(null) }

        val fmt = SimpleDateFormat("dd/MM/yyyy", Locale.US)
        val todayStart = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        val labels = keys.map { k ->
            val n = groups[k]?.size ?: 0
            if (k == null) "Tanpa tanggal   ($n item)"
            else {
                val diff = Math.round((k - todayStart).toDouble() / DAY_MS).toInt()
                val rel = when {
                    diff == 0 -> "hari ini"
                    diff == 1 -> "besok"
                    diff == -1 -> "kemarin"
                    diff > 0 -> "$diff hari lagi"
                    else -> "${-diff} hari lalu"
                }
                "${fmt.format(Date(k))}  •  $rel   ($n item)"
            }
        }.toTypedArray()

        val checked = BooleanArray(keys.size).also { it[0] = true }  // terdekat langsung dipilih
        val dlg = AlertDialog.Builder(this)
            .setTitle("Export $title — pilih tanggal End")
            .setMultiChoiceItems(labels, checked) { _, which, isChecked -> checked[which] = isChecked }
            .setPositiveButton("EXPORT", null)
            .setNeutralButton("PILIH SEMUA", null)
            .setNegativeButton("Batal", null)
            .create()
        dlg.show()
        // Neutral: toggle semua tanpa menutup dialog
        dlg.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
            val selectAll = checked.any { !it }
            for (i in checked.indices) { checked[i] = selectAll; dlg.listView.setItemChecked(i, selectAll) }
        }
        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val picked = keys.indices.filter { checked[it] }
            if (picked.isEmpty()) { toast("Pilih minimal 1 tanggal."); return@setOnClickListener }
            val items = sortByShelf(picked.flatMap { groups[keys[it]] ?: emptyList() })
            // 1 tanggal saja → tanggalnya ikut di nama file supaya tidak saling menimpa.
            val label = if (picked.size == 1 && keys[picked[0]] != null)
                "$title END ${SimpleDateFormat("dd-MM-yyyy", Locale.US).format(Date(keys[picked[0]]!!))}"
            else title
            dlg.dismiss()
            runExport(label, items)
        }
    }

    // ── Edit shelf (tab NO SHELF) ─────────────────────────────────────────

    private fun showEditShelfDialog(item: ProdItem) {
        val et = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS or
                InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            setSingleLine(true)
            hint = "Shelf baru, mis. AG04-01"
            setText(shelfEdits[item.sku] ?: "")
            setSelection(text.length)
        }
        val box = android.widget.FrameLayout(this).apply {
            val pad = (20 * resources.displayMetrics.density).toInt()
            setPadding(pad, 8, pad, 0); addView(et)
        }
        val b = AlertDialog.Builder(this)
            .setTitle("Edit Shelf — ${item.sku}")
            .setMessage(item.desc)
            .setView(box)
            .setPositiveButton("Simpan") { _, _ ->
                val v = et.text.toString().trim().uppercase()
                if (v.isEmpty()) shelfEdits.remove(item.sku) else shelfEdits[item.sku] = v
                afterShelfEditChanged()
            }
            .setNegativeButton("Batal", null)
        if (shelfEdits.containsKey(item.sku)) {
            b.setNeutralButton("Hapus edit") { _, _ ->
                shelfEdits.remove(item.sku)
                afterShelfEditChanged()
            }
        }
        b.show()
    }

    /** Simpan edit ke file, susun ulang daftar NO SHELF (urut shelf + SKU order), render ulang. */
    private fun afterShelfEditChanged() {
        saveShelfEdits()
        special = special.copy(noShelf = overlayShelfEdits(special.noShelfBase))
        updateTabLabels()
        renderCurrentTab()
    }

    private fun overlayShelfEdits(base: List<ProdItem>): List<ProdItem> = sortByShelf(
        base.map { item -> shelfEdits[item.sku]?.let { item.copy(shelf = it) } ?: item }
    )

    private fun editedItems(): List<ProdItem> = special.noShelf.filter { shelfEdits.containsKey(it.sku) }

    private fun updateBottomBar() {
        val show = currentTab == Tab.NO_SHELF
        bottomBarShelfEdit.visibility = if (show) View.VISIBLE else View.GONE
        if (!show) return
        val n = editedItems().size
        btnExportShelfEdits.text = "EXPORT HASIL EDIT ($n)"
        btnExportShelfEdits.alpha = if (n == 0) 0.5f else 1f
        tvShelfEditInfo.text = if (n == 0) "Tap item untuk edit shelf" else "$n SKU sudah diedit shelf-nya"
    }

    /**
     * Export hasil edit shelf → 2 file sekaligus (urut shelf A→Z + SKU order):
     *  1. "PRINT NO SHELF (tanggal).txt"    → "SKU,1"
     *  2. "EXCEL IN NO SHELF (tanggal).txt" → "SHELF,SKU"
     */
    private fun exportShelfEdits() {
        val items = editedItems()
        if (items.isEmpty()) { toast("Belum ada shelf yang diedit."); return }
        val today = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(Date())
        val printName = "PRINT NO SHELF ($today).txt"
        val excelName = "EXCEL IN NO SHELF ($today).txt"
        val printContent = items.joinToString("\n") { "${it.sku},1" }
        val excelContent = items.joinToString("\n") { "${it.shelf},${it.sku}" }

        lifecycleScope.launch {
            try {
                val (p1, p2) = withContext(Dispatchers.IO) {
                    val a = OutputWriter.write(this@ProductMasterActivity, printName, printContent, OutputModule.PRODUCT_MASTER)
                    val b = OutputWriter.write(this@ProductMasterActivity, excelName, excelContent, OutputModule.PRODUCT_MASTER)
                    a to b
                }
                toast("NO SHELF EDIT — ${items.size} item(s)\n$printName\n$p1\n\n$excelName\n$p2")
            } catch (e: Exception) {
                toast("Export gagal: ${e.message}")
            }
        }
    }

    /** Buang edit yang sudah tidak relevan (SKU hilang / shelf di master sudah terisi). */
    private fun pruneShelfEdits(items: List<ProdItem>) {
        if (shelfEdits.isEmpty()) return
        val bySku = items.associateBy { it.sku }
        val before = shelfEdits.size
        shelfEdits.keys.retainAll { sku -> bySku[sku]?.let { isShelfEmpty(it.shelf) } ?: false }
        if (shelfEdits.size != before) saveShelfEdits()
    }

    private fun shelfEditsFile() = File(filesDir, "product_master_shelf_edits.json")

    private fun loadShelfEdits(): MutableMap<String, String> {
        val f = shelfEditsFile()
        val m = LinkedHashMap<String, String>()
        if (!f.exists()) return m
        runCatching {
            val root = JSONObject(f.readText())
            root.keys().forEach { k -> root.optString(k, "").takeIf { it.isNotBlank() }?.let { m[k] = it } }
        }
        return m
    }

    private fun saveShelfEdits() {
        runCatching {
            val root = JSONObject()
            shelfEdits.forEach { (k, v) -> root.put(k, v) }
            shelfEditsFile().writeText(root.toString())
        }
    }

    // ── SKU_ORDER.csv (upload manual) ─────────────────────────────────────

    private fun skuOrderFile() = File(filesDir, "SKU_ORDER.csv")

    private fun loadSkuOrderFile(): Map<String, Double> {
        val f = skuOrderFile()
        if (!f.exists()) return emptyMap()
        return runCatching { parseSkuOrder(f.readText(Charsets.UTF_8)) }.getOrDefault(emptyMap())
    }

    /**
     * Port cd_load_sku_order: baris "Shelf,SKU,NomorUrut". Baris header / SKU kosong /
     * NomorUrut kosong atau bukan angka dilewati (SKU itu = tanpa nomor urut).
     * Pemisah ',' (atau ';' kalau file memakai titik-koma), mendukung tanda kutip & BOM.
     */
    private fun parseSkuOrder(text: String): Map<String, Double> {
        val clean = text.removePrefix("\uFEFF")
        val lines = clean.lineSequence().filter { it.isNotBlank() }.toList()
        if (lines.isEmpty()) return emptyMap()
        val sep = if (lines[0].contains(';') && !lines[0].contains(',')) ';' else ','
        val map = LinkedHashMap<String, Double>()
        for (line in lines) {
            val row = splitCsvLine(line.trimEnd('\r', '\n'), sep)
            if (row.size < 2) continue
            val shelf = row[0].trim()
            val sku = row[1].trim()
            if (sku.isEmpty() || sku.equals("sku", ignoreCase = true)) continue
            val orderRaw = if (row.size >= 3) row[2].trim() else ""
            if (orderRaw.isEmpty()) continue
            val order = orderRaw.replace(",", ".").toDoubleOrNull() ?: continue
            map[orderKey(shelf, sku)] = order
        }
        return map
    }

    private fun splitCsvLine(line: String, sep: Char): List<String> {
        val out = ArrayList<String>()
        val cur = StringBuilder()
        var inQuote = false
        var i = 0
        while (i < line.length) {
            val c = line[i]
            when {
                c == '"' && inQuote && i + 1 < line.length && line[i + 1] == '"' -> { cur.append('"'); i++ }
                c == '"' -> inQuote = !inQuote
                c == sep && !inQuote -> { out.add(cur.toString()); cur.setLength(0) }
                else -> cur.append(c)
            }
            i++
        }
        out.add(cur.toString())
        return out
    }

    private fun importSkuOrder(uri: Uri) {
        lifecycleScope.launch {
            try {
                val (text, parsed) = withContext(Dispatchers.IO) {
                    val t = contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) }
                        ?: throw Exception("File tidak bisa dibuka")
                    t to parseSkuOrder(t)
                }
                if (parsed.isEmpty()) {
                    toast("SKU ORDER tidak valid / kosong.\nFormat: Shelf,SKU,NomorUrut (satu baris per SKU).")
                    return@launch
                }
                withContext(Dispatchers.IO) { skuOrderFile().writeText(text, Charsets.UTF_8) }
                toast("SKU ORDER dimuat: ${parsed.size} SKU punya nomor urut.")
                loadData()   // hitung ulang urutan semua daftar
            } catch (e: Exception) {
                toast("Upload SKU ORDER gagal: ${e.message}")
            }
        }
    }

    private fun deleteSkuOrder() {
        AlertDialog.Builder(this)
            .setTitle("Hapus SKU ORDER?")
            .setMessage("Export akan kembali diurutkan berdasarkan shelf saja.")
            .setPositiveButton("Hapus") { _, _ ->
                skuOrderFile().delete()
                toast("SKU ORDER dihapus.")
                loadData()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    /** Qty positif (abs) — bulat tanpa desimal, sama seperti cd_export_qty_minus. */
    private fun fmtQty(balance: Double): String = fmtNum(Math.abs(balance))

    // ── Perform export ────────────────────────────────────────────────────
    private fun runExport(
        label: String,
        items: List<ProdItem>,
        line: (ProdItem) -> String = { "${it.sku},1" }
    ) {
        if (items.isEmpty()) {
            toast("$label: tidak ada item untuk di-export."); return
        }
        val today = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(Date())
        val fileName = "$label ($today).txt"
        val content  = items.joinToString("\n") { line(it) }

        lifecycleScope.launch {
            try {
                val path = withContext(Dispatchers.IO) {
                    OutputWriter.write(this@ProductMasterActivity, fileName, content, OutputModule.PRODUCT_MASTER)
                }
                toast("$label\n${items.size} item(s)\n$path")
            } catch (e: Exception) {
                toast("Export gagal: ${e.message}")
            }
        }
    }

    // ── SMB settings dialog ───────────────────────────────────────────────
    private fun showSmbOutputSettingsDialog() {
        val et = EditText(this).apply {
            setText(smbUploadPathExpiredDiscount)
            hint = "smb://HOSTNAME/share/subfolder"
        }
        val container = android.widget.FrameLayout(this).apply {
            val pad = (16 * resources.displayMetrics.density).toInt()
            setPadding(pad, 8, pad, 0); addView(et)
        }
        AlertDialog.Builder(this)
            .setTitle("SMB Output Settings — Product Master")
            .setMessage("Folder SMB tujuan export khusus menu ini. Kosongkan untuk pakai path dari Settings global.")
            .setView(container)
            .setPositiveButton("Simpan") { _, _ ->
                smbUploadPathExpiredDiscount = et.text.toString().trim()
                toast("SMB Output setting saved")
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
