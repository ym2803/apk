package com.tms.qubeapps.qubedatacollector

import android.app.AlertDialog
import android.database.Cursor
import android.net.Uri
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.lifecycleScope
import com.tms.qubeapps.qubedatacollector.Prefs.dcMode
import com.tms.qubeapps.qubedatacollector.Prefs.dcScanMethod
import com.tms.qubeapps.qubedatacollector.Prefs.fileFormat
import com.tms.qubeapps.qubedatacollector.Prefs.smbUploadPathDataCollector
import com.tms.qubeapps.qubedatacollector.Prefs.ksWebAppUrl
import com.tms.qubeapps.qubedatacollector.Prefs.ksApiToken
import com.tms.qubeapps.qubedatacollector.Prefs.ksLastStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * ★ FIX (baru — Menu 4: Data Collector).
 *
 * Layar generik untuk mencatat data lapangan lewat scan HID/kamera, dengan
 * 2 mode kerja (pengganti fungsi lama "Menu QTY"):
 *  - Shelf Record : cuma Shelf + Scan Code (TANPA Qty).
 *  - Stock Take   : Shelf + Scan Code + Qty (proses stock opname).
 *
 * 2 metode input:
 *  - Manual     : user isi/pilih Shelf dulu, fokus pindah ke Scan Code,
 *                 tiap barcode discan langsung tersimpan (Auto Enter),
 *                 fokus balik ke Scan Code untuk scan berikutnya.
 *  - Auto Detect: SATU field scan (Scan Code) dipakai untuk SEMUA input —
 *                 kalau hasil scan mengandung huruf dianggap Shelf baru,
 *                 kalau cuma angka dianggap Scan Code dan langsung disimpan.
 *
 * Output TXT (dibuat saat Upload to PC ditekan):
 *  - Mode Shelf Record : setiap baris "Shelf,ScanCode"
 *  - Mode Stock Take   : setiap baris "Shelf,ScanCode,Qty"
 *  Nama file: <FileFormat>_<ModeCode>_<YYYYMMDD>_<HHMMSS>.txt
 *  - <FileFormat> diambil dari isian "File Format" di menu Setting (default "YM").
 *  - <ModeCode> tetap (bukan Store Code isian user): 05 untuk Shelf Record,
 *    04 untuk Stock Take / add box.
 */
class DataCollectorActivity : BaseScanner() {

    private lateinit var db: AppDatabase
    private lateinit var etShelf: EditText
    private lateinit var etScanCode: EditText
    private lateinit var etQty: EditText
    private lateinit var rowQty: View
    private lateinit var rowScanCode: View
    private lateinit var rowAutoDetect: View
    private lateinit var btnModeShelfRecord: TextView
    private lateinit var btnModeStockTake: TextView
    private lateinit var switchAutoDetect: android.widget.Switch
    private lateinit var lvRecords: ListView
    private lateinit var tvDcCount: TextView
    private lateinit var tvDcEmpty: TextView
    private lateinit var adapter: BaseAdapter
    private lateinit var btnUploadToKs: View
    private lateinit var btnCompareStock: View
    private lateinit var btnImportFromHistory: View

    // Baris [_id, shelf, scanCode, qty, mode, time, uploaded]
    // ★ FIX: data record SHELF_RECORD & STOCK_TAKE disimpan/ditampilkan
    // terpisah per mode (tidak digabung) — daftar penuh tetap disimpan di
    // DB (rowsAll), tapi yang dirender ke adapter cuma yang sesuai mode aktif.
    private val rowsAll = mutableListOf<Array<String>>()
    private val rows = mutableListOf<Array<String>>()

    private val onlyLettersRegex = Regex(".*[A-Za-z].*")

    // ★ FIX (baru — #2): deteksi hasil scan berformat link/URL atau konten QR
    // umum lainnya (bukan kode Shelf biasa) — dipakai KHUSUS di mode Shelf
    // Record (Auto maupun Manual) supaya link/QR tidak ikut kesimpan sebagai
    // Shelf. Mencakup URL berskema (http/https/www/ftp) dan skema QR umum
    // lain (mailto/tel/sms/geo/wifi/market/intent/vCard), plus pola
    // "domain.tld" tanpa skema eksplisit.
    private val linkOrQrRegex = Regex(
        "^(https?://|www\\.|ftp://|mailto:|tel:|sms(to)?:|geo:|wifi:|market:|intent:|BEGIN:VCARD)",
        RegexOption.IGNORE_CASE
    )
    private val domainLikeRegex = Regex("^[\\w-]+\\.[A-Za-z]{2,}(/\\S*)?$")

    private fun isLinkOrQrFormat(value: String): Boolean {
        val v = value.trim()
        if (v.isEmpty()) return false
        if (linkOrQrRegex.containsMatchIn(v)) return true
        if (domainLikeRegex.matches(v)) return true
        return false
    }

    // ── Import from TXT file ────────────────────────────────────────────
    /** ★ FIX (baru): Import data lewat file .txt, mengikuti mode kerja yang
     *  sedang aktif SAAT file dipilih:
     *  - Shelf Record       : tiap baris "Shelf,SKU"        (2 kolom)
     *    contoh: AG01-01,1234567
     *  - Stock Take/Add Box : tiap baris "Shelf,SKU,Qty"    (3 kolom)
     *    contoh: A001/AG01-01,1234567,100
     *  Baris yang tidak sesuai format (jumlah kolom salah, Shelf/SKU kosong,
     *  atau Qty bukan angka untuk Stock Take) dilewati (tidak disimpan) dan
     *  dilaporkan di dialog ringkasan sesudah proses selesai. */
    private val importFileLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            if (uri != null) importFromTxtFile(uri)
        }

    /** ★ FIX (baru): tampilkan format yang berlaku sesuai mode aktif SEBELUM
     *  membuka file picker, supaya user menyiapkan file .txt dengan format
     *  yang benar (jumlah baris besar/import massal jadi tidak sia-sia). */
    private fun showImportConfirmDialog() {
        val isStockTake = dcMode == "STOCK_TAKE"
        val modeLabel = if (isStockTake) "Stock Take/Add Box" else "Shelf Record"
        val formatDesc = if (isStockTake)
            "Shelf,SKU,Qty\nExample: A001/AG01-01,1234567,100"
        else
            "Shelf,SKU\nExample: AG01-01,1234567\n\n(3 columns also supported — first column ignored, e.g. S,AG01-01,1234567)"
        AlertDialog.Builder(this)
            .setTitle("Import File — $modeLabel")
            .setMessage("Select a .txt file with one record per line, format:\n\n$formatDesc")
            .setPositiveButton("Choose File") { _, _ -> importFileLauncher.launch("text/plain") }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun importFromTxtFile(uri: Uri) {
        val mode = dcMode
        val lines = try {
            contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readLines() }
                ?: emptyList()
        } catch (e: Exception) {
            AlertDialog.Builder(this)
                .setTitle("Import Failed")
                .setMessage("Unable to read the selected file.\n\n(${e.message})")
                .setPositiveButton("OK", null).show()
            return
        }

        var successCount = 0
        val failedLines = mutableListOf<String>()

        for ((idx, rawLine) in lines.withIndex()) {
            val line = rawLine.trim()
            if (line.isEmpty()) continue
            val cols = line.split(",").map { it.trim() }

            if (mode == "STOCK_TAKE") {
                // Format wajib: Shelf,SKU,Qty (3 kolom)
                if (cols.size != 3) {
                    failedLines.add("Line ${idx + 1}: \"$line\" (expected Shelf,SKU,Qty)")
                    continue
                }
                val (shelf, sku, qtyStr) = cols
                val qty = qtyStr.toIntOrNull()
                if (shelf.isEmpty() || sku.isEmpty() || qty == null || qty < 0) {
                    failedLines.add("Line ${idx + 1}: \"$line\" (Shelf/SKU empty or Qty is not a valid number)")
                    continue
                }
                db.insertDataCollect(shelf, sku, qty.toString(), mode)
                successCount++
            } else {
                // Mode Shelf Record — format wajib: Shelf,SKU (2 kolom).
                // ★ FIX (baru): dukung juga format 3 kolom "Prefix,Shelf,SKU"
                // (mis. "S,AG01-01,1234567") — kolom PERTAMA (kode/abjad
                // apa pun, mis. "S") DIABAIKAN, kolom kedua & ketiga dipakai
                // sebagai Shelf & SKU.
                val (shelf, sku) = when (cols.size) {
                    2 -> cols[0] to cols[1]
                    3 -> cols[1] to cols[2]
                    else -> {
                        failedLines.add("Line ${idx + 1}: \"$line\" (expected Shelf,SKU or Prefix,Shelf,SKU)")
                        continue
                    }
                }
                if (shelf.isEmpty() || sku.isEmpty()) {
                    failedLines.add("Line ${idx + 1}: \"$line\" (Shelf/SKU empty)")
                    continue
                }
                db.insertDataCollect(shelf, sku, "", mode)
                successCount++
            }
        }

        loadRecords()

        val modeLabel = if (mode == "STOCK_TAKE") "Stock Take/Add Box" else "Shelf Record"
        val summary = StringBuilder()
        summary.append("Mode: $modeLabel\n")
        summary.append("Imported: $successCount record(s)\n")
        summary.append("Failed: ${failedLines.size} line(s)")
        if (failedLines.isNotEmpty()) {
            summary.append("\n\n").append(failedLines.take(10).joinToString("\n"))
            if (failedLines.size > 10) summary.append("\n… and ${failedLines.size - 10} more")
        }

        AlertDialog.Builder(this)
            .setTitle("Import Result")
            .setMessage(summary.toString())
            .setPositiveButton("OK", null).show()
    }

    // ── Import from Stock Balance Check (History Scan) ─────────────────────
    /**
     * ★ FIX (baru): tarik data langsung dari menu "Stock Balance Check" >
     * History Scan (tabel Price, diisi lewat scan di layar itu) ke daftar
     * mode kerja yang SEDANG AKTIF (dcMode) — TANPA perlu scan ulang.
     *  - Mode Stock Take/Add Box : ambil Shelf + SKU + Qty (Qty = HASIL SCAN,
     *    dijumlahkan per Shelf+SKU kalau SKU yang sama discan berkali-kali).
     *  - Mode Shelf Record       : HANYA ambil kolom 1 (Shelf) & kolom 2
     *    (SKU) dari History Scan — Qty sengaja DIABAIKAN karena Shelf Record
     *    memang tidak punya kolom Qty. Contoh data yang diambil: "AG01-01,1234567".
     * Data ditambahkan (append) ke list mode aktif yang sudah ada — kalau
     * dijalankan 2x, baris akan ikut ter-dobel (sama seperti Import File),
     * jadi dialog konfirmasi menyebutkan ini dengan jelas.
     */
    private fun showImportFromHistoryDialog() {
        lifecycleScope.launch {
            val groups = withContext(Dispatchers.IO) { db.getPriceHistoryGrouped() }
            val isStockTake = dcMode == "STOCK_TAKE"
            val modeLabel = if (isStockTake) "Stock Take/Add Box" else "Shelf Record"
            if (groups.isEmpty()) {
                AlertDialog.Builder(this@DataCollectorActivity)
                    .setTitle("Import from History Scan")
                    .setMessage("No History Scan data yet. Scan some items in \"Stock Balance Check\" first.")
                    .setPositiveButton("OK", null).show()
                return@launch
            }
            val detailLine = if (isStockTake) {
                "Total Qty (from SCAN result, not system): ${groups.sumOf { it.qty }}"
            } else {
                // ★ FIX (baru — Shelf Record): Qty History Scan TIDAK relevan buat Shelf Record
                // (format wajib Shelf,SKU saja), jadi tidak ditampilkan di sini supaya tidak
                // menyesatkan — hanya kolom 1 (Shelf) & kolom 2 (SKU) yang akan diambil.
                "Only column 1 (Shelf) & column 2 (SKU) will be taken — Qty is ignored.\nExample: AG01-01,1234567"
            }
            AlertDialog.Builder(this@DataCollectorActivity)
                .setTitle("Import from History Scan — $modeLabel")
                .setMessage(
                    "Pull data from \"Stock Balance Check\" > History Scan into $modeLabel?\n\n" +
                        "Shelf+SKU groups: ${groups.size}\n" +
                        "$detailLine\n\n" +
                        "This will be ADDED to the current $modeLabel list " +
                        "(running this again will add the data again)."
                )
                .setPositiveButton("Import") { _, _ -> importFromHistory(groups) }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    private fun importFromHistory(groups: List<AppDatabase.PriceHistoryGroup>) {
        val mode = dcMode
        lifecycleScope.launch {
            val imported = withContext(Dispatchers.IO) {
                var count = 0
                groups.forEach { g ->
                    if (mode == "STOCK_TAKE") {
                        db.insertDataCollect(g.shelf, g.sku, g.qty.toString(), mode)
                    } else {
                        // ★ FIX (baru — Shelf Record): cuma kolom 1 (Shelf) & kolom 2 (SKU)
                        // yang diambil dari History Scan, Qty diabaikan (Shelf Record memang
                        // tidak punya kolom Qty) — sama seperti pola Import File di atas.
                        db.insertDataCollect(g.shelf, g.sku, "", mode)
                    }
                    count++
                }
                count
            }
            loadRecords()
            val modeLabel = if (mode == "STOCK_TAKE") "Stock Take/Add Box" else "Shelf Record"
            val detail = if (mode == "STOCK_TAKE") "qty from scan result" else "Shelf & SKU only, Qty ignored"
            Toast.makeText(
                this@DataCollectorActivity,
                "Imported $imported record(s) into $modeLabel from History Scan ($detail)",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_data_collector)
        db = AppDatabase(this)

        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<View>(R.id.btnSmbOutputSettings).setOnClickListener { showSmbOutputSettingsDialog() }
        findViewById<View>(R.id.btnImportFile).setOnClickListener { showImportConfirmDialog() }
        findViewById<View>(R.id.btnCompareStock).setOnClickListener {
            startActivity(android.content.Intent(this, StockTakeCompareActivity::class.java))
        }

        etShelf    = findViewById(R.id.etShelf)
        etScanCode = findViewById(R.id.etScanCode)
        etQty      = findViewById(R.id.etQty)
        rowQty     = findViewById(R.id.rowQty)
        rowScanCode = findViewById(R.id.rowScanCode)
        rowAutoDetect = findViewById(R.id.rowAutoDetect)
        btnModeShelfRecord = findViewById(R.id.btnModeShelfRecord)
        btnModeStockTake   = findViewById(R.id.btnModeStockTake)
        switchAutoDetect   = findViewById(R.id.switchAutoDetect)
        lvRecords  = findViewById(R.id.lvRecords)
        tvDcCount  = findViewById(R.id.tvDcCount)
        tvDcEmpty  = findViewById(R.id.tvDcEmpty)
        btnUploadToKs = findViewById(R.id.btnUploadToKs)
        btnCompareStock = findViewById(R.id.btnCompareStock)
        btnImportFromHistory = findViewById(R.id.btnImportFromHistory)
        // ★ FIX (crash — UninitializedPropertyAccessException): listener ini
        // HARUS dipasang SETELAH findViewById di atas, bukan sebelumnya —
        // sebelumnya dipasang duluan sebelum btnImportFromHistory di-assign,
        // jadi lateinit property-nya belum terisi saat diakses -> force close
        // setiap kali menu Data Collector dibuka.
        btnImportFromHistory.setOnClickListener { showImportFromHistoryDialog() }

        initScanner(findViewById(R.id.scannerView))
        findViewById<View>(R.id.btnCamera).setOnClickListener { toggleCamera() }

        // ★ FIX (baru): "Shelf Price Enquiry" — pintasan ke ShelfPriceEnquireActivity
        // (mode Enquire), dipindah kesini dari menu utama. TIDAK mengubah dcMode.
        findViewById<View>(R.id.btnShelfPriceEnquiry).setOnClickListener {
            startActivity(android.content.Intent(this, ShelfPriceEnquireActivity::class.java).apply {
                putExtra(ShelfPriceEnquireActivity.EXTRA_MODE, ShelfPriceEnquireActivity.MODE_ENQUIRE)
            })
        }
        btnModeShelfRecord.setOnClickListener { setMode("SHELF_RECORD") }
        btnModeStockTake.setOnClickListener { setMode("STOCK_TAKE") }
        // ★ FIX (baru): Auto Detect / Manual sekarang 1 toggle on/off (Switch).
        switchAutoDetect.setOnCheckedChangeListener { _, isChecked ->
            setScanMethod(if (isChecked) "AUTO" else "MANUAL")
        }

        // ★ FIX (baru — #2): setelah user isi/scan Shelf, fokus otomatis pindah
        // ke Scan Code TANPA perlu di-tap manual — dipanggil lewat .post{}
        // (bukan langsung) supaya tidak "kalah rebutan" fokus dengan proses IME
        // yang menutup keyboard setelah actionNext (ini pola yang sama persis
        // dipakai submitRecord() di bawah, yang sudah terbukti stabil). Ini
        // berlaku tiap kali Shelf BERUBAH/berpindah (mis. AG01-01 -> AG01-02),
        // termasuk kalau Shelf diisi lewat scan barcode (HID mengirim Enter,
        // yang pada EditText singleLine dgn imeOptions="actionNext" ditangkap
        // sebagai IME_ACTION_NEXT juga).
        etShelf.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_NEXT) {
                // ★ FIX (baru — #2): mode Shelf Record (Manual) — tolak Shelf
                // berformat link/URL atau QR umum lainnya.
                val shelfVal = etShelf.text.toString()
                if (dcMode == "SHELF_RECORD" && isLinkOrQrFormat(shelfVal)) {
                    Toast.makeText(this,
                        "Invalid Shelf: link/QR format is not allowed", Toast.LENGTH_SHORT).show()
                    etShelf.setText("")
                    etShelf.post { etShelf.requestFocus() }
                    return@setOnEditorActionListener true
                }
                // ★ FIX (baru — #3): mode Stock Take/Add Box — Scan Code & Qty
                // baru ditampilkan SETELAH Shelf terisi (progressive reveal).
                if (dcMode == "STOCK_TAKE") {
                    rowScanCode.visibility = View.VISIBLE
                    rowQty.visibility = View.VISIBLE
                }
                etScanCode.post { etScanCode.requestFocus() }
                true
            } else false
        }
        // ★ FIX (baru — #2): jaga-jaga scanner HID kirim raw KEYCODE_ENTER
        // (bukan lewat IME action) saat men-scan Shelf — sama pola dengan
        // etScanCode di bawah, supaya perpindahan Shelf -> Scan Code tetap
        // otomatis walau device scanner tertentu tidak memicu actionNext.
        etShelf.setOnKeyListener { _, keyCode, event ->
            if (event.action == KeyEvent.ACTION_DOWN &&
                (keyCode == KeyEvent.KEYCODE_ENTER || keyCode == KeyEvent.KEYCODE_TAB)) {
                val shelfVal = etShelf.text.toString()
                if (dcMode == "SHELF_RECORD" && isLinkOrQrFormat(shelfVal)) {
                    Toast.makeText(this,
                        "Invalid Shelf: link/QR format is not allowed", Toast.LENGTH_SHORT).show()
                    etShelf.setText("")
                    etShelf.post { etShelf.requestFocus() }
                    return@setOnKeyListener true
                }
                if (dcMode == "STOCK_TAKE") {
                    rowScanCode.visibility = View.VISIBLE
                    rowQty.visibility = View.VISIBLE
                }
                etScanCode.post { etScanCode.requestFocus() }
                true
            } else false
        }

        // ★ FIX: Scan Code — dipakai untuk Manual (khusus kode) MAUPUN Auto
        // Detect (kode ATAU shelf, dibedakan otomatis). Barcode scanner HID
        // mengirim teks lalu Enter, ditangkap di sini sebagai IME_ACTION_DONE
        // → "Auto Enter", user tidak perlu menekan tombol apa pun.
        etScanCode.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                handleScanInput(etScanCode.text.toString()); true
            } else false
        }
        // ★ FIX: jaga-jaga kalau scanner HID kirim raw KEYCODE_ENTER (bukan
        // lewat IME action) — beberapa scanner/keyboard eksternal begitu.
        etScanCode.setOnKeyListener { _, keyCode, event ->
            if (event.action == KeyEvent.ACTION_DOWN &&
                (keyCode == KeyEvent.KEYCODE_ENTER || keyCode == KeyEvent.KEYCODE_TAB)) {
                handleScanInput(etScanCode.text.toString()); true
            } else false
        }

        // ★ FIX (#2): Qty — setelah user mengisi Qty dan menekan Enter/Done
        // (baik lewat keyboard maupun scanner HID yang kirim Enter), baris
        // baru benar-benar disimpan di sini. submitRecord() akan menolak
        // (Toast + fokus balik ke Qty) kalau Qty masih kosong.
        etQty.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                submitRecord(etScanCode.text.toString()); true
            } else false
        }
        etQty.setOnKeyListener { _, keyCode, event ->
            if (event.action == KeyEvent.ACTION_DOWN &&
                (keyCode == KeyEvent.KEYCODE_ENTER || keyCode == KeyEvent.KEYCODE_TAB)) {
                submitRecord(etScanCode.text.toString()); true
            } else false
        }

        // Tombol ↵ di sebelah Qty — submit manual (dipakai kalau user isi
        // Scan Code & Qty lewat keyboard biasa tanpa menekan Enter/Done).
        // submitRecord() sendiri yang menjaga validasi Shelf/Scan Code/Qty.
        findViewById<View>(R.id.btnEnter).setOnClickListener {
            submitRecord(etScanCode.text.toString())
        }

        adapter = object : BaseAdapter() {
            override fun getCount() = rows.size
            override fun getItem(p: Int) = rows[p]
            override fun getItemId(p: Int) = p.toLong()
            override fun getView(pos: Int, convertView: View?, parent: ViewGroup): View {
                val v = convertView ?: layoutInflater.inflate(R.layout.item_data_collector_row, parent, false)
                val r = rows[pos]
                // ★ FIX: Shelf & Scan Code sekarang satu baris "[Shelf] ScanCode"
                v.findViewById<TextView>(R.id.tvDcShelfCode).text = "[${r[1]}] ${r[2]}"
                val tvQty = v.findViewById<TextView>(R.id.tvDcQty)
                if (r[4] == "STOCK_TAKE" && r[3].isNotBlank()) {
                    tvQty.visibility = View.VISIBLE
                    tvQty.text = r[3]
                } else {
                    tvQty.visibility = View.GONE
                }
                return v
            }
        }
        lvRecords.adapter = adapter

        // ★ FIX (baru): tap salah satu record → dialog konfirmasi hapus.
        // Hapus langsung dari list (UI) + DB, nomor urut & total otomatis
        // diperbarui, tanpa perlu refresh halaman.
        lvRecords.setOnItemClickListener { _, _, position, _ ->
            confirmDeleteRecord(position)
        }

        // ★ FIX (baru): tekan & tahan record → langsung edit Shelf, SKU, Qty.
        lvRecords.setOnItemLongClickListener { _, _, position, _ ->
            showEditRecordDialog(position)
            true
        }

        findViewById<View>(R.id.btnClearAll).setOnClickListener { confirmClearAll() }
        findViewById<View>(R.id.btnUploadToPc).setOnClickListener { showUploadChoiceDialog() }
        btnUploadToKs.setOnClickListener { showUploadToKsDialog() }

        setMode(dcMode, persist = false)
        setScanMethod(dcScanMethod, persist = false)
        loadRecords()

        // ★ FIX (samakan dgn Scan Process/SKU Code, disesuaikan #3): kalau mode
        // aktif Stock Take/Add Box dan Shelf masih kosong, fokus mulai dari
        // Shelf dulu (Scan Code & Qty belum tampil). Selain itu (Shelf Record,
        // atau Stock Take yang Shelf-nya sudah terisi), Scan Code langsung
        // standby seperti sebelumnya.
        if (dcMode == "STOCK_TAKE" && etShelf.text.toString().trim().isEmpty()) {
            etShelf.post { etShelf.requestFocus() }
        } else {
            etScanCode.post { etScanCode.requestFocus() }
        }
    }

    override fun onResume() {
        super.onResume()
        loadRecords()
        if (dcMode == "STOCK_TAKE" && etShelf.text.toString().trim().isEmpty()) {
            etShelf.requestFocus()
        } else {
            etScanCode.requestFocus()
        }
    }

    override fun onBarcodeScanned(barcode: String) {
        etScanCode.setText(barcode)
        handleScanInput(barcode)
    }

    // ── Mode Kerja & Metode Scan ─────────────────────────────────────────
    private fun setMode(mode: String, persist: Boolean = true) {
        if (persist) dcMode = mode
        val isStockTake = mode == "STOCK_TAKE"

        if (!isStockTake) btnModeShelfRecord.setBackgroundResource(R.drawable.bg_card_gradient_1)
        else btnModeShelfRecord.setBackgroundColor(resources.getColor(R.color.gray_button))
        btnModeShelfRecord.setTextColor(if (!isStockTake) 0xFFFFFFFF.toInt() else 0xFF000000.toInt())

        if (isStockTake) btnModeStockTake.setBackgroundResource(R.drawable.bg_card_gradient_1)
        else btnModeStockTake.setBackgroundColor(resources.getColor(R.color.gray_button))
        btnModeStockTake.setTextColor(if (isStockTake) 0xFFFFFFFF.toInt() else 0xFF000000.toInt())

        // ★ FIX (baru — #3): "UPLOAD TO KS" hanya untuk mode Stock Take/Add Box.
        btnUploadToKs.visibility = if (isStockTake) View.VISIBLE else View.GONE
        // ★ FIX (baru): "Compare Stock" (sistem vs Stock Take/Add Box) juga
        // hanya relevan untuk mode Stock Take/Add Box.
        btnCompareStock.visibility = if (isStockTake) View.VISIBLE else View.GONE
        // ★ FIX (baru — Import from History Scan sekarang tersedia di KEDUA mode):
        // dulu tombol ini disembunyikan total di mode Shelf Record. Sekarang selalu
        // tampil — importFromHistory() sudah mode-aware (Shelf Record cuma ambil
        // kolom Shelf+SKU, Qty diabaikan; Stock Take tetap ambil Shelf+SKU+Qty).
        btnImportFromHistory.visibility = View.VISIBLE

        if (isStockTake) {
            // ★ FIX (baru — #3): Stock Take/Add Box SELALU mode Manual — Auto
            // Detect TIDAK berlaku/disembunyikan khusus di mode ini (mode
            // Shelf Record tidak terpengaruh, Auto Detect tetap ada di sana).
            rowAutoDetect.visibility = View.GONE
            setScanMethod("MANUAL", persist = false)
            // ★ Pengisian data dimulai dari Shelf dulu — Scan Code & Qty baru
            // muncul SETELAH Shelf terisi (progressive reveal, lihat gambar
            // referensi). Kalau Shelf kebetulan sudah terisi (mis. balik dari
            // mode lain / data lama), langsung tampilkan supaya tidak
            // mengganggu proses yang sedang berjalan.
            val shelfFilled = etShelf.text.toString().trim().isNotEmpty()
            rowScanCode.visibility = if (shelfFilled) View.VISIBLE else View.GONE
            rowQty.visibility = if (shelfFilled) View.VISIBLE else View.GONE
            if (!shelfFilled) etShelf.post { etShelf.requestFocus() }
        } else {
            // Shelf Record: perilaku seperti sebelumnya — Auto Detect
            // tersedia, Scan Code selalu tampil (Manual maupun Auto Detect).
            rowAutoDetect.visibility = View.VISIBLE
            rowScanCode.visibility = View.VISIBLE
            rowQty.visibility = View.GONE
            setScanMethod(dcScanMethod, persist = false)
        }

        // ★ FIX: data record Shelf Record & Stock Take dipisah — tiap
        // ganti mode, list yang dirender cuma milik mode aktif (tidak digabung).
        applyModeFilter()
    }

    private fun setScanMethod(method: String, persist: Boolean = true) {
        if (persist) dcScanMethod = method
        val isAuto = method == "AUTO"
        // ★ FIX (baru): sync posisi Switch tanpa memicu ulang listener-nya.
        if (switchAutoDetect.isChecked != isAuto) {
            switchAutoDetect.setOnCheckedChangeListener(null)
            switchAutoDetect.isChecked = isAuto
            switchAutoDetect.setOnCheckedChangeListener { _, isChecked ->
                setScanMethod(if (isChecked) "AUTO" else "MANUAL")
            }
        }

        // ★ FIX: Manual — Shelf diisi manual duluan, fokus ke Scan Code.
        //        Auto Detect → langsung fokus ke Scan Code (field serbaguna).
        // ★ FIX (baru — #3): kalau Scan Code sedang disembunyikan (mode Stock
        // Take/Add Box sebelum Shelf diisi), JANGAN paksa fokus ke situ —
        // fokus Shelf yang mengurus (lihat setMode()).
        if (rowScanCode.visibility == View.VISIBLE) {
            etScanCode.requestFocus()
        }
    }

    // ── Proses Scan ───────────────────────────────────────────────────────
    /** ★ FIX (baru): titik masuk tunggal untuk semua hasil scan (kamera, HID
     *  keyboard scanner via Enter/Tab, atau ketik manual + tombol ↵). */
    private fun handleScanInput(raw: String) {
        val value = raw.trim()
        if (value.isEmpty()) return

        val method = dcScanMethod
        if (method == "AUTO") {
            // ★ FIX: Auto Detect — huruf di dalam hasil scan = Shelf baru,
            // cuma angka = Scan Code (langsung simpan baris).
            // (Auto Detect hanya berlaku di mode Shelf Record — Stock
            // Take/Add Box selalu MANUAL, lihat setMode().)
            if (onlyLettersRegex.matches(value)) {
                // ★ FIX (#1): mode Shelf Record — tolak hasil scan
                // berformat link/URL atau QR umum lainnya sebagai Shelf.
                if (isLinkOrQrFormat(value)) {
                    Toast.makeText(this,
                        "Invalid Shelf: link/QR format is not allowed", Toast.LENGTH_SHORT).show()
                    etScanCode.setText("")
                    etScanCode.post { etScanCode.requestFocus() }
                    return
                }
                etShelf.setText(value)
                etScanCode.setText("")
                etScanCode.requestFocus()
                Toast.makeText(this, "Shelf set to: $value", Toast.LENGTH_SHORT).show()
            } else {
                // ★ FIX (#1): mode Shelf Record — tolak Scan Code berformat
                // link/URL atau QR umum lainnya.
                if (isLinkOrQrFormat(value)) {
                    Toast.makeText(this,
                        "Invalid Scan Code: link/QR format is not allowed", Toast.LENGTH_SHORT).show()
                    etScanCode.setText("")
                    etScanCode.post { etScanCode.requestFocus() }
                    return
                }
                submitRecord(value)
            }
        } else if (dcMode == "STOCK_TAKE") {
            // ★ FIX (#2): Manual, mode Stock Take/Add Box — Scan Code TIDAK
            // langsung disimpan. Setelah Scan Code terdeteksi/masuk (scan
            // maupun ketik manual), fokus otomatis pindah (auto-tab) ke Qty;
            // baris baru benar-benar tersimpan setelah Qty diisi & di-Enter
            // (lihat listener etQty & submitRecord()).
            val shelf = etShelf.text.toString().trim()
            if (shelf.isEmpty()) {
                Toast.makeText(this, "Fill in Shelf before scanning Scan Code", Toast.LENGTH_SHORT).show()
                etScanCode.setText("")
                etShelf.requestFocus()
                return
            }
            etScanCode.setText(value)
            etQty.setText("")
            etQty.post { etQty.requestFocus() }
        } else {
            // ★ FIX: Manual, mode Shelf Record — field Scan Code SELALU
            // dianggap Scan Code (Shelf sudah diisi terpisah oleh user
            // sebelumnya). ★ FIX (#1): tolak format link/URL/QR.
            if (isLinkOrQrFormat(value)) {
                Toast.makeText(this,
                    "Invalid Scan Code: link/QR format is not allowed", Toast.LENGTH_SHORT).show()
                etScanCode.setText("")
                etScanCode.post { etScanCode.requestFocus() }
                return
            }
            submitRecord(value)
        }
    }

    private fun submitRecord(scanCode: String) {
        val shelf = etShelf.text.toString().trim()
        if (shelf.isEmpty()) {
            Toast.makeText(this, "Fill in Shelf before scanning Scan Code", Toast.LENGTH_SHORT).show()
            etScanCode.setText("")
            etShelf.requestFocus()
            return
        }
        if (scanCode.isEmpty()) {
            Toast.makeText(this, "Fill in Scan Code before saving", Toast.LENGTH_SHORT).show()
            etScanCode.post { etScanCode.requestFocus() }
            return
        }
        val mode = dcMode
        val qty = if (mode == "STOCK_TAKE") etQty.text.toString().trim() else ""
        // ★ FIX (#2): mode Stock Take/Add Box — data TIDAK BOLEH tersimpan
        // selama field Qty masih kosong. User wajib mengisi Qty dulu sebelum
        // baris ini benar-benar disubmit ke DB.
        if (mode == "STOCK_TAKE" && qty.isEmpty()) {
            Toast.makeText(this, "Fill in Qty before saving", Toast.LENGTH_SHORT).show()
            etQty.post { etQty.requestFocus() }
            return
        }

        db.insertDataCollect(shelf, scanCode, qty, mode)
        etScanCode.setText("")
        etQty.setText("")
        // ★ FIX (samakan dgn Scan Process/SKU Code): loadRecords() (refresh
        // ListView) HARUS dijalankan SEBELUM requestFocus() — kalau tidak,
        // ListView bisa "merebut" fokus lagi setelah refresh sehingga field
        // Scan Code butuh di-tap manual tiap data ke-2 dst. "Scanner siap
        // menerima barcode berikutnya" — fokus balik otomatis, tanpa tap.
        loadRecords()
        etScanCode.post { etScanCode.requestFocus() }
    }

    private fun loadRecords() {
        rowsAll.clear()
        val c: Cursor = db.getAllDataCollect()
        c.use {
            while (it.moveToNext()) {
                rowsAll.add(arrayOf(
                    it.getInt(it.getColumnIndexOrThrow(AppDatabase.C_DC_ID)).toString(),
                    it.getString(it.getColumnIndexOrThrow(AppDatabase.C_DC_SHELF)) ?: "",
                    it.getString(it.getColumnIndexOrThrow(AppDatabase.C_DC_CODE)) ?: "",
                    it.getString(it.getColumnIndexOrThrow(AppDatabase.C_DC_QTY)) ?: "",
                    it.getString(it.getColumnIndexOrThrow(AppDatabase.C_DC_MODE)) ?: "",
                    it.getString(it.getColumnIndexOrThrow(AppDatabase.C_DC_TIME)) ?: "",
                    it.getInt(it.getColumnIndexOrThrow(AppDatabase.C_DC_UPLOADED)).toString()
                ))
            }
        }
        applyModeFilter()
    }

    /** ★ FIX (baru): saring `rowsAll` (semua data di DB) supaya yang tampil
     *  di layar cuma milik mode kerja yang sedang aktif — Shelf Record dan
     *  Stock Take/Add Box punya daftar record masing-masing, tidak digabung
     *  saat user pindah mode. Data mode lain TETAP ada di DB (tidak hilang),
     *  cuma disembunyikan dari tampilan sampai mode-nya diaktifkan lagi. */
    private fun applyModeFilter() {
        rows.clear()
        rows.addAll(rowsAll.filter { it[4] == dcMode })
        adapter.notifyDataSetChanged()
        tvDcCount.text = "${rows.size} record"
        val empty = rows.isEmpty()
        tvDcEmpty.visibility = if (empty) View.VISIBLE else View.GONE
        lvRecords.visibility = if (empty) View.GONE else View.VISIBLE
    }

    /** ★ FIX (baru): tap record → dialog konfirmasi hapus. Setelah dihapus,
     *  list, nomor urut & total counter otomatis diperbarui tanpa refresh. */
    private fun confirmDeleteRecord(position: Int) {
        if (position !in rows.indices) return
        val r = rows[position]
        val summary = if (r[4] == "STOCK_TAKE" && r[3].isNotBlank())
            "${r[1]}, ${r[2]}, ${r[3]}" else "${r[1]}, ${r[2]}"
        AlertDialog.Builder(this)
            .setTitle("Delete this record?")
            .setMessage(summary)
            .setPositiveButton("Delete") { _, _ ->
                db.deleteDataCollect(r[0].toInt())
                rowsAll.removeAll { it[0] == r[0] }
                rows.removeAt(position)
                adapter.notifyDataSetChanged()
                tvDcCount.text = "${rows.size} record"
                val empty = rows.isEmpty()
                tvDcEmpty.visibility = if (empty) View.VISIBLE else View.GONE
                lvRecords.visibility = if (empty) View.GONE else View.VISIBLE
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    /** ★ FIX (baru): dialog edit record (tekan & tahan). Qty hanya tampil di mode Stock Take. */
    private fun showEditRecordDialog(position: Int) {
        if (position !in rows.indices) return
        val r = rows[position]
        val isStockTake = r[4] == "STOCK_TAKE"
        val pad = (20 * resources.displayMetrics.density).toInt()

        fun field(label: String, value: String, numeric: Boolean = false) = EditText(this).apply {
            hint = label
            setText(value)
            setSingleLine(true)
            if (numeric) inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setSelectAllOnFocus(true)
        }
        val etShelf = field("Shelf", r[1])
        val etSku   = field("SKU", r[2])
        val etQty   = field("Qty", r[3], numeric = true)

        val box = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(pad, pad / 2, pad, 0)
            addView(etShelf); addView(etSku)
            if (isStockTake) addView(etQty)
        }

        AlertDialog.Builder(this)
            .setTitle("Edit record")
            .setView(box)
            .setPositiveButton("Save") { _, _ ->
                val shelf = etShelf.text.toString().trim()
                val sku   = etSku.text.toString().trim()
                val qty   = if (isStockTake) etQty.text.toString().trim() else ""
                if (shelf.isBlank() || sku.isBlank() || (isStockTake && qty.isBlank())) {
                    android.widget.Toast.makeText(this, "Shelf, SKU${if (isStockTake) ", Qty" else ""} must not be empty", android.widget.Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                db.updateDataCollect(r[0].toInt(), shelf, sku, qty)
                // array yang sama dipakai rows & rowsAll → cukup ubah di tempat
                r[1] = shelf; r[2] = sku; r[3] = qty; r[6] = "0"
                adapter.notifyDataSetChanged()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun confirmClearAll() {
        if (rows.isEmpty()) return
        AlertDialog.Builder(this)
            .setTitle("Clear All")
            .setMessage("Delete all ${rows.size} ${if (dcMode == "STOCK_TAKE") "Stock Take/Add Box" else "Shelf Record"} record(s) in Data Collector? Both uploaded and not-yet-uploaded data will be deleted.")
            .setPositiveButton("Delete") { _, _ ->
                // ★ FIX: Clear All hanya menghapus record milik mode aktif
                // (Shelf Record / Stock Take/Add Box), bukan seluruh data.
                val idsToDelete = rowsAll.filter { it[4] == dcMode }.map { it[0] }
                idsToDelete.forEach { db.deleteDataCollect(it.toInt()) }
                loadRecords()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ── Upload to PC ─────────────────────────────────────────────────────
    private fun showUploadChoiceDialog() {
        if (rows.isEmpty()) {
            Toast.makeText(this, "No data to upload yet", Toast.LENGTH_SHORT).show()
            return
        }
        // ★ FIX (baru — tampilan pop-up disamakan dengan gambar acuan):
        // "Upload Selection" / "Do You Wan To Upload To Server Directly or
        // Save To Local?", tombol LOCAL (kiri/negative) & UPLOAD (kanan/positive).
        AlertDialog.Builder(this)
            .setTitle("Upload Selection")
            .setMessage("Do You Wan To Upload To Server Directly or Save To Local?")
            .setNegativeButton("LOCAL") { _, _ -> doUpload(toLocal = true) }
            .setPositiveButton("UPLOAD") { _, _ -> doUpload(toLocal = false) }
            .show()
    }

    /** ★ FIX (baru): bangun isi TXT sesuai mode aktif SAAT INI —
     *  Shelf Record → "Shelf,ScanCode" per baris (kolom Qty TIDAK ada);
     *  Stock Take   → "Shelf,ScanCode,Qty" per baris (Qty WAJIB ada).
     *  Tidak ada header, tidak ada baris kosong di akhir, pemisah koma,
     *  encoding UTF-8 (default String di Kotlin/JVM). */
    private fun buildTxtContent(): String {
        val mode = dcMode
        val sb = StringBuilder()
        // Urutan file mengikuti urutan scan (lama → baru), rows di memori
        // urut _id DESC (terbaru dulu) jadi dibalik dulu.
        val ordered = rows.asReversed()
        ordered.forEachIndexed { idx, r ->
            val shelf = r[1]; val code = r[2]; val qty = r[3]
            if (mode == "STOCK_TAKE") {
                sb.append(shelf).append(",").append(code).append(",").append(qty.ifBlank { "0" })
            } else {
                sb.append(shelf).append(",").append(code)
            }
            if (idx != ordered.lastIndex) sb.append("\n")
        }
        return sb.toString()
    }

    private fun buildFileName(): String {
        val prefix = fileFormat.ifBlank { "YM" }
        // Store code segment: fixed per mode, not the user-entered Store Code.
        //  - Shelf Record   -> 05
        //  - Stock Take     -> 04 (juga dipakai untuk alur add box)
        val store = if (dcMode == "STOCK_TAKE") "04" else "05"
        val fmt = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        return "${prefix}_${store}_$fmt.txt"
    }

    private fun doUpload(toLocal: Boolean) {
        val fileName = buildFileName()
        val content = buildTxtContent()
        val modeAtUpload = dcMode
        lifecycleScope.launch {
            try {
                val path = withContext(Dispatchers.IO) {
                    if (toLocal) OutputWriter.writeToLocalDirect(this@DataCollectorActivity, fileName, content)
                    else OutputWriter.writeToSmbDirect(this@DataCollectorActivity, fileName, content, OutputModule.DATA_COLLECTOR)
                }
                // ★ FIX (baru): "Upload to PC (Data Local)" khusus mode Stock
                // Take — selain nulis file TXT lokal, data hasil scan JUGA
                // otomatis ditambahkan ke Keep Stock (Google Sheets), reuse
                // proses backend yang SAMA PERSIS dengan tombol Add di
                // Keep Stock → View & Edit Data (KeepStockGasClient.addRows).
                // Tidak berlaku untuk mode Shelf Record atau untuk pilihan
                // "Server Directly (Via SMB)".
                if (toLocal && modeAtUpload == "STOCK_TAKE") {
                    syncStockTakeToKeepStock(path)
                } else {
                    Toast.makeText(this@DataCollectorActivity, "Successfully saved: $path", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                AlertDialog.Builder(this@DataCollectorActivity)
                    .setTitle("Upload failed")
                    .setMessage(e.message ?: "Unknown error")
                    .setPositiveButton("OK", null).showSafely()
            }
        }
    }

    /**
     * ★ FIX (baru): kirim seluruh baris Stock Take (Shelf → No Ctn, Scan
     * Code → SKU, Qty → Qty) ke Keep Stock (GSheet) — dikelompokkan per
     * Shelf/No Ctn (persis seperti dialog Add: 1 No Ctn bisa punya beberapa
     * SKU sekaligus), lalu dipanggil lewat `KeepStockGasClient.addRows`
     * (fungsi backend YANG SAMA dipakai tombol Add — TIDAK ada endpoint/
     * struktur data baru). Toko yang dipakai = toko Keep Stock aktif
     * (`ksLastStore`, sama dengan sesi login Keep Stock terakhir).
     *
     * `localPath` bersifat opsional — dipakai HANYA untuk ditampilkan di
     * pesan toast/dialog kalau proses ini dipanggil sesudah simpan lokal.
     * Dipanggil sendiri (tanpa `localPath`) dari menu "UPLOAD TO KS" →
     * "Upload Data Gsheet", independen dari "Save to Local".
     */
    private suspend fun syncStockTakeToKeepStock(localPath: String? = null) {
        val prefix = if (localPath != null) "Successfully saved locally: $localPath\n" else ""
        if (ksWebAppUrl.isBlank()) {
            Toast.makeText(this,
                "$prefix(Keep Stock sync skipped — Web App URL is not set in the Keep Stock menu)",
                Toast.LENGTH_LONG).show()
            return
        }
        val stockTakeRows = rows.filter { it[4] == "STOCK_TAKE" }
        if (stockTakeRows.isEmpty()) {
            Toast.makeText(this, "${prefix}No Stock Take/Add Box data to sync yet", Toast.LENGTH_LONG).show()
            return
        }
        // Group per Shelf (No Ctn) → List<Pair<SKU, Qty>>, urutan scan asli dijaga.
        val grouped = LinkedHashMap<String, MutableList<Pair<String, String>>>()
        stockTakeRows.asReversed().forEach { r ->
            val noCtn = r[1]; val sku = r[2]; val qty = r[3].ifBlank { "1" }
            grouped.getOrPut(noCtn) { mutableListOf() }.add(sku to qty)
        }
        val store = ksLastStore.ifBlank { Prefs.KEEP_STOCK_STORES.first() }
        var successGroups = 0
        var failGroups = 0
        val errors = mutableListOf<String>()
        withContext(Dispatchers.IO) {
            for ((noCtn, items) in grouped) {
                try {
                    KeepStockGasClient.addRows(ksWebAppUrl, ksApiToken, store, noCtn, items)
                    successGroups++
                } catch (e: Exception) {
                    failGroups++
                    errors.add("$noCtn: ${e.message}")
                }
            }
        }
        // ★ FIX: notifikasi bahwa sinkronisasi Keep Stock berhasil (atau
        // sebagian gagal, supaya user tahu perlu retry lewat Keep Stock →
        // View & Edit Data → Add secara manual untuk grup yang gagal).
        if (failGroups == 0) {
            Toast.makeText(this,
                "$prefix$successGroups No Ctn successfully synced to Keep Stock (Google Sheets)",
                Toast.LENGTH_LONG).show()
        } else {
            AlertDialog.Builder(this)
                .setTitle("Keep Stock sync partially failed")
                .setMessage("$prefix\nSucceeded: $successGroups No Ctn\nFailed: $failGroups No Ctn\n\n${errors.joinToString("\n")}")
                .setPositiveButton("OK", null).showSafely()
        }
    }

    // ── UPLOAD TO KS (khusus Stock Take/Add Box) ───────────────────────────
    /** ★ FIX (baru): menu "UPLOAD TO KS" — "Save to Local" & "Upload Data
     *  Gsheet" sekarang dua tombol/aksi independen (tidak lagi otomatis
     *  bergandengan seperti sebelumnya). Hanya tersedia di mode Stock
     *  Take/Add Box. Tidak mengubah proses "Upload to PC" (SMB) yang lama. */
    private fun showUploadToKsDialog() {
        if (rows.isEmpty()) {
            Toast.makeText(this, "No Stock Take/Add Box data to upload yet", Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Upload to KS")
            .setItems(arrayOf("Save to Local", "Upload Data Gsheet")) { _, which ->
                if (which == 0) saveStockTakeToLocalOnly() else uploadStockTakeToGsheetOnly()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    /** ★ FIX (baru): simpan file TXT ke penyimpanan lokal HP SAJA, TIDAK
     *  memicu sinkronisasi ke Keep Stock (Google Sheets). Independen dari
     *  "Upload Data Gsheet". */
    private fun saveStockTakeToLocalOnly() {
        val fileName = buildFileName()
        val content = buildTxtContent()
        lifecycleScope.launch {
            try {
                val path = withContext(Dispatchers.IO) {
                    OutputWriter.writeToLocalDirect(this@DataCollectorActivity, fileName, content)
                }
                Toast.makeText(this@DataCollectorActivity, "Successfully saved: $path", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                AlertDialog.Builder(this@DataCollectorActivity)
                    .setTitle("Local save failed")
                    .setMessage(e.message ?: "Unknown error")
                    .setPositiveButton("OK", null).showSafely()
            }
        }
    }

    /** ★ FIX (baru): kirim data Stock Take/Add Box langsung ke Keep Stock
     *  (Google Sheets) SAJA, TIDAK menyimpan file TXT lokal. Independen
     *  dari "Save to Local". Reuse proses backend yang sama persis dengan
     *  tombol Add di Keep Stock (`KeepStockGasClient.addRows`). */
    private fun uploadStockTakeToGsheetOnly() {
        lifecycleScope.launch {
            syncStockTakeToKeepStock(localPath = null)
        }
    }

    // ── SMB Output Settings (khusus Data Collector, terpisah dari Setting global) ──
    private fun showSmbOutputSettingsDialog() {
        val container = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            val pad = (16 * resources.displayMetrics.density).toInt()
            setPadding(pad, 8, pad, 0)
        }
        val etPath = EditText(this).apply {
            setText(smbUploadPathDataCollector)
            hint = "smb://HOSTNAME/share/subfolder"
        }
        container.addView(etPath)
        AlertDialog.Builder(this)
            .setTitle("SMB Output Settings — Data Collector")
            .setMessage("File name format: <FileFormat>_<ModeCode>_<date>_<time>.txt (FileFormat diatur di menu Setting, ModeCode tetap: 05 Shelf Record / 04 Stock Take). Leave SMB folder empty to use the path from global Settings.")
            .setView(container)
            .setPositiveButton("Save") { _, _ ->
                smbUploadPathDataCollector = etPath.text.toString().trim()
                Toast.makeText(this, "Data Collector setting saved", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
