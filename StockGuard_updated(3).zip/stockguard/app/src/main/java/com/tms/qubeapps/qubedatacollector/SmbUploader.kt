package com.tms.qubeapps.qubedatacollector

import com.hierynomus.msdtyp.AccessMask
import com.hierynomus.mssmb2.SMB2CreateDisposition
import com.hierynomus.mssmb2.SMB2ShareAccess
import com.hierynomus.smbj.SMBClient
import com.hierynomus.smbj.auth.AuthenticationContext
import com.hierynomus.smbj.share.DiskShare
import jcifs.context.SingletonContext
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.InetAddress

/**
 * SMB upload/download menggunakan library smbj.
 *
 * Format smbPath dari Setting: smb://HOSTNAME/shareName/subfolder/
 * Contoh: smb://BACKEND/QasDev/QubeV10/BackEnd/Data
 * Juga menerima path gaya Windows Explorer yang di-copy-paste apa adanya:
 * \\BACKEND\QasDev\QubeV10\BackEnd\Data
 *
 * Parsing:
 *   host      = BACKEND
 *   shareName = QasDev
 *   subPath   = QubeV10\BackEnd\Data
 *
 * ★ FIX bug sebelumnya:
 *   - Validasi smbUrl/host/share kosong → pesan error jelas (bukan NPE generik)
 *   - try-finally eksplisit untuk pastikan connection ditutup walau error
 *
 * ★ FIX (upload/download SMB selalu gagal walau 1 jaringan & folder sudah share):
 *   1. Path gaya Windows (\\SERVER\share\folder) sekarang diterima juga —
 *      sebelumnya kalau user copy-paste path dari Windows Explorer (pakai
 *      backslash, bukan format smb://), parsing gagal total karena tidak
 *      ada karakter "/" untuk memisahkan host & share.
 *   2. smbj HANYA bisa connect pakai alamat IP atau nama yang terdaftar di
 *      DNS — TIDAK BISA resolve nama komputer Windows (NetBIOS name) seperti
 *      "BACKEND". Windows bisa connect ke nama itu karena Windows otomatis
 *      broadcast NetBIOS untuk mencari nama tsb; Android tidak. Ini penyebab
 *      paling umum kenapa SMB "selalu gagal" walau HP & server sudah satu
 *      jaringan dan folder sudah di-share dengan benar. Sekarang sebelum
 *      connect, hostname di-resolve dulu: coba IP langsung → coba DNS →
 *      fallback ke resolusi NetBIOS (lewat jcifs-ng). Kalau semua gagal,
 *      pesan error menyarankan user isi SMB Path pakai alamat IP server.
 */
object SmbUploader {

    private data class SmbParts(val host: String, val share: String, val subPath: String)

    private fun parse(smbUrl: String): SmbParts {
        if (smbUrl.isBlank()) {
            throw IllegalArgumentException("SMB Path is empty. Fill it in Settings first (example: smb://SERVER/share/folder)")
        }
        // FIX: normalisasi dulu. User sering copy-paste path ala Windows Explorer
        // (\\SERVER\share\folder) yang pakai backslash, bukan format smb://.
        // Backslash diubah ke forward-slash supaya parsing di bawah konsisten
        // untuk kedua format.
        val normalized = smbUrl.trim().replace('\\', '/')
        val stripped = normalized
            .removePrefix("smb://").removePrefix("SMB://")
            .trimStart('/')   // buang sisa leading "//" dari UNC path (\\SERVER\...)
            .trimEnd('/')
        val parts = stripped.split("/").filter { it.isNotBlank() }
        val host = parts.getOrNull(0)
            ?: throw IllegalArgumentException("Invalid SMB Path: hostname not found")
        val share = parts.getOrNull(1)
            ?: throw IllegalArgumentException(
                "Invalid SMB Path: share name not found " +
                "(example: smb://HOST/SHARE/folder or \\\\HOST\\SHARE\\folder)"
            )
        val sub = parts.drop(2).joinToString("\\")
        return SmbParts(host, share, sub)
    }

    /**
     * FIX: resolusi hostname → IP sebelum connect.
     * smbj (client.connect) tidak punya resolver NetBIOS, jadi kalau SMB Path
     * diisi nama komputer (mis. "BACKEND", bukan IP), koneksi bisa selalu
     * gagal walau device sudah 1 jaringan & folder sudah di-share — karena
     * Android tidak tahu cara menerjemahkan nama itu ke alamat IP tanpa
     * bantuan resolver NetBIOS (yang otomatis ada di Windows).
     *
     * Urutan coba:
     *   1. Kalau host sudah berupa IP → langsung pakai, tidak perlu resolve apa-apa.
     *   2. Coba DNS biasa (InetAddress.getByName) — jalan kalau jaringan
     *      punya DNS server lokal / hosts file yang mengenal nama itu.
     *   3. Fallback ke resolusi NetBIOS lewat jcifs-ng (NbtAddress) — ini yang
     *      menyamai cara Windows menemukan nama komputer di LAN/WiFi yang sama.
     */
    private fun resolveHost(host: String): String {
        val ipRegex = Regex("^\\d{1,3}(\\.\\d{1,3}){3}$")
        if (ipRegex.matches(host)) return host

        try {
            val addr = InetAddress.getByName(host)
            if (!addr.isLoopbackAddress) return addr.hostAddress
        } catch (_: Exception) {
            // lanjut coba resolusi NetBIOS di bawah
        }

        return try {
            // FIX: jcifs-ng (beda dari jCIFS versi lama) tidak punya method static
            // NbtAddress.getByName lagi — semua lewat CIFSContext.
            // SingletonContext.getInstance() = context global default (setara
            // perilaku jCIFS lama), lalu getNameServiceClient().getNbtByName()
            // yang melakukan broadcast NetBIOS untuk cari IP dari nama komputer.
            val nbt = SingletonContext.getInstance().nameServiceClient.getNbtByName(host)
            nbt.hostAddress
        } catch (e: Exception) {
            throw Exception(
                "Unable to find server '$host' on the network (failed to resolve name to IP). " +
                "Android devices cannot always resolve Windows computer names the way Windows " +
                "can. Try entering the SMB Path using the server's IP address, e.g. smb://192.168.1.10/share/folder " +
                "(check the server IP via Command Prompt on the PC server: type 'ipconfig')."
            )
        }
    }

    /**
     * ★ FIX: SMB tetap butuh semacam autentikasi (bagian dari protokolnya, tidak
     * bisa dihilangkan sepenuhnya) — TAPI banyak folder share di Windows memang
     * dikonfigurasi untuk akses Guest/anonymous (tanpa username/password).
     * Sebelumnya username WAJIB diisi, jadi kalau share-nya memang guest-only,
     * field wajib ini yang bikin koneksi selalu gagal. Sekarang: username kosong
     * = login sebagai anonymous/guest (didukung smbj), tidak lagi dilempar error.
     *
     * ★ FIX (Autentikasi gagal terus meski IP & path sudah benar): tambah
     * parameter domain (opsional) — beberapa jaringan kantor/domain Windows
     * butuh domain eksplisit di NTLM handshake, kalau di-null-kan terus bisa
     * ditolak server walau username/password sudah benar.
     */
    private fun buildAuth(username: String, password: String, domain: String = ""): AuthenticationContext {
        return if (username.isBlank()) {
            AuthenticationContext.anonymous()
        } else {
            AuthenticationContext(username, password.toCharArray(), domain.ifBlank { null })
        }
    }

    /**
     * ★ FIX (Menu 5 — Export PDF): upload file BINARY (mis. PDF) ke server SMB.
     * Sama seperti upload() tapi menerima ByteArray mentah, tidak boleh lewat
     * String/Charset karena akan merusak isi file biner.
     */
    fun uploadBytes(smbUrl: String, username: String, password: String,
                     fileName: String, bytes: ByteArray, domain: String = "") {
        val (host, share, subPath) = parse(smbUrl)
        val resolvedHost = resolveHost(host)

        val client = SMBClient()
        val connection = try {
            client.connect(resolvedHost)
        } catch (e: Exception) {
            throw Exception("Failed to connect to server '$host' ($resolvedHost). Make sure the device is on the same network as the server and the hostname/IP is correct. (${e.message})")
        }

        try {
            val auth = buildAuth(username, password, domain)
            val session = try {
                connection.authenticate(auth)
            } catch (e: Exception) {
                throw Exception("Authentication failed. ${authHint(username)} (${e.message})")
            }

            val diskShare = try {
                session.connectShare(share) as DiskShare
            } catch (e: Exception) {
                throw Exception("Unable to access share '$share'. Check the share name in the SMB Path. (${e.message})")
            }

            try {
                val filePath = if (subPath.isNotEmpty()) "$subPath\\$fileName" else fileName
                val file = diskShare.openFile(
                    filePath,
                    setOf(AccessMask.GENERIC_WRITE),
                    null,
                    setOf(SMB2ShareAccess.FILE_SHARE_WRITE),
                    SMB2CreateDisposition.FILE_OVERWRITE_IF,
                    null
                )
                try {
                    file.outputStream.use { out -> out.write(bytes) }
                } finally {
                    file.close()
                }
            } finally {
                diskShare.close()
            }
        } finally {
            connection.close()
        }
    }

    private fun authHint(username: String): String =
        if (username.isBlank())
            "Anonymous/guest login was rejected by the server — this share likely does NOT allow access without an account. Fill in Username & Password in Settings."
        else
            "Possible causes: (1) Username/Password is wrong — it must be a REAL Windows account on the PC server, not an arbitrary value. " +
            "(2) If Username is still the default 'admin' but the PC has no account named 'admin', change it to the actual Windows username. " +
            "(3) If the Windows account password is EMPTY, Windows often rejects network logins with an empty password (default security policy) — try setting a password on that Windows account. " +
            "(4) If the PC server has joined an office Domain, also fill in the Domain field in Settings."

    /**
     * Upload string content ke file di server SMB.
     * Melempar Exception jika gagal — panggil dari Dispatchers.IO.
     */
    fun upload(smbUrl: String, username: String, password: String,
               fileName: String, content: String, domain: String = "") {
        val (host, share, subPath) = parse(smbUrl)
        val resolvedHost = resolveHost(host)

        val client = SMBClient()
        val connection = try {
            client.connect(resolvedHost)
        } catch (e: Exception) {
            throw Exception("Failed to connect to server '$host' ($resolvedHost). Make sure the device is on the same network as the server and the hostname/IP is correct. (${e.message})")
        }

        try {
            val auth = buildAuth(username, password, domain)
            val session = try {
                connection.authenticate(auth)
            } catch (e: Exception) {
                throw Exception("Authentication failed. ${authHint(username)} (${e.message})")
            }

            val diskShare = try {
                session.connectShare(share) as DiskShare
            } catch (e: Exception) {
                throw Exception("Unable to access share '$share'. Check the share name in the SMB Path. (${e.message})")
            }

            try {
                val filePath = if (subPath.isNotEmpty()) "$subPath\\$fileName" else fileName
                val file = diskShare.openFile(
                    filePath,
                    setOf(AccessMask.GENERIC_WRITE),
                    null,
                    setOf(SMB2ShareAccess.FILE_SHARE_WRITE),
                    SMB2CreateDisposition.FILE_OVERWRITE_IF,
                    null
                )
                try {
                    file.outputStream.use { out ->
                        out.write(content.toByteArray(Charsets.UTF_8))
                    }
                } finally {
                    file.close()
                }
            } finally {
                diskShare.close()
            }
        } finally {
            connection.close()
        }
    }

    /**
     * FIX (APK Download): download file BINARY (mis. APK) dari SMB, return
     * sebagai ByteArray mentah — TIDAK boleh lewat InputStreamReader/Charset
     * seperti fungsi download() di bawah, karena itu akan merusak isi file
     * biner (APK jadi corrupt kalau didekode sebagai teks).
     */
    fun downloadBytes(smbUrl: String, username: String, password: String,
                       fileName: String, domain: String = ""): ByteArray {
        val (host, share, subPath) = parse(smbUrl)
        val resolvedHost = resolveHost(host)

        val client = SMBClient()
        val connection = try {
            client.connect(resolvedHost)
        } catch (e: Exception) {
            throw Exception("Failed to connect to server '$host' ($resolvedHost). (${e.message})")
        }
        try {
            val auth = buildAuth(username, password, domain)
            val session = try {
                connection.authenticate(auth)
            } catch (e: Exception) {
                throw Exception("Authentication failed. ${authHint(username)} (${e.message})")
            }
            val diskShare = session.connectShare(share) as DiskShare
            try {
                val filePath = if (subPath.isNotEmpty()) "$subPath\\$fileName" else fileName
                if (!diskShare.fileExists(filePath)) {
                    throw Exception("File '$fileName' not found on server")
                }
                val file = diskShare.openFile(
                    filePath,
                    setOf(AccessMask.GENERIC_READ),
                    null,
                    setOf(SMB2ShareAccess.FILE_SHARE_READ),
                    SMB2CreateDisposition.FILE_OPEN,
                    null
                )
                try {
                    return file.inputStream.use { it.readBytes() }
                } finally {
                    file.close()
                }
            } finally {
                diskShare.close()
            }
        } finally {
            connection.close()
        }
    }

    /**
     * Download file dari SMB, return sebagai String.
     */
    fun download(smbUrl: String, username: String, password: String,
                 fileName: String, domain: String = ""): String {
        val (host, share, subPath) = parse(smbUrl)
        val resolvedHost = resolveHost(host)

        val client = SMBClient()
        val connection = try {
            client.connect(resolvedHost)
        } catch (e: Exception) {
            throw Exception("Failed to connect to server '$host' ($resolvedHost). (${e.message})")
        }

        try {
            val auth = buildAuth(username, password, domain)
            val session = try {
                connection.authenticate(auth)
            } catch (e: Exception) {
                throw Exception("Authentication failed. ${authHint(username)} (${e.message})")
            }
            val diskShare = session.connectShare(share) as DiskShare
            try {
                val filePath = if (subPath.isNotEmpty()) "$subPath\\$fileName" else fileName
                if (!diskShare.fileExists(filePath)) {
                    throw Exception("File '$fileName' not found on server")
                }
                val file = diskShare.openFile(
                    filePath,
                    setOf(AccessMask.GENERIC_READ),
                    null,
                    setOf(SMB2ShareAccess.FILE_SHARE_READ),
                    SMB2CreateDisposition.FILE_OPEN,
                    null
                )
                try {
                    return BufferedReader(InputStreamReader(file.inputStream)).use { it.readText() }
                } finally {
                    file.close()
                }
            } finally {
                diskShare.close()
            }
        } finally {
            connection.close()
        }
    }
}
