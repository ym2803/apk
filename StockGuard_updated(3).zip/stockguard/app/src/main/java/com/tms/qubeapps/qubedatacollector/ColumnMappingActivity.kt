package com.tms.qubeapps.qubedatacollector

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class ColumnMappingActivity : BaseActivity() {

    companion object {
        const val EXTRA_PREVIEW_ROW = "preview_row"
        const val EXTRA_SEPARATOR   = "separator"
        const val EXTRA_TOTAL_COLS  = "total_cols"
    }

    private var previewRow  = ""
    private var separator   = ","
    private var totalCols   = 0
    // BUG FIX: gunakan splitLine() bukan split() langsung
    private var sampleParts = listOf<String>()

    private lateinit var tvPreviewRow    : TextView
    private lateinit var tvSepDetected   : TextView
    private lateinit var tvColCount      : TextView
    private lateinit var etDisplayOrder  : EditText
    // ★ FIX (baru): pilihan jumlah baris tampilan kartu RESULT (10 / 5)
    private lateinit var rgResultRows    : RadioGroup
    private lateinit var tvPreviewSku    : TextView
    private lateinit var tvPreviewBalance: TextView
    private lateinit var tvPreviewShelf  : TextView
    private lateinit var tvPreviewPrice  : TextView
    private lateinit var tvPreviewDesc   : TextView

    private lateinit var rowSku    : View
    private lateinit var rowBalance: View
    private lateinit var rowShelf  : View
    private lateinit var rowPrice  : View
    private lateinit var rowDesc   : View
    // ★ FIX: row mapping tambahan (opsional) untuk Discount, Disc Start/End Date, Long SKU, Keep Stock
    private lateinit var rowDiscount : View
    private lateinit var rowDiscStart: View
    private lateinit var rowDiscEnd  : View
    private lateinit var rowLongSku  : View
    private lateinit var rowKeepStock: View

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_column_mapping)

        previewRow  = intent.getStringExtra(EXTRA_PREVIEW_ROW) ?: ""
        separator   = intent.getStringExtra(EXTRA_SEPARATOR)   ?: ","
        totalCols   = intent.getIntExtra(EXTRA_TOTAL_COLS, 0)

        // FIX: pakai splitLine() — sama persis dengan cara parsePriceList() memecah baris
        // sehingga nomor kolom yang dimasukkan user sesuai dengan data yang diparse
        sampleParts = if (previewRow.isNotBlank())
            ColMappingPrefs.splitLine(previewRow, separator)
        else emptyList()

        tvPreviewRow     = findViewById(R.id.tvPreviewRow)
        tvSepDetected    = findViewById(R.id.tvSepDetected)
        tvColCount       = findViewById(R.id.tvColCount)
        etDisplayOrder   = findViewById(R.id.etDisplayOrder)
        rgResultRows     = findViewById(R.id.rgResultRows)
        tvPreviewSku     = findViewById(R.id.tvPreviewSku)
        tvPreviewBalance = findViewById(R.id.tvPreviewBalance)
        tvPreviewShelf   = findViewById(R.id.tvPreviewShelf)
        tvPreviewPrice   = findViewById(R.id.tvPreviewPrice)
        tvPreviewDesc    = findViewById(R.id.tvPreviewDesc)

        rowSku     = findViewById(R.id.rowSku)
        rowBalance = findViewById(R.id.rowBalance)
        rowShelf   = findViewById(R.id.rowShelf)
        rowPrice   = findViewById(R.id.rowPrice)
        rowDesc    = findViewById(R.id.rowDesc)
        rowDiscount  = findViewById(R.id.rowDiscount)
        rowDiscStart = findViewById(R.id.rowDiscStart)
        rowDiscEnd   = findViewById(R.id.rowDiscEnd)
        rowLongSku   = findViewById(R.id.rowLongSku)
        rowKeepStock = findViewById(R.id.rowKeepStock)

        setupRow(rowSku,     "SKU")
        setupRow(rowBalance, "Balance")
        setupRow(rowShelf,   "Shelf")
        setupRow(rowPrice,   "Price")
        setupRow(rowDesc,    "Desc")
        setupRow(rowDiscount,  "Discount")
        setupRow(rowDiscStart, "Disc Start Date")
        setupRow(rowDiscEnd,   "Disc End Date")
        setupRow(rowLongSku,   "Long SKU")
        setupRow(rowKeepStock, "Keep Stock")

        // Tampilkan baris sample dengan nomor kolom — pakai sampleParts yang sudah fix
        val numbered = sampleParts.mapIndexed { i, v -> "[${i+1}] $v" }.joinToString("   ")
        tvPreviewRow.text  = numbered.ifBlank { "No preview (download data first)" }
        tvSepDetected.text = if (separator == ",") "KOMA  (,)" else "PIPE  (|)"
        // FIX: totalCols diambil dari sampleParts.size agar akurat
        val actualCols = if (sampleParts.isNotEmpty()) sampleParts.size else totalCols
        tvColCount.text    = "$actualCols column(s)"

        val saved = ColMappingPrefs.load(this)
        setColIndex(rowSku,     saved.colSku)
        setColIndex(rowBalance, saved.colBalance)
        setColIndex(rowShelf,   saved.colShelf)
        setColIndex(rowPrice,   saved.colPrice)
        setColIndex(rowDesc,    saved.colDesc)
        setColIndex(rowDiscount,  saved.colDiscount)
        setColIndex(rowDiscStart, saved.colDiscStart)
        setColIndex(rowDiscEnd,   saved.colDiscEnd)
        setColIndex(rowLongSku,   saved.colLongSku)
        setColIndex(rowKeepStock, saved.colKeepStock)
        etDisplayOrder.setText(saved.displayOrder)
        rgResultRows.check(if (saved.resultRowCount == 5) R.id.rbRows5 else R.id.rbRows10)

        val allRows = listOf(rowSku, rowBalance, rowShelf, rowPrice, rowDesc,
            rowDiscount, rowDiscStart, rowDiscEnd, rowLongSku, rowKeepStock)
        allRows.forEach { row ->
            getColEdit(row).addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { updateSampleValues() }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        }
        updateSampleValues()

        findViewById<Button>(R.id.btnPreview).setOnClickListener { showPreviewResult() }
        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<Button>(R.id.btnSaveMapping).setOnClickListener { saveAndExit() }
    }

    private fun setupRow(row: View, label: String) {
        row.findViewById<TextView>(R.id.tvFieldName).text = label
    }
    private fun getColEdit(row: View): EditText = row.findViewById(R.id.etColIndex)
    private fun getSampleTv(row: View): TextView = row.findViewById(R.id.tvSampleValue)
    private fun setColIndex(row: View, idx: Int) {
        getColEdit(row).setText(if (idx > 0) idx.toString() else "")
    }
    private fun getColIndex(row: View): Int = getColEdit(row).text.toString().toIntOrNull() ?: 0

    private fun updateSampleValues() {
        val allRows = listOf(rowSku, rowBalance, rowShelf, rowPrice, rowDesc,
            rowDiscount, rowDiscStart, rowDiscEnd, rowLongSku, rowKeepStock)
        allRows.forEach { row ->
            val idx   = getColIndex(row)
            val value = ColMappingPrefs.getCol(sampleParts, idx)
            getSampleTv(row).text = if (idx > 0) "→ \"$value\"" else ""
        }
    }

    private fun showPreviewResult() {
        val values = mapOf(
            "SKU"     to ColMappingPrefs.getCol(sampleParts, getColIndex(rowSku)),
            "BALANCE" to ColMappingPrefs.getCol(sampleParts, getColIndex(rowBalance)),
            "SHELF"   to ColMappingPrefs.getCol(sampleParts, getColIndex(rowShelf)),
            "PRICE"   to ColMappingPrefs.getCol(sampleParts, getColIndex(rowPrice)),
            "DESC"    to ColMappingPrefs.getCol(sampleParts, getColIndex(rowDesc))
        )
        val order        = etDisplayOrder.text.toString().split(",").map { it.trim().uppercase() }
        val displayLines = order.mapNotNull { key -> values[key]?.let { v -> "$key : $v" } }

        tvPreviewSku.text     = displayLines.getOrElse(0) { "" }
        tvPreviewBalance.text = displayLines.getOrElse(1) { "" }
        tvPreviewShelf.text   = displayLines.getOrElse(2) { "" }
        tvPreviewPrice.text   = displayLines.getOrElse(3) { "" }
        tvPreviewDesc.text    = displayLines.getOrElse(4) { "" }
    }

    private fun saveAndExit() {
        val iSku = getColIndex(rowSku)
        if (iSku <= 0) { Toast.makeText(this, "SKU column is required", Toast.LENGTH_SHORT).show(); return }

        val displayOrder = etDisplayOrder.text.toString().trim().ifBlank { ColMappingPrefs.DEFAULT_DISPLAY_ORDER }
        val resultRows   = if (rgResultRows.checkedRadioButtonId == R.id.rbRows5) 5 else 10
        ColMappingPrefs.save(this, ColMappingPrefs.Mapping(
            colSku       = iSku,
            colBalance   = getColIndex(rowBalance),
            colShelf     = getColIndex(rowShelf),
            colPrice     = getColIndex(rowPrice),
            colDesc      = getColIndex(rowDesc),
            colDiscount  = getColIndex(rowDiscount),
            colDiscStart = getColIndex(rowDiscStart),
            colDiscEnd   = getColIndex(rowDiscEnd),
            colLongSku   = getColIndex(rowLongSku),
            colKeepStock = getColIndex(rowKeepStock),
            separator    = separator,
            displayOrder = displayOrder,
            previewRow   = previewRow,
            totalCols    = totalCols,
            userSaved    = true,  // tandai bahwa user sudah set mapping manual
            resultRowCount = resultRows
        ))
        Toast.makeText(this, "Mapping saved", Toast.LENGTH_SHORT).show()
        finish()
    }
}
