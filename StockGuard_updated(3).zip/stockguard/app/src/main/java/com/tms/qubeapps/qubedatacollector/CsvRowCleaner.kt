package com.tms.qubeapps.qubedatacollector

/**
 * ★ CsvRowCleaner — pembersih baris CSV/teks (mis. file 02.txt) supaya SETIAP
 * baris SELALU punya TEPAT 24 kolom sebelum dimasukkan ke SQLite.
 *
 * ★ FIX (baru — "anchor dari pola", bukan tebak index tetap):
 * Sebelumnya versi ini mengasumsikan SEMUA kelebihan kolom (koma ekstra)
 * selalu berasal dari SATU tempat saja, yaitu kolom ke-4 (Desc pendek),
 * lalu langsung digabung balik ke index itu. Ternyata dari data mentah
 * 02.txt asli, ADA DUA kolom yang sama-sama bisa mengandung koma bebas:
 *   - Kolom ke-4  (Desc pendek, mis. "MEN EVA SANDAL BL,PK,PP P2055522M")
 *   - Kolom ke-24 (Desc/Master di akhir baris, mis. "MEN EVA SANDAL BL,PK")
 * Kalau cuma kolom-4 yang digabung sementara kolom-24 JUGA punya koma
 * ekstra, semua kolom DI ANTARA keduanya (kolom 5..23 — termasuk Balance,
 * Discount, tanggal, dst) ikut salah geser posisi.
 *
 * Solusi barunya: kolom 5..23 (19 kolom) itu formatnya SELALU tetap per
 * skema Data Master 02.txt (kode pendek / angka / tanggal dd/mm/yyyy /
 * kosong pada posisi-posisi tertentu yang konsisten). Jadi alih-alih
 * menebak index, kita CARI titik potong yang benar dengan mencocokkan pola
 * 19 kolom tengah itu (anchor), baru semua fragmen SEBELUM titik itu jadi
 * kolom-4 (Desc), dan semua fragmen SESUDAHNYA jadi kolom-24 (Master
 * Desc) — berapa pun banyak komanya di masing-masing sisi.
 *
 * Kalau baris terlalu pendek/aneh sehingga tidak ada titik potong yang
 * cocok dengan pola sama sekali (kasus sangat jarang / data korup),
 * fallback aman ke logika lama (gabung semua kelebihan ke kolom-4) supaya
 * tidak pernah crash dan tetap menghasilkan 24 kolom.
 *
 * Aturan umum:
 *  1. Hitung total elemen hasil split berdasarkan pemisah (default koma).
 *  2. Elemen == 24  -> tidak diubah.
 *  3. Elemen < 24   -> tambahkan "" di akhir sampai tepat 24 kolom.
 *  4. Elemen > 24   -> cari titik potong Desc(kolom-4)/MasterDesc(kolom-24)
 *                      lewat pencocokan pola kolom 5..23, lalu gabungkan
 *                      fragmen di tiap sisi sesuai titik itu.
 */
object CsvRowCleaner {

    /** Jumlah kolom target yang WAJIB dihasilkan untuk tiap baris. */
    const val TARGET_COLUMN_COUNT = 24

    /** Kolom ke-4 (0-based index 3) — tempat elemen berlebih digabungkan kembali
     *  kalau fallback (pencocokan pola gagal total). */
    const val MERGE_COLUMN_INDEX = 3

    // ---- Skema tetap kolom 5..23 (19 kolom, offset 0-based DI DALAM zona
    // tengah, offset = posisi_kolom_1based - 5) hasil analisa baris bersih
    // 02.txt (baris yang jumlah kolomnya persis 24, tanpa ambiguitas):
    //   offset 0..5  : kode pendek bebas (col5..col10)              -> tidak divalidasi ketat
    //   offset 6     : HARUS kosong                                  (col11)
    //   offset 7     : HARUS kosong                                  (col12)
    //   offset 8     : angka desimal, mis. "52000.00"                (col13 - Discount)
    //   offset 9     : tanggal dd/mm/yyyy                            (col14 - Discount Start)
    //   offset 10    : tanggal dd/mm/yyyy                            (col15 - Discount End)
    //   offset 11    : angka desimal, mis. "0.00"                    (col16)
    //   offset 12    : tanggal dd/mm/yyyy                            (col17)
    //   offset 13    : tanggal dd/mm/yyyy                            (col18)
    //   offset 14    : bilangan bulat (tanpa titik/slash)            (col19)
    //   offset 15    : HARUS kosong                                  (col20)
    //   offset 16    : tanggal dd/mm/yyyy                            (col21 - Last Update)
    //   offset 17    : HARUS kosong                                  (col22)
    //   offset 18    : angka (SKU/Long SKU, boleh berisi huruf juga)  (col23)
    private const val MIDDLE_FIXED_COUNT = 19

    /** Offset (0-based, di dalam zona tengah) yang WAJIB kosong. */
    private val EMPTY_OFFSETS = intArrayOf(6, 7, 15, 17)

    /** Offset yang WAJIB berupa bilangan bulat murni (tanpa titik/slash). */
    private const val INTEGER_OFFSET = 14

    /** Offset yang bentuknya angka desimal, mis. "0.00" / "52000.00". */
    private val DECIMAL_OFFSETS = intArrayOf(8, 11)

    /** Offset yang bentuknya tanggal dd/mm/yyyy. */
    private val DATE_OFFSETS = intArrayOf(9, 10, 12, 13, 16)

    private val DECIMAL_REGEX = Regex("""^\d+\.\d{1,2}$""")
    private val DATE_REGEX    = Regex("""^\d{1,2}/\d{1,2}/\d{4}$""")
    private val INTEGER_REGEX = Regex("""^\d+$""")

    /** Berapa kolom pasti di depan sebelum Desc (SKU, Rack, Price) — tidak pernah mengandung koma. */
    private const val FRONT_FIXED_COUNT = 3

    /**
     * Bersihkan SATU baris teks mentah (belum di-split) menjadi List<String>
     * yang panjangnya TEPAT [TARGET_COLUMN_COUNT] (24) elemen.
     *
     * @param line       baris mentah, mis. "SKU001,A01,PK,79500.00,..."
     * @param separator  pemisah kolom, default koma (",")
     */
    fun cleanRow(line: String, separator: String = ","): List<String> {
        // Trim karakter line-ending (CR/LF) di ujung baris supaya tidak ikut
        // menempel di elemen terakhir, tapi TIDAK trim spasi (spasi di dalam
        // elemen/isi kolom tetap dipertahankan apa adanya).
        val cleanedLine = line.trimEnd('\r', '\n')
        val parts = if (cleanedLine.isEmpty()) emptyList() else cleanedLine.split(separator)
        return normalize(parts, separator)
    }

    /**
     * Bersihkan baris yang SUDAH di-split jadi List<String>, memastikan
     * hasilnya TEPAT [TARGET_COLUMN_COUNT] (24) elemen.
     */
    fun normalize(rawParts: List<String>, separator: String = ","): List<String> {
        val parts = rawParts
        return when {
            parts.size > TARGET_COLUMN_COUNT -> mergeExcessSmart(parts, separator).columns
            parts.size < TARGET_COLUMN_COUNT -> padWithEmptyStrings(parts)
            else -> parts
        }
    }

    /**
     * Sama seperti [normalize], tapi juga mengembalikan info apakah proses
     * penggabungan kolom > 24 berhasil DIYAKINI benar (cocok dengan pola
     * kolom 5..23) atau cuma fallback tebakan (butuh dicek manual). Dipakai
     * untuk laporan "baris bermasalah" setelah Download selesai.
     */
    fun normalizeWithConfidence(rawParts: List<String>, separator: String = ","): CleanResult {
        return when {
            rawParts.size > TARGET_COLUMN_COUNT -> mergeExcessSmart(rawParts, separator)
            rawParts.size < TARGET_COLUMN_COUNT -> CleanResult(padWithEmptyStrings(rawParts), confident = true)
            else -> CleanResult(rawParts, confident = true)
        }
    }

    /**
     * @param repaired true kalau baris diperbaiki lewat [repairBrokenRow]
     *                 (port cd_repair_broken_row di ProdMast.py).
     */
    data class CleanResult(val columns: List<String>, val confident: Boolean,
                           val repaired: Boolean = false)

    /**
     * Elemen > 24: cari titik potong Desc(kolom-4) / MasterDesc(kolom-24)
     * dengan mencocokkan pola tetap kolom 5..23 (lihat dokumentasi di atas
     * object ini). Kalau tidak ada titik potong yang cocok pola sama sekali,
     * fallback ke [mergeExcessFixedIndex] (logika lama, gabung semua
     * kelebihan ke kolom-4) supaya tetap aman & tidak pernah crash.
     */
    private fun mergeExcessSmart(parts: List<String>, separator: String): CleanResult {
        val total = parts.size
        // Butuh minimal: 3 (depan) + >=1 (desc) + 19 (tengah) + >=1 (master desc)
        val minRequired = FRONT_FIXED_COUNT + MIDDLE_FIXED_COUNT + 2
        if (total < minRequired) {
            return fallbackWithRepair(parts, separator)
        }

        // k = berapa banyak fragmen mentah yang jadi isi kolom-4 (Desc).
        // Minimal 1 (tidak ada koma ekstra di Desc), maksimal menyisakan
        // minimal 1 fragmen untuk kolom-24 (Master Desc) di ujung.
        val maxK = total - FRONT_FIXED_COUNT - MIDDLE_FIXED_COUNT - 1
        if (maxK < 1) {
            return fallbackWithRepair(parts, separator)
        }

        var bestK: Int = -1
        var bestScore = -1
        for (k in 1..maxK) {
            val start  = FRONT_FIXED_COUNT + k
            val middle = parts.subList(start, start + MIDDLE_FIXED_COUNT)

            // Syarat WAJIB (hard constraint): kolom yang mestinya selalu
            // kosong harus kosong, dan kolom bilangan bulat harus digit murni.
            val emptyOk = EMPTY_OFFSETS.all { middle[it].isBlank() }
            if (!emptyOk) continue
            val intOk = INTEGER_REGEX.matches(middle[INTEGER_OFFSET].trim())
            if (!intOk) continue

            // Skor tambahan (soft check): makin banyak kolom desimal/tanggal
            // yang polanya cocok, makin yakin ini titik potong yang benar.
            var score = 0
            DECIMAL_OFFSETS.forEach { if (DECIMAL_REGEX.matches(middle[it].trim())) score++ }
            DATE_OFFSETS.forEach { if (DATE_REGEX.matches(middle[it].trim())) score++ }

            if (score > bestScore) {
                bestScore = score
                bestK = k
            }
        }

        if (bestK == -1) {
            // Tidak ada kandidat yang lolos syarat wajib -> coba perbaikan regex
            // ala ProdMast.py (cd_repair_broken_row); kalau itu juga gagal baru
            // fallback aman & tandai TIDAK yakin supaya dilaporkan untuk dicek manual.
            return fallbackWithRepair(parts, separator)
        }

        val descEnd   = FRONT_FIXED_COUNT + bestK        // exclusive, akhir zona Desc
        val middleEnd = descEnd + MIDDLE_FIXED_COUNT      // exclusive, akhir zona tengah

        val descJoined       = parts.subList(FRONT_FIXED_COUNT, descEnd).joinToString(separator)
        val masterDescJoined = parts.subList(middleEnd, parts.size).joinToString(separator)

        val result = ArrayList<String>(TARGET_COLUMN_COUNT)
        result.addAll(parts.subList(0, FRONT_FIXED_COUNT))  // col1-3 (SKU, Rack, Price)
        result.add(descJoined)                                // col4  (Desc)
        result.addAll(parts.subList(descEnd, middleEnd))      // col5-23 (19 kolom tetap)
        result.add(masterDescJoined)                          // col24 (Master Desc)
        return CleanResult(result, confident = true)
    }

    /**
     * Tahap fallback sebelum tebakan buta: coba [repairBrokenRow] (port
     * cd_repair_broken_row ProdMast.py) dulu; kalau gagal juga baru
     * [mergeExcessFixedIndex] dengan confident = false.
     */
    private fun fallbackWithRepair(parts: List<String>, separator: String): CleanResult {
        if (separator == ",") {
            val repaired = repairBrokenRow(parts.joinToString(separator))
            if (repaired != null && repaired.size == TARGET_COLUMN_COUNT) {
                return CleanResult(repaired, confident = true, repaired = true)
            }
        }
        return CleanResult(mergeExcessFixedIndex(parts, separator), confident = false)
    }

    // ═══════════════════════════════════════════════════════════════════
    // ★ PERBAIKAN DATA ERROR — port dari ProdMast.py (TAHAP 2 CheckDisc)
    //   cd_merge_broken_lines / cd_repair_broken_row
    // ═══════════════════════════════════════════════════════════════════

    /** Minimal kolom agar sebuah baris dianggap utuh (CD: `< 23` = rusak/terpotong). */
    const val MIN_VALID_COLUMNS = 23

    /** Maksimal baris fisik yang boleh digabung jadi 1 record (CD_MAX_LINE_MERGE). */
    const val MAX_LINE_MERGE = 5

    /**
     * Pola blok tengah baris (CD_ROW_MID_PATTERN):
     * ,,,<harga>,<tgl>,<tgl>,<harga>,<tgl>,<tgl>,<int>,,<tgl>,,
     */
    private val ROW_MID_REGEX = Regex(
        """,,,(\d+\.\d{2}),(\d{2}/\d{2}/\d{4}),(\d{2}/\d{2}/\d{4}),(\d+\.\d{2}),""" +
        """(\d{2}/\d{2}/\d{4}),(\d{2}/\d{2}/\d{4}),(\d+),,(\d{2}/\d{2}/\d{4}),,"""
    )

    /** Penghitung hasil perbaikan, diisi saat sequence [reassembleBrokenLines] dikonsumsi. */
    class RepairStats {
        /** Jumlah record hasil gabung dari >1 baris fisik. */
        var merged = 0
        /** Jumlah baris >24 kolom yang diperbaiki lewat [repairBrokenRow]. */
        var repaired = 0
        /** Jumlah baris < [MIN_VALID_COLUMNS] kolom yang dilewati. */
        var skipped = 0
        /** Contoh SKU/potongan baris yang dilewati (maks 10). */
        val skippedSamples = mutableListOf<String>()
    }

    /**
     * Port cd_merge_broken_lines: baris fisik yang kolomnya < 23 (terpotong
     * enter di tengah deskripsi) disambung (TANPA pemisah, persis seperti
     * versi Python) dengan baris berikutnya selama baris berikutnya TIDAK
     * diawali pola SKU (`^\d+<sep>`), maksimal [MAX_LINE_MERGE] kali.
     * Baris kosong dilewati. Streaming (Sequence) — tidak menahan seluruh file.
     */
    fun reassembleBrokenLines(raw: String, separator: String = ",",
                              stats: RepairStats = RepairStats()): Sequence<String> = sequence {
        val skuStart = Regex("^\\d+" + Regex.escape(separator))
        val iter = raw.lineSequence().map { it.trimEnd('\r', '\n') }.iterator()
        var lookahead: String? = null
        var hasLookahead = false

        while (true) {
            val line: String = if (hasLookahead) {
                hasLookahead = false
                lookahead ?: break
            } else {
                if (iter.hasNext()) iter.next() else break
            }
            if (line.isEmpty()) continue

            var current = line
            var merges = 0
            while (current.split(separator).size < MIN_VALID_COLUMNS && merges < MAX_LINE_MERGE) {
                if (!iter.hasNext()) break
                val next = iter.next()
                if (next.isEmpty() || skuStart.containsMatchIn(next)) {
                    lookahead = next
                    hasLookahead = true
                    break
                }
                current += next
                merges++
            }
            if (merges > 0) stats.merged++
            val finalLine = current.trim()
            if (finalLine.isNotEmpty()) yield(finalLine)
        }
    }

    /**
     * Port cd_repair_broken_row: perbaiki baris > 24 kolom yang blok
     * tengahnya cocok [ROW_MID_REGEX]. Koma di dalam deskripsi diganti ";"
     * dan Master Desc (kolom-24) dipotong 20 karakter, sama seperti versi
     * Python. Mengembalikan null kalau pola tidak cocok / bagian kiri < 9 kolom.
     */
    fun repairBrokenRow(line: String): List<String>? {
        val m = ROW_MID_REGEX.find(line) ?: return null
        val left  = line.substring(0, m.range.first)
        val right = line.substring(m.range.last + 1)
        val leftParts = left.split(",")
        if (leftParts.size < 9) return null

        val sku   = leftParts[0]
        val shelf = leftParts[1]
        val price = leftParts[2]
        val category6    = leftParts.takeLast(6)
        val descFragments = leftParts.subList(3, leftParts.size - 6)
        val descFixed = descFragments.joinToString(",").replace(",", ";")
        val field23 = if (right.isNotEmpty()) right.split(",").first() else sku
        val descTrunc = descFixed.take(20)
        val g = m.groupValues   // g[0] = match penuh, g[1..8] = grup

        val result = ArrayList<String>(TARGET_COLUMN_COUNT)
        result.add(sku); result.add(shelf); result.add(price); result.add(descFixed)
        result.addAll(category6)
        result.add(""); result.add("")
        result.add(g[1]); result.add(g[2]); result.add(g[3]); result.add(g[4])
        result.add(g[5]); result.add(g[6]); result.add(g[7])
        result.add("")
        result.add(g[8])
        result.add("")
        result.add(field23)
        result.add(descTrunc)
        return result
    }

    /**
     * Fallback LAMA (dipakai HANYA kalau pencocokan pola gagal total):
     * gabungkan semua elemen berlebih ke kolom ke-4 saja, seperti versi
     * sebelumnya. Tetap menghasilkan 24 kolom, tapi TIDAK menjamin posisi
     * kolom sesudahnya benar kalau kelebihan sebenarnya juga ada di kolom-24.
     */
    private fun mergeExcessFixedIndex(parts: List<String>, separator: String): List<String> {
        val excess     = parts.size - TARGET_COLUMN_COUNT
        val mergeStart = MERGE_COLUMN_INDEX
        val mergeEnd   = mergeStart + excess

        if (mergeStart < 0 || mergeEnd >= parts.size) {
            return parts.take(TARGET_COLUMN_COUNT)
        }

        val merged = parts.subList(mergeStart, mergeEnd + 1).joinToString(separator)
        val result = ArrayList<String>(TARGET_COLUMN_COUNT)
        result.addAll(parts.subList(0, mergeStart))
        result.add(merged)
        result.addAll(parts.subList(mergeEnd + 1, parts.size))
        return result
    }

    /** Elemen < 24: tambahkan "" di akhir sampai total tepat 24 kolom. */
    private fun padWithEmptyStrings(parts: List<String>): List<String> {
        if (parts.size >= TARGET_COLUMN_COUNT) return parts
        val result = ArrayList<String>(TARGET_COLUMN_COUNT)
        result.addAll(parts)
        while (result.size < TARGET_COLUMN_COUNT) result.add("")
        return result
    }

    /**
     * Sama seperti [cleanRow], tapi juga mengembalikan info apakah proses
     * penggabungan kolom yakin benar (cocok pola) atau cuma fallback tebakan.
     */
    fun cleanRowWithConfidence(line: String, separator: String = ","): CleanResult {
        val cleanedLine = line.trimEnd('\r', '\n')
        val parts = if (cleanedLine.isEmpty()) emptyList() else cleanedLine.split(separator)
        return normalizeWithConfidence(parts, separator)
    }

    /**
     * Sama seperti [cleanRow], tapi hasilnya langsung digabung kembali jadi
     * satu String baris CSV (24 kolom), siap ditulis/di-insert ke SQLite.
     */
    fun cleanLine(line: String, separator: String = ","): String =
        cleanRow(line, separator).joinToString(separator)

    /**
     * Bersihkan SELURUH teks (banyak baris, mis. isi file 02.txt) menjadi
     * daftar baris yang masing-masing SUDAH tepat 24 kolom. Baris kosong
     * (blank) dilewati/di-skip.
     */
    fun cleanText(rawText: String, separator: String = ","): List<String> =
        rawText.lineSequence()
            .filter { it.isNotBlank() }
            .map { cleanLine(it, separator) }
            .toList()

    /**
     * Versi Sequence dari [cleanText] — dipakai kalau file besar dan tidak
     * mau seluruh isinya ditahan penuh di RAM sekaligus (streaming), sama
     * seperti pola yang dipakai di ColMappingPrefs.reassembleRecords().
     */
    fun cleanTextSequence(rawText: String, separator: String = ","): Sequence<String> =
        rawText.lineSequence()
            .filter { it.isNotBlank() }
            .map { cleanLine(it, separator) }
}
