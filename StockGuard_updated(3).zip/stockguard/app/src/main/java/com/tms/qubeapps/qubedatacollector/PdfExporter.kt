package com.tms.qubeapps.qubedatacollector

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * ★ FIX (Menu 5 — Stock Comparison): generate PDF tabel hasil perbandingan
 * stock, siap dicetak. Kolom: SKU, Shelf, Description, Balance, System
 * Balance, Difference, 2nd Check, Remark (2 kolom terakhir dikosongkan untuk
 * diisi manual di kertas cetakan).
 *
 * ★ FIX: tampilan dibuat POLOS hitam-putih (tidak ada warna latar/teks
 * berwarna) supaya mirip cetakan sheet biasa, dan font/kolom diperkecil
 * supaya lebih banyak baris data muat per lembar.
 */
object PdfExporter {

    // Portrait A4 (points)
    private const val PAGE_W = 595f
    private const val PAGE_H = 842f
    private const val MARGIN = 20f
    // ★ FIX: baris & font diperkecil supaya lebih banyak data muat per halaman
    private const val ROW_H  = 15f
    private const val HEADER_H = 18f
    private const val TITLE_H = 34f

    private val headers = listOf("SKU", "Shelf", "Description", "Balance", "Keep Stock", "System Balance", "Difference", "2nd Check", "Remark")
    // Total = 555 (PAGE_W - 2*MARGIN = 555)
    private val colWidths = listOf(65f, 40f, 130f, 50f, 30f, 60f, 55f, 60f, 65f)

    /**
     * ★ FIX (baru — Export PDF): urutkan data berdasarkan WAKTU SCAN (timestamp)
     * sebelum dicetak — Ascending: yang PALING LAMA discan tampil PALING ATAS,
     * yang PALING BARU discan tampil PALING BAWAH. Baris yang belum pernah
     * discan (scanned = false, tidak punya waktu scan) selalu ditaruh di
     * PALING BAWAH, setelah semua baris yang sudah discan.
     * `sortedWith` di Kotlin adalah STABLE SORT, jadi untuk baris dengan kunci
     * urut yang sama urutan aslinya tetap dipertahankan — tidak diacak.
     */
    fun generate(rows: List<ComparisonRow>, title: String = "Stock Comparison Report"): ByteArray {
        val sortedRows = rows.sortedWith(
            compareBy({ !it.scanned }, { it.firstScanId })
        )
        val doc = PdfDocument()
        val usableW = PAGE_W - 2 * MARGIN
        val usableH = PAGE_H - 2 * MARGIN - TITLE_H

        // ★ FIX: semua polos hitam-putih, tidak ada warna latar/teks — seperti cetakan sheet biasa.
        val titlePaint  = Paint().apply { color = Color.BLACK; textSize = 12f; isFakeBoldText = true }
        val subPaint    = Paint().apply { color = Color.BLACK; textSize = 7.5f }
        val headerPaint = Paint().apply { color = Color.BLACK; textSize = 7f; isFakeBoldText = true }
        val cellPaint   = Paint().apply { color = Color.BLACK; textSize = 7f }
        val gridPaint   = Paint().apply { color = Color.BLACK; style = Paint.Style.STROKE; strokeWidth = 0.5f }

        val rowsPerPage = ((usableH - HEADER_H) / ROW_H).toInt().coerceAtLeast(1)
        val totalPages = if (sortedRows.isEmpty()) 1 else Math.ceil(sortedRows.size / rowsPerPage.toDouble()).toInt()

        val dateStr = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())

        for (page in 0 until totalPages) {
            val pageInfo = PdfDocument.PageInfo.Builder(PAGE_W.toInt(), PAGE_H.toInt(), page + 1).create()
            val pdfPage = doc.startPage(pageInfo)
            val canvas: Canvas = pdfPage.canvas

            var y = MARGIN
            canvas.drawText(title, MARGIN, y + 12f, titlePaint)
            canvas.drawText("Printed: $dateStr   |   Page ${page + 1} / $totalPages   |   Total SKU: ${sortedRows.size}",
                MARGIN, y + 22f, subPaint)
            // ★ FIX (baru): keterangan bahwa System Balance sudah dikurangi
            // Stok Keep Stock — dicetak di tiap halaman (versi Inggris).
            canvas.drawText("*Result = (Scan Result + Keep Stock) - System",
                MARGIN, y + 31f, subPaint)
            y += TITLE_H

            // Header row (polos: cuma border + teks bold, tanpa warna latar)
            var x = MARGIN
            headers.forEachIndexed { i, h ->
                canvas.drawText(truncateToWidth(h, headerPaint, colWidths[i] - 4f), x + 2f, y + HEADER_H - 6f, headerPaint)
                canvas.drawRect(x, y, x + colWidths[i], y + HEADER_H, gridPaint)
                x += colWidths[i]
            }
            y += HEADER_H

            val start = page * rowsPerPage
            val end = minOf(start + rowsPerPage, sortedRows.size)
            for (i in start until end) {
                val row = sortedRows[i]
                x = MARGIN
                // ★ FIX: SKU yang belum pernah discan (row.scanned == false, hasil
                // ekspansi filter Shelf) ditandai "BELUM" di kolom Balance & Difference.
                val balanceText = if (row.scanned) row.historyBalance.toString() else "-"
                val diffText = if (!row.scanned) "NOT SCANNED" else if (row.difference > 0) "+${row.difference}" else row.difference.toString()
                val values = listOf(
                    row.sku, row.shelf, row.desc,
                    balanceText, row.keepStock.toString(), row.systemBalance.toString(), diffText,
                    "", ""
                )
                values.forEachIndexed { colIdx, v ->
                    val maxW = colWidths[colIdx] - 4f
                    canvas.drawText(truncateToWidth(v, cellPaint, maxW), x + 2f, y + ROW_H - 4f, cellPaint)
                    canvas.drawRect(x, y, x + colWidths[colIdx], y + ROW_H, gridPaint)
                    x += colWidths[colIdx]
                }
                y += ROW_H
            }

            doc.finishPage(pdfPage)
        }

        val out = ByteArrayOutputStream()
        doc.writeTo(out)
        doc.close()
        return out.toByteArray()
    }

    private fun truncateToWidth(text: String, paint: Paint, maxWidth: Float): String {
        if (paint.measureText(text) <= maxWidth) return text
        var end = text.length
        while (end > 0 && paint.measureText(text.substring(0, end) + "…") > maxWidth) end--
        return if (end <= 0) "" else text.substring(0, end) + "…"
    }

    /**
     * ★ FIX (baru — Export Denah Custom, gaya tabel polos yang sama dengan
     * Stock Comparison): generator tabel generik, dipakai untuk data selain
     * ComparisonRow (mis. daftar No Ctn + posisi + status dari menu Denah).
     * [rows] = list of list String, urutan sesuai [headers]. [colWidths]
     * opsional — kalau tidak diisi, lebar kolom dibagi rata.
     */
    fun generateGenericTable(
        title: String,
        headers: List<String>,
        rows: List<List<String>>,
        colWidths: List<Float>? = null,
        subtitle: String? = null
    ): ByteArray {
        val doc = PdfDocument()
        val usableW = PAGE_W - 2 * MARGIN
        val usableH = PAGE_H - 2 * MARGIN - TITLE_H
        val widths = colWidths ?: List(headers.size) { usableW / headers.size }

        val titlePaint  = Paint().apply { color = Color.BLACK; textSize = 12f; isFakeBoldText = true }
        val subPaint    = Paint().apply { color = Color.BLACK; textSize = 7.5f }
        val headerPaint = Paint().apply { color = Color.BLACK; textSize = 7f; isFakeBoldText = true }
        val cellPaint   = Paint().apply { color = Color.BLACK; textSize = 7f }
        val gridPaint   = Paint().apply { color = Color.BLACK; style = Paint.Style.STROKE; strokeWidth = 0.5f }

        val subLine = subtitle ?: ""
        val titleBlockH = if (subLine.isBlank()) 24f else TITLE_H
        val rowsPerPage = ((usableH - HEADER_H) / ROW_H).toInt().coerceAtLeast(1)
        val totalPages = if (rows.isEmpty()) 1 else Math.ceil(rows.size / rowsPerPage.toDouble()).toInt()
        val dateStr = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())

        for (page in 0 until totalPages) {
            val pageInfo = PdfDocument.PageInfo.Builder(PAGE_W.toInt(), PAGE_H.toInt(), page + 1).create()
            val pdfPage = doc.startPage(pageInfo)
            val canvas: Canvas = pdfPage.canvas

            var y = MARGIN
            canvas.drawText(title, MARGIN, y + 12f, titlePaint)
            canvas.drawText("Printed: $dateStr   |   Page ${page + 1} / $totalPages   |   Total: ${rows.size}", MARGIN, y + 22f, subPaint)
            if (subLine.isNotBlank()) canvas.drawText(subLine, MARGIN, y + 31f, subPaint)
            y += titleBlockH

            var x = MARGIN
            headers.forEachIndexed { i, h ->
                canvas.drawText(truncateToWidth(h, headerPaint, widths[i] - 4f), x + 2f, y + HEADER_H - 6f, headerPaint)
                canvas.drawRect(x, y, x + widths[i], y + HEADER_H, gridPaint)
                x += widths[i]
            }
            y += HEADER_H

            val start = page * rowsPerPage
            val end = minOf(start + rowsPerPage, rows.size)
            for (i in start until end) {
                val row = rows[i]
                x = MARGIN
                row.forEachIndexed { colIdx, v ->
                    val maxW = widths[colIdx] - 4f
                    canvas.drawText(truncateToWidth(v, cellPaint, maxW), x + 2f, y + ROW_H - 4f, cellPaint)
                    canvas.drawRect(x, y, x + widths[colIdx], y + ROW_H, gridPaint)
                    x += widths[colIdx]
                }
                y += ROW_H
            }

            doc.finishPage(pdfPage)
        }

        val out = ByteArrayOutputStream()
        doc.writeTo(out)
        doc.close()
        return out.toByteArray()
    }
}
