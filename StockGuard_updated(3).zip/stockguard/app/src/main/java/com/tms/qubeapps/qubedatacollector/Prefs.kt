package com.tms.qubeapps.qubedatacollector

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private const val NAME = "QubePrefs"

    private fun sp(ctx: Context): SharedPreferences =
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    /** "SMB", "LOCAL", atau "HTTP" — menentukan tujuan Upload to PC */
    var Context.uploadMode: String
        get() = sp(this).getString("upload_mode", "SMB") ?: "SMB"
        set(v) = sp(this).edit().putString("upload_mode", v).apply()

    /** URL HTTP server PC, contoh: http://192.168.1.100:8765 */
    var Context.httpServerUrl: String
        get() = sp(this).getString("http_server_url", "") ?: ""
        set(v) = sp(this).edit().putString("http_server_url", v).apply()

    /** Folder lokal tujuan jika uploadMode = LOCAL.
     *  Kosong = default /storage/emulated/0/QubeOutput */
    var Context.localFolderPath: String
        get() = sp(this).getString("local_folder_path", "") ?: ""
        set(v) = sp(this).edit().putString("local_folder_path", v).apply()

    /** ★ FIX (baru): folder LOCAL khusus untuk UPLOAD/EXPORT output (Scan
     *  Process, Stock Comparison, Expired Discount Checker) — SENGAJA
     *  dipisah dari `localFolderPath` di atas yang dipakai untuk DOWNLOAD
     *  data katalog (02.txt), supaya folder download & upload tidak
     *  bercampur. Kosong = default /storage/emulated/0/QubeOutputUpload */
    var Context.localUploadFolderPath: String
        get() = sp(this).getString("local_upload_folder_path", "") ?: ""
        set(v) = sp(this).edit().putString("local_upload_folder_path", v).apply()

    var Context.smbPath: String
        get() = sp(this).getString("smb_path", "") ?: ""
        set(v) = sp(this).edit().putString("smb_path", v).apply()

    /** ★ FIX (baru): SMB Path khusus untuk UPLOAD/EXPORT output — dipisah
     *  dari `smbPath` di atas yang dipakai untuk DOWNLOAD data katalog (02.txt).
     *  Username/Password/Domain tetap dipakai bersama (biasanya PC yang sama). */
    var Context.smbUploadPath: String
        get() = sp(this).getString("smb_upload_path", "") ?: ""
        set(v) = sp(this).edit().putString("smb_upload_path", v).apply()

    /** ★ FIX (baru): SMB Path output KHUSUS Menu Scan Process (Upload di
     *  ShelfPriceEnquireActivity) — SENGAJA dipisah dari `smbUploadPath`
     *  (dipakai menu lain, mis. Stock Comparison) supaya tiap menu bisa
     *  punya folder tujuan sendiri di server. Diatur lewat dialog "SMB Output
     *  Settings" di layar Scan Process itu sendiri, BUKAN di Setting global.
     *  Kosong = pakai `smbUploadPath` (Setting global) sebagai fallback. */
    var Context.smbUploadPathScanProcess: String
        get() = sp(this).getString("smb_upload_path_scan_process", "") ?: ""
        set(v) = sp(this).edit().putString("smb_upload_path_scan_process", v).apply()

    /** ★ FIX (baru): SMB Path output KHUSUS Menu Expired Discount Checker —
     *  sama seperti di atas, dipisah dari `smbUploadPath` menu lain dan diatur
     *  lewat dialog "SMB Output Settings" di layar Expired Discount Checker
     *  sendiri. Kosong = pakai `smbUploadPath` (Setting global) sebagai fallback. */
    var Context.smbUploadPathExpiredDiscount: String
        get() = sp(this).getString("smb_upload_path_expired_discount", "") ?: ""
        set(v) = sp(this).edit().putString("smb_upload_path_expired_discount", v).apply()

    /** ★ FIX (baru — Menu 4: Data Collector) */
    var Context.dcMode: String
        get() = sp(this).getString("dc_mode", "SHELF_RECORD") ?: "SHELF_RECORD"
        set(v) = sp(this).edit().putString("dc_mode", v).apply()

    var Context.dcScanMethod: String
        get() = sp(this).getString("dc_scan_method", "MANUAL") ?: "MANUAL"
        set(v) = sp(this).edit().putString("dc_scan_method", v).apply()

    /** Kode toko dipakai untuk nama file output Data Collector:
     *  YM_<StoreCode>_<YYYYMMDD>_<HHMMSS>.txt */
    var Context.dcStoreCode: String
        get() = sp(this).getString("dc_store_code", "") ?: ""
        set(v) = sp(this).edit().putString("dc_store_code", v).apply()

    /** SMB Path output KHUSUS Data Collector — sengaja dipisah dari
     *  `smbUploadPath` menu lain, diatur lewat dialog "SMB Output Settings"
     *  di layar Data Collector itu sendiri, BUKAN di Setting global. */
    var Context.smbUploadPathDataCollector: String
        get() = sp(this).getString("smb_upload_path_data_collector", "") ?: ""
        set(v) = sp(this).edit().putString("smb_upload_path_data_collector", v).apply()

    var Context.smbUser: String
        get() = sp(this).getString("smb_user", "admin") ?: "admin"
        set(v) = sp(this).edit().putString("smb_user", v).apply()

    var Context.smbPass: String
        get() = sp(this).getString("smb_pass", "") ?: ""
        set(v) = sp(this).edit().putString("smb_pass", v).apply()

    /** ★ FIX (Autentikasi gagal): domain/workgroup opsional untuk NTLM auth.
     *  Kosongkan kalau PC server tidak join Domain (workgroup biasa/rumahan). */
    var Context.smbDomain: String
        get() = sp(this).getString("smb_domain", "") ?: ""
        set(v) = sp(this).edit().putString("smb_domain", v).apply()

    var Context.fileFormat: String
        get() = sp(this).getString("file_format", "YM") ?: "YM"
        set(v) = sp(this).edit().putString("file_format", v).apply()

    /** Waktu terakhir katalog 02.txt berhasil di-download (epoch millis).
     *  Hanya menyimpan 1 angka (bukan seluruh data), jadi ringan. */
    var Context.catalogUpdatedTime: Long
        get() = sp(this).getLong("catalog_updated_time", 0L)
        set(v) = sp(this).edit().putLong("catalog_updated_time", v).apply()

    /** FIX (APK Download): nama file APK di server, dipakai tombol APK DOWNLOAD di Setting. */
    var Context.apkFileName: String
        get() = sp(this).getString("apk_file_name", "update.apk") ?: "update.apk"
        set(v) = sp(this).edit().putString("apk_file_name", v).apply()

    /** ★ FIX: IP HP terakhir yang terdeteksi, dipakai untuk memberi tahu user
     *  kalau IP berubah dari sesi sebelumnya (supaya alamat di PC bisa disesuaikan
     *  atau user diarahkan untuk pasang IP statis lewat Pengaturan WiFi). */
    var Context.lastKnownIp: String
        get() = sp(this).getString("last_known_ip", "") ?: ""
        set(v) = sp(this).edit().putString("last_known_ip", v).apply()

    /** App language: "system" (follow device), "en" (English, default) or "in" (Indonesian). */
    var Context.appLanguage: String
        get() = sp(this).getString("app_language", LocaleHelper.LANG_ENGLISH) ?: LocaleHelper.LANG_ENGLISH
        set(v) = sp(this).edit().putString("app_language", v).apply()

    /** ★ FIX (Menu 4 — Keep Stock): URL Web App Google Apps Script untuk
     *  fitur "Tambah Data" ke Google Sheets, dan token rahasianya. */
    var Context.ksWebAppUrl: String
        get() = sp(this).getString("ks_webapp_url", "") ?: ""
        set(v) = sp(this).edit().putString("ks_webapp_url", v).apply()

    var Context.ksApiToken: String
        get() = sp(this).getString("ks_api_token", "") ?: ""
        set(v) = sp(this).edit().putString("ks_api_token", v).apply()

    /** ★ FIX (Menu 4 — Keep Stock, Login): kode toko + PIC dari sesi login
     *  terakhir, dipakai untuk pre-fill layar login supaya tidak perlu
     *  ketik ulang tiap buka Menu Keep Stock. */
    var Context.ksLastStore: String
        get() = sp(this).getString("ks_last_store", "") ?: ""
        set(v) = sp(this).edit().putString("ks_last_store", v).apply()

    var Context.ksLastPic: String
        get() = sp(this).getString("ks_last_pic", "") ?: ""
        set(v) = sp(this).edit().putString("ks_last_pic", v).apply()

    /** ★ FIX (Menu 5 — Stock Comparison, 2nd Check → Export ke Google Sheets):
     *  URL Web App Google Apps Script tujuan (diisi bebas/fleksibel oleh user
     *  di dialog Export), disimpan supaya jadi default di export berikutnya. */
    var Context.secondCheckSheetUrl: String
        get() = sp(this).getString("sc_sheet_url", "") ?: ""
        set(v) = sp(this).edit().putString("sc_sheet_url", v).apply()

    var Context.secondCheckSheetToken: String
        get() = sp(this).getString("sc_sheet_token", "") ?: ""
        set(v) = sp(this).edit().putString("sc_sheet_token", v).apply()

    /** ★ FIX (Menu 4 — Keep Stock, Sync IN/OUT): daftar 8 toko yang didukung. */
    val KEEP_STOCK_STORES = listOf("CGAR", "XCMK", "XKLR", "XCIH", "XCMG", "XGKA", "XING", "XGSG")

    /** Konfigurasi per-toko untuk sinkronisasi IN/OUT (porting dari EXINOUT_xxxx.py):
     *  Spreadsheet ID + GID sumber data, dan 2 path SMB tujuan file hasil
     *  (folder "Scan" untuk file label print, folder "Proses" untuk file Excel IN/OUT).
     *  Sengaja per-toko & bisa diisi manual (bukan hardcode) karena tiap toko
     *  punya spreadsheet dan struktur folder PC yang berbeda-beda. */
    fun Context.exioSpreadsheetId(store: String): String =
        sp(this).getString("exio_${store}_ssid", "") ?: ""
    fun Context.setExioSpreadsheetId(store: String, v: String) =
        sp(this).edit().putString("exio_${store}_ssid", v).apply()

    fun Context.exioGid(store: String): String =
        sp(this).getString("exio_${store}_gid", "") ?: ""
    fun Context.setExioGid(store: String, v: String) =
        sp(this).edit().putString("exio_${store}_gid", v).apply()

    /** Full SMB path (smb://host/share/subfolder) tujuan file "+PRINT IN LABEL.txt" & "-PRINT OUT LABEL.txt" */
    fun Context.exioScanPath(store: String): String =
        sp(this).getString("exio_${store}_scanpath", "") ?: ""
    fun Context.setExioScanPath(store: String, v: String) =
        sp(this).edit().putString("exio_${store}_scanpath", v).apply()

    /** Full SMB path (smb://host/share/subfolder) tujuan file "EXCEL IN BOX.txt" & "EXCEL OUT BOX.txt" */
    fun Context.exioProsesPath(store: String): String =
        sp(this).getString("exio_${store}_prosespath", "") ?: ""
    fun Context.setExioProsesPath(store: String, v: String) =
        sp(this).edit().putString("exio_${store}_prosespath", v).apply()

    /** Nama file output — sama persis dengan nama file di EXINOUT_xxxx.py, tidak diubah
     *  supaya tetap kompatibel dengan software EBarcode/print label yang sudah ada di PC. */
    const val EXIO_FILE1 = "EXCEL IN BOX.txt"
    const val EXIO_FILE2 = "+PRINT IN LABEL.txt"
    const val EXIO_FILE3 = "EXCEL OUT BOX.txt"
    const val EXIO_FILE4 = "-PRINT OUT LABEL.txt"

    /** Nama file output: format fileFormat + timestamp */
    fun outFileName(ctx: Context, prefix: String): String {
        val fmt = ctx.fileFormat
        val ts = java.text.SimpleDateFormat("yyMMddHHmm", java.util.Locale.getDefault())
            .format(java.util.Date())
        return "${prefix}_${fmt}_$ts.txt"
    }
}
