package com.tms.qubeapps.qubedatacollector

import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * ★ FIX (Menu 6 — Keep Stock, Sync IN/OUT): porting dari EXINOUT_xxxx.py,
 * REVISI TOTAL ke sistem sinkronisasi berbasis KELUARGA SKU (bukan lagi
 * keluarga No Ctn via suffix huruf).
 *
 * ═══════════════════════════════════════════════════════════════════════
 * DEFINISI
 * ═══════════════════════════════════════════════════════════════════════
 * - SKU     : identifier unik item (kolom C / barcode).
 * - No Ctn  : nomor container/lokasi (kolom B).
 * - Kunci   : setiap record diidentifikasi (No Ctn, SKU) -> "NoCtn|SKU".
 * - Keluarga: SEMUA relasi No Ctn yang masih terhubung ke SKU yang sama,
 *             DI SELURUH snapshot baru (bukan lagi dikelompokkan lewat
 *             kemiripan kode No Ctn / suffix huruf seperti versi lama).
 * - Snapshot Lama: kunci aktif tersimpan di state (SQLite) dari sync terakhir.
 * - Snapshot Baru: hasil parsing CSV Google Sheets saat ini.
 *
 * ═══════════════════════════════════════════════════════════════════════
 * STATUS
 * ═══════════════════════════════════════════════════════════════════════
 * - IN       : kunci baru, SKU-nya juga belum pernah OUT sebelumnya.
 * - RE-IN    : kunci baru, TAPI SKU-nya pernah tercatat OUT sebelumnya
 *              (dianggap aktif kembali; dihapus dari riwayat OUT).
 * - OUT      : kunci hilang dari snapshot baru DAN SKU-nya sudah tidak
 *              muncul di No Ctn manapun pada snapshot baru.
 * - ACTIVE / MOVE: kunci hilang, TAPI SKU-nya masih muncul di No Ctn lain
 *              pada snapshot baru -> TIDAK di-OUT-kan (kunci lama otomatis
 *              gugur dari state, kunci baru sudah tercatat lewat IN).
 * - DUPLICATE: kombinasi (No Ctn, SKU) yang sama muncul >1 kali dalam satu
 *              snapshot -> hanya diproses sekali, sisanya dicatat di log
 *              dan tidak diproses ulang.
 * - INVALID  : No Ctn kosong tapi SKU ada, atau sebaliknya -> dicatat di
 *              log dan dilewati (tidak diproses).
 * - IGNORE   : No Ctn dan SKU dua-duanya kosong -> dilewati tanpa log.
 *
 * ═══════════════════════════════════════════════════════════════════════
 * RULE PALING PENTING
 * ═══════════════════════════════════════════════════════════════════════
 * OUT hanya terjadi jika KEDUA syarat terpenuhi:
 *   1. Kombinasi (No Ctn, SKU) hilang dari snapshot baru.
 *   2. SKU tersebut sudah tidak punya hubungan aktif di No Ctn manapun
 *      pada snapshot baru.
 * Kalau salah satu syarat belum terpenuhi -> ACTIVE atau MOVE (bukan OUT).
 *
 * Evaluasi memakai Snapshot Awal (state) vs Snapshot Akhir (CSV saat ini),
 * bukan perubahan per langkah.
 *
 * Di Android: state disimpan di SQLite (AppDatabase.getExioKeys/saveExioKeys
 * untuk kunci aktif, getExioOutKeys/saveExioOutKeys untuk riwayat OUT/RE-IN),
 * dan file hasil dikirim lewat SMB memakai path yang dikonfigurasi per toko.
 *
 * ═══════════════════════════════════════════════════════════════════════
 * ★ FIX (baru — dipisah jadi 2 lapis: computeSync() murni vs sync() I/O):
 * ═══════════════════════════════════════════════════════════════════════
 * Sebelumnya seluruh parsing CSV + perhitungan IN/OUT/MOVE bercampur
 * langsung dengan network call (download CSV) dan akses SQLite (AppDatabase)
 * di satu fungsi sync(). Ini bikin logika inti TIDAK BISA diuji otomatis
 * (unit test) tanpa emulator Android — jadi setiap perubahan logika cuma
 * bisa divalidasi manual di HP, resiko bug lolos ke lapangan tinggi.
 *
 * Sekarang dipecah:
 *   - computeSync()  : FUNGSI MURNI (pure function). Terima teks CSV +
 *     state lama (Set<String>) sebagai parameter, kembalikan hasil hitung
 *     sebagai data class — TIDAK ada network call, TIDAK ada akses
 *     AppDatabase/Android sama sekali. Bisa dites langsung di JVM biasa
 *     (lihat app/src/test/.../ExInOutSyncTest.kt) tanpa emulator.
 *   - sync()         : pembungkus tipis — download CSV, baca state dari
 *     AppDatabase, panggil computeSync(), simpan hasilnya balik ke
 *     AppDatabase. Tidak ada logika bisnis di sini lagi, jadi kecil
 *     kemungkinan ada bug baru muncul di lapisan ini.
 */
object ExInOutSync {

    private const val RANGE = "B6:AI2000"
    private const val B_COL_INDEX = 0   // kolom B (index 0 karena range mulai dari B)
    private const val C_COL_INDEX = 1   // kolom C

    // ★ FIX (baru — sanity check): kalau jumlah OUT dalam SATU run melebihi
    // ambang ini (baik secara jumlah absolut maupun proporsi terhadap total
    // kunci aktif sebelumnya), ini indikasi kuat sheet salah gid/salah toko/
    // ter-clear tidak sengaja — BUKAN perubahan stok wajar. Sync tetap
    // diproses (tidak diblokir, supaya tidak mengganggu operasional), tapi
    // ditandai WARNING yang jelas di log supaya user sadar & bisa cek ulang
    // sebelum upload hasilnya ke server.
    private const val MASS_OUT_ABS_THRESHOLD = 20
    private const val MASS_OUT_RATIO_THRESHOLD = 0.5
    // ★ FIX (baru — cegah false positive di toko kecil): cek rasio HANYA
    // berlaku kalau jumlah kunci aktif sebelumnya cukup besar. Tanpa ini,
    // toko dengan cuma 2 kunci aktif & 1 SKU OUT wajar (rasio 50%) akan
    // salah ditandai WARNING padahal itu perubahan normal.
    private const val MASS_OUT_RATIO_MIN_SAMPLE = 10

    data class SyncResult(
        val store: String,
        val newInCount: Int,
        val outCount: Int,
        val file1: String, // EXCEL IN BOX.txt
        val file2: String, // +PRINT IN LABEL.txt
        val file3: String, // EXCEL OUT BOX.txt
        val file4: String, // -PRINT OUT LABEL.txt
        val hasNewIn: Boolean,
        val log: List<String>,
        // ★ FIX (poin 3): state hasil hitung IKUT dibawa di sini, TAPI belum
        // disimpan ke SQLite. Baru dipersist lewat commitState() setelah
        // caller memastikan file1-4 SUKSES terkirim (mis. SMB upload OK).
        // Ini mencegah kunci dianggap "sudah diproses" padahal datanya
        // gagal terkirim (lihat penjelasan lengkap di commitState()).
        val updatedKeys: Set<String>,
        val updatedOutHistory: Set<String>
    )

    /** ★ FIX (baru): hasil computeSync() — dipakai baik oleh sync() (Android)
     *  maupun langsung oleh unit test (JVM murni, tanpa Android). */
    data class SyncCompute(
        val out1: List<String>,
        val out2: List<String>,
        val out3: List<String>,
        val out4: List<String>,
        val foundNew: Boolean,
        val foundOut: Boolean,
        val updatedKeys: Set<String>,
        val updatedOutHistory: Set<String>,
        val log: List<String>
    )

    /** Harus dipanggil dari Dispatchers.IO — melakukan network call + query DB
     *  (read-only untuk state lama).
     *
     * ★ FIX (poin 3 — perbaikan sinkronisasi):
     * SEBELUMNYA fungsi ini langsung memanggil db.saveExioKeys()/
     * db.saveExioOutKeys() di sini, TEPAT setelah computeSync(), SEBELUM
     * file hasilnya benar-benar terkirim (SMB upload) ke PC. Akibatnya:
     * kalau upload gagal (network error/upload gagal tersimpan), state di
     * SQLite SUDAH TERLANJUR terkunci seolah-olah kunci itu sudah
     * diproses. Saat user coba sync ulang, snapshot lama (state) sudah
     * dianggap sama dengan snapshot baru -> baris itu tidak lagi terdeteksi
     * sebagai IN/OUT baru -> datanya HILANG, tidak pernah terkirim.
     *
     * FIX: fungsi ini sekarang HANYA membaca CSV + state lama, menghitung
     * hasil (computeSync — tetap murni), dan MENGEMBALIKAN state hasil
     * hitung ke caller TANPA menyimpannya ke SQLite. Penyimpanan (lock)
     * dipindah ke commitState(), yang WAJIB dipanggil caller HANYA SETELAH
     * file1-4 dipastikan sukses terkirim. Kalau upload gagal, caller cukup
     * TIDAK memanggil commitState() — maka retry berikutnya akan membaca
     * state lama (belum berubah) dan menghitung ulang dengan benar,
     * termasuk baris yang gagal terkirim di percobaan sebelumnya. */
    fun sync(db: AppDatabase, store: String, spreadsheetId: String, gid: String): SyncResult {
        val encodedRange = URLEncoder.encode(RANGE, "UTF-8")
        val csvUrl = "https://docs.google.com/spreadsheets/d/$spreadsheetId/export" +
            "?format=csv&gid=$gid&range=$encodedRange"
        val csvData = httpGet(csvUrl)
        if (csvData.isBlank()) throw Exception("Data CSV kosong. Cek Spreadsheet ID/GID untuk toko $store di Setting.")

        val processedKeys = db.getExioKeys(store)      // Snapshot Lama (kunci aktif)
        val outHistory = db.getExioOutKeys(store)       // riwayat kunci yang pernah OUT

        val result = computeSync(csvData, processedKeys, outHistory)

        return SyncResult(
            store = store,
            newInCount = result.out1.size,
            outCount = result.out3.size,
            file1 = result.out1.joinToString("\r\n"),
            file2 = result.out2.joinToString("\r\n"),
            file3 = result.out3.joinToString("\r\n"),
            file4 = result.out4.joinToString("\r\n"),
            hasNewIn = result.foundNew,
            log = result.log,
            updatedKeys = result.updatedKeys,
            updatedOutHistory = result.updatedOutHistory
        )
    }

    /** ★ FIX (baru): kunci (persist) state hasil sync() ke SQLite.
     *  WAJIB dipanggil oleh caller HANYA SETELAH file1-4 dari [SyncResult]
     *  dipastikan sukses terkirim (mis. semua SmbUploader.upload() sukses,
     *  tidak ada exception). Kalau dipanggil sebelum itu, kita balik lagi
     *  ke bug lama (state terkunci walau data belum terkirim). */
    fun commitState(db: AppDatabase, result: SyncResult) {
        db.saveExioKeys(result.store, result.updatedKeys)
        db.saveExioOutKeys(result.store, result.updatedOutHistory)
    }

    // ═══════════════════════════════════════════════════════════════════
    // ★ FIX (baru — Outbox Pattern, lapis proteksi TAMBAHAN di atas pemisahan
    // compute/commit di atas):
    //
    // Pemisahan sync()/commitState() di atas sudah mencegah data hilang kalau
    // terjadi EXCEPTION (network error, SMB gagal, dll) — karena commitState()
    // baru dipanggil setelah upload sukses.
    //
    // TAPI itu masih rentan pada 1 skenario lain: kalau APLIKASI SENDIRI mati
    // di tengah proses (force-close oleh user, OS membunuh proses karena
    // kehabisan memori, HP restart, dsb) SEBELUM upload selesai — bukan
    // exception yang bisa ditangkap try/catch, tapi proses berhenti total.
    // Kalau itu terjadi, SyncResult yang sudah dihitung (ada di variabel
    // lokal/memori) IKUT HILANG bersama matinya proses. User buka app lagi,
    // sync ulang akan menghitung ULANG dari awal — secara teori ini masih
    // "aman" (karena state SQLite belum berubah, sesuai fix di atas), TAPI:
    //   1. Boros: harus download CSV & hitung ulang dari nol.
    //   2. Kalau ternyata data di Google Sheets SUDAH BERUBAH LAGI sebelum
    //      user sempat retry, hasil hitung baru bisa BEDA dari yang harusnya
    //      terkirim sebelumnya — berpotensi ada perubahan yang "terlewat"
    //      di antara waktu itu (bukan hilang permanen, tapi tercampur dengan
    //      perubahan berikutnya sehingga log historinya kurang presisi).
    //
    // SOLUSI: sebelum upload SAMA SEKALI dimulai, hasil compute (file1-4 +
    // updatedKeys/updatedOutHistory) disimpan dulu ke tabel exio_outbox di
    // SQLite ("staging"). Kalau proses mati di tengah upload, data yang SUDAH
    // DIHITUNG itu tetap ada di SQLite, dan sync berikutnya akan otomatis
    // MELANJUTKAN (resume) upload dari payload yang SAMA persis — bukan
    // menghitung ulang dari nol dan bukan pula kehilangan diff yang sudah
    // dihitung. Baris outbox baru dihapus (clearOutbox) setelah SEMUA file
    // dipastikan sukses terkirim DAN state sudah di-commit ke exio_state.
    // ═══════════════════════════════════════════════════════════════════

    /** Simpan hasil compute ke staging (exio_outbox) SEBELUM upload dimulai. */
    fun saveOutboxPending(db: AppDatabase, result: SyncResult) {
        db.saveExioOutbox(result.store, result)
    }

    /** Ambil payload pending dari percobaan sync sebelumnya yang belum selesai
     *  (belum ter-commit), kalau ada. Null kalau tidak ada sync yang "menggantung"
     *  untuk toko ini — berarti aman untuk compute baru dari sync(). */
    fun loadPendingOutbox(db: AppDatabase, store: String): SyncResult? {
        return db.getExioOutbox(store)
    }

    /** Hapus staging setelah dipastikan SEMUA file terkirim & state ter-commit. */
    fun clearOutbox(db: AppDatabase, store: String) {
        db.deleteExioOutbox(store)
    }

    /**
     * ★ FIX (baru): FUNGSI MURNI — semua logika bisnis Sync IN/OUT ada di sini.
     * TIDAK ada network call, TIDAK ada akses AppDatabase/Android. Hanya
     * menerima teks CSV mentah + state lama, mengembalikan hasil hitung.
     * Ini yang memungkinkan unit test dijalankan di JVM biasa tanpa emulator.
     *
     * @param csvData teks CSV mentah (belum di-split per baris)
     * @param processedKeys Snapshot Lama — kunci (No Ctn|SKU) aktif dari sync sebelumnya
     * @param outHistory riwayat kunci yang pernah OUT (dipakai deteksi RE-IN)
     */
    fun computeSync(
        csvData: String,
        processedKeys: Set<String>,
        outHistory: Set<String>
    ): SyncCompute {
        val log = mutableListOf<String>()
        fun logLine(s: String) { log.add(s) }

        val allLines = csvData.replace("\r\n", "\n").replace("\r", "\n").split("\n")
        logLine("Total baris CSV: ${allLines.size}")
        logLine("Kunci di state (Snapshot Lama): ${processedKeys.size}")
        logLine("Riwayat OUT tersimpan: ${outHistory.size}")

        val outHistoryMutable = outHistory.toMutableSet()
        val out1 = mutableListOf<String>()
        val out2 = mutableListOf<String>()
        val out3 = mutableListOf<String>()
        val out4 = mutableListOf<String>()
        var foundNew = false
        var foundOut = false

        // ── 3. Validasi Data + 4. Deteksi DUPLICATE ───────────────────────
        data class Row(val b: String, val c: String, val key: String)
        val parsedRows = mutableListOf<Row>()
        val seenKeysThisRun = HashSet<String>()
        var invalidCount = 0
        var duplicateCount = 0

        for (line in allLines) {
            if (line.isBlank()) continue
            val cols = parseCsvLine(line)
            if (cols.size <= C_COL_INDEX) continue

            val bVal = cols[B_COL_INDEX].trim()
            val cVal = cols[C_COL_INDEX].trim()

            // IGNORE: dua-duanya kosong -> lewati tanpa log
            if (bVal.isBlank() && cVal.isBlank()) continue

            // INVALID: salah satu kosong, atau SKU bukan angka murni
            if (bVal.isBlank() || cVal.isBlank() || !cVal.all { it.isDigit() }) {
                invalidCount++
                logLine("  INVALID: No Ctn='$bVal' SKU='$cVal' -> dilewati")
                continue
            }

            val key = "$bVal|$cVal"

            // DUPLICATE: kombinasi (No Ctn, SKU) yang sama sudah diproses di run ini
            if (key in seenKeysThisRun) {
                duplicateCount++
                logLine("  DUPLICATE: [$key] muncul lebih dari 1x di snapshot -> hanya diproses sekali")
                continue
            }
            seenKeysThisRun.add(key)
            parsedRows.add(Row(bVal, cVal, key))
        }

        val activeKeys = parsedRows.map { it.key }.toSet()           // Snapshot Baru (kunci aktif)
        val activeSkus = parsedRows.map { it.c }.toSet()             // SKU yang hidup di snapshot baru (di mana pun)
        if (invalidCount > 0) logLine("Total INVALID: $invalidCount baris dilewati")
        if (duplicateCount > 0) logLine("Total DUPLICATE: $duplicateCount baris dilewati")

        // ── 5. Deteksi IN / RE-IN ──────────────────────────────────────────
        val newKeys = LinkedHashSet<String>()
        for (row in parsedRows) {
            if (row.key !in processedKeys) {
                out1.add("${row.b.take(4)},${row.c}")
                out2.add("${row.c},1")
                newKeys.add(row.key)
                foundNew = true
                if (row.key in outHistoryMutable) {
                    outHistoryMutable.remove(row.key)
                    logLine("  [${row.key}] RE-IN (sebelumnya pernah OUT, sekarang aktif lagi)")
                } else {
                    logLine("  [${row.key}] IN (baru)")
                }
            }
        }

        // ── 6, 7, 8, 9. MOVE / DELETE CANDIDATE / Family Validation / Generate OUT ──
        val updatedKeys: Set<String>
        if (activeKeys.isNotEmpty()) {
            val removedKeys = processedKeys - activeKeys  // DELETE CANDIDATE
            updatedKeys = LinkedHashSet((processedKeys + newKeys).intersect(activeKeys))

            // ★ FIX: cegah SKU sama OUT 2x kalau lebih dari 1 kunci lama (No Ctn
            // beda) untuk SKU yang sama sama-sama hilang & SKU-nya benar-benar
            // sudah tidak aktif di mana pun — hanya proses OUT SEKALI per SKU
            // dalam 1 run ini.
            val outSkusThisRun = HashSet<String>()

            if (removedKeys.isNotEmpty()) {
                logLine("Kunci hilang dari snapshot baru (delete candidate): ${removedKeys.size}")

                for (rkey in removedKeys.sorted()) {
                    val parts = rkey.split("|", limit = 2)
                    if (parts.size != 2) continue
                    val cFromKey = parts[1]

                    // Family Validation: SKU masih hidup di No Ctn manapun pada snapshot baru?
                    if (cFromKey in activeSkus) {
                        // ★ FIX: kunci lama TIDAK di-add balik ke updatedKeys — kunci
                        // lama yang sudah tidak ada di CSV harus benar-benar gugur
                        // dari state (sebelumnya ini bug: kunci lama nyangkut
                        // permanen). Lokasi baru untuk SKU ini sudah otomatis masuk
                        // updatedKeys lewat intersect di atas (ada di newKeys &
                        // activeKeys), jadi cukup log saja di sini.
                        logLine("  [$rkey] ACTIVE/MOVE — SKU=$cFromKey masih ada di No Ctn lain, SKIP OUT")
                    } else if (cFromKey in outSkusThisRun) {
                        logLine("  [$rkey] SKIP — SKU=$cFromKey sudah diproses OUT dari kunci lain di run ini")
                        outHistoryMutable.add(rkey)
                    } else {
                        out3.add(",$cFromKey")
                        out4.add("$cFromKey,3")
                        foundOut = true
                        outHistoryMutable.add(rkey)
                        outSkusThisRun.add(cFromKey)
                        logLine("  [$rkey] OUT — SKU=$cFromKey sudah tidak ada di No Ctn manapun")
                    }
                }
            }

            logLine("State diperbarui: ${updatedKeys.size} kunci aktif, ${outHistoryMutable.size} riwayat OUT tersimpan")
        } else {
            logLine("Snapshot baru kosong (tidak ada baris valid) — state lama dipertahankan, tidak ada OUT diproses")
            updatedKeys = if (newKeys.isNotEmpty()) processedKeys + newKeys else processedKeys
        }

        // ── 11. Orphan Validation (sanity check ringan) ───────────────────
        // Struktur data (No Ctn, SKU) sudah menjamin tidak ada SKU aktif tanpa
        // No Ctn atau sebaliknya (satu kunci selalu punya keduanya), jadi tidak
        // perlu pengecekan orphan terpisah di sini.

        // ── 12. ★ FIX (baru) — Sanity Check Mass OUT ───────────────────────
        // OUT dalam jumlah besar sekaligus (baik secara jumlah maupun proporsi
        // terhadap total kunci aktif sebelumnya) HAMPIR SELALU tanda sheet
        // salah gid/salah toko/ke-clear tidak sengaja, bukan stok yang memang
        // benar-benar keluar semua. Tidak diblokir otomatis (biar tidak
        // mengganggu kasus yang memang valid, misal toko tutup total), tapi
        // ditandai jelas di log supaya user cek ulang sebelum upload ke server.
        if (out3.isNotEmpty()) {
            val ratio = if (processedKeys.isNotEmpty()) out3.size.toDouble() / processedKeys.size else 0.0
            val ratioTriggered = processedKeys.size >= MASS_OUT_RATIO_MIN_SAMPLE && ratio >= MASS_OUT_RATIO_THRESHOLD
            if (out3.size >= MASS_OUT_ABS_THRESHOLD || ratioTriggered) {
                logLine("⚠ WARNING: OUT sekaligus ${out3.size} SKU " +
                    "(${(ratio * 100).toInt()}% dari ${processedKeys.size} kunci aktif sebelumnya). " +
                    "Cek ulang Spreadsheet ID/GID toko ini sebelum upload — kemungkinan sheet salah/ter-clear.")
            }
        }

        if (foundNew) logLine("IN/RE-IN OK: ${out1.size} baris")
        else logLine("IN/RE-IN - tidak ada data baru")
        if (foundOut) logLine("OUT OK: ${out3.size} baris (SKU sudah tidak aktif di No Ctn manapun)")
        else logLine("OUT - tidak ada SKU yang benar-benar hilang, FILE3 & FILE4 kosong")

        return SyncCompute(
            out1 = out1, out2 = out2, out3 = out3, out4 = out4,
            foundNew = foundNew, foundOut = foundOut,
            updatedKeys = updatedKeys, updatedOutHistory = outHistoryMutable,
            log = log
        )
    }

    /** Porting dari parse_csv_line() di EXINOUT_xxxx.py — CSV parser sadar tanda kutip. */
    private fun parseCsvLine(line: String): List<String> {
        val cols = mutableListOf<String>()
        val current = StringBuilder()
        var inQuotes = false
        for (ch in line) {
            when {
                ch == '"' -> inQuotes = !inQuotes
                ch == ',' && !inQuotes -> {
                    cols.add(current.toString().trim().trim('"').trim())
                    current.clear()
                }
                else -> current.append(ch)
            }
        }
        cols.add(current.toString().trim().trim('"').trim())
        return cols.map { it.trim() }
    }

    private fun httpGet(url: String): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.requestMethod = "GET"
        conn.setRequestProperty("User-Agent", "Mozilla/5.0")
        conn.connectTimeout = 20000
        conn.readTimeout = 30000
        try {
            if (conn.responseCode !in 200..299) {
                throw Exception("HTTP ${conn.responseCode} saat download CSV. Pastikan spreadsheet bisa diakses publik (Share > Anyone with link > Viewer).")
            }
            return conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }
}
