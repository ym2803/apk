package com.tms.qubeapps.qubedatacollector

/**
 * ★ FIX (baru — Auto-Generate Denah): logika umum untuk:
 *  1. Membangkitkan posisi (kolom,baris) urutan kode dasar (mis. A001..A129)
 *     memakai pola "serpentine" grid — kelompok kolom TETAP dengan baris
 *     berjalan (ROWS_FIRST), atau kelompok baris TETAP dengan kolom berjalan
 *     (COLS_FIRST). Divalidasi cocok 1:1 dengan 3 cluster di contoh denah
 *     user (lihat penjelasan chat): cluster kiri & kanan-atas pakai
 *     ROWS_FIRST (kolom 2-4 tetap / 22-24 tetap, baris turun), cluster
 *     tengah pakai COLS_FIRST (kolom 5-21 naik, baris siklus 17-19).
 *  2. Membangkitkan "alias" untuk kode akhiran huruf A-Z (mis. A001A..Z)
 *     yang TIDAK punya kotak sendiri — posisinya = posisi kode dasar ke-
 *     (index + offset huruf) DALAM URUTAN YANG SAMA (bukan berdasarkan
 *     angka literal, supaya tetap benar walau urutannya ada gap/tidak
 *     berurutan sempurna). Offset habis (lewat akhir urutan) -> alias
 *     tidak dibuat sama sekali (kosong), sesuai konfirmasi user.
 */
object DenahAutoGenerator {

    enum class GridMode { ROWS_FIRST, COLS_FIRST }

    /**
     * Bangkitkan urutan posisi (x=kolom, y=baris) sepanjang [count] kotak,
     * dengan pola serpentine sesuai [mode].
     *
     * ROWS_FIRST: "outer" = baris (outerStart..outerEnd step outerStep,
     *             lewati nilai di outerSkip), "inner" = kolom. Untuk tiap
     *             baris yang tidak di-skip, isi semua kolom inner dulu
     *             sebelum pindah ke baris berikutnya.
     * COLS_FIRST: kebalikannya — "outer" = kolom, "inner" = baris.
     *
     * [zigzag]: kalau true, arah "inner" DIBALIK setiap kali pindah ke
     * outer berikutnya (baris/kolom genap jalan mundur) — pola ular
     * (boustrophedon), dipakai untuk "Direction Flow: Zig-zag".
     *
     * Berhenti otomatis begitu sudah menghasilkan [count] posisi, walau
     * range outer/inner yang diberikan masih panjang (supaya user bisa
     * kasih range longgar tanpa perlu hitung pas).
     */
    fun generateGridPositions(
        mode: GridMode,
        outerStart: Int, outerEnd: Int, outerStep: Int, outerSkip: Set<Int>,
        innerStart: Int, innerEnd: Int, innerStep: Int, innerSkip: Set<Int>,
        count: Int,
        zigzag: Boolean = false
    ): List<Pair<Int, Int>> {
        val result = mutableListOf<Pair<Int, Int>>()
        if (outerStep == 0 || innerStep == 0 || count <= 0) return result

        fun innerRange(reversed: Boolean): List<Int> {
            val list = mutableListOf<Int>()
            var v = innerStart
            while (if (innerStep > 0) v <= innerEnd else v >= innerEnd) { list.add(v); v += innerStep }
            return if (reversed) list.asReversed() else list
        }

        var outer = outerStart
        var pass = 0
        while (if (outerStep > 0) outer <= outerEnd else outer >= outerEnd) {
            if (outer !in outerSkip) {
                val reversed = zigzag && (pass % 2 == 1)
                for (inner in innerRange(reversed)) {
                    if (inner !in innerSkip) {
                        val pos = if (mode == GridMode.ROWS_FIRST) inner to outer else outer to inner
                        result.add(pos)
                        if (result.size >= count) return result
                    }
                }
                pass++
            }
            outer += outerStep
        }
        return result
    }

    /**
     * ★ FIX (baru — "Auto-Fit Block", mirip Insert Table Word): hitung
     * dimensi kolom x baris yang paling "pas" (mendekati persegi) buat
     * menampung [count] kode, dipakai saat user tidak isi ukuran manual.
     */
    fun autoFitDims(count: Int): Pair<Int, Int> {
        if (count <= 0) return 1 to 1
        val cols = Math.ceil(Math.sqrt(count.toDouble())).toInt().coerceAtLeast(1)
        val rows = Math.ceil(count.toDouble() / cols).toInt().coerceAtLeast(1)
        return cols to rows
    }

    /** Parse "37" atau "37,40,41" jadi Set<Int>. Input kosong/invalid -> set kosong (tidak ada yang di-skip). */
    fun parseSkipList(text: String): Set<Int> =
        text.split(",", " ")
            .mapNotNull { it.trim().toIntOrNull() }
            .toSet()

    /**
     * Bangkitkan alias A-Z untuk tiap kode dalam [sequenceCodes] (urutan
     * index 0-based = urutan fisik kode itu, BUKAN angkanya). Untuk kode
     * ke-i, alias huruf ke-L (A=0..Z=25) merujuk ke kode index (i+L) dalam
     * urutan yang sama. Begitu (i+L) lewat akhir urutan, huruf itu DAN
     * seluruh huruf sesudahnya untuk kode ke-i tidak dibuat (blank).
     */
    fun generateSuffixAliases(sequenceCodes: List<String>): List<DenahLayoutPrefs.Alias> {
        val result = mutableListOf<DenahLayoutPrefs.Alias>()
        for (i in sequenceCodes.indices) {
            for (letterIdx in 0 until 26) {
                val targetIdx = i + letterIdx
                if (targetIdx >= sequenceCodes.size) break // sisa huruf pasti blank juga, berhenti di sini
                val letter = ('A' + letterIdx)
                result.add(DenahLayoutPrefs.Alias(code = "${sequenceCodes[i]}$letter", baseNoCtn = sequenceCodes[targetIdx]))
            }
        }
        return result
    }
}
