package com.tms.qubeapps.qubedatacollector

import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.OpenableColumns
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Vault tersembunyi — dibuka dari kalkulator dengan kode rahasia.
 * Tiga fitur utama:
 *   1. Apps  – simpan shortcut app "tersembunyi" dan luncurkan dari sini.
 *   2. Media – sembunyikan foto & video dari Gallery.
 *   3. Files – sembunyikan dokumen & file lainnya.
 *
 * File yang disembunyikan dipindah ke direktori privat app (filesDir/vault/)
 * sehingga tidak terindeks oleh MediaStore dan tidak terlihat di Gallery
 * maupun File Manager biasa.
 */
class VaultActivity : BaseActivity() {

    // ── Views ──────────────────────────────────────────────────────────────
    private lateinit var btnTabApps:  TextView
    private lateinit var btnTabMedia: TextView
    private lateinit var btnTabFiles: TextView
    private lateinit var sectionApps:  View
    private lateinit var sectionMedia: View
    private lateinit var sectionFiles: View
    private lateinit var lvApps:  ListView
    private lateinit var lvMedia: ListView
    private lateinit var lvFiles: ListView
    private lateinit var tvAppsEmpty:  TextView
    private lateinit var tvMediaEmpty: TextView
    private lateinit var tvFilesEmpty: TextView

    // ── Data ───────────────────────────────────────────────────────────────
    /** packageName, label */
    private val hiddenApps   = mutableListOf<Pair<String, String>>()
    private val mediaEntries = mutableListOf<JSONObject>()
    private val fileEntries  = mutableListOf<JSONObject>()

    // ── File pickers (SAF) ────────────────────────────────────────────────
    private val pickMedia = registerForActivityResult(
        ActivityResultContracts.GetMultipleContents()) { uris ->
        uris.forEach { importFile(it, isMedia = true) }
    }
    private val pickFile = registerForActivityResult(
        ActivityResultContracts.GetMultipleContents()) { uris ->
        uris.forEach { importFile(it, isMedia = false) }
    }

    // ─────────────────────────────────────────────────────────────────────
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_vault)

        btnTabApps  = findViewById(R.id.btnVaultTabApps)
        btnTabMedia = findViewById(R.id.btnVaultTabMedia)
        btnTabFiles = findViewById(R.id.btnVaultTabFiles)
        sectionApps  = findViewById(R.id.sectionVaultApps)
        sectionMedia = findViewById(R.id.sectionVaultMedia)
        sectionFiles = findViewById(R.id.sectionVaultFiles)
        lvApps  = findViewById(R.id.lvVaultApps)
        lvMedia = findViewById(R.id.lvVaultMedia)
        lvFiles = findViewById(R.id.lvVaultFiles)
        tvAppsEmpty  = findViewById(R.id.tvVaultAppsEmpty)
        tvMediaEmpty = findViewById(R.id.tvVaultMediaEmpty)
        tvFilesEmpty = findViewById(R.id.tvVaultFilesEmpty)

        btnTabApps.setOnClickListener  { showTab(0) }
        btnTabMedia.setOnClickListener { showTab(1) }
        btnTabFiles.setOnClickListener { showTab(2) }

        findViewById<View>(R.id.btnVaultLock).setOnClickListener { finish() }
        findViewById<View>(R.id.btnAddHiddenApp).setOnClickListener  { pickAppToHide() }
        // Buka picker untuk foto + video sekaligus
        findViewById<View>(R.id.btnImportMedia).setOnClickListener   { pickMedia.launch("*/*") }
        // Buka picker untuk semua tipe file
        findViewById<View>(R.id.btnImportFile).setOnClickListener    { pickFile.launch("*/*")  }

        showTab(0)
        loadAll()
    }

    // ── Tab navigation ────────────────────────────────────────────────────
    private fun showTab(tab: Int) {
        sectionApps.visibility  = if (tab == 0) View.VISIBLE else View.GONE
        sectionMedia.visibility = if (tab == 1) View.VISIBLE else View.GONE
        sectionFiles.visibility = if (tab == 2) View.VISIBLE else View.GONE

        val on  = Color.parseColor("#6C63FF")
        val off = Color.parseColor("#2D3561")
        btnTabApps.setBackgroundColor(if (tab == 0) on else off)
        btnTabMedia.setBackgroundColor(if (tab == 1) on else off)
        btnTabFiles.setBackgroundColor(if (tab == 2) on else off)
    }

    // ── Load all data ─────────────────────────────────────────────────────
    private fun loadAll() {
        loadApps(); loadFilesFromIndex()
    }

    // ── APPS ──────────────────────────────────────────────────────────────
    private fun loadApps() {
        val pm   = packageManager
        val pkgs = VaultPrefs.getHiddenApps(this)
        hiddenApps.clear()
        pkgs.forEach { pkg ->
            runCatching {
                val info = pm.getApplicationInfo(pkg, 0)
                hiddenApps.add(pkg to pm.getApplicationLabel(info).toString())
            }
        }
        refreshApps()
    }

    private fun pickAppToHide() {
        val pm = packageManager
        val installed = try {
            pm.getInstalledApplications(0)
        } catch (e: Exception) { emptyList() }
            .filter { (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 }
            .filter { it.packageName != packageName }
            .sortedBy { pm.getApplicationLabel(it).toString().lowercase() }

        if (installed.isEmpty()) {
            toast("Tidak ada app yang bisa dipilih"); return
        }

        val names   = installed.map { pm.getApplicationLabel(it).toString() }.toTypedArray()
        val hidden  = VaultPrefs.getHiddenApps(this)
        val checked = BooleanArray(installed.size) { hidden.contains(installed[it].packageName) }

        AlertDialog.Builder(this)
            .setTitle("Pilih app yang ingin disembunyikan")
            .setMultiChoiceItems(names, checked) { _, which, isChecked ->
                checked[which] = isChecked
            }
            .setPositiveButton("Simpan") { _, _ ->
                val newSet = mutableSetOf<String>()
                checked.forEachIndexed { i, c -> if (c) newSet.add(installed[i].packageName) }
                VaultPrefs.saveHiddenApps(this, newSet)
                loadApps()
                if (newSet.isNotEmpty()) {
                    AlertDialog.Builder(this)
                        .setTitle("Tips menyembunyikan ikon")
                        .setMessage(
                            "App sudah ditambahkan ke Vault dan bisa diluncurkan dari sini.\n\n" +
                            "Untuk menyembunyikan ikonnya dari layar utama HP:\n" +
                            "Tekan & tahan ikon app → pilih Remove / Hapus dari layar utama.\n\n" +
                            "App tetap ada di Settings → Apps dan bisa dibuka dari Vault ini."
                        )
                        .setPositiveButton("Mengerti", null)
                        .show()
                }
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun refreshApps() {
        tvAppsEmpty.visibility = if (hiddenApps.isEmpty()) View.VISIBLE else View.GONE
        lvApps.visibility      = if (hiddenApps.isEmpty()) View.GONE   else View.VISIBLE
        lvApps.adapter = object : BaseAdapter() {
            override fun getCount()              = hiddenApps.size
            override fun getItem(p: Int)         = hiddenApps[p]
            override fun getItemId(p: Int)       = p.toLong()
            override fun getView(pos: Int, convert: View?, parent: ViewGroup): View {
                val v   = convert ?: layoutInflater.inflate(R.layout.item_vault_app, parent, false)
                val (pkg, label) = hiddenApps[pos]
                val iv  = v.findViewById<ImageView>(R.id.ivVaultAppIcon)
                val tv  = v.findViewById<TextView>(R.id.tvVaultAppName)
                val pkg2 = v.findViewById<TextView>(R.id.tvVaultAppPkg)
                val btnLaunch = v.findViewById<View>(R.id.btnLaunchVaultApp)
                val btnRemove = v.findViewById<View>(R.id.btnRemoveVaultApp)

                runCatching { iv.setImageDrawable(packageManager.getApplicationIcon(pkg)) }
                tv.text   = label
                pkg2.text = pkg

                btnLaunch.setOnClickListener {
                    packageManager.getLaunchIntentForPackage(pkg)
                        ?.let { startActivity(it) }
                        ?: toast("Tidak bisa membuka app ini")
                }
                btnRemove.setOnClickListener {
                    AlertDialog.Builder(this@VaultActivity)
                        .setMessage("Hapus \"$label\" dari Vault?")
                        .setPositiveButton("Hapus") { _, _ ->
                            val s = VaultPrefs.getHiddenApps(this@VaultActivity)
                                .also { it.remove(pkg) }
                            VaultPrefs.saveHiddenApps(this@VaultActivity, s)
                            loadApps()
                        }
                        .setNegativeButton("Batal", null).show()
                }
                return v
            }
        }
    }

    // ── FILES ─────────────────────────────────────────────────────────────
    private fun loadFilesFromIndex() {
        val index = VaultPrefs.loadIndex(this)
        mediaEntries.clear(); fileEntries.clear()
        for (i in 0 until index.length()) {
            val o = index.getJSONObject(i)
            if (o.getString("type") in listOf("image","video")) mediaEntries.add(o)
            else fileEntries.add(o)
        }
        refreshMedia(); refreshFiles()
    }

    // Import file dari picker SAF
    private fun importFile(uri: Uri, isMedia: Boolean) {
        val type      = detectType(uri)
        // Kalau dipilih lewat Media tab tapi filenya non-media, tetap tangani
        val origName  = getFileName(uri)
        val stored    = VaultPrefs.newStoredName(origName)
        val dest      = VaultPrefs.storedFile(this, stored, type)

        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    contentResolver.openInputStream(uri)?.use { inp ->
                        dest.outputStream().use { inp.copyTo(it) }
                    }
                    val size = dest.length()
                    VaultPrefs.addEntry(this@VaultActivity, origName, stored, type, size)
                    // Coba hapus file asli (berhasil untuk URI MediaStore)
                    val deleted = runCatching {
                        contentResolver.delete(uri, null, null) > 0
                    }.getOrDefault(false)
                    deleted
                }
            }
            result.onSuccess { deleted ->
                val msg = if (deleted) "\"$origName\" berhasil disembunyikan"
                else "\"$origName\" disalin ke Vault.\nHapus file aslinya secara manual dari Gallery/File Manager."
                Toast.makeText(this@VaultActivity, msg, Toast.LENGTH_LONG).show()
                loadFilesFromIndex()
            }.onFailure {
                dest.delete()
                toast("Gagal: ${it.message}")
            }
        }
    }

    private fun restoreFile(o: JSONObject) {
        val stored   = o.getString("stored")
        val type     = o.getString("type")
        val origName = o.getString("orig")
        val src      = VaultPrefs.storedFile(this, stored, type)
        if (!src.exists()) { toast("File tidak ditemukan di vault"); return }

        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) {
                runCatching {
                    val downloads = Environment
                        .getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                    downloads.mkdirs()
                    val dest = File(downloads, origName)
                    src.copyTo(dest, overwrite = true)
                    android.media.MediaScannerConnection.scanFile(
                        this@VaultActivity, arrayOf(dest.absolutePath), null, null)
                    VaultPrefs.removeEntry(this@VaultActivity, stored)
                    src.delete()
                    true
                }.getOrDefault(false)
            }
            if (ok) {
                toast("\"$origName\" dikembalikan ke folder Downloads")
                loadFilesFromIndex()
            } else toast("Gagal mengembalikan file")
        }
    }

    private fun confirmDelete(o: JSONObject) {
        AlertDialog.Builder(this)
            .setTitle("Hapus permanen?")
            .setMessage("\"${o.getString("orig")}\" akan dihapus selamanya dan tidak bisa dikembalikan.")
            .setPositiveButton("Hapus") { _, _ ->
                val stored = o.getString("stored")
                VaultPrefs.storedFile(this, stored, o.getString("type")).delete()
                VaultPrefs.removeEntry(this, stored)
                loadFilesFromIndex()
            }
            .setNegativeButton("Batal", null).show()
    }

    private fun refreshMedia() {
        tvMediaEmpty.visibility = if (mediaEntries.isEmpty()) View.VISIBLE else View.GONE
        lvMedia.visibility      = if (mediaEntries.isEmpty()) View.GONE   else View.VISIBLE
        lvMedia.adapter         = fileAdapter(mediaEntries)
    }

    private fun refreshFiles() {
        tvFilesEmpty.visibility = if (fileEntries.isEmpty()) View.VISIBLE else View.GONE
        lvFiles.visibility      = if (fileEntries.isEmpty()) View.GONE   else View.VISIBLE
        lvFiles.adapter         = fileAdapter(fileEntries)
    }

    private fun fileAdapter(list: MutableList<JSONObject>) = object : BaseAdapter() {
        private val sdf = SimpleDateFormat("dd MMM yy", Locale.getDefault())
        private val szFmt = DecimalFormat("#,##0")

        override fun getCount()        = list.size
        override fun getItem(p: Int)   = list[p]
        override fun getItemId(p: Int) = p.toLong()

        override fun getView(pos: Int, convert: View?, parent: ViewGroup): View {
            val v = convert ?: layoutInflater.inflate(R.layout.item_vault_file, parent, false)
            val o = list[pos]
            val stored = o.getString("stored")
            val type   = o.getString("type")
            val file   = VaultPrefs.storedFile(this@VaultActivity, stored, type)

            v.findViewById<TextView>(R.id.tvVaultFileName).text = o.getString("orig")
            val kb   = (o.optLong("size", file.length()) / 1024).coerceAtLeast(1)
            val info = "${type.replaceFirstChar { it.uppercase() }} • ${sdf.format(Date(o.getLong("date")))} • ${szFmt.format(kb)} KB"
            v.findViewById<TextView>(R.id.tvVaultFileInfo).text = info

            // Thumbnail (untuk image)
            val iv = v.findViewById<ImageView>(R.id.ivVaultFileThumb)
            when (type) {
                "image" -> {
                    iv.setImageResource(android.R.drawable.ic_menu_gallery)
                    if (file.exists()) lifecycleScope.launch(Dispatchers.IO) {
                        val bmp = BitmapFactory.decodeFile(file.absolutePath,
                            BitmapFactory.Options().apply { inSampleSize = 4 })
                        withContext(Dispatchers.Main) { if (bmp != null) iv.setImageBitmap(bmp) }
                    }
                }
                "video" -> iv.setImageResource(android.R.drawable.ic_media_play)
                else    -> iv.setImageResource(android.R.drawable.ic_menu_save)
            }

            v.findViewById<View>(R.id.btnVaultRestore).setOnClickListener { restoreFile(o) }
            v.findViewById<View>(R.id.btnVaultDelete).setOnClickListener  { confirmDelete(o) }
            return v
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────
    private fun detectType(uri: Uri): String {
        val mime = contentResolver.getType(uri) ?: ""
        return when {
            mime.startsWith("image/") -> "image"
            mime.startsWith("video/") -> "video"
            else -> "file"
        }
    }

    private fun getFileName(uri: Uri): String {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME),
            null, null, null)?.use { if (it.moveToFirst()) return it.getString(0) }
        return uri.lastPathSegment ?: "file_${System.currentTimeMillis()}"
    }

    private fun toast(msg: String) =
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
