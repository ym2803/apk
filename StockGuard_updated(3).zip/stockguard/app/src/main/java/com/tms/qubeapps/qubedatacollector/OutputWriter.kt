package com.tms.qubeapps.qubedatacollector

import android.content.Context
import android.os.Environment
import com.tms.qubeapps.qubedatacollector.Prefs.localFolderPath
import com.tms.qubeapps.qubedatacollector.Prefs.localUploadFolderPath
import com.tms.qubeapps.qubedatacollector.Prefs.smbPass
import com.tms.qubeapps.qubedatacollector.Prefs.smbPath
import com.tms.qubeapps.qubedatacollector.Prefs.smbUploadPath
import com.tms.qubeapps.qubedatacollector.Prefs.smbUploadPathScanProcess
import com.tms.qubeapps.qubedatacollector.Prefs.smbUploadPathExpiredDiscount
import com.tms.qubeapps.qubedatacollector.Prefs.smbUploadPathDataCollector
import com.tms.qubeapps.qubedatacollector.Prefs.smbUser
import com.tms.qubeapps.qubedatacollector.Prefs.smbDomain
import com.tms.qubeapps.qubedatacollector.Prefs.uploadMode
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * ★ FIX (baru): identitas menu output, dipakai supaya SMB Path yang dipakai
 * bisa berbeda per menu. SCAN_PROCESS, EXPIRED_DISCOUNT & DATA_COLLECTOR
 * punya setting SMB SENDIRI (lihat Prefs.smbUploadPathScanProcess /
 * smbUploadPathExpiredDiscount / smbUploadPathDataCollector), diatur dari
 * dialog di layar masing-masing — BUKAN dari Setting global.
 * DEFAULT tetap pakai `smbUploadPath` (Setting global), dipakai menu lain
 * seperti Stock Comparison.
 */
enum class OutputModule { DEFAULT, SCAN_PROCESS, PRODUCT_MASTER, DATA_COLLECTOR }

/**
 * Abstraksi "Upload to PC" — 3 mode:
 *
 *  • SMB   → kirim via jaringan ke server Windows (jCIFS/smbj)
 *  • HTTP  → FIX: server HTTP kini berjalan LANGSUNG di HP (QubeHttpServer),
 *            data disimpan/dibaca dari folder lokal yang sama dengan mode
 *            LOCAL — PC tinggal buka browser ke http://<ip-hp>:8080,
 *            TIDAK perlu lagi jalankan script Python di PC.
 *  • LOCAL → simpan langsung ke folder di device
 *            default: /storage/emulated/0/QubeOutputUpload
 *
 * ★ FIX (baru): folder DOWNLOAD (dipakai untuk ambil data katalog 02.txt)
 * dan folder UPLOAD (dipakai untuk export/output dari Scan Process, Stock
 * Comparison, Expired Discount Checker) SEKARANG DIPISAH — baik untuk mode
 * SMB (smbPath vs smbUploadPath) maupun LOCAL (localFolderPath vs
 * localUploadFolderPath). Mode HTTP tetap memakai folder DOWNLOAD yang sama
 * seperti sebelumnya (satu folder lokal untuk browsing lewat browser PC).
 */
object OutputWriter {

    /** ★ FIX (baru — Data Collector "Upload to PC"): user pilih SENDIRI tiap
     *  kali klik Upload — "Server Directly (Via SMB)" atau "Save to Local"
     *  — TIDAK ikut setting `uploadMode` global, supaya pilihan ini murni
     *  keputusan user saat itu juga. */
    fun writeToSmbDirect(ctx: Context, fileName: String, content: String, module: OutputModule): String =
        writeSmb(ctx, fileName, content, module)

    fun writeToLocalDirect(ctx: Context, fileName: String, content: String): String =
        writeLocal(ctx, fileName, content)

    fun write(ctx: Context, fileName: String, content: String, module: OutputModule = OutputModule.DEFAULT): String {
        return when (ctx.uploadMode) {
            // FIX: mode HTTP sekarang = server built-in di HP (lihat QubeHttpServer).
            // Data cukup disimpan ke folder lokal, lalu PC download lewat browser
            // ke http://<ip-hp>:8080 — tidak perlu POST ke script Python lagi.
            "LOCAL", "HTTP" -> writeLocal(ctx, fileName, content)
            else -> writeSmb(ctx, fileName, content, module)
        }
    }

    /**
     * ★ FIX (Menu 5 — Export PDF): sama seperti write(), tapi untuk file
     * BINARY (PDF). Routing SMB/LOCAL/HTTP sama persis dengan write().
     */
    fun writeBytes(ctx: Context, fileName: String, bytes: ByteArray, module: OutputModule = OutputModule.DEFAULT): String {
        return when (ctx.uploadMode) {
            "LOCAL", "HTTP" -> writeLocalBytes(ctx, fileName, bytes)
            else -> writeSmbBytes(ctx, fileName, bytes, module)
        }
    }

    /** ★ FIX (baru): pilih SMB Path sesuai module — SCAN_PROCESS &
     *  EXPIRED_DISCOUNT pakai setting sendiri (diatur di layar masing-masing);
     *  kalau setting sendiri itu masih kosong, fallback ke `smbUploadPath`
     *  (Setting global) supaya tetap kompatibel untuk yang belum diatur. */
    private fun resolveUploadSmbPath(ctx: Context, module: OutputModule): String {
        val dedicated = when (module) {
            OutputModule.SCAN_PROCESS     -> ctx.smbUploadPathScanProcess
            OutputModule.PRODUCT_MASTER   -> ctx.smbUploadPathExpiredDiscount
            OutputModule.DATA_COLLECTOR   -> ctx.smbUploadPathDataCollector
            OutputModule.DEFAULT          -> ""
        }
        return dedicated.ifBlank { ctx.smbUploadPath }
    }

    private fun writeSmbBytes(ctx: Context, fileName: String, bytes: ByteArray, module: OutputModule): String {
        val path = resolveUploadSmbPath(ctx, module)
        val user = ctx.smbUser
        val pass = ctx.smbPass
        if (path.isBlank()) throw IllegalStateException("Upload SMB Path is not set")
        SmbUploader.uploadBytes(path, user, pass, fileName, bytes, ctx.smbDomain)
        return "$path/$fileName"
    }

    private fun writeLocalBytes(ctx: Context, fileName: String, bytes: ByteArray): String {
        val dir = resolveLocalUploadDir(ctx)
        val file = File(dir, fileName)
        file.writeBytes(bytes)
        return file.absolutePath
    }

    fun read(ctx: Context, fileName: String): String {
        return when (ctx.uploadMode) {
            // FIX: mode HTTP sekarang = server built-in di HP (lihat QubeHttpServer),
            // filenya di folder lokal yang sama dengan mode LOCAL — jadi baca lokal juga.
            "LOCAL", "HTTP" -> readLocal(ctx, fileName)
            else -> readSmb(ctx, fileName)
        }
    }

    // ── SMB ──────────────────────────────────────────────────────────
    private fun writeSmb(ctx: Context, fileName: String, content: String, module: OutputModule): String {
        val path = resolveUploadSmbPath(ctx, module)
        val user = ctx.smbUser
        val pass = ctx.smbPass
        if (path.isBlank()) throw IllegalStateException("Upload SMB Path is not set")
        SmbUploader.upload(path, user, pass, fileName, content, ctx.smbDomain)
        return "$path/$fileName"
    }

    private fun readSmb(ctx: Context, fileName: String): String {
        val path = ctx.smbPath
        val user = ctx.smbUser
        val pass = ctx.smbPass
        if (path.isBlank()) throw IllegalStateException("SMB Path is not set in Settings")
        return SmbUploader.download(path, user, pass, fileName, ctx.smbDomain)
    }

    // ── LOCAL FOLDER (dipakai juga oleh mode HTTP, lihat QubeHttpServer) ──
    /** Dipakai QubeHttpServer untuk tahu folder mana yang harus dilayani/di-serve
     *  (tetap folder DOWNLOAD, supaya browsing lewat browser PC tidak berubah). */
    fun resolveLocalDirPublic(ctx: Context): File = resolveLocalDownloadDir(ctx)

    private fun resolveLocalDownloadDir(ctx: Context): File {
        val customPath = ctx.localFolderPath
        val dir = if (customPath.isNotBlank()) {
            File(customPath)
        } else {
            File(Environment.getExternalStorageDirectory(), "QubeOutput")
        }
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    /** ★ FIX (baru): folder LOCAL khusus tujuan UPLOAD/EXPORT — terpisah dari
     *  folder download di atas. */
    private fun resolveLocalUploadDir(ctx: Context): File {
        val customPath = ctx.localUploadFolderPath
        val dir = if (customPath.isNotBlank()) {
            File(customPath)
        } else {
            File(Environment.getExternalStorageDirectory(), "QubeOutputUpload")
        }
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    private fun writeLocal(ctx: Context, fileName: String, content: String): String {
        val dir = resolveLocalUploadDir(ctx)
        val file = File(dir, fileName)
        file.writeText(content, Charsets.UTF_8)
        return file.absolutePath
    }

    private fun readLocal(ctx: Context, fileName: String): String {
        val dir = resolveLocalDownloadDir(ctx)
        val file = File(dir, fileName)
        if (!file.exists()) throw IllegalStateException("File not found: ${file.absolutePath}")
        return file.readText(Charsets.UTF_8)
    }

    // ── APK Download (FIX: dulu tombol ini belum dihubungkan ke apa pun) ──
    /**
     * ★ FIX (baru): sumber APK Download diganti dari SMB/LOCAL (perlu 1
     * jaringan dengan PC) menjadi GitHub Releases langsung (butuh internet
     * saja, bisa update dari mana pun). Selalu ambil file TERBARU di link
     * ini (bukan snapshot versi tertentu), jadi cukup replace file di repo
     * GitHub-nya tiap kali mau rilis update baru — tidak perlu ubah kode.
     */
    private const val APK_GITHUB_URL = "https://github.com/ym2803/apk/raw/refs/heads/main/sgxcalc.apk"

    /** Download APK terbaru dari GitHub, simpan ke folder internal khusus
     *  aplikasi (tidak perlu izin storage), lalu return File-nya untuk
     *  dibuka lewat installer Android. */
    fun downloadApkFromGithub(ctx: Context): File {
        val bytes = httpGetBytes(APK_GITHUB_URL)
        val dir = ctx.getExternalFilesDir(null) ?: ctx.filesDir
        val outFile = File(dir, "sgxcalc.apk")
        outFile.writeBytes(bytes)
        return outFile
    }

    /** GET biner mengikuti redirect (GitHub "raw" link redirect 302 ke
     *  raw.githubusercontent.com — HttpURLConnection TIDAK auto-follow
     *  redirect lintas host secara default, jadi ditangani manual di sini). */
    private fun httpGetBytes(url: String, maxRedirects: Int = 5): ByteArray {
        var currentUrl = url
        repeat(maxRedirects) {
            val conn = (URL(currentUrl).openConnection() as HttpURLConnection).apply {
                instanceFollowRedirects = false
                requestMethod = "GET"
                setRequestProperty("User-Agent", "Mozilla/5.0")
                connectTimeout = 20000
                readTimeout = 30000
            }
            try {
                val code = conn.responseCode
                if (code in 300..399) {
                    val location = conn.getHeaderField("Location")
                        ?: throw Exception("Redirect tanpa Location header dari $currentUrl")
                    currentUrl = location
                    return@repeat
                }
                if (code !in 200..299) {
                    throw Exception("HTTP $code saat download APK dari $currentUrl")
                }
                return conn.inputStream.use { it.readBytes() }
            } finally {
                conn.disconnect()
            }
        }
        throw Exception("Terlalu banyak redirect saat download APK (>$maxRedirects)")
    }

    /** ★ Fungsi lama (SMB/LOCAL) dipertahankan kalau suatu saat dibutuhkan
     *  lagi, tapi sudah TIDAK dipakai oleh tombol APK Download (lihat
     *  downloadApkFromGithub di atas — sekarang jadi sumber utama). */
    fun downloadApkFile(ctx: Context, fileName: String): File {
        val bytes = when (ctx.uploadMode) {
            "LOCAL", "HTTP" -> readLocalBytes(ctx, fileName)
            else -> SmbUploader.downloadBytes(ctx.smbPath, ctx.smbUser, ctx.smbPass, fileName, ctx.smbDomain)
        }
        val dir = ctx.getExternalFilesDir(null) ?: ctx.filesDir
        val outFile = File(dir, fileName)
        outFile.writeBytes(bytes)
        return outFile
    }

    private fun readLocalBytes(ctx: Context, fileName: String): ByteArray {
        val dir = resolveLocalDownloadDir(ctx)
        val file = File(dir, fileName)
        if (!file.exists()) throw IllegalStateException("File not found: ${file.absolutePath}")
        return file.readBytes()
    }
}
