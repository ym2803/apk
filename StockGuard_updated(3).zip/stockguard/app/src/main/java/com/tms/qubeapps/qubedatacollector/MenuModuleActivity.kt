package com.tms.qubeapps.qubedatacollector

import android.animation.ObjectAnimator
import android.animation.AnimatorSet
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

/**
 * ★ FIX: menu 1 (DO/IB CHECK), 3 (STOCK TAKE) & 4 (SHELF RECORD) dihapus dari
 * aplikasi sesuai permintaan. Sisa menu cuma SCAN PROCESS & STOCK
 * COMPARISON.
 *
 * ★ FIX: tampilan menu diganti total dari ListView polos jadi grid card
 * modern (2 kolom) dengan gradient, elevation/shadow, dan animasi "tekan"
 * (scale-down lalu balik) supaya terasa lebih tactile / 3D saat disentuh.
 *
 * ★ FIX: tambah menu KEEP STOCK (diambil dari Menu 6 di source lain):
 * ADD DATA langsung ke Google Sheets & SYNC IN/OUT box lewat SMB.
 *
 * ★ FIX: STOCK COMPARISON digabung ke dalam SCAN PROCESS (diakses lewat
 * ikon di header layar Scan Process) — tidak lagi jadi kartu menu terpisah
 * di halaman utama ini.
 *
 * ★ FIX: nomor urut di header tiap layar (misal "4. KEEP STOCK") dihapus —
 * sekarang cuma nama menunya saja.
 */
class MenuModuleActivity : BaseActivity() {

    data class MenuEntry(
        val number: Int,
        val title: String,
        val iconRes: Int,
        val backgroundRes: Int,
        val target: Class<*>,
        // ★ FIX (baru — pemisahan menu Scan Process): extra opsional untuk
        // membedakan mode layar tujuan (mis. Shelf Price Enquire vs Stock
        // Balance Check), yang keduanya sama-sama membuka ShelfPriceEnquireActivity.
        val modeExtra: String? = null
    )

    // ★ FIX (baru): menu "Scan Process" dipecah jadi 2 kartu menu terpisah —
    // "Shelf Price Enquire" (mode cari harga, tampilkan kartu Result saja)
    // dan "Stock Balance Check" (mode lihat History, Clear Data & Upload to
    // PC, serta akses ke Stock Comparison). Keduanya berbagi data yang sama
    // (tabel Price), jadi Stock Comparison tetap mengambil data History
    // seperti sebelumnya.
    // ★ FIX (baru — tema pastel): tiap kartu menu sekarang pakai warna
    // gradient pastel yang BEDA satu sama lain (tidak ada yang duplikat).
    // ★ FIX (baru): "Shelf Price Enquire" dipindah keluar dari grid menu utama
    // ini — sekarang jadi tombol pintasan di dalam layar Data Collector,
    // di sebelah kiri tombol "Shelf Record" (lihat activity_data_collector.xml
    // & DataCollectorActivity.kt). Nomor urut menu di bawah digeser mengikuti.
    private val menuItems = listOf(
        MenuEntry(1, "Stock\nBalance Check", android.R.drawable.ic_menu_sort_by_size, R.drawable.bg_card_gradient_2,
            ShelfPriceEnquireActivity::class.java, ShelfPriceEnquireActivity.MODE_BALANCE),
        MenuEntry(2, "Product\nMaster", android.R.drawable.ic_menu_recent_history, R.drawable.bg_card_gradient_3, ProductMasterActivity::class.java),
        MenuEntry(3, "Keep\nStock", android.R.drawable.ic_menu_save, R.drawable.bg_card_gradient_4, KeepStockLoginActivity::class.java),
        // ★ FIX (baru): menu ke-4 — Data Collector (Shelf Record / Stock Take generik)
        MenuEntry(4, "Data\nCollector", android.R.drawable.ic_menu_edit, R.drawable.bg_card_gradient_5, DataCollectorActivity::class.java)
        // ★ FIX: menu Credits dipindah dari grid ini ke bottom navigation bar
        // (di sisi paling kanan, setelah Setting & Feedback) — lihat tabCredits.
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu_module)

        // FIX: tampilkan setiap kali aplikasi dibuka
        Toast.makeText(this, "© 2026 Yayang Mardiansyah", Toast.LENGTH_SHORT).show()

        val rv = findViewById<RecyclerView>(R.id.rvMenu)
        rv.layoutManager = GridLayoutManager(this, 2)
        rv.adapter = MenuGridAdapter(menuItems) { entry ->
            startActivity(Intent(this, entry.target).apply {
                if (entry.modeExtra != null) putExtra(ShelfPriceEnquireActivity.EXTRA_MODE, entry.modeExtra)
            })
        }

        // ★ FIX: btnSetting (ikon kanan atas) sudah dihapus dari layout — duplikat tabSetting
        findViewById<View>(R.id.tabSetting).setOnClickListener {
            startActivity(Intent(this, SettingActivity::class.java))
        }

        // ★ FIX (baru): Feedback & Credits sekarang di bottom navigation bar,
        // di sebelah kanan Setting (Setting → Feedback → Credits).
        findViewById<View>(R.id.tabFeedback).setOnClickListener {
            FeedbackHelper.showFeedbackDialog(this)
        }
        findViewById<View>(R.id.tabCredits).setOnClickListener {
            startActivity(Intent(this, CreditsActivity::class.java))
        }
    }

    private class MenuGridAdapter(
        private val items: List<MenuEntry>,
        private val onClick: (MenuEntry) -> Unit
    ) : RecyclerView.Adapter<MenuGridAdapter.VH>() {

        inner class VH(view: View) : RecyclerView.ViewHolder(view) {
            val cardBg: FrameLayout = view.findViewById(R.id.cardBg)
            val icon: ImageView = view.findViewById(R.id.ivMenuIcon)
            val title: TextView = view.findViewById(R.id.tvMenuTitle)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.item_menu_card, parent, false)
            return VH(v)
        }

        override fun onBindViewHolder(holder: VH, position: Int) {
            val entry = items[position]
            holder.cardBg.setBackgroundResource(entry.backgroundRes)
            holder.icon.setImageResource(entry.iconRes)
            holder.title.text = entry.title

            // ★ FIX: animasi tekan (scale down/up) supaya kartu terasa "3D" & responsif
            holder.itemView.setOnTouchListener { v, event ->
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> animateScale(v, 0.94f)
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> animateScale(v, 1f)
                }
                false
            }
            holder.itemView.setOnClickListener { onClick(entry) }
        }

        private fun animateScale(view: View, scale: Float) {
            val sx = ObjectAnimator.ofFloat(view, "scaleX", scale)
            val sy = ObjectAnimator.ofFloat(view, "scaleY", scale)
            AnimatorSet().apply {
                playTogether(sx, sy)
                duration = 120
                start()
            }
        }

        override fun getItemCount() = items.size
    }
}
