package com.tms.qubeapps.qubedatacollector

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale

/**
 * Kamuflase: activity ini yang muncul pertama kali saat aplikasi dibuka
 * (launcher), tampil sebagai kalkulator biasa dan berfungsi penuh.
 * Jika pengguna mengetik angka "2026" lalu menekan "=", aplikasi akan
 * membuka menu utama StockGuard yang sesungguhnya.
 *
 * Tampilan: ekspresi di baris atas, hasil sementara (live) di baris bawah,
 * keypad angka di kiri, operator + DEL di kanan.
 */
class CalculatorActivity : BaseActivity() {

    private lateinit var tvResult: TextView
    private lateinit var tvExpression: TextView

    /** Ekspresi mentah, tanpa pemisah ribuan. Contoh: "0+4−4÷85−1000+45". */
    private var raw = StringBuilder()
    private var justComputed = false

    private val ops = charArrayOf('+', '−', '×', '÷')

    private val resultFmt = DecimalFormat("#,##0.##########", DecimalFormatSymbols(Locale.US))

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calculator)

        tvResult = findViewById(R.id.tvResult)
        tvExpression = findViewById(R.id.tvExpression)

        val digitIds = intArrayOf(
            R.id.btn0, R.id.btn1, R.id.btn2, R.id.btn3, R.id.btn4,
            R.id.btn5, R.id.btn6, R.id.btn7, R.id.btn8, R.id.btn9
        )
        digitIds.forEachIndexed { d, id ->
            findViewById<TextView>(id).setOnClickListener { onDigit(d.toString()) }
        }
        findViewById<TextView>(R.id.btnDot).setOnClickListener { onDot() }

        findViewById<TextView>(R.id.btnDivide).setOnClickListener { onOperator('÷') }
        findViewById<TextView>(R.id.btnMultiply).setOnClickListener { onOperator('×') }
        findViewById<TextView>(R.id.btnMinus).setOnClickListener { onOperator('−') }
        findViewById<TextView>(R.id.btnPlus).setOnClickListener { onOperator('+') }

        findViewById<TextView>(R.id.btnDel).apply {
            setOnClickListener { onDelete() }
            setOnLongClickListener { onClear(); true }
        }
        findViewById<TextView>(R.id.btnEquals).setOnClickListener { onEquals() }

        refresh()
    }

    // ── Input ────────────────────────────────────────────────────────────

    private fun currentNumber(): String {
        var i = raw.length
        while (i > 0 && (raw[i - 1].isDigit() || raw[i - 1] == '.')) i--
        return raw.substring(i)
    }

    private fun onDigit(d: String) {
        if (justComputed) { raw.clear(); justComputed = false }
        val cur = currentNumber()
        if (cur == "0") {
            raw.setLength(raw.length - 1)          // hindari angka berawalan 0 ("00", "05")
        } else if (cur.count { it.isDigit() } >= 15) {
            return
        }
        raw.append(d)
        refresh()
    }

    private fun onDot() {
        if (justComputed) { raw.clear(); justComputed = false }
        val cur = currentNumber()
        if (cur.contains('.')) return
        if (cur.isEmpty()) raw.append('0')
        raw.append('.')
        refresh()
    }

    private fun onOperator(op: Char) {
        justComputed = false
        if (raw.isEmpty()) {
            raw.append(if (op == '−') "−" else "0$op")
        } else {
            val last = raw.last()
            if (last in ops) {
                // ganti operator terakhir (kecuali tanda minus di awal ekspresi)
                if (raw.length == 1) {
                    if (op != '−') { raw.setLength(0); raw.append("0$op") }
                } else {
                    raw.setLength(raw.length - 1)
                    raw.append(op)
                }
            } else {
                if (last == '.') raw.setLength(raw.length - 1)
                raw.append(op)
            }
        }
        refresh()
    }

    private fun onDelete() {
        if (justComputed) { onClear(); return }
        if (raw.isNotEmpty()) raw.setLength(raw.length - 1)
        refresh()
    }

    private fun onClear() {
        raw.clear()
        justComputed = false
        refresh()
    }

    // Kode yang murni angka (tidak ada operator)
    private fun isJustDigits(s: String) = s.isNotEmpty() && s.all { it.isDigit() }

    private fun openHidden(cls: Class<*>) { onClear(); startActivity(Intent(this, cls)) }

    private fun onEquals() {
        val input = raw.toString().trim()

        // ★ Triggers tersembunyi — hanya valid jika input murni angka tanpa operator
        if (!justComputed && isJustDigits(input)) {
            when (input) {
                "2026"    -> { openHidden(MenuModuleActivity::class.java); return }
                "282828"  -> { openHidden(VaultSetCodeActivity::class.java); return }
                VaultPrefs.getCode(this) -> { openHidden(VaultActivity::class.java); return }
            }
        }
        val value = evaluate(raw.toString())
        if (value == null) return
        if (value.isNaN() || value.isInfinite()) {
            tvResult.text = "Error"
            return
        }
        raw.clear()
        raw.append(plain(value))
        justComputed = true
        refresh(showResult = false)
    }

    // ── Perhitungan ──────────────────────────────────────────────────────

    /** Evaluasi dengan prioritas operator (× ÷ sebelum + −). Operator di akhir diabaikan. */
    private fun evaluate(expr: String): Double? {
        var s = expr
        while (s.isNotEmpty() && s.last() in ops) s = s.dropLast(1)
        if (s.isEmpty() || s == "−") return null

        val nums = ArrayList<Double>()
        val opList = ArrayList<Char>()
        var i = 0
        var negative = false
        if (s[0] == '−') { negative = true; i = 1 }
        val sb = StringBuilder()
        while (i < s.length) {
            val c = s[i]
            if (c in ops) {
                nums.add((sb.toString().toDoubleOrNull() ?: return null).let { if (negative) -it else it })
                negative = false
                opList.add(c); sb.clear()
            } else sb.append(c)
            i++
        }
        nums.add((sb.toString().toDoubleOrNull() ?: return null).let { if (negative) -it else it })

        // Tahap 1: × dan ÷
        val n2 = ArrayList<Double>(); val o2 = ArrayList<Char>()
        n2.add(nums[0])
        for (k in opList.indices) {
            val op = opList[k]; val b = nums[k + 1]
            when (op) {
                '×' -> n2[n2.size - 1] = n2.last() * b
                '÷' -> n2[n2.size - 1] = if (b == 0.0) Double.NaN else n2.last() / b
                else -> { o2.add(op); n2.add(b) }
            }
        }
        // Tahap 2: + dan −
        var res = n2[0]
        for (k in o2.indices) res = if (o2[k] == '+') res + n2[k + 1] else res - n2[k + 1]
        return res
    }

    private fun plain(v: Double): String {
        val r = java.math.BigDecimal(v).setScale(10, java.math.RoundingMode.HALF_UP)
            .stripTrailingZeros()
        return if (r.signum() == 0) "0" else r.toPlainString().replace('-', '−')
    }

    // ── Tampilan ─────────────────────────────────────────────────────────

    /** Beri pemisah ribuan pada bagian bulat tiap angka: "1000+45" → "1,000+45". */
    private fun formatExpression(expr: String): String {
        val out = StringBuilder()
        var i = 0
        while (i < expr.length) {
            if (expr[i].isDigit()) {
                var j = i
                while (j < expr.length && expr[j].isDigit()) j++
                val intPart = expr.substring(i, j)
                out.append(intPart.reversed().chunked(3).joinToString(",").reversed())
                i = j
            } else { out.append(expr[i]); i++ }
        }
        return out.toString()
    }

    private fun refresh(showResult: Boolean = true) {
        tvExpression.text = formatExpression(raw.toString())
        if (!showResult) { tvResult.text = ""; return }
        val hasOp = raw.indexOfFirst { it in ops } > 0 ||
                (raw.isNotEmpty() && raw[0] == '−' && raw.drop(1).any { it in ops })
        val v = if (hasOp) evaluate(raw.toString()) else null
        tvResult.text = when {
            v == null -> ""
            v.isNaN() || v.isInfinite() -> ""
            else -> resultFmt.format(v).replace('-', '−')
        }
    }


}
