package com.tms.qubeapps.qubedatacollector

import android.content.Context

/**
 * ★ FIX: keterangan di bawah input SKU Code (hasil scan) sekarang berbentuk
 * grid custom 5x2 — 5 baris di kolom kiri, 5 baris di kolom kanan (total 10
 * slot), dan field mana yang tampil di tiap slot beserta judulnya BISA
 * DI-CUSTOM oleh user (lihat ResultLayoutActivity).
 *
 * Slot 0-4 = kolom kiri (atas ke bawah), slot 5-9 = kolom kanan (atas ke bawah).
 * Tiap slot menyimpan 2 hal: field key (data mana yang ditampilkan) dan
 * judul/label custom untuk slot itu.
 */
object ResultLayoutPrefs {

    private const val NAME = "QubeResultLayout"
    private const val SLOT_COUNT = 10

    /** Semua field yang tersedia untuk dipilih di tiap slot, plus label default-nya. */
    val availableFields: List<Pair<String, String>> = listOf(
        "" to "(Empty)",
        "sku" to "SKU",
        "desc" to "Desc",
        "shelf" to "Shelf",
        "price" to "Price",
        "balance" to "Balance",
        "discount" to "Discount",
        "discStart" to "Discount Start Date",
        "discEnd" to "Discount End Date",
        "longSku" to "Long SKU",
        "keepStock" to "Keep Stock"
    )

    private val defaultLabelFor: Map<String, String> = availableFields.toMap()

    data class Slot(val fieldKey: String, val label: String)

    private val defaultSlots: List<Slot> = listOf(
        Slot("sku", "SKU"),
        Slot("balance", "Balance"),
        Slot("shelf", "Shelf"),
        Slot("price", "Price"),
        Slot("desc", "Desc"),
        Slot("discount", "Discount"),
        Slot("discStart", "Discount Start Date"),
        Slot("discEnd", "Discount End Date"),
        Slot("longSku", "Long SKU"),
        Slot("keepStock", "Keep Stock")
    )

    fun labelFor(fieldKey: String): String = defaultLabelFor[fieldKey] ?: fieldKey

    fun load(ctx: Context): List<Slot> {
        val sp = ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE)
        return (0 until SLOT_COUNT).map { i ->
            val def = defaultSlots[i]
            val key = sp.getString("slot_${i}_key", def.fieldKey) ?: def.fieldKey
            val lbl = sp.getString("slot_${i}_label", def.label) ?: def.label
            Slot(key, lbl)
        }
    }

    fun save(ctx: Context, slots: List<Slot>) {
        val editor = ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).edit()
        slots.forEachIndexed { i, slot ->
            editor.putString("slot_${i}_key", slot.fieldKey)
            editor.putString("slot_${i}_label", slot.label)
        }
        editor.apply()
    }

    fun resetToDefault(ctx: Context) {
        save(ctx, defaultSlots)
        saveDisplayStyle(ctx, DEFAULT_FONT_PCT, DEFAULT_SPACING)
    }

    // ★ FIX (baru): ukuran font & jarak antar baris (menu 1 ke menu 2, dst) di kartu Result.
    // Font: persen dari ukuran dasar (80 / 100 / 120 / 140). Spacing: 0 = Rapat, 1 = Normal, 2 = Renggang.
    const val DEFAULT_FONT_PCT = 100
    const val DEFAULT_SPACING  = 1

    fun fontPct(ctx: Context): Int =
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).getInt("font_pct", DEFAULT_FONT_PCT)

    fun spacing(ctx: Context): Int =
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).getInt("row_spacing", DEFAULT_SPACING)

    fun saveDisplayStyle(ctx: Context, fontPct: Int, spacing: Int) {
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).edit()
            .putInt("font_pct", fontPct)
            .putInt("row_spacing", spacing)
            .apply()
    }

    /** Padding atas/bawah tiap baris (dp) sesuai pilihan spacing. */
    fun rowPaddingDp(spacing: Int): Int = when (spacing) { 0 -> 1; 2 -> 16; else -> 8 }
}
