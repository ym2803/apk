package com.tms.qubeapps.qubedatacollector

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.text.SimpleDateFormat
import java.util.*

/**
 * FIX (force close saat download data 02.txt besar):
 * Katalog hasil download 02.txt dulunya digabung jadi SATU string besar
 * (JSON per baris) lalu disimpan di SharedPreferences, dan juga dipegang
 * penuh di memori sebagai nested Map. Untuk katalog besar (puluhan ribu
 * SKU) ini bikin memori membengkak dan aplikasi force close / hang lama.
 *
 * Sekarang katalog disimpan di tabel SQLite (T_CATALOG) dengan index di
 * kolom SKU. Insert dilakukan streaming baris-per-baris di dalam SATU
 * transaction (bukan Map raksasa di RAM), dan pencarian SKU memakai query
 * ber-index sehingga cepat walau datanya besar.
 */
data class CatalogRow(
    val sku: String, val desc: String, val shelf: String,
    val price: String, val balance: String,
    // ★ FIX: field baru untuk keterangan tambahan di hasil scan SKU
    val discount: String = "-", val discStart: String = "-", val discEnd: String = "-",
    val longSku: String = "-", val keepStock: String = "-",
    // ★ FIX (Menu 4 — Keep Stock, Sync Recon: Data Master dari lokal SQLite/02):
    // kolom FIXED (bukan hasil ColMappingPrefs yang bisa diubah user), dipakai
    // KHUSUS untuk pembanding Data Master di KeepStockReconSync —
    // Rack = kolom 2, Deskripsi Master = kolom 4, No Ctn = kolom 22.
    val masterRack: String = "-", val masterDesc: String = "-", val masterNoCtn: String = "-"
)

/**
 * ★ FIX (Menu 5 — Stock Comparison): hasil perbandingan antara jumlah fisik
 * yang di-scan/hitung di Scan Process (history, di-sum per SKU) dengan
 * balance sistem (dari katalog hasil download 02.txt).
 */
data class ComparisonRow(
    val sku: String,
    val shelf: String,
    val desc: String,
    val historyBalance: Int,
    val systemBalance: Int,
    val difference: Int,
    // ★ FIX: true = SKU ini sudah di-scan di Menu 2. false = SKU ini belum
    // pernah di-scan sama sekali, ditambahkan ke list karena satu shelf dengan
    // filter Shelf yang aktif (supaya kelihatan item apa saja yang "Belum" discan).
    val scanned: Boolean = true,
    // ★ FIX (baru — Stock Comparison vs Keep Stock): qty Keep Stock SKU ini
    // (kolom "Keep Stock" di katalog, hasil mapping ColMappingPrefs), dan
    // systemBalance DI ATAS SUDAH DIKURANGI nilai ini:
    //   systemBalance (adjusted) = Stok Sekarang (raw) - Stok Keep Stock
    // rawSystemBalance disimpan terpisah untuk keperluan tampilan/export kalau
    // dibutuhkan nanti.
    val keepStock: Int = 0,
    val rawSystemBalance: Int = 0,
    // ★ FIX (baru — Export PDF sort by scan time): id record scan PALING AWAL
    // untuk SKU ini (dipakai untuk urutkan Ascending: paling lama di atas,
    // paling baru di bawah). 0 untuk baris yang belum pernah discan (scanned
    // = false) — baris begini tidak punya waktu scan sama sekali.
    val firstScanId: Long = 0L,
    // ★ FIX (baru — Export PDF filter by Time): waktu scan PERTAMA untuk SKU
    // ini (format "dd/MM/yy HH:mm:ss", sama seperti kolom scan_time di DB).
    // "-" untuk baris yang belum pernah discan (scanned = false). Dipakai
    // khusus untuk filter Time pada logika Export PDF (data Scan Result).
    val firstScanTime: String = "-",
    // ★ FIX (Menu 5 — Fitur Edit Langsung / 2nd Check): true kalau SKU ini
    // sudah pernah melalui alur 2nd check (ada record di T_SECOND_CHECK),
    // dipakai untuk penanda visual (badge) di baris list.
    val secondChecked: Boolean = false,
    val secondCheckUser: String = "-",
    val secondCheckTime: String = "-"
)

/**
 * ★ FIX (Menu 5 — Fitur Edit Langsung / 2nd Check di Stock Comparison):
 * satu baris riwayat audit trail hasil edit langsung (inline edit) pada
 * data dengan status Difference (+), Difference (-), atau Not Scanned.
 * Disimpan per-SKU (1 baris terbaru per SKU, REPLACE kalau di-edit lagi).
 */
data class SecondCheckRow(
    val sku: String,
    val shelf: String,
    val desc: String,
    val systemBalance: Int,
    val keepStock: Int,
    val balance: Int,
    val difference: Int,
    val userId: String,
    val editTime: String,
    val synced: Boolean = false
)

class AppDatabase(context: Context) :
    SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {

    companion object {
        const val DB_NAME    = "QubeDB.db"
        // ★ FIX: naik ke versi 6 karena tambah tabel exio_state (state
        // "kunci sudah diproses" untuk fitur Menu 4 Keep Stock - Sync IN/OUT).
        // ★ FIX: naik ke versi 9 karena tambah kolom master_rack/master_desc/master_noctn
        // di T_CATALOG (Data Master lokal SQLite/02 untuk Menu 4 Keep Stock - Sync Recon).
        // ★ FIX: naik ke versi 11 karena tambah tabel exio_outbox (Outbox Pattern
        // untuk Sync IN/OUT — staging hasil compute sebelum upload, supaya tahan
        // force-close/crash di tengah proses, bukan cuma tahan exception biasa).
        // ★ FIX: naik ke versi 12 karena tambah tabel second_check (audit
        // trail fitur Edit Langsung / 2nd Check di Menu 5 - Stock Comparison).
        const val DB_VERSION = 12

        // ── VAULT constants ───────────────────────────────────────────────
        const val T_VAULT      = "vault_item"
        const val C_VLT_ID     = "_id"
        const val C_VLT_NAME   = "orig_name"
        const val C_VLT_STORED = "stored_name"
        const val C_VLT_MIME   = "mime_type"
        const val C_VLT_KIND   = "kind"
        const val C_VLT_SIZE   = "size_bytes"
        const val C_VLT_TIME   = "added_time"

        const val T_DOIB      = "doib_check"
        const val C_DOIB_ID   = "_id"
        const val C_DOIB_CODE = "scan_code"
        const val C_DOIB_TIME = "scan_time"

        const val T_STOCK   = "stock_take"
        const val C_ST_ID   = "_id"
        const val C_ST_SKU  = "sku"
        const val C_ST_QTY  = "qty"
        const val C_ST_TIME = "scan_time"

        const val T_PRICE       = "price_enquire"
        const val C_PE_ID       = "_id"
        const val C_PE_SKU      = "sku"
        const val C_PE_DESC     = "description"
        const val C_PE_SHELF    = "shelf"
        const val C_PE_PRICE    = "price"
        const val C_PE_BALANCE  = "balance"
        // ★ FIX: jumlah fisik yang di-scan/hitung untuk 1 kali scan (default 1),
        // dipakai untuk fitur Menu 5 - Stock Comparison (sum per SKU vs sistem).
        const val C_PE_QTY      = "qty"
        const val C_PE_TIME     = "scan_time"
        const val C_PE_UPLOADED = "uploaded"

        const val T_SHELF    = "shelf_record"
        const val C_SH_ID    = "_id"
        const val C_SH_SHELF = "shelf_code"
        const val C_SH_SKU   = "sku"
        const val C_SH_TIME  = "scan_time"

        // ── DATA COLLECTOR (Menu 4 — Shelf Record / Stock Take generik) ────
        const val T_DC        = "data_collector"
        const val C_DC_ID     = "_id"
        const val C_DC_SHELF  = "shelf"
        const val C_DC_CODE   = "scan_code"
        const val C_DC_QTY    = "qty"           // "" kalau mode Shelf Record
        const val C_DC_MODE   = "mode"          // "SHELF_RECORD" | "STOCK_TAKE"
        const val C_DC_TIME   = "scan_time"
        const val C_DC_UPLOADED = "uploaded"

        // ── PRICE CATALOG (hasil download 02.txt) ─────────────────────
        const val T_CATALOG      = "price_catalog"
        const val C_CAT_ID       = "_id"
        const val C_CAT_SKU      = "sku"
        const val C_CAT_DESC     = "description"
        const val C_CAT_SHELF    = "shelf"
        const val C_CAT_PRICE    = "price"
        const val C_CAT_BALANCE  = "balance"
        // ★ FIX: kolom tambahan untuk keterangan hasil scan SKU (custom 5x2)
        const val C_CAT_DISCOUNT    = "discount"
        const val C_CAT_DISC_START  = "disc_start_date"
        const val C_CAT_DISC_END    = "disc_end_date"
        const val C_CAT_LONGSKU     = "long_sku"
        const val C_CAT_KEEPSTOCK   = "keep_stock"
        // ★ FIX (Menu 4 — Keep Stock, Sync Recon): Data Master FIXED-column dari
        // lokal SQLite/02, terpisah dari ColMappingPrefs yang dipakai menu lain
        // (Shelf Price Enquire dll, bisa diubah-ubah user). Mapping SELALU:
        // SKU = kolom 1 (pakai C_CAT_SKU yang sudah ada), Rack = kolom 2,
        // No Ctn = kolom 22, Deskripsi = kolom 4.
        const val C_CAT_MASTER_RACK   = "master_rack"
        const val C_CAT_MASTER_DESC   = "master_desc"
        const val C_CAT_MASTER_NOCTN  = "master_noctn"

        // ★ FIX (Menu 4 — Keep Stock Sync IN/OUT)
        const val T_EXIO_STATE  = "exio_state"
        const val C_EXIO_STORE  = "store"
        const val C_EXIO_KEY    = "bc_key"

        // ★ FIX (Sync IN/OUT — logika keluarga SKU baru): riwayat kunci yang
        // pernah di-OUT-kan, per toko. Dipakai untuk deteksi RE-IN (kunci yang
        // dulu OUT lalu muncul lagi harus ditandai RE-IN, bukan IN biasa).
        const val T_EXIO_OUT_HISTORY = "exio_out_history"
        const val C_EXIO_OUT_STORE   = "store"
        const val C_EXIO_OUT_KEY     = "bc_key"

        // ★ FIX (baru — Outbox Pattern untuk Sync IN/OUT): staging hasil compute
        // (file1-4 + state hasil hitung) SEBELUM upload dimulai, per toko (1 baris
        // "pending" per toko). Kalau app mati di tengah upload (force-close, OS
        // kill, HP restart — bukan sekadar exception biasa), data yang sudah
        // dihitung TETAP ADA di sini dan bisa dilanjutkan (resume) di sync
        // berikutnya tanpa hitung ulang dari nol. Baris dihapus (clearOutbox)
        // setelah semua file dipastikan terkirim & state ter-commit ke exio_state.
        // Delimiter antar-elemen Set/List pakai U+0001 (unit separator) supaya
        // aman walau ada karakter koma/newline di data SKU/No Ctn.
        const val T_EXIO_OUTBOX          = "exio_outbox"
        const val C_EXOB_STORE           = "store"
        const val C_EXOB_FILE1           = "file1"
        const val C_EXOB_FILE2           = "file2"
        const val C_EXOB_FILE3           = "file3"
        const val C_EXOB_FILE4           = "file4"
        const val C_EXOB_HAS_NEW_IN      = "has_new_in"
        const val C_EXOB_NEW_IN_COUNT    = "new_in_count"
        const val C_EXOB_OUT_COUNT       = "out_count"
        const val C_EXOB_UPDATED_KEYS    = "updated_keys"
        const val C_EXOB_UPDATED_OUT_HIST = "updated_out_history"
        const val C_EXOB_LOG             = "log_text"
        const val C_EXOB_TIME            = "created_time"
        private const val OUTBOX_DELIM = "\u0001"

        // ★ FIX (Menu 4 — Keep Stock, Edit History): riwayat aksi Add/Edit/Move/Delete
        // dari layar View & Edit Data — disimpan lokal di HP (per device), bukan di
        // Google Sheets, supaya tetap tercatat walau LOG AKTIVITAS di Sheets tidak
        // ke-trigger untuk perubahan yang datang dari Web App (setValues via script
        // tidak memicu onEdit trigger Google Sheets).
        const val T_KS_HISTORY       = "ks_history"
        const val C_KSH_ID           = "id"
        const val C_KSH_TIME         = "time"
        const val C_KSH_STORE        = "store"
        const val C_KSH_PIC          = "pic"
        const val C_KSH_ACTION       = "action"       // ADD / EDIT / MOVE / DELETE
        const val C_KSH_NOCTN_BEFORE = "noctn_before"
        const val C_KSH_SKU_BEFORE   = "sku_before"
        const val C_KSH_QTY_BEFORE   = "qty_before"
        const val C_KSH_NOCTN_AFTER  = "noctn_after"
        const val C_KSH_SKU_AFTER    = "sku_after"
        const val C_KSH_QTY_AFTER    = "qty_after"

        // ★ FIX (Menu 5 — Stock Comparison, Fitur Edit Langsung / 2nd Check):
        // audit trail hasil edit inline (Shelf/System/Balance) untuk baris
        // dengan status Difference (+), Difference (-), atau Not Scanned.
        // 1 baris TERBARU per SKU (sku = PRIMARY KEY, di-REPLACE tiap edit
        // ulang). TIDAK di-drop di onUpgrade supaya riwayat tidak hilang.
        const val T_SECOND_CHECK   = "second_check"
        const val C_SC_SKU         = "sku"
        const val C_SC_SHELF       = "shelf"
        const val C_SC_DESC        = "description"
        const val C_SC_SYSTEM      = "system_balance"
        const val C_SC_KEEPSTOCK   = "keep_stock"
        const val C_SC_BALANCE     = "balance"
        const val C_SC_DIFF        = "difference"
        const val C_SC_USER        = "user_id"
        const val C_SC_TIME        = "edit_time"
        const val C_SC_SYNCED      = "synced_to_sheet"
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS $T_DOIB ($C_DOIB_ID INTEGER PRIMARY KEY AUTOINCREMENT, $C_DOIB_CODE TEXT, $C_DOIB_TIME TEXT)")
        db.execSQL("CREATE TABLE IF NOT EXISTS $T_STOCK ($C_ST_ID INTEGER PRIMARY KEY AUTOINCREMENT, $C_ST_SKU TEXT, $C_ST_QTY INTEGER, $C_ST_TIME TEXT)")
        db.execSQL("CREATE TABLE IF NOT EXISTS $T_PRICE ($C_PE_ID INTEGER PRIMARY KEY AUTOINCREMENT, $C_PE_SKU TEXT, $C_PE_DESC TEXT, $C_PE_SHELF TEXT, $C_PE_PRICE TEXT, $C_PE_BALANCE TEXT, $C_PE_QTY INTEGER DEFAULT 1, $C_PE_TIME TEXT, $C_PE_UPLOADED INTEGER DEFAULT 0)")
        db.execSQL("CREATE TABLE IF NOT EXISTS $T_SHELF ($C_SH_ID INTEGER PRIMARY KEY AUTOINCREMENT, $C_SH_SHELF TEXT, $C_SH_SKU TEXT, $C_SH_TIME TEXT)")
        // ★ FIX (baru — Menu 4: Data Collector)
        db.execSQL("CREATE TABLE IF NOT EXISTS $T_DC ($C_DC_ID INTEGER PRIMARY KEY AUTOINCREMENT, $C_DC_SHELF TEXT, $C_DC_CODE TEXT, $C_DC_QTY TEXT, $C_DC_MODE TEXT, $C_DC_TIME TEXT, $C_DC_UPLOADED INTEGER DEFAULT 0)")
        db.execSQL("CREATE TABLE IF NOT EXISTS $T_VAULT ($C_VLT_ID INTEGER PRIMARY KEY AUTOINCREMENT, $C_VLT_NAME TEXT, $C_VLT_STORED TEXT, $C_VLT_MIME TEXT, $C_VLT_KIND TEXT, $C_VLT_SIZE INTEGER, $C_VLT_TIME TEXT)")
        db.execSQL("CREATE TABLE IF NOT EXISTS $T_CATALOG ($C_CAT_ID INTEGER PRIMARY KEY AUTOINCREMENT, $C_CAT_SKU TEXT, $C_CAT_DESC TEXT, $C_CAT_SHELF TEXT, $C_CAT_PRICE TEXT, $C_CAT_BALANCE TEXT, $C_CAT_DISCOUNT TEXT, $C_CAT_DISC_START TEXT, $C_CAT_DISC_END TEXT, $C_CAT_LONGSKU TEXT, $C_CAT_KEEPSTOCK TEXT, $C_CAT_MASTER_RACK TEXT, $C_CAT_MASTER_DESC TEXT, $C_CAT_MASTER_NOCTN TEXT)")
        db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_catalog_sku ON $T_CATALOG($C_CAT_SKU)")
        // ★ FIX (Menu 4 — Keep Stock Sync IN/OUT): state "kunci B|C sudah diproses"
        // per toko, porting dari file CGAR_processed.txt di EXINOUT_CGAR.py.
        db.execSQL("CREATE TABLE IF NOT EXISTS $T_EXIO_STATE ($C_EXIO_STORE TEXT, $C_EXIO_KEY TEXT, PRIMARY KEY ($C_EXIO_STORE, $C_EXIO_KEY))")
        // ★ FIX (Sync IN/OUT — RE-IN): riwayat kunci yang pernah di-OUT-kan per toko.
        db.execSQL("CREATE TABLE IF NOT EXISTS $T_EXIO_OUT_HISTORY ($C_EXIO_OUT_STORE TEXT, $C_EXIO_OUT_KEY TEXT, PRIMARY KEY ($C_EXIO_OUT_STORE, $C_EXIO_OUT_KEY))")
        // ★ FIX (baru — Outbox Pattern): staging hasil compute Sync IN/OUT sebelum
        // upload, 1 baris per toko (PRIMARY KEY = store, jadi otomatis overwrite
        // kalau sync ulang dipanggil sebelum outbox lama dibersihkan).
        db.execSQL("CREATE TABLE IF NOT EXISTS $T_EXIO_OUTBOX (" +
            "$C_EXOB_STORE TEXT PRIMARY KEY, $C_EXOB_FILE1 TEXT, $C_EXOB_FILE2 TEXT, " +
            "$C_EXOB_FILE3 TEXT, $C_EXOB_FILE4 TEXT, $C_EXOB_HAS_NEW_IN INTEGER, " +
            "$C_EXOB_NEW_IN_COUNT INTEGER, $C_EXOB_OUT_COUNT INTEGER, " +
            "$C_EXOB_UPDATED_KEYS TEXT, $C_EXOB_UPDATED_OUT_HIST TEXT, " +
            "$C_EXOB_LOG TEXT, $C_EXOB_TIME TEXT)")
        // ★ FIX (Menu 4 — Keep Stock, Edit History): TIDAK di-drop di onUpgrade (lihat
        // di bawah) supaya riwayat edit tidak hilang saat skema database naik versi.
        db.execSQL("CREATE TABLE IF NOT EXISTS $T_KS_HISTORY (" +
            "$C_KSH_ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
            "$C_KSH_TIME TEXT, $C_KSH_STORE TEXT, $C_KSH_PIC TEXT, $C_KSH_ACTION TEXT, " +
            "$C_KSH_NOCTN_BEFORE TEXT, $C_KSH_SKU_BEFORE TEXT, $C_KSH_QTY_BEFORE TEXT, " +
            "$C_KSH_NOCTN_AFTER TEXT, $C_KSH_SKU_AFTER TEXT, $C_KSH_QTY_AFTER TEXT)")
        // ★ FIX (Menu 5 — Fitur Edit Langsung / 2nd Check): TIDAK di-drop di
        // onUpgrade (lihat di bawah) supaya audit trail edit tidak hilang
        // saat skema database naik versi.
        db.execSQL("CREATE TABLE IF NOT EXISTS $T_SECOND_CHECK (" +
            "$C_SC_SKU TEXT PRIMARY KEY, $C_SC_SHELF TEXT, $C_SC_DESC TEXT, " +
            "$C_SC_SYSTEM INTEGER, $C_SC_KEEPSTOCK INTEGER, $C_SC_BALANCE INTEGER, " +
            "$C_SC_DIFF INTEGER, $C_SC_USER TEXT, $C_SC_TIME TEXT, $C_SC_SYNCED INTEGER DEFAULT 0)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $T_DOIB")
        db.execSQL("DROP TABLE IF EXISTS $T_STOCK")
        db.execSQL("DROP TABLE IF EXISTS $T_PRICE")
        db.execSQL("DROP TABLE IF EXISTS $T_SHELF")
        db.execSQL("DROP TABLE IF EXISTS $T_DC")
        db.execSQL("DROP TABLE IF EXISTS $T_CATALOG")
        // ★ FIX (Perbaikan Sinkronisasi — lanjutan): SEBELUMNYA baris di bawah ini ada:
        //     db.execSQL("DROP TABLE IF EXISTS $T_EXIO_STATE")
        // Efeknya: SETIAP KALI aplikasi di-update ke versi yang menaikkan
        // DB_VERSION, seluruh "memori" Sync IN/OUT (kunci mana saja yang
        // sudah tercatat aktif per toko) IKUT DIHAPUS TOTAL. Skema tabel ini
        // sendiri TIDAK PERNAH berubah sejak dibuat (tetap 2 kolom: store,
        // bc_key) — jadi drop ini bukan untuk keperluan migrasi skema, murni
        // efek samping dari pola "drop semua lalu bikin ulang" yang dipakai
        // di fungsi ini. Akibat nyatanya di lapangan: setelah update APK,
        // Sync IN/OUT berikutnya bisa "kebingungan" — misalnya menganggap
        // SEMUA data di GSheet sebagai baru (state lama kosong lagi), atau
        // sebaliknya kombinasi state-kosong + logika ACTIVE/MOVE membuat
        // perubahan yang sebenarnya banyak di GSheet malah tidak terdeteksi
        // dengan benar sebagai IN/OUT saat sync — persis gejala yang dilaporkan.
        //
        // FIX: T_EXIO_STATE & T_EXIO_OUT_HISTORY TIDAK di-drop lagi di sini.
        // onCreate() di bawah tetap dipanggil dan tetap aman karena semua
        // CREATE TABLE-nya pakai "IF NOT EXISTS" — kalau tabelnya sudah ada
        // (skema sudah sesuai sejak awal, tidak pernah berubah), baris ini
        // otomatis dilewati dan data yang sudah ada TETAP UTUH.
        onCreate(db)
            db?.execSQL("CREATE TABLE IF NOT EXISTS $T_VAULT ($C_VLT_ID INTEGER PRIMARY KEY AUTOINCREMENT, $C_VLT_NAME TEXT, $C_VLT_STORED TEXT, $C_VLT_MIME TEXT, $C_VLT_KIND TEXT, $C_VLT_SIZE INTEGER, $C_VLT_TIME TEXT)")
}

    private fun now() = SimpleDateFormat("dd/MM/yy HH:mm:ss", Locale.getDefault()).format(Date())

    // ── DO/IB ──────────────────────────────────────────────────────────
    fun insertDoib(code: String) {
        val v = ContentValues().apply { put(C_DOIB_CODE, code); put(C_DOIB_TIME, now()) }
        writableDatabase.insert(T_DOIB, null, v)
    }
    fun getAllDoib(): Cursor = readableDatabase.query(T_DOIB, null, null, null, null, null, "$C_DOIB_ID DESC")
    fun clearDoib()  = writableDatabase.delete(T_DOIB, null, null)
    /** FIX: hapus 1 baris data DO/IB (klik item di list -> konfirmasi -> hapus) */
    fun deleteDoib(id: Int) = writableDatabase.delete(T_DOIB, "$C_DOIB_ID=?", arrayOf(id.toString()))

    // ── STOCK TAKE ─────────────────────────────────────────────────────
    fun insertStock(sku: String, qty: Int) {
        val v = ContentValues().apply { put(C_ST_SKU, sku); put(C_ST_QTY, qty); put(C_ST_TIME, now()) }
        writableDatabase.insert(T_STOCK, null, v)
    }
    fun insertOrSumStock(sku: String, qty: Int, sumMode: Boolean) {
        val db = writableDatabase
        if (sumMode) {
            val cur = db.query(T_STOCK, arrayOf(C_ST_ID, C_ST_QTY), "$C_ST_SKU=?", arrayOf(sku), null, null, null)
            if (cur.moveToFirst()) {
                val id = cur.getInt(0); val existing = cur.getInt(1); cur.close()
                val v = ContentValues().apply { put(C_ST_QTY, existing + qty); put(C_ST_TIME, now()) }
                db.update(T_STOCK, v, "$C_ST_ID=?", arrayOf(id.toString())); return
            }
            cur.close()
        }
        val v = ContentValues().apply { put(C_ST_SKU, sku); put(C_ST_QTY, qty); put(C_ST_TIME, now()) }
        db.insert(T_STOCK, null, v)
    }
    fun getAllStock(): Cursor = readableDatabase.query(T_STOCK, null, null, null, null, null, "$C_ST_ID DESC")
    fun clearStock()  = writableDatabase.delete(T_STOCK, null, null)
    /** FIX: hapus 1 baris data stock take (klik item di list -> konfirmasi -> hapus) */
    fun deleteStock(id: Int) = writableDatabase.delete(T_STOCK, "$C_ST_ID=?", arrayOf(id.toString()))

    // ── PRICE ENQUIRE ──────────────────────────────────────────────────
    // ★ FIX: tambah parameter qty (default 1) = jumlah fisik yang dihitung
    // saat scan ini, dipakai fitur Menu 5 - Stock Comparison.
    /** ★ FIX (baru — indikator "baru discan"): sekarang me-return row id (rowid)
     *  hasil insert, supaya UI (History Scan) bisa tahu persis baris mana yang
     *  BARU SAJA masuk dan menandainya (highlight/badge "NEW"). */
    fun insertPrice(sku: String, desc: String, shelf: String, price: String, balance: String, qty: Int = 1): Long {
        val v = ContentValues().apply {
            put(C_PE_SKU, sku); put(C_PE_DESC, desc); put(C_PE_SHELF, shelf)
            put(C_PE_PRICE, price); put(C_PE_BALANCE, balance); put(C_PE_QTY, qty)
            put(C_PE_TIME, now()); put(C_PE_UPLOADED, 0)
        }
        return writableDatabase.insert(T_PRICE, null, v)
    }
    fun getAllPrice(): Cursor        = readableDatabase.query(T_PRICE, null, null, null, null, null, "$C_PE_ID DESC")

    /**
     * ★ FIX (baru — Import History Scan ke Stock Take/Add Box): ambil data
     * History Scan (tabel $T_PRICE, diisi lewat menu "Stock Balance Check")
     * SUDAH DIKELOMPOKKAN per (Shelf, SKU) dengan Qty DIJUMLAHKAN — persis
     * qty HASIL SCAN (bukan balance/qty sistem dari katalog). Dipakai untuk
     * mengisi Stock Take/Add Box (menu Data Collector) tanpa perlu scan
     * ulang, kalau user sudah scan lewat Stock Balance Check duluan.
     * Baris dengan Shelf atau SKU kosong dilewati (tidak valid untuk Stock
     * Take/Add Box, yang wajib punya Shelf & SKU).
     */
    data class PriceHistoryGroup(val shelf: String, val sku: String, val desc: String, val qty: Int)
    fun getPriceHistoryGrouped(): List<PriceHistoryGroup> {
        val result = mutableListOf<PriceHistoryGroup>()
        val c = readableDatabase.rawQuery(
            "SELECT $C_PE_SHELF, $C_PE_SKU, MAX($C_PE_DESC), SUM($C_PE_QTY), MIN($C_PE_ID) " +
                "FROM $T_PRICE GROUP BY $C_PE_SHELF, $C_PE_SKU ORDER BY MIN($C_PE_ID) ASC", null
        )
        c.use {
            while (it.moveToNext()) {
                val shelf = it.getString(0)?.trim() ?: ""
                val sku = it.getString(1)?.trim() ?: ""
                val desc = it.getString(2) ?: "-"
                val qty = it.getInt(3)
                if (shelf.isEmpty() || sku.isEmpty()) continue
                result.add(PriceHistoryGroup(shelf, sku, desc, qty))
            }
        }
        return result
    }
    fun getPriceUnuploaded(): Cursor = readableDatabase.query(T_PRICE, null, "$C_PE_UPLOADED=0", null, null, null, "$C_PE_ID ASC")
    fun markPriceUploaded(id: Int) {
        val v = ContentValues().apply { put(C_PE_UPLOADED, 1) }
        writableDatabase.update(T_PRICE, v, "$C_PE_ID=?", arrayOf(id.toString()))
    }
    fun updatePriceBalance(id: Int, newBalance: String) {
        val v = ContentValues().apply { put(C_PE_BALANCE, newBalance) }
        writableDatabase.update(T_PRICE, v, "$C_PE_ID=?", arrayOf(id.toString()))
    }
    /** ★ FIX: edit Qty (jumlah fisik) dari history — dipakai fitur Menu 5 Stock Comparison. */
    fun updatePriceQty(id: Int, newQty: Int) {
        val v = ContentValues().apply { put(C_PE_QTY, newQty) }
        writableDatabase.update(T_PRICE, v, "$C_PE_ID=?", arrayOf(id.toString()))
    }
    fun clearPrice()  = writableDatabase.delete(T_PRICE, null, null)
    /** ★ FIX (baru — delete per SKU di History Stock Balance Check): hapus 1
     *  record scan berdasarkan id (dipicu lewat long-press pada baris History). */
    fun deletePrice(id: Int) = writableDatabase.delete(T_PRICE, "$C_PE_ID=?", arrayOf(id.toString()))
    fun countPrice(): Int {
        val c = readableDatabase.rawQuery("SELECT COUNT(*) FROM $T_PRICE", null)
        c.moveToFirst(); val n = c.getInt(0); c.close(); return n
    }

    /**
     * FIX (force close): ganti total katalog dengan data baru dari 02.txt.
     * `rows` berupa Sequence sehingga baris diproses satu-per-satu tanpa
     * pernah menahan seluruh katalog di memori. Semua insert dibungkus
     * SATU transaction (bukan auto-commit per baris) supaya penyimpanan
     * katalog besar tetap cepat & tidak bikin UI terasa hang.
     */
    fun replaceCatalog(rows: Sequence<CatalogRow>): Int {
        val wdb = writableDatabase
        var count = 0
        wdb.beginTransaction()
        try {
            wdb.delete(T_CATALOG, null, null)
            // FIX (UNIQUE constraint failed): 02.txt kadang berisi SKU yang muncul
            // lebih dari sekali. Pakai INSERT OR REPLACE supaya baris yang belakangan
            // menimpa baris sebelumnya (SKU sama), bukan bikin seluruh download gagal.
            val stmt = wdb.compileStatement(
                "INSERT OR REPLACE INTO $T_CATALOG " +
                    "($C_CAT_SKU,$C_CAT_DESC,$C_CAT_SHELF,$C_CAT_PRICE,$C_CAT_BALANCE," +
                    "$C_CAT_DISCOUNT,$C_CAT_DISC_START,$C_CAT_DISC_END,$C_CAT_LONGSKU,$C_CAT_KEEPSTOCK," +
                    "$C_CAT_MASTER_RACK,$C_CAT_MASTER_DESC,$C_CAT_MASTER_NOCTN) " +
                    "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)"
            )
            rows.forEach { r ->
                stmt.clearBindings()
                stmt.bindString(1, r.sku)
                stmt.bindString(2, r.desc)
                stmt.bindString(3, r.shelf)
                stmt.bindString(4, r.price)
                stmt.bindString(5, r.balance)
                stmt.bindString(6, r.discount)
                stmt.bindString(7, r.discStart)
                stmt.bindString(8, r.discEnd)
                stmt.bindString(9, r.longSku)
                stmt.bindString(10, r.keepStock)
                stmt.bindString(11, r.masterRack)
                stmt.bindString(12, r.masterDesc)
                stmt.bindString(13, r.masterNoCtn)
                stmt.executeInsert()
                count++
            }
            wdb.setTransactionSuccessful()
        } finally {
            wdb.endTransaction()
        }
        return count
    }

    /** Cari 1 SKU langsung dari SQLite (pakai index) — tidak perlu load semua data ke RAM. */
    fun findCatalog(sku: String): Map<String, String>? {
        val c = readableDatabase.query(
            T_CATALOG, null, "$C_CAT_SKU=?", arrayOf(sku), null, null, null, "1"
        )
        c.use {
            if (it.moveToFirst()) {
                fun col(name: String) = it.getString(it.getColumnIndexOrThrow(name)) ?: "-"
                return mapOf(
                    "sku"       to sku,
                    "balance"   to col(C_CAT_BALANCE),
                    "shelf"     to col(C_CAT_SHELF),
                    "price"     to col(C_CAT_PRICE),
                    "desc"      to col(C_CAT_DESC),
                    // ★ FIX: field tambahan untuk keterangan hasil scan SKU (custom 5x2)
                    "discount"  to col(C_CAT_DISCOUNT),
                    "discStart" to col(C_CAT_DISC_START),
                    "discEnd"   to col(C_CAT_DISC_END),
                    "longSku"   to col(C_CAT_LONGSKU),
                    "keepStock" to col(C_CAT_KEEPSTOCK)
                )
            }
        }
        return null
    }

    fun countCatalog(): Int {
        val c = readableDatabase.rawQuery("SELECT COUNT(*) FROM $T_CATALOG", null)
        c.use { it.moveToFirst(); return it.getInt(0) }
    }

    /** Untuk layar "Lihat Data Download 02" — Cursor dipakai langsung oleh CursorAdapter,
     *  jadi baris hanya dimuat sesuai yang tampil di layar (tidak semua ke RAM sekaligus). */
    // ★ FIX: filter sekarang juga cocok ke kolom Shelf, bukan cuma SKU/Desc
    // ★ FIX (baru): tambah filter Shelf (cocok sebagian, tidak case-sensitive) dan
    // filter Balance: 0 = semua, 1 = Balance > 0, 2 = Balance = 0, 3 = Balance < 0.
    // Balance disimpan sebagai TEXT, jadi di-CAST ke angka (koma ribuan dibuang dulu).
    fun getCatalogCursor(filter: String, shelf: String = "", balanceMode: Int = 0): Cursor {
        val where = StringBuilder()
        val args = ArrayList<String>()
        if (filter.isNotBlank()) {
            val like = "%${filter.uppercase()}%"
            where.append("(UPPER($C_CAT_SKU) LIKE ? OR UPPER($C_CAT_DESC) LIKE ? OR UPPER($C_CAT_SHELF) LIKE ?)")
            args.add(like); args.add(like); args.add(like)
        }
        if (shelf.isNotBlank()) {
            if (where.isNotEmpty()) where.append(" AND ")
            where.append("UPPER($C_CAT_SHELF) LIKE ?")
            args.add("%${shelf.trim().uppercase()}%")
        }
        val balNum = "CAST(REPLACE(COALESCE($C_CAT_BALANCE,''), ',', '') AS REAL)"
        val balCond = when (balanceMode) {
            1 -> "$balNum > 0"
            2 -> "$balNum = 0"
            3 -> "$balNum < 0"
            else -> null
        }
        if (balCond != null) {
            if (where.isNotEmpty()) where.append(" AND ")
            where.append(balCond)
        }
        return readableDatabase.query(
            T_CATALOG, null,
            if (where.isEmpty()) null else where.toString(),
            if (args.isEmpty()) null else args.toTypedArray(),
            null, null, "$C_CAT_SKU ASC"
        )
    }

    fun clearCatalog() = writableDatabase.delete(T_CATALOG, null, null)

    /**
     * ★ FIX (baru — Menu 3: Expired Discount Checker): ambil SEMUA baris
     * katalog (sudah termasuk kolom Discount/Start/End) untuk diproses jadi
     * Active/Expired. Data yang dipakai SAMA dengan data hasil download 02
     * yang sudah ada di T_CATALOG — tidak perlu file input terpisah lagi
     * seperti versi desktop (CheckDisc.py), karena format & sumber datanya sama.
     */
    fun getAllCatalogRows(): List<CatalogRow> {
        val list = ArrayList<CatalogRow>()
        // ★ FIX (perf — Compare Sistem vs Scan bisa lag/crash): sebelumnya
        // getColumnIndexOrThrow(name) dipanggil ULANG untuk SETIAP kolom di
        // SETIAP baris (lookup nama kolom via string, O(kolom) per baris).
        // Untuk katalog dengan ribuan baris ini jadi overhead besar & bikin
        // proses lama. Sekarang index kolom di-resolve SEKALI saja sebelum
        // loop, lalu dipakai berulang per baris (jauh lebih ringan).
        val c = readableDatabase.query(T_CATALOG, null, null, null, null, null, "$C_CAT_SKU ASC")
        c.use {
            val idxSku = it.getColumnIndexOrThrow(C_CAT_SKU)
            val idxDesc = it.getColumnIndexOrThrow(C_CAT_DESC)
            val idxShelf = it.getColumnIndexOrThrow(C_CAT_SHELF)
            val idxPrice = it.getColumnIndexOrThrow(C_CAT_PRICE)
            val idxBalance = it.getColumnIndexOrThrow(C_CAT_BALANCE)
            val idxDiscount = it.getColumnIndexOrThrow(C_CAT_DISCOUNT)
            val idxDiscStart = it.getColumnIndexOrThrow(C_CAT_DISC_START)
            val idxDiscEnd = it.getColumnIndexOrThrow(C_CAT_DISC_END)
            val idxLongSku = it.getColumnIndexOrThrow(C_CAT_LONGSKU)
            val idxKeepStock = it.getColumnIndexOrThrow(C_CAT_KEEPSTOCK)
            val idxMasterRack = it.getColumnIndexOrThrow(C_CAT_MASTER_RACK)
            val idxMasterDesc = it.getColumnIndexOrThrow(C_CAT_MASTER_DESC)
            val idxMasterNoCtn = it.getColumnIndexOrThrow(C_CAT_MASTER_NOCTN)

            list.ensureCapacity(it.count)
            while (it.moveToNext()) {
                list.add(
                    CatalogRow(
                        sku = it.getString(idxSku) ?: "-",
                        desc = it.getString(idxDesc) ?: "-",
                        shelf = it.getString(idxShelf) ?: "-",
                        price = it.getString(idxPrice) ?: "-",
                        balance = it.getString(idxBalance) ?: "-",
                        discount = it.getString(idxDiscount) ?: "-",
                        discStart = it.getString(idxDiscStart) ?: "-",
                        discEnd = it.getString(idxDiscEnd) ?: "-",
                        longSku = it.getString(idxLongSku) ?: "-",
                        keepStock = it.getString(idxKeepStock) ?: "-",
                        masterRack = it.getString(idxMasterRack) ?: "-",
                        masterDesc = it.getString(idxMasterDesc) ?: "-",
                        masterNoCtn = it.getString(idxMasterNoCtn) ?: "-"
                    )
                )
            }
        }
        return list
    }

    /**
     * ★ FIX (baru — Compare Sistem vs Scan untuk Stock Take/Add Box):
     * porting logika dari halaman web "Compare Sistem vs Scan" — TANPA
     * upload file, langsung membandingkan:
     *  - Data Sistem  : T_CATALOG (SKU, Shelf, Balance, Keep Stock, Desc) —
     *                   sama seperti "Data 1" di web (hasil download 02.txt).
     *  - Data Scan    : T_DC yang mode-nya STOCK_TAKE (Shelf, SKU, Qty),
     *                   di-SUM per (Shelf, SKU) kalau SKU yang sama discan
     *                   berkali-kali di shelf yang sama — sama seperti
     *                   "Data 2" di web.
     *
     * Perbandingan HANYA dilakukan untuk Shelf yang MUNCUL di data scan
     * (sama seperti web: grup dibentuk dari alamat yang ada di Data Scan),
     * supaya tidak menampilkan seluruh katalog untuk Shelf yang memang
     * belum mulai di-stock-take.
     *
     * Status per baris (dipetakan ke field ComparisonRow yang sudah ada,
     * dianotasi lewat `desc` untuk status yang tidak ada field khususnya):
     *  - scanned=false                → "Belum Discan" (SKU sistem di shelf
     *                                    itu tapi tidak ada di data scan)
     *  - scanned=true, difference=0   → "Sesuai"
     *  - scanned=true, difference!=0  → "Selisih Qty"
     *  - desc diawali "[WRONG SHELF"  → "Alamat Tidak Sesuai" (SKU discan di
     *                                    shelf X tapi terdaftar sistem di shelf lain)
     *  - desc diawali "[NOT REGIST"   → "Tidak Terdaftar" (SKU discan tapi
     *                                    sama sekali tidak ada di sistem)
     *
     * effectiveScan = qty scan + Keep Stock (kalau ada), sama seperti web.
     */
    fun getStockTakeCompareRows(): List<ComparisonRow> {
        val catalog = getAllCatalogRows()
        val sysBySku = HashMap<String, MutableList<CatalogRow>>()
        catalog.forEach { sysBySku.getOrPut(it.sku) { mutableListOf() }.add(it) }
        val sysByShelf = HashMap<String, MutableList<CatalogRow>>()
        catalog.forEach { sysByShelf.getOrPut(it.shelf.trim().lowercase()) { mutableListOf() }.add(it) }

        data class ScanAgg(var qty: Int = 0, var firstId: Long = 0L, var firstTime: String = "-")
        // key = shelf(lowercase-trim) to SKU
        val scanMap = LinkedHashMap<Pair<String, String>, ScanAgg>()
        val displayShelf = HashMap<String, String>() // lowercase -> original casing (first seen)

        val cScan = readableDatabase.query(
            T_DC, null, "$C_DC_MODE=?", arrayOf("STOCK_TAKE"), null, null, "$C_DC_ID ASC"
        )
        cScan.use {
            while (it.moveToNext()) {
                val shelfRaw = it.getString(it.getColumnIndexOrThrow(C_DC_SHELF))?.trim() ?: ""
                val sku = it.getString(it.getColumnIndexOrThrow(C_DC_CODE))?.trim() ?: ""
                val qty = it.getString(it.getColumnIndexOrThrow(C_DC_QTY))?.toIntOrNull() ?: 0
                val id = it.getLong(it.getColumnIndexOrThrow(C_DC_ID))
                val time = it.getString(it.getColumnIndexOrThrow(C_DC_TIME)) ?: "-"
                if (shelfRaw.isEmpty() || sku.isEmpty()) continue
                val shelfKey = shelfRaw.lowercase()
                displayShelf.putIfAbsent(shelfKey, shelfRaw)
                val key = shelfKey to sku
                val agg = scanMap.getOrPut(key) { ScanAgg() }
                agg.qty += qty
                if (agg.firstId == 0L || id < agg.firstId) {
                    agg.firstId = id
                    agg.firstTime = time
                }
            }
        }

        val result = mutableListOf<ComparisonRow>()
        val shelfKeys = scanMap.keys.map { it.first }.toSortedSet()

        shelfKeys.forEach { shelfKey ->
            val shelfLabel = displayShelf[shelfKey] ?: shelfKey
            val sysItemsInShelf = sysByShelf[shelfKey] ?: emptyList()
            val sysSkuSet = sysItemsInShelf.map { it.sku }.toSet()
            val scannedSkusInShelf = scanMap.keys.filter { it.first == shelfKey }.map { it.second }

            // 1) Item sistem di shelf ini: cocok (Sesuai/Selisih) atau Belum Discan.
            sysItemsInShelf.forEach { sysItem ->
                val agg = scanMap[shelfKey to sysItem.sku]
                val ks = sysItem.keepStock.toIntOrNull() ?: 0
                val sysQty = sysItem.balance.toIntOrNull() ?: 0
                if (agg == null) {
                    if (sysQty == 0) return@forEach
                    result.add(
                        ComparisonRow(
                            sku = sysItem.sku, shelf = shelfLabel, desc = sysItem.desc,
                            historyBalance = 0, systemBalance = sysQty, difference = -sysQty,
                            scanned = false, keepStock = ks, rawSystemBalance = sysQty
                        )
                    )
                } else {
                    val effectiveScan = agg.qty + ks
                    val diff = effectiveScan - sysQty
                    result.add(
                        ComparisonRow(
                            sku = sysItem.sku, shelf = shelfLabel, desc = sysItem.desc,
                            historyBalance = agg.qty, systemBalance = sysQty, difference = diff,
                            scanned = true, keepStock = ks, rawSystemBalance = sysQty,
                            firstScanId = agg.firstId, firstScanTime = agg.firstTime
                        )
                    )
                }
            }

            // 2) SKU hasil scan yang TIDAK ada di sistem untuk shelf ini:
            //    Alamat Tidak Sesuai (ada di sistem tapi di shelf lain) atau
            //    Tidak Terdaftar (tidak ada sama sekali di sistem).
            scannedSkusInShelf.forEach { sku ->
                if (sysSkuSet.contains(sku)) return@forEach
                val agg = scanMap[shelfKey to sku]!!
                val elsewhere = sysBySku[sku]?.firstOrNull()
                if (elsewhere != null) {
                    val ks = elsewhere.keepStock.toIntOrNull() ?: 0
                    val sysQty = elsewhere.balance.toIntOrNull() ?: 0
                    val effectiveScan = agg.qty + ks
                    val diff = effectiveScan - sysQty
                    result.add(
                        ComparisonRow(
                            sku = sku, shelf = shelfLabel,
                            desc = "[WRONG SHELF: system=${elsewhere.shelf}] ${elsewhere.desc}",
                            historyBalance = agg.qty, systemBalance = sysQty, difference = diff,
                            scanned = true, keepStock = ks, rawSystemBalance = sysQty,
                            firstScanId = agg.firstId, firstScanTime = agg.firstTime
                        )
                    )
                } else {
                    result.add(
                        ComparisonRow(
                            sku = sku, shelf = shelfLabel,
                            desc = "[NOT REGISTERED IN SYSTEM]",
                            historyBalance = agg.qty, systemBalance = 0, difference = agg.qty,
                            scanned = true, keepStock = 0, rawSystemBalance = 0,
                            firstScanId = agg.firstId, firstScanTime = agg.firstTime
                        )
                    )
                }
            }
        }

        return result
    }

    /**
     * ★ FIX (Menu 5 — Stock Comparison): bandingkan hasil scan Shelf Price
     * Enquire (history, di-SUM per SKU kalau SKU yang sama di-scan berkali-kali)
     * dengan balance sistem (dari katalog hasil download 02.txt).
     *
     * difference = historyBalance - systemBalance
     *   > 0  → hasil scan LEBIH banyak dari sistem
     *   < 0  → hasil scan KURANG dari sistem
     *   = 0  → sama persis
     */
    /**
     * ★ FIX: tambah parameter shelfFilter (opsional). Kalau diisi, SEMUA SKU
     * di sistem yang shelf-nya sama (walau belum pernah di-scan sama sekali)
     * ikut ditampilkan — supaya kelihatan item apa saja yang "Belum" discan
     * di shelf itu, bukan cuma yang sudah ada di history.
     */
    /**
     * ★ FIX (baru — Barcode Filter di Stock Comparison Report): sebagian data
     * katalog punya 2 representasi barcode untuk 1 item yang sama — kolom 1
     * (SKU utama) dan kolom 23 (long_sku / barcode alternatif). Kalau
     * keduanya BEDA, utamakan yang persis 7 digit (barcode "asli"); yang
     * versi panjang diabaikan. Kalau dua-duanya 7 digit atau dua-duanya
     * bukan 7 digit, default tetap pakai kolom 1 (SKU utama).
     */
    private fun resolveBarcodeIdentity(colSku: String, colLongSku: String): String {
        val a = colSku.trim()
        val b = colLongSku.trim()
        if (b.isBlank() || b == "-" || a.equals(b, ignoreCase = true)) return a
        val aIs7 = a.length == 7 && a.all { it.isDigit() }
        val bIs7 = b.length == 7 && b.all { it.isDigit() }
        return when {
            aIs7 && !bIs7 -> a
            !aIs7 && bIs7 -> b
            else -> a
        }
    }

    /**
     * ★ FIX (baru): sama seperti findCatalog(), tapi khusus dipakai Stock
     * Comparison — kalau SKU yang di-scan TIDAK cocok dengan kolom 1 (SKU
     * utama) tapi cocok dengan kolom 23 (long_sku), tetap dianggap match
     * (fallback), supaya item yang di-scan pakai barcode versi panjang tidak
     * muncul sebagai "NOT FOUND IN SYSTEM" padahal sebenarnya ada di katalog.
     */
    fun findCatalogForComparison(scannedSku: String): Map<String, String>? {
        findCatalog(scannedSku)?.let { return it }
        val c = readableDatabase.query(
            T_CATALOG, null, "$C_CAT_LONGSKU=?", arrayOf(scannedSku), null, null, null, "1"
        )
        c.use {
            if (it.moveToFirst()) {
                fun col(name: String) = it.getString(it.getColumnIndexOrThrow(name)) ?: "-"
                return mapOf(
                    "sku" to scannedSku,
                    "balance" to col(C_CAT_BALANCE),
                    "shelf" to col(C_CAT_SHELF),
                    "price" to col(C_CAT_PRICE),
                    "desc" to col(C_CAT_DESC),
                    "discount" to col(C_CAT_DISCOUNT),
                    "discStart" to col(C_CAT_DISC_START),
                    "discEnd" to col(C_CAT_DISC_END),
                    "longSku" to col(C_CAT_LONGSKU),
                    "keepStock" to col(C_CAT_KEEPSTOCK)
                )
            }
        }
        return null
    }

    /**
     * ★ FIX (baru — Keep Stock harus dari GSheet live, bukan kolom katalog):
     * `keepStockMap` (SKU -> Qty) WAJIB diisi oleh caller dari data Keep Stock
     * TERBARU hasil fetch langsung ke Google Sheets (lihat
     * KeepStockSheetReader.fetchRows di StockComparisonActivity) — fungsi ini
     * SENGAJA tidak lagi baca kolom "keep_stock" di katalog lokal (data itu
     * cuma snapshot lama dari import 02.txt, bukan data live).
     */
    fun getComparisonData(shelfFilters: List<String> = emptyList(), keepStockMap: Map<String, Int> = emptyMap()): List<ComparisonRow> {
        val historyTotals = LinkedHashMap<String, Int>()
        // ★ FIX (baru — Export PDF sort by scan time): ambil juga MIN($C_PE_ID)
        // per SKU = id record scan PERTAMA untuk SKU itu, dipakai sebagai kunci
        // urut waktu (id autoincrement = urutan kronologis insert).
        val firstScanIds = LinkedHashMap<String, Long>()
        val c = readableDatabase.rawQuery(
            "SELECT $C_PE_SKU, SUM($C_PE_QTY), MIN($C_PE_ID) FROM $T_PRICE GROUP BY $C_PE_SKU ORDER BY $C_PE_SKU ASC", null
        )
        c.use {
            while (it.moveToNext()) {
                val sku = it.getString(0) ?: continue
                val qty = it.getInt(1)
                historyTotals[sku] = qty
                firstScanIds[sku] = it.getLong(2)
            }
        }

        // ★ FIX (baru — Export PDF filter by Time): ambil waktu scan (scan_time)
        // untuk tiap id di firstScanIds, dipakai untuk filter Time pada Export
        // PDF (data Scan Result). Query terpisah supaya tidak perlu subquery
        // berat per baris.
        val scanTimeById = HashMap<Long, String>()
        if (firstScanIds.isNotEmpty()) {
            val ids = firstScanIds.values.distinct()
            val placeholders = ids.joinToString(",") { "?" }
            val args = ids.map { it.toString() }.toTypedArray()
            readableDatabase.rawQuery(
                "SELECT $C_PE_ID, $C_PE_TIME FROM $T_PRICE WHERE $C_PE_ID IN ($placeholders)", args
            ).use {
                while (it.moveToNext()) {
                    scanTimeById[it.getLong(0)] = it.getString(1) ?: "-"
                }
            }
        }

        val result = LinkedHashMap<String, ComparisonRow>()
        historyTotals.forEach { (sku, historyBalance) ->
            // ★ FIX (Barcode Filter): pakai findCatalogForComparison supaya SKU yang
            // di-scan pakai barcode versi panjang (kolom 23) tetap ketemu datanya.
            val cat = findCatalogForComparison(sku)
            val shelf  = cat?.get("shelf") ?: "-"
            val desc   = cat?.get("desc")  ?: "NOT FOUND IN SYSTEM"
            val rawSysBal = cat?.get("balance")?.toIntOrNull() ?: 0
            // ★ FIX (baru — Keep Stock dari GSheet live): Stok Sekarang
            // dikurangi Stok Keep Stock (SKU & Qty dari Google Sheets Keep
            // Stock TERBARU, di-fetch fresh oleh caller) dulu sebelum
            // dibandingkan dengan hasil scan.
            // ★ FIX (baru — Keep Stock dari GSheet live): dipakai di rumus
            //   Hasil = (Scan Result + Stok Keep Stock) - System (lihat di bawah)
            val keepStockQty = keepStockMap[sku] ?: 0
            // ★ FIX (baru — rumus diubah): System TIDAK diubah/dikurangi apa
            // pun (tetap raw dari katalog). Yang berubah adalah rumus Hasil:
            //   Hasil = (Scan Result + Stok Keep Stock) - System
            val sysBal = rawSysBal
            // ★ FIX (baru — filter System=0): baris data hasil Scan Process
            // (historyTotals, sudah pasti scanned=true) yang System Balance-nya
            // 0 SEMENTARA Qty Scan JUGA 0 disembunyikan (tidak ada nilai apa pun
            // untuk dibandingkan). Tapi kalau Qty Scan > 0, baris TETAP tampil
            // walau System=0, karena user tetap perlu tahu ada scan tanpa
            // balance sistem. Aturan ini khusus data Scan Process — tidak
            // memengaruhi baris ekspansi shelf ("belum discan") di bawah.
            // ★ FIX (baru): kalau hasil Scan LEBIH BESAR dari System, baris ini
            // tidak boleh kena filter apa pun (termasuk aturan System=0 di atas)
            // — selalu ditampilkan.
            val scanExceedsSystem = historyBalance > sysBal
            if (!scanExceedsSystem && sysBal == 0 && historyBalance == 0) return@forEach
            result[sku] = ComparisonRow(
                sku = sku, shelf = shelf, desc = desc,
                historyBalance = historyBalance, systemBalance = sysBal,
                difference = (historyBalance + keepStockQty) - sysBal, scanned = true,
                keepStock = keepStockQty, rawSystemBalance = rawSysBal,
                firstScanId = firstScanIds[sku] ?: 0L,
                firstScanTime = scanTimeById[firstScanIds[sku]] ?: "-"
            )
        }

        // ★ FIX: kalau filter Shelf dipilih (checklist), tambahkan SKU dari katalog
        // sistem yang shelf-nya cocok (exact match, salah satu dari yang dipilih)
        // tapi BELUM ada di history (belum pernah discan).
        if (shelfFilters.isNotEmpty()) {
            val placeholders = shelfFilters.joinToString(",") { "?" }
            val args = shelfFilters.map { it.uppercase() }.toTypedArray()
            val cc = readableDatabase.query(
                T_CATALOG, null, "UPPER($C_CAT_SHELF) IN ($placeholders)", args,
                null, null, "$C_CAT_SKU ASC"
            )
            cc.use {
                while (it.moveToNext()) {
                    val rawSku = it.getString(it.getColumnIndexOrThrow(C_CAT_SKU)) ?: continue
                    val rawLongSku = it.getString(it.getColumnIndexOrThrow(C_CAT_LONGSKU)) ?: "-"
                    // ★ FIX (Barcode Filter): kalau kolom 1 & kolom 23 beda, utamakan yang
                    // 7 digit supaya tidak muncul 2 baris terpisah untuk item yang sama.
                    val sku = resolveBarcodeIdentity(rawSku, rawLongSku)
                    if (result.containsKey(sku)) continue  // sudah ada dari history, skip
                    val shelf  = it.getString(it.getColumnIndexOrThrow(C_CAT_SHELF)) ?: "-"
                    val desc   = it.getString(it.getColumnIndexOrThrow(C_CAT_DESC))  ?: "-"
                    val rawSysBal = it.getString(it.getColumnIndexOrThrow(C_CAT_BALANCE))?.toIntOrNull() ?: 0
                    // ★ FIX (baru — rumus diubah): System TIDAK diubah/dikurangi.
                    val keepStockQty = keepStockMap[sku] ?: 0
                    val sysBal = rawSysBal
                    result[sku] = ComparisonRow(
                        sku = sku, shelf = shelf, desc = desc,
                        historyBalance = 0, systemBalance = sysBal,
                        difference = 0, scanned = false,  // ← belum discan
                        keepStock = keepStockQty, rawSystemBalance = rawSysBal
                    )
                }
            }
        }

        // ★ FIX: JANGAN di-sort ulang berdasarkan SKU di sini — urutan yang
        // diinginkan adalah data hasil SCAN dulu (sesuai urutan di atas),
        // baru DIIKUTI data yang belum discan (NOT SCANNED) di bagian bawah.
        // `result` (LinkedHashMap) sudah otomatis dalam urutan itu karena
        // entry scanned dimasukkan duluan, baru entry not-scanned menyusul.
        // ★ FIX: urutan dari fungsi ini dipakai BERSAMA oleh tampilan layar
        // MAUPUN Export PDF/Excel (lewat queriedRows) — supaya Export tetap
        // konsisten seperti sebelumnya (Scan Result urut SKU), pengubahan
        // urutan tampilan layar jadi per-Shelf (sesuai permintaan) dilakukan
        // KHUSUS di StockComparisonActivity.applyFilters(), BUKAN di sini.
        // ★ FIX (Menu 5 — Fitur Edit Langsung / 2nd Check): tempelkan penanda
        // visual (badge) + audit trail (User & Waktu) untuk SKU yang sudah
        // pernah di-2nd-check.
        val scMap = getSecondCheckMap()
        if (scMap.isEmpty()) return result.values.toList()
        return result.values.map { row ->
            val sc = scMap[row.sku] ?: return@map row
            row.copy(secondChecked = true, secondCheckUser = sc.userId, secondCheckTime = sc.editTime)
        }
    }

    /** ★ FIX: daftar shelf unik dari katalog sistem, dipakai untuk isi pilihan
     *  checklist dropdown "Filter Shelf" di Menu 5 - Stock Comparison. */
    fun getDistinctShelves(): List<String> {
        val list = mutableListOf<String>()
        val c = readableDatabase.rawQuery(
            "SELECT DISTINCT $C_CAT_SHELF FROM $T_CATALOG WHERE $C_CAT_SHELF IS NOT NULL AND $C_CAT_SHELF != '' ORDER BY $C_CAT_SHELF ASC",
            null
        )
        c.use { while (it.moveToNext()) { it.getString(0)?.let { s -> list.add(s) } } }
        return list
    }

    // ══════════════════════════════════════════════════════════════════
    // ★ FIX (Menu 5 — Stock Comparison): Fitur Edit Langsung (2nd Check)
    // ══════════════════════════════════════════════════════════════════

    private fun nowStr(): String =
        SimpleDateFormat("dd/MM/yy HH:mm:ss", Locale.getDefault()).format(Date())

    /** Konsolidasikan seluruh record history scan (T_PRICE) 1 SKU jadi SATU
     *  baris baru dengan qty & shelf hasil edit 2nd check — supaya SUM per
     *  SKU (dipakai getComparisonData) langsung mencerminkan nilai Balance
     *  (fisik) yang baru, dan menu History Scan ikut ter-update otomatis. */
    fun applySecondCheckToHistory(sku: String, newShelf: String, newQty: Int) {
        val wdb = writableDatabase
        wdb.beginTransaction()
        try {
            var desc = "-"; var price = "-"; var balance = "-"
            wdb.query(
                T_PRICE, arrayOf(C_PE_DESC, C_PE_PRICE, C_PE_BALANCE),
                "$C_PE_SKU=?", arrayOf(sku), null, null, "$C_PE_ID ASC", "1"
            ).use {
                if (it.moveToFirst()) {
                    desc = it.getString(0) ?: "-"
                    price = it.getString(1) ?: "-"
                    balance = it.getString(2) ?: "-"
                }
            }
            // Kalau history-nya belum ada sama sekali (kasus "Not Scanned"
            // yang baru di-2nd-check), coba ambil deskripsi dari katalog.
            if (desc == "-") {
                findCatalogForComparison(sku)?.let { desc = it["desc"] ?: "-" }
            }
            wdb.delete(T_PRICE, "$C_PE_SKU=?", arrayOf(sku))
            val cv = ContentValues().apply {
                put(C_PE_SKU, sku)
                put(C_PE_DESC, desc)
                put(C_PE_SHELF, newShelf)
                put(C_PE_PRICE, price)
                put(C_PE_BALANCE, balance)
                put(C_PE_QTY, newQty)
                put(C_PE_TIME, nowStr())
                put(C_PE_UPLOADED, 0)
            }
            wdb.insert(T_PRICE, null, cv)
            wdb.setTransactionSuccessful()
        } finally {
            wdb.endTransaction()
        }
    }

    /** Update Balance sistem (katalog) untuk SKU ini — dicocokkan ke kolom
     *  SKU utama maupun long_sku (barcode panjang), supaya konsisten dengan
     *  resolveBarcodeIdentity yang dipakai di getComparisonData. */
    fun updateCatalogSystemBalance(sku: String, newBalance: Int): Int =
        writableDatabase.update(
            T_CATALOG,
            ContentValues().apply { put(C_CAT_BALANCE, newBalance.toString()) },
            "$C_CAT_SKU=? OR $C_CAT_LONGSKU=?", arrayOf(sku, sku)
        )

    fun updateCatalogShelfBySku(sku: String, newShelf: String): Int =
        writableDatabase.update(
            T_CATALOG,
            ContentValues().apply { put(C_CAT_SHELF, newShelf) },
            "$C_CAT_SKU=? OR $C_CAT_LONGSKU=?", arrayOf(sku, sku)
        )

    /** Simpan/replace 1 baris audit trail 2nd check untuk SKU ini. */
    fun saveSecondCheck(row: SecondCheckRow) {
        val cv = ContentValues().apply {
            put(C_SC_SKU, row.sku)
            put(C_SC_SHELF, row.shelf)
            put(C_SC_DESC, row.desc)
            put(C_SC_SYSTEM, row.systemBalance)
            put(C_SC_KEEPSTOCK, row.keepStock)
            put(C_SC_BALANCE, row.balance)
            put(C_SC_DIFF, row.difference)
            put(C_SC_USER, row.userId)
            put(C_SC_TIME, row.editTime)
            put(C_SC_SYNCED, 0)
        }
        writableDatabase.insertWithOnConflict(T_SECOND_CHECK, null, cv, SQLiteDatabase.CONFLICT_REPLACE)
    }

    private fun cursorToSecondCheckRow(c: Cursor): SecondCheckRow = SecondCheckRow(
        sku = c.getString(c.getColumnIndexOrThrow(C_SC_SKU)),
        shelf = c.getString(c.getColumnIndexOrThrow(C_SC_SHELF)) ?: "-",
        desc = c.getString(c.getColumnIndexOrThrow(C_SC_DESC)) ?: "-",
        systemBalance = c.getInt(c.getColumnIndexOrThrow(C_SC_SYSTEM)),
        keepStock = c.getInt(c.getColumnIndexOrThrow(C_SC_KEEPSTOCK)),
        balance = c.getInt(c.getColumnIndexOrThrow(C_SC_BALANCE)),
        difference = c.getInt(c.getColumnIndexOrThrow(C_SC_DIFF)),
        userId = c.getString(c.getColumnIndexOrThrow(C_SC_USER)) ?: "-",
        editTime = c.getString(c.getColumnIndexOrThrow(C_SC_TIME)) ?: "-",
        synced = c.getInt(c.getColumnIndexOrThrow(C_SC_SYNCED)) != 0
    )

    /** Map SKU -> SecondCheckRow, dipakai untuk penanda visual (badge) &
     *  audit trail di list Stock Comparison. */
    fun getSecondCheckMap(): Map<String, SecondCheckRow> {
        val map = LinkedHashMap<String, SecondCheckRow>()
        readableDatabase.query(T_SECOND_CHECK, null, null, null, null, null, "$C_SC_TIME DESC").use {
            while (it.moveToNext()) {
                val row = cursorToSecondCheckRow(it)
                map[row.sku] = row
            }
        }
        return map
    }

    /** Baris 2nd check yang BELUM pernah dikirim ke Google Sheets (dipakai
     *  fitur Export > Google Sheets, supaya baris lama tidak dobel append). */
    fun getUnsyncedSecondCheckRows(): List<SecondCheckRow> {
        val list = mutableListOf<SecondCheckRow>()
        readableDatabase.query(
            T_SECOND_CHECK, null, "$C_SC_SYNCED=0", null, null, null, "$C_SC_TIME ASC"
        ).use { while (it.moveToNext()) list.add(cursorToSecondCheckRow(it)) }
        return list
    }

    fun markSecondCheckSynced(skus: List<String>) {
        if (skus.isEmpty()) return
        val wdb = writableDatabase
        wdb.beginTransaction()
        try {
            skus.forEach { sku ->
                wdb.execSQL("UPDATE $T_SECOND_CHECK SET $C_SC_SYNCED=1 WHERE $C_SC_SKU=?", arrayOf(sku))
            }
            wdb.setTransactionSuccessful()
        } finally {
            wdb.endTransaction()
        }
    }


    fun insertShelf(shelfCode: String, sku: String) {
        val v = ContentValues().apply { put(C_SH_SHELF, shelfCode); put(C_SH_SKU, sku); put(C_SH_TIME, now()) }
        writableDatabase.insert(T_SHELF, null, v)
    }
    fun getAllShelf(): Cursor = readableDatabase.query(T_SHELF, null, null, null, null, null, "$C_SH_ID DESC")
    fun clearShelf()  = writableDatabase.delete(T_SHELF, null, null)
    /** FIX: hapus 1 baris shelf record (klik item di list -> konfirmasi -> hapus) */
    fun deleteShelf(id: Int) = writableDatabase.delete(T_SHELF, "$C_SH_ID=?", arrayOf(id.toString()))

    // ── DATA COLLECTOR (Menu 4) ──────────────────────────────────────────
    /** ★ FIX (baru): simpan 1 baris hasil scan Data Collector. `qty` kosong
     *  ("") untuk mode Shelf Record — kolom Qty memang tidak dipakai di mode
     *  itu. Real-time: 1 insert per hasil scan, tanpa buffering/batching,
     *  supaya tetap responsif walau scan beruntun dalam jumlah besar
     *  (SQLite auto-commit per insert cukup cepat untuk kecepatan scan HID). */
    fun insertDataCollect(shelf: String, scanCode: String, qty: String, mode: String): Long {
        val v = ContentValues().apply {
            put(C_DC_SHELF, shelf); put(C_DC_CODE, scanCode); put(C_DC_QTY, qty)
            put(C_DC_MODE, mode); put(C_DC_TIME, now()); put(C_DC_UPLOADED, 0)
        }
        return writableDatabase.insert(T_DC, null, v)
    }
    fun getAllDataCollect(): Cursor = readableDatabase.query(T_DC, null, null, null, null, null, "$C_DC_ID DESC")
    fun clearDataCollect() = writableDatabase.delete(T_DC, null, null)
    /** ★ FIX (baru): edit 1 record hasil scan (Shelf, SKU/scan code, Qty). Record yang
     *  diedit ditandai belum ter-upload lagi (uploaded=0) supaya ikut terkirim ulang. */
    fun updateDataCollect(id: Int, shelf: String, scanCode: String, qty: String): Int {
        val v = ContentValues().apply {
            put(C_DC_SHELF, shelf); put(C_DC_CODE, scanCode); put(C_DC_QTY, qty)
            put(C_DC_UPLOADED, 0)
        }
        return writableDatabase.update(T_DC, v, "$C_DC_ID=?", arrayOf(id.toString()))
    }
    fun deleteDataCollect(id: Int) = writableDatabase.delete(T_DC, "$C_DC_ID=?", arrayOf(id.toString()))
    fun markDataCollectUploaded() {
        val v = ContentValues().apply { put(C_DC_UPLOADED, 1) }
        writableDatabase.update(T_DC, v, null, null)
    }

    // ── VAULT: CRUD ─────────────────────────────────────────────────────
    fun insertVaultItem(origName: String, storedName: String, mime: String, kind: String, size: Long): Long {
        val v = ContentValues().apply {
            put(C_VLT_NAME, origName); put(C_VLT_STORED, storedName)
            put(C_VLT_MIME, mime); put(C_VLT_KIND, kind)
            put(C_VLT_SIZE, size); put(C_VLT_TIME, now())
        }
        return writableDatabase.insert(T_VAULT, null, v)
    }
    fun getAllVaultItems(): Cursor = readableDatabase.query(T_VAULT, null, null, null, null, null, "$C_VLT_ID DESC")
    fun deleteVaultItem(id: Int) = writableDatabase.delete(T_VAULT, "$C_VLT_ID=?", arrayOf(id.toString()))

    // ── VAULT (fitur privasi: simpan file pribadi, tersembunyi dari Gallery/File
    //    Manager, diakses lewat kode rahasia di kalkulator) ─────────────────

    // ── EXINOUT SYNC STATE (Menu 4 — Keep Stock) ──────────────────────────
    // ★ FIX: porting dari file CGAR_processed.txt di EXINOUT_CGAR.py — dulu
    // disimpan sebagai file teks lokal per toko di PC, sekarang disimpan di
    // SQLite di HP, per toko (kolom "store"), supaya proses sync bisa jalan
    // langsung dari aplikasi.
    fun getExioKeys(store: String): Set<String> {
        val result = LinkedHashSet<String>()
        val c = readableDatabase.query(T_EXIO_STATE, arrayOf(C_EXIO_KEY), "$C_EXIO_STORE=?", arrayOf(store), null, null, null)
        c.use { while (it.moveToNext()) result.add(it.getString(0)) }
        return result
    }

    fun saveExioKeys(store: String, keys: Set<String>) {
        val wdb = writableDatabase
        wdb.beginTransaction()
        try {
            wdb.delete(T_EXIO_STATE, "$C_EXIO_STORE=?", arrayOf(store))
            val stmt = wdb.compileStatement("INSERT INTO $T_EXIO_STATE ($C_EXIO_STORE,$C_EXIO_KEY) VALUES (?,?)")
            keys.forEach { key ->
                stmt.clearBindings()
                stmt.bindString(1, store)
                stmt.bindString(2, key)
                stmt.executeInsert()
            }
            wdb.setTransactionSuccessful()
        } finally {
            wdb.endTransaction()
        }
    }

    // ── EXINOUT OUT-HISTORY (Sync IN/OUT — deteksi RE-IN) ───────────────
    fun getExioOutKeys(store: String): Set<String> {
        val result = LinkedHashSet<String>()
        val c = readableDatabase.query(T_EXIO_OUT_HISTORY, arrayOf(C_EXIO_OUT_KEY), "$C_EXIO_OUT_STORE=?", arrayOf(store), null, null, null)
        c.use { while (it.moveToNext()) result.add(it.getString(0)) }
        return result
    }

    fun saveExioOutKeys(store: String, keys: Set<String>) {
        val wdb = writableDatabase
        wdb.beginTransaction()
        try {
            wdb.delete(T_EXIO_OUT_HISTORY, "$C_EXIO_OUT_STORE=?", arrayOf(store))
            val stmt = wdb.compileStatement("INSERT INTO $T_EXIO_OUT_HISTORY ($C_EXIO_OUT_STORE,$C_EXIO_OUT_KEY) VALUES (?,?)")
            keys.forEach { key ->
                stmt.clearBindings()
                stmt.bindString(1, store)
                stmt.bindString(2, key)
                stmt.executeInsert()
            }
            wdb.setTransactionSuccessful()
        } finally {
            wdb.endTransaction()
        }
    }

    // ── EXINOUT OUTBOX (Sync IN/OUT — Outbox Pattern, tahan force-close) ──
    // ★ FIX (baru): staging hasil compute SEBELUM upload dimulai, supaya kalau
    // proses aplikasi mati di tengah jalan (bukan cuma exception biasa), hasil
    // hitung yang sudah ada tidak hilang dan bisa dilanjutkan (resume) di sync
    // berikutnya tanpa hitung ulang dari nol.
    fun saveExioOutbox(store: String, r: ExInOutSync.SyncResult) {
        val v = ContentValues().apply {
            put(C_EXOB_STORE, store)
            put(C_EXOB_FILE1, r.file1)
            put(C_EXOB_FILE2, r.file2)
            put(C_EXOB_FILE3, r.file3)
            put(C_EXOB_FILE4, r.file4)
            put(C_EXOB_HAS_NEW_IN, if (r.hasNewIn) 1 else 0)
            put(C_EXOB_NEW_IN_COUNT, r.newInCount)
            put(C_EXOB_OUT_COUNT, r.outCount)
            put(C_EXOB_UPDATED_KEYS, r.updatedKeys.joinToString(OUTBOX_DELIM))
            put(C_EXOB_UPDATED_OUT_HIST, r.updatedOutHistory.joinToString(OUTBOX_DELIM))
            put(C_EXOB_LOG, r.log.joinToString(OUTBOX_DELIM))
            put(C_EXOB_TIME, now())
        }
        // ★ FIX: 1 baris per toko — sync ulang untuk toko yang sama akan
        // menimpa (bukan menumpuk) baris outbox lamanya.
        writableDatabase.insertWithOnConflict(T_EXIO_OUTBOX, null, v, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun getExioOutbox(store: String): ExInOutSync.SyncResult? {
        fun splitOrEmpty(s: String): Set<String> = if (s.isEmpty()) emptySet() else s.split(OUTBOX_DELIM).toSet()
        fun splitListOrEmpty(s: String): List<String> = if (s.isEmpty()) emptyList() else s.split(OUTBOX_DELIM)

        val c = readableDatabase.query(T_EXIO_OUTBOX, null, "$C_EXOB_STORE=?", arrayOf(store), null, null, null)
        c.use {
            if (!it.moveToFirst()) return null
            return ExInOutSync.SyncResult(
                store = store,
                newInCount = it.getInt(it.getColumnIndexOrThrow(C_EXOB_NEW_IN_COUNT)),
                outCount = it.getInt(it.getColumnIndexOrThrow(C_EXOB_OUT_COUNT)),
                file1 = it.getString(it.getColumnIndexOrThrow(C_EXOB_FILE1)) ?: "",
                file2 = it.getString(it.getColumnIndexOrThrow(C_EXOB_FILE2)) ?: "",
                file3 = it.getString(it.getColumnIndexOrThrow(C_EXOB_FILE3)) ?: "",
                file4 = it.getString(it.getColumnIndexOrThrow(C_EXOB_FILE4)) ?: "",
                hasNewIn = it.getInt(it.getColumnIndexOrThrow(C_EXOB_HAS_NEW_IN)) == 1,
                log = splitListOrEmpty(it.getString(it.getColumnIndexOrThrow(C_EXOB_LOG)) ?: ""),
                updatedKeys = splitOrEmpty(it.getString(it.getColumnIndexOrThrow(C_EXOB_UPDATED_KEYS)) ?: ""),
                updatedOutHistory = splitOrEmpty(it.getString(it.getColumnIndexOrThrow(C_EXOB_UPDATED_OUT_HIST)) ?: "")
            )
        }
    }

    fun deleteExioOutbox(store: String) {
        writableDatabase.delete(T_EXIO_OUTBOX, "$C_EXOB_STORE=?", arrayOf(store))
    }

    // ── KEEP STOCK EDIT HISTORY (Menu 4) ────────────────────────────────
    data class KsHistoryEntry(
        val id: Int,
        val time: String,
        val store: String,
        val pic: String,
        val action: String,
        val noCtnBefore: String,
        val skuBefore: String,
        val qtyBefore: String,
        val noCtnAfter: String,
        val skuAfter: String,
        val qtyAfter: String
    )

    /** ★ FIX: catat 1 aksi Add/Edit/Move/Delete ke riwayat lokal (tanggal, store, PIC, sebelum/sesudah). */
    fun insertKsHistory(
        store: String, pic: String, action: String,
        noCtnBefore: String, skuBefore: String, qtyBefore: String,
        noCtnAfter: String, skuAfter: String, qtyAfter: String
    ) {
        val v = ContentValues().apply {
            put(C_KSH_TIME, now())
            put(C_KSH_STORE, store)
            put(C_KSH_PIC, pic.ifBlank { "-" })
            put(C_KSH_ACTION, action)
            put(C_KSH_NOCTN_BEFORE, noCtnBefore)
            put(C_KSH_SKU_BEFORE, skuBefore)
            put(C_KSH_QTY_BEFORE, qtyBefore)
            put(C_KSH_NOCTN_AFTER, noCtnAfter)
            put(C_KSH_SKU_AFTER, skuAfter)
            put(C_KSH_QTY_AFTER, qtyAfter)
        }
        writableDatabase.insert(T_KS_HISTORY, null, v)
    }

    /** Ambil riwayat edit untuk 1 toko, terbaru dulu. */
    fun getKsHistory(store: String): List<KsHistoryEntry> {
        val result = mutableListOf<KsHistoryEntry>()
        val c = readableDatabase.query(
            T_KS_HISTORY, null, "$C_KSH_STORE=?", arrayOf(store),
            null, null, "$C_KSH_ID DESC"
        )
        c.use {
            while (it.moveToNext()) {
                result.add(
                    KsHistoryEntry(
                        id = it.getInt(it.getColumnIndexOrThrow(C_KSH_ID)),
                        time = it.getString(it.getColumnIndexOrThrow(C_KSH_TIME)) ?: "",
                        store = it.getString(it.getColumnIndexOrThrow(C_KSH_STORE)) ?: "",
                        pic = it.getString(it.getColumnIndexOrThrow(C_KSH_PIC)) ?: "",
                        action = it.getString(it.getColumnIndexOrThrow(C_KSH_ACTION)) ?: "",
                        noCtnBefore = it.getString(it.getColumnIndexOrThrow(C_KSH_NOCTN_BEFORE)) ?: "",
                        skuBefore = it.getString(it.getColumnIndexOrThrow(C_KSH_SKU_BEFORE)) ?: "",
                        qtyBefore = it.getString(it.getColumnIndexOrThrow(C_KSH_QTY_BEFORE)) ?: "",
                        noCtnAfter = it.getString(it.getColumnIndexOrThrow(C_KSH_NOCTN_AFTER)) ?: "",
                        skuAfter = it.getString(it.getColumnIndexOrThrow(C_KSH_SKU_AFTER)) ?: "",
                        qtyAfter = it.getString(it.getColumnIndexOrThrow(C_KSH_QTY_AFTER)) ?: ""
                    )
                )
            }
        }
        return result
    }

    /** ★ FIX: hapus 1 entri riwayat edit (tap icon hapus di 1 baris). */
    fun deleteKsHistoryEntry(id: Int) = writableDatabase.delete(T_KS_HISTORY, "$C_KSH_ID=?", arrayOf(id.toString()))

    /** ★ FIX: hapus SEMUA riwayat edit untuk 1 toko (tombol "Clear All" di header). */
    fun deleteAllKsHistory(store: String) = writableDatabase.delete(T_KS_HISTORY, "$C_KSH_STORE=?", arrayOf(store))
}
