package com.tms.qubeapps.qubedatacollector

import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * ★ FIX (Menu 4 — Keep Stock, View & Search Data): baca kolom B (NO CTN),
 * C (SKU), D (QTY) langsung dari Google Sheets toko yang aktif — dipakai
 * untuk layar "View Data" & fitur pencarian NO CTN / SKU / QTY. Cara ambil
 * datanya sama seperti ExInOutSync (export CSV publik), cuma range-nya
 * dipersempit ke B:D saja karena kolom lain tidak dibutuhkan di sini.
 */
object KeepStockSheetReader {

    private const val RANGE = "B6:D5000"

    data class KsRow(val rowNumber: Int, val noCtn: String, val sku: String, val qty: String)

    /** Harus dipanggil dari Dispatchers.IO. */
    fun fetchRows(spreadsheetId: String, gid: String): List<KsRow> {
        val encodedRange = URLEncoder.encode(RANGE, "UTF-8")
        val csvUrl = "https://docs.google.com/spreadsheets/d/$spreadsheetId/export" +
            "?format=csv&gid=$gid&range=$encodedRange"
        val csvData = httpGet(csvUrl)
        if (csvData.isBlank()) return emptyList()

        val rows = mutableListOf<KsRow>()
        val lines = csvData.replace("\r\n", "\n").replace("\r", "\n").split("\n")
        // ★ FIX: range mulai dari baris 6, jadi nomor baris asli di sheet =
        // 6 + index baris di CSV. Nomor ini dipakai untuk EDIT/DELETE/MOVE.
        lines.forEachIndexed { index, line ->
            if (line.isBlank()) return@forEachIndexed
            val cols = parseCsvLine(line)
            val b = cols.getOrNull(0)?.trim().orEmpty()
            val c = cols.getOrNull(1)?.trim().orEmpty()
            val d = cols.getOrNull(2)?.trim().orEmpty()
            if (b.isBlank() && c.isBlank()) return@forEachIndexed
            rows.add(KsRow(rowNumber = 6 + index, noCtn = b, sku = c, qty = d.ifBlank { "-" }))
        }
        return rows
    }

    private fun parseCsvLine(line: String): List<String> {
        val cols = mutableListOf<String>()
        val current = StringBuilder()
        var inQuotes = false
        for (ch in line) {
            when {
                ch == '"' -> inQuotes = !inQuotes
                ch == ',' && !inQuotes -> {
                    cols.add(current.toString().trim().trim('"').trim())
                    current.clear()
                }
                else -> current.append(ch)
            }
        }
        cols.add(current.toString().trim().trim('"').trim())
        return cols.map { it.trim() }
    }

    private fun httpGet(url: String): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.requestMethod = "GET"
        conn.setRequestProperty("User-Agent", "Mozilla/5.0")
        conn.connectTimeout = 20000
        conn.readTimeout = 30000
        try {
            if (conn.responseCode !in 200..299) {
                throw Exception("HTTP ${conn.responseCode} while downloading data. Make sure the spreadsheet is shared (Anyone with link > Viewer).")
            }
            return conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }
}
