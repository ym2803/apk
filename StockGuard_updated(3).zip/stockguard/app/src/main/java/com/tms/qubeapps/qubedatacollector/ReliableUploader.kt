package com.tms.qubeapps.qubedatacollector

/**
 * ★ FIX (baru — lapis reliabilitas TAMBAHAN untuk semua upload SMB terkait
 * Sync IN/OUT & Sync Recon, di atas Outbox Pattern di ExInOutSync.kt):
 *
 * SEBELUMNYA: `SmbUploader.upload()` dianggap "berhasil" begitu saja kalau
 * tidak melempar exception. Padahal itu HANYA memastikan panggilan API SMB-nya
 * tidak error — bukan jaminan filenya benar-benar tertulis utuh di server.
 * Kegagalan "diam-diam" (silent failure) tetap mungkin terjadi, misalnya:
 *   - Koneksi putus PERSIS setelah beberapa byte pertama tertulis (partial
 *     write) tapi sebelum stream ditutup sempurna — API bisa saja tidak
 *     melempar exception yang jelas tergantung timing.
 *   - Disk penuh / write ditolak Windows tapi errornya tidak selalu propagate
 *     sebagai exception yang bisa ditangkap dengan pasti oleh client SMB.
 *   - Gangguan jaringan sesaat (WiFi flaky) yang sebenarnya transient — kalau
 *     langsung dianggap gagal permanen, user harus tap ulang manual padahal
 *     percobaan ke-2 kemungkinan besar akan sukses sendiri.
 *
 * SOLUSI di sini:
 *   1. VERIFIKASI: setelah upload, file yang BARU DIUPLOAD di-download lagi
 *      dan isinya dibandingkan byte-exact dengan yang seharusnya dikirim.
 *      Kalau tidak cocok (corrupt/partial), dianggap GAGAL walau API upload
 *      tadi tidak melempar exception — supaya tidak ada file yang "kelihatan
 *      terkirim" padahal isinya rusak/tidak lengkap.
 *   2. RETRY dengan backoff: kegagalan (baik upload maupun verifikasi) di-
 *      retry otomatis beberapa kali sebelum benar-benar dilaporkan ke user,
 *      untuk menyerap gangguan jaringan sesaat yang sifatnya transient.
 */
object ReliableUploader {

    private const val DEFAULT_MAX_RETRIES = 2       // total percobaan = 1 + DEFAULT_MAX_RETRIES
    private const val BASE_BACKOFF_MS = 800L

    /**
     * Upload string content ke server SMB, verifikasi isinya dengan baca ulang,
     * retry otomatis kalau gagal. Melempar Exception (dengan riwayat percobaan
     * di pesannya) kalau semua percobaan tetap gagal — panggil dari Dispatchers.IO.
     */
    fun uploadVerified(
        smbUrl: String, username: String, password: String,
        fileName: String, content: String, domain: String = "",
        maxRetries: Int = DEFAULT_MAX_RETRIES
    ) {
        var lastError: Exception? = null
        for (attempt in 0..maxRetries) {
            try {
                SmbUploader.upload(smbUrl, username, password, fileName, content, domain)

                // ── Verifikasi: baca ulang file yang baru saja ditulis ──
                val readBack = try {
                    SmbUploader.download(smbUrl, username, password, fileName, domain)
                } catch (e: Exception) {
                    throw Exception(
                        "Upload '$fileName' tidak bisa diverifikasi (gagal membaca ulang file " +
                        "dari server setelah upload). ${e.message}"
                    )
                }

                if (readBack == content) {
                    return  // ★ sukses & terverifikasi byte-exact — selesai
                } else {
                    throw Exception(
                        "Verifikasi gagal untuk '$fileName': isi file di server TIDAK cocok " +
                        "dengan yang dikirim (kemungkinan penulisan terputus/corrupt di tengah jalan)."
                    )
                }
            } catch (e: Exception) {
                lastError = e
                if (attempt < maxRetries) {
                    // Backoff sederhana (bertambah tiap percobaan) sebelum retry,
                    // supaya tidak langsung membanjiri server/jaringan yang sedang
                    // bermasalah. Aman dipanggil blocking di sini karena fungsi ini
                    // selalu dijalankan dari Dispatchers.IO (bukan main thread).
                    Thread.sleep(BASE_BACKOFF_MS * (attempt + 1))
                }
            }
        }
        throw Exception(
            "Gagal upload '$fileName' setelah ${maxRetries + 1}x percobaan. " +
            "Kesalahan terakhir: ${lastError?.message}"
        )
    }
}
