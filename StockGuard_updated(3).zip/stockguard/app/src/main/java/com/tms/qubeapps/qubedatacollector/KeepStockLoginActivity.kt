package com.tms.qubeapps.qubedatacollector

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.tms.qubeapps.qubedatacollector.Prefs.KEEP_STOCK_STORES
import com.tms.qubeapps.qubedatacollector.Prefs.ksLastPic
import com.tms.qubeapps.qubedatacollector.Prefs.ksLastStore

/**
 * ★ FIX (Menu 4 — Keep Stock, Login): layar login sebelum masuk ke Menu Keep
 * Stock. User wajib pilih Kode Toko (kolom 1) + isi nama PIC (kolom 2) dulu,
 * supaya jelas siapa yang input data / sync di toko tersebut saat itu.
 *
 * Catatan: ini BUKAN otentikasi ke server (tidak ada verifikasi password) —
 * cuma gerbang identifikasi lokal sebelum masuk Menu Keep Stock, dan nilainya
 * ditampilkan di header layar Keep Stock berikutnya.
 */
class KeepStockLoginActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_STORE = "extra_ks_store"
        const val EXTRA_PIC = "extra_ks_pic"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_keep_stock_login)

        val spStore = findViewById<Spinner>(R.id.spLoginStore)
        val etPic = findViewById<EditText>(R.id.etLoginPic)
        val btnLogin = findViewById<Button>(R.id.btnLogin)

        spStore.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, KEEP_STOCK_STORES).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }

        // FIX: pre-fill dari sesi login terakhir supaya tidak perlu ketik ulang tiap buka
        val lastStore = ksLastStore
        if (lastStore.isNotBlank()) {
            val idx = KEEP_STOCK_STORES.indexOf(lastStore)
            if (idx >= 0) spStore.setSelection(idx)
        }
        etPic.setText(ksLastPic)

        findViewById<View>(R.id.btnBackLogin).setOnClickListener { finish() }

        btnLogin.setOnClickListener {
            val store = spStore.selectedItem as String
            val pic = etPic.text.toString().trim()
            if (pic.isBlank()) {
                Toast.makeText(this, "PIC name is required", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            ksLastStore = store
            ksLastPic = pic
            startActivity(Intent(this, KeepStockActivity::class.java).apply {
                putExtra(EXTRA_STORE, store)
                putExtra(EXTRA_PIC, pic)
            })
            finish()
        }
    }
}
