package com.tms.qubeapps.qubedatacollector

import android.app.AlertDialog
import android.app.ProgressDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Modern "Credits / About" screen: app info, developer credit, and an
 * in-app update checker backed by GitHub Releases.
 *
 * "Check for update" and "View on GitHub" both point to
 * [GithubUpdateChecker.REPO], the same repo used for APK Download
 * (see OutputWriter.APK_GITHUB_URL) — "ym2803/apk".
 */
class CreditsActivity : BaseActivity() {

    private lateinit var tvUpdateStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_credits)

        findViewById<View>(R.id.btnBackCredits).setOnClickListener { finish() }

        tvUpdateStatus = findViewById(R.id.tvUpdateStatus)
        findViewById<TextView>(R.id.tvCreditsVersion).text =
            "Version ${BuildConfig.VERSION_NAME}"

        findViewById<View>(R.id.btnCheckUpdate).setOnClickListener { checkForUpdate() }
        // ★ FIX: APK Download dipindah kesini dari menu Setting — logic &
        // sumber file (GitHub, via OutputWriter.downloadApkFromGithub) TIDAK
        // berubah, cuma lokasi tombolnya.
        findViewById<View>(R.id.btnApkDownload).setOnClickListener { downloadAndInstallApk() }
        findViewById<View>(R.id.btnOpenReleases).setOnClickListener {
            openUrl("https://github.com/${GithubUpdateChecker.REPO}/releases")
        }
    }

    private fun downloadAndInstallApk() {
        val pd = ProgressDialog(this).apply { setMessage("Downloading sgxcalc.apk from GitHub..."); show() }
        lifecycleScope.launch {
            try {
                val file = withContext(Dispatchers.IO) {
                    OutputWriter.downloadApkFromGithub(this@CreditsActivity)
                }
                pd.dismissSafely()
                installApk(file)
            } catch (e: Exception) {
                pd.dismissSafely()
                AlertDialog.Builder(this@CreditsActivity)
                    .setTitle("APK Download Failed")
                    .setMessage(e.message)
                    .setPositiveButton("OK", null).showSafely()
            }
        }
    }

    private fun installApk(file: File) {
        try {
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/vnd.android.package-archive")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)
        } catch (e: Exception) {
            AlertDialog.Builder(this)
                .setTitle("Failed to Open Installer")
                .setMessage("APK already saved at:\n${file.absolutePath}\n\n" +
                    "Open it manually via File Manager to install.\n\n" +
                    "Note: make sure \"Install unknown apps\" permission for this app is enabled in the device Settings.\n\n(${e.message})")
                .setPositiveButton("OK", null).showSafely()
        }
    }

    private fun checkForUpdate() {
        val pd = ProgressDialog(this).apply { setMessage("Checking for updates..."); show() }
        lifecycleScope.launch {
            try {
                val release = withContext(Dispatchers.IO) { GithubUpdateChecker.fetchLatestRelease() }
                pd.dismissSafely()
                val currentVersion = BuildConfig.VERSION_NAME
                if (GithubUpdateChecker.isNewer(release.tagName, currentVersion)) {
                    tvUpdateStatus.text = "New version available: ${release.tagName}"
                    AlertDialog.Builder(this@CreditsActivity)
                        .setTitle("Update Available — ${release.tagName}")
                        .setMessage(
                            "You have $currentVersion. ${release.tagName} is now available.\n\n" +
                                release.body.ifBlank { "See the release page for details." }
                        )
                        .setPositiveButton("Download") { _, _ ->
                            val target = release.apkDownloadUrl ?: release.htmlUrl
                            openUrl(target)
                        }
                        .setNegativeButton("Later", null)
                        .showSafely()
                } else {
                    tvUpdateStatus.text = "You're up to date (v$currentVersion)."
                    Toast.makeText(this@CreditsActivity, "You're on the latest version", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                pd.dismissSafely()
                tvUpdateStatus.text = "Could not check for updates."
                AlertDialog.Builder(this@CreditsActivity)
                    .setTitle("Update Check Failed")
                    .setMessage(
                        "Could not reach GitHub. (${e.message})\n\n" +
                            "Make sure the GitHub repository link has been configured " +
                            "(GithubUpdateChecker.REPO) and that this device has internet access."
                    )
                    .setPositiveButton("OK", null).showSafely()
            }
        }
    }

    private fun openUrl(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: Exception) {
            Toast.makeText(this, "Could not open link: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
