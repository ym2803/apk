package com.tms.qubeapps.qubedatacollector

import android.app.Activity
import android.content.Intent
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File

/**
 * ★ FIX (baru — Fungsi "Share Data" app-to-app): helper bersama untuk share
 * isi data (History Scan, Shelf Record, Stock Take/Add Box) ke aplikasi lain
 * (WhatsApp, Email, Drive, dll) lewat share sheet Android BAWAAN
 * (Intent.ACTION_SEND + Intent.createChooser) — BUKAN cuma "buka dengan"
 * (ACTION_VIEW) yang sudah ada di fitur export lain, tapi benar-benar "kirim
 * ke aplikasi lain" sesuai permintaan user.
 *
 * Ditulis sebagai file/objek baru & terpisah (bukan menambah ke class
 * Activity manapun) supaya bisa dipakai bareng dari 3 layar berbeda
 * (ShelfPriceEnquireActivity/History Scan, DataCollectorActivity/Shelf
 * Record & Stock Take) tanpa duplikasi kode, dan tidak menyentuh/mengubah
 * fungsi export/upload yang sudah ada sama sekali.
 *
 * Cara kerja: isi data ditulis ke file teks sementara di cache app
 * (cacheDir/shared_exports/...), lalu dibagikan sebagai LAMPIRAN via
 * FileProvider (bukan cuma teks polos) supaya:
 *  - datanya utuh dibuka via aplikasi tujuan (mis. dibuka rapi di WhatsApp/
 *    Excel/Notepad) walaupun isinya panjang/banyak baris.
 *  - path cache sudah otomatis ke-cover oleh <cache-path path="."/> yang
 *    sudah ada di res/xml/file_paths.xml — jadi TIDAK PERLU ubah konfigurasi
 *    FileProvider apapun (aman dari IllegalArgumentException "not found").
 */
object ShareHelper {

    /**
     * @param activity      context untuk startActivity & Toast.
     * @param fileName      nama file yang dibagikan (mis. "ShelfRecord_20250101.txt").
     * @param content       isi teks (CSV/plain) yang mau dibagikan.
     * @param chooserTitle  judul dialog pemilih aplikasi tujuan share.
     */
    fun shareTextAsFile(activity: Activity, fileName: String, content: String, chooserTitle: String = "Share Data") {
        if (content.isBlank()) {
            Toast.makeText(activity, "Tidak ada data untuk di-share", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val dir = File(activity.cacheDir, "shared_exports").apply { mkdirs() }
            val file = File(dir, fileName)
            file.writeText(content)
            val uri = FileProvider.getUriForFile(activity, "${activity.packageName}.fileprovider", file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, fileName)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            activity.startActivity(Intent.createChooser(intent, chooserTitle))
        } catch (e: Exception) {
            Toast.makeText(activity, "Gagal share: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
