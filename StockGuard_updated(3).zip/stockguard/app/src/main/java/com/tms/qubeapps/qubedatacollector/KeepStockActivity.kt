package com.tms.qubeapps.qubedatacollector

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.tms.qubeapps.qubedatacollector.Prefs.KEEP_STOCK_STORES
import com.tms.qubeapps.qubedatacollector.Prefs.exioGid
import com.tms.qubeapps.qubedatacollector.Prefs.exioProsesPath
import com.tms.qubeapps.qubedatacollector.Prefs.exioScanPath
import com.tms.qubeapps.qubedatacollector.Prefs.exioSpreadsheetId
import com.tms.qubeapps.qubedatacollector.Prefs.ksApiToken
import com.tms.qubeapps.qubedatacollector.Prefs.ksWebAppUrl
import com.tms.qubeapps.qubedatacollector.Prefs.setExioGid
import com.tms.qubeapps.qubedatacollector.Prefs.setExioProsesPath
import com.tms.qubeapps.qubedatacollector.Prefs.setExioScanPath
import com.tms.qubeapps.qubedatacollector.Prefs.setExioSpreadsheetId

/**
 * ★ FIX (Menu 4 — Keep Stock):
 *  - Wajib login dulu (Kode Toko + PIC) lewat KeepStockLoginActivity sebelum
 *    sampai di sini — Store & PIC ditampilkan di header sebagai identifikasi.
 *  - Layar ini sekarang cuma gerbang ke 2 hal: VIEW & EDIT DATA dan
 *    EDIT HISTORY. SYNC IN/OUT & SYNC RECON dipindah ke dalam layar
 *    "View & Edit Data" (KeepStockDataViewActivity) supaya semua kerja
 *    dengan data toko ada di 1 tempat.
 *  - ADD DATA (form manual) juga sudah jadi bagian dari View & Edit Data.
 */
class KeepStockActivity : AppCompatActivity() {

    private lateinit var tvStoreChip: TextView
    private var loggedInStore: String = ""
    private var loggedInPic: String = ""

    private val currentStore get() = loggedInStore.ifBlank { KEEP_STOCK_STORES.first() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_keep_stock)

        tvStoreChip = findViewById(R.id.tvStoreChip)

        loggedInStore = intent.getStringExtra(KeepStockLoginActivity.EXTRA_STORE)
            .orEmpty().ifBlank { KEEP_STOCK_STORES.first() }
        loggedInPic = intent.getStringExtra(KeepStockLoginActivity.EXTRA_PIC).orEmpty()
        tvStoreChip.text = "Store: $loggedInStore   •   PIC: ${loggedInPic.ifBlank { "-" }}"

        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<View>(R.id.btnStoreConfig).setOnClickListener { showStoreConfigDialog() }
        findViewById<View>(R.id.btnSwitchStore).setOnClickListener {
            startActivity(Intent(this, KeepStockLoginActivity::class.java))
            finish()
        }

        val cardViewData = findViewById<View>(R.id.cardViewData)
        val cardHistory = findViewById<View>(R.id.cardReports)
        setupPressAnimation(cardViewData)
        setupPressAnimation(cardHistory)

        cardViewData.setOnClickListener {
            startActivity(Intent(this, KeepStockDataViewActivity::class.java).apply {
                putExtra(KeepStockLoginActivity.EXTRA_STORE, currentStore)
                putExtra(KeepStockLoginActivity.EXTRA_PIC, loggedInPic)
            })
        }
        cardHistory.setOnClickListener {
            startActivity(Intent(this, KeepStockHistoryActivity::class.java).apply {
                putExtra(KeepStockLoginActivity.EXTRA_STORE, currentStore)
            })
        }
    }

    /** ★ FIX: animasi "tekan" (scale-down lalu balik) biar kartu terasa tactile. */
    private fun setupPressAnimation(view: View) {
        view.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> animateScale(v, 0.96f)
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> animateScale(v, 1f)
            }
            false
        }
    }

    private fun animateScale(view: View, scale: Float) {
        val sx = ObjectAnimator.ofFloat(view, "scaleX", scale)
        val sy = ObjectAnimator.ofFloat(view, "scaleY", scale)
        AnimatorSet().apply { playTogether(sx, sy); duration = 120; start() }
    }

    // ────────────────────────────────────────────────────────────────────
    // Per-store config dialog (Spreadsheet ID, GID, SMB paths)
    // ────────────────────────────────────────────────────────────────────
    /** ★ FIX (baru): "Store Config" sekarang jadi 1 tempat untuk SEMUA
     *  setingan Keep Stock — baik yang per-toko (Spreadsheet ID/GID/SMB Path)
     *  maupun yang umum untuk semua toko (GAS Web App URL/API Token, dulunya
     *  ada di menu Setting terpisah, sekarang dipindah kesini biar tidak
     *  bingung cari setingan mana ada di mana). */
    private fun showStoreConfigDialog() {
        val store = currentStore
        val view = LayoutInflater.from(this).inflate(R.layout.dialog_store_config, null)
        val etSsid  = view.findViewById<EditText>(R.id.etCfgSpreadsheetId)
        val etGid   = view.findViewById<EditText>(R.id.etCfgGid)
        val etScan  = view.findViewById<EditText>(R.id.etCfgScanPath)
        val etProses = view.findViewById<EditText>(R.id.etCfgProsesPath)
        val etKsUrl   = view.findViewById<EditText>(R.id.etCfgKsWebAppUrl)
        val etKsToken = view.findViewById<EditText>(R.id.etCfgKsApiToken)

        etSsid.setText(exioSpreadsheetId(store))
        etGid.setText(exioGid(store))
        etScan.setText(exioScanPath(store))
        etProses.setText(exioProsesPath(store))
        etKsUrl.setText(ksWebAppUrl)
        etKsToken.setText(ksApiToken)

        AlertDialog.Builder(this)
            .setTitle("Store Config — $store")
            .setView(view)
            .setPositiveButton("SAVE") { _, _ ->
                setExioSpreadsheetId(store, etSsid.text.toString().trim())
                setExioGid(store, etGid.text.toString().trim())
                setExioScanPath(store, etScan.text.toString().trim())
                setExioProsesPath(store, etProses.text.toString().trim())
                ksWebAppUrl = etKsUrl.text.toString().trim()
                ksApiToken = etKsToken.text.toString().trim()
                Toast.makeText(this, "Config for $store saved", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
