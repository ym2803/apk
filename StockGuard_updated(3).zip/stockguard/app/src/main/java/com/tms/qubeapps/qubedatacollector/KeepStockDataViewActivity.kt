package com.tms.qubeapps.qubedatacollector

import android.app.AlertDialog
import android.app.ProgressDialog
import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.BaseExpandableListAdapter
import android.widget.EditText
import android.widget.ExpandableListView
import android.widget.GridView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import com.tms.qubeapps.qubedatacollector.Prefs.exioGid
import com.tms.qubeapps.qubedatacollector.Prefs.exioProsesPath
import com.tms.qubeapps.qubedatacollector.Prefs.exioScanPath
import com.tms.qubeapps.qubedatacollector.Prefs.exioSpreadsheetId
import com.tms.qubeapps.qubedatacollector.Prefs.ksApiToken
import com.tms.qubeapps.qubedatacollector.Prefs.ksWebAppUrl
import com.tms.qubeapps.qubedatacollector.Prefs.smbDomain
import com.tms.qubeapps.qubedatacollector.Prefs.smbPass
import com.tms.qubeapps.qubedatacollector.Prefs.smbUser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

/**
 * ★ FIX (Menu 4 — Keep Stock, View & Edit Data):
 *  - Menampilkan SEMUA baris kolom B-D (NO CTN, SKU, QTY) dari Google Sheets
 *    toko yang login, dikelompokkan per NO CTN.
 *  - Search box + filter chip (All / Regular / Receiving / Duplicates).
 *  - Tombol "+ ADD" untuk tambah data (multi SKU/QTY per NO CTN).
 *  - Tap SKU/QTY -> EDIT, PINDAH, atau DELETE (per baris).
 *  - Tiap baris SKU menampilkan info dari SQLite lokal: SHELF, DESKRIPSI, QTY SISTEM.
 *
 *  ★ FIX BARU (revisi lanjutan):
 *  1. Aksi bulk per NO CTN (bukan cuma per SKU): tap ikon di header grup (mode
 *     List) atau tap kotak No Ctn (mode Grid) -> "Edit/Move No Ctn" (ganti
 *     kode NO CTN untuk SEMUA SKU di dalamnya sekaligus) & "Delete This Ctn"
 *     (hapus semua SKU di dalamnya sekaligus).
 *  2. (di layar Edit History) tombol hapus riwayat.
 *  3. SYNC IN/OUT & SYNC RECON dipindah ke sini dari layar utama Keep Stock —
 *     ditampilkan sebagai 2 kartu kecil di atas, supaya semua kerja dengan
 *     data toko (lihat, edit, sync) ada di 1 tempat.
 *  4. Toggle tampilan LIST (expand per NO CTN) / GRID (kotak ikon box per
 *     NO CTN, tap untuk lihat isi & aksi bulk).
 */
class KeepStockDataViewActivity : BaseActivity() {

    private lateinit var db: AppDatabase
    private lateinit var store: String
    private var pic: String = ""
    private var allRows: List<EnrichedRow> = emptyList()
    private var headerStats: HeaderStats = HeaderStats(0, 0, 0, 0)
    private var activeCategoryFilter: String = "ALL"
    private var isGridMode: Boolean = false

    private lateinit var listAdapter: GroupedAdapter
    private lateinit var gridAdapter: BoxGridAdapter
    private lateinit var elv: ExpandableListView
    private lateinit var gv: GridView
    private lateinit var tvHeaderStats: TextView
    private lateinit var tvFilteredCount: TextView
    private lateinit var chipAll: TextView
    private lateinit var chipRegular: TextView
    private lateinit var chipReceiving: TextView
    private lateinit var chipDuplicate: TextView
    private lateinit var btnToggleView: android.widget.ImageView

    /** Baris KeepStock (sheet) + info tambahan dari SQLite lokal + hasil analisis dobel/agregat. */
    data class EnrichedRow(
        val ksRow: KeepStockSheetReader.KsRow,
        val shelf: String,
        val desc: String,
        val systemQty: String,
        val diffLabel: String,
        val isDuplicate: Boolean,
        val duplicateCtns: List<String>,
        val totalKsQtyAllCtn: Double,
        val appearsInMultipleCtn: Boolean
    )

    data class HeaderStats(val regularCtn: Int, val regularSku: Int, val receivingCtn: Int, val receivingSku: Int)
    data class GroupItem(val noCtn: String, val items: List<EnrichedRow>)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_keep_stock_data_view)

        db = AppDatabase(this)
        store = intent.getStringExtra(KeepStockLoginActivity.EXTRA_STORE) ?: ""
        pic = intent.getStringExtra(KeepStockLoginActivity.EXTRA_PIC) ?: ""

        findViewById<View>(R.id.btnBackDataView).setOnClickListener { finish() }
        findViewById<TextView>(R.id.tvDataViewTitle).text = "KEEP STOCK DATA — $store"

        elv = findViewById(R.id.elvKsData)
        gv = findViewById(R.id.gvKsData)
        tvHeaderStats = findViewById(R.id.tvKsDataCount)
        tvFilteredCount = findViewById(R.id.tvKsFilteredCount)
        chipAll = findViewById(R.id.chipFilterAll)
        chipRegular = findViewById(R.id.chipFilterRegular)
        chipReceiving = findViewById(R.id.chipFilterReceiving)
        chipDuplicate = findViewById(R.id.chipFilterDuplicate)
        btnToggleView = findViewById(R.id.btnToggleView)
        val etSearch = findViewById<EditText>(R.id.etKsSearch)

        listAdapter = GroupedAdapter(emptyList())
        elv.setAdapter(listAdapter)
        elv.setOnChildClickListener { _, _, groupPosition, childPosition, _ ->
            showRowActionsDialog(listAdapter.getGroupItem(groupPosition).items[childPosition])
            true
        }

        gridAdapter = BoxGridAdapter(emptyList())
        gv.adapter = gridAdapter
        gv.setOnItemClickListener { _, _, position, _ -> showBoxDetailDialog(gridAdapter.getItem(position)) }

        btnToggleView.setOnClickListener { toggleViewMode() }

        // ★ FIX (baru — Denah Custom per No Ctn)
        findViewById<View>(R.id.btnCustomLayout).setOnClickListener {
            val i = android.content.Intent(this, DenahLayoutActivity::class.java)
            i.putExtra(KeepStockLoginActivity.EXTRA_STORE, store)
            i.putExtra(KeepStockLoginActivity.EXTRA_PIC, pic)
            startActivity(i)
        }

        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                applyFilter(s?.toString().orEmpty())
            }
        })

        chipAll.setOnClickListener { setCategoryFilter("ALL"); applyFilter(etSearch.text.toString()) }
        chipRegular.setOnClickListener { setCategoryFilter("REGULAR"); applyFilter(etSearch.text.toString()) }
        chipReceiving.setOnClickListener { setCategoryFilter("RECEIVING"); applyFilter(etSearch.text.toString()) }
        chipDuplicate.setOnClickListener { setCategoryFilter("DUPLICATE"); applyFilter(etSearch.text.toString()) }

        findViewById<View>(R.id.btnKsRefresh).setOnClickListener { loadData() }
        findViewById<View>(R.id.btnKsAdd).setOnClickListener { showAddDialog() }
        // ★ FIX (baru): Bersihkan Data Keep Stock — hapus semua No Ctn/SKU/Qty toko ini.
        findViewById<View>(R.id.btnKsClearAll).setOnClickListener { confirmClearAllKeepStockData() }

        findViewById<View>(R.id.cardSyncInOut).setOnClickListener { syncInOut() }
        findViewById<View>(R.id.cardSyncRecon).setOnClickListener { syncRecon() }

        loadData()
    }

    // ────────────────────────────────────────────────────────────────────
    // ★ FIX (poin 4): toggle List <-> Grid
    // ────────────────────────────────────────────────────────────────────
    private fun toggleViewMode() {
        isGridMode = !isGridMode
        elv.visibility = if (isGridMode) View.GONE else View.VISIBLE
        gv.visibility = if (isGridMode) View.VISIBLE else View.GONE
        btnToggleView.setImageResource(
            if (isGridMode) android.R.drawable.ic_menu_sort_by_size else android.R.drawable.ic_menu_gallery
        )
        Toast.makeText(this, if (isGridMode) "Grid view" else "List view", Toast.LENGTH_SHORT).show()
    }

    private fun loadData() {
        val ssid = exioSpreadsheetId(store)
        val gid = exioGid(store)
        if (ssid.isBlank() || gid.isBlank()) {
            AlertDialog.Builder(this)
                .setTitle("Not configured")
                .setMessage("Spreadsheet ID/GID for $store not set yet (tap the gear icon in Keep Stock menu).")
                .setPositiveButton("OK", null).showSafely()
            return
        }
        val pd = ProgressDialog(this).apply { setMessage("Loading data..."); show() }
        lifecycleScope.launch {
            try {
                val (enriched, stats) = withContext(Dispatchers.IO) {
                    val raw = KeepStockSheetReader.fetchRows(ssid, gid)
                    buildEnrichedRows(raw) to computeHeaderStats(raw)
                }
                pd.dismissSafely()
                allRows = enriched
                headerStats = stats
                tvHeaderStats.text = "KS Regular: ${stats.regularCtn} Ctn • ${stats.regularSku} SKU\n" +
                    "KS Receiving: ${stats.receivingCtn} Ctn • ${stats.receivingSku} SKU"
                applyFilter("")
            } catch (e: Exception) {
                pd.dismissSafely()
                AlertDialog.Builder(this@KeepStockDataViewActivity)
                    .setTitle("Load Failed")
                    .setMessage(e.message)
                    .setPositiveButton("OK", null).showSafely()
            }
        }
    }

    // ────────────────────────────────────────────────────────────────────
    // ★ FIX (poin 3): SYNC IN/OUT & SYNC RECON (dipindah dari layar utama)
    // ────────────────────────────────────────────────────────────────────
    private fun syncInOut() {
        val ssid = exioSpreadsheetId(store)
        val gid = exioGid(store)
        if (ssid.isBlank() || gid.isBlank()) {
            Toast.makeText(this, "Spreadsheet ID/GID for $store not set yet (tap the gear icon in Keep Stock menu)", Toast.LENGTH_LONG).show()
            return
        }
        val scanPath = exioScanPath(store)
        val prosesPath = exioProsesPath(store)
        if (scanPath.isBlank() || prosesPath.isBlank()) {
            Toast.makeText(this, "SMB folders for $store not set yet (tap the gear icon in Keep Stock menu)", Toast.LENGTH_LONG).show()
            return
        }

        val pd = ProgressDialog(this).apply { setMessage("Syncing $store..."); show() }
        lifecycleScope.launch {
            var resumedFromOutbox = false
            try {
                val user = smbUser; val pass = smbPass; val domain = smbDomain
                // ★ FIX (Perbaikan Sinkronisasi — Outbox Pattern + upload terverifikasi):
                // 1. Cek dulu apakah ada payload PENDING dari percobaan sync
                //    sebelumnya yang belum sempat ter-commit (mis. app sempat
                //    force-close/di-kill di tengah upload). Kalau ada, LANJUTKAN
                //    payload yang SAMA itu — jangan hitung ulang dari nol, supaya
                //    tidak ada diff yang "tercampur" dengan perubahan sheet
                //    berikutnya sebelum sempat terkirim.
                // 2. Kalau tidak ada pending, hitung fresh lewat ExInOutSync.sync()
                //    lalu SIMPAN dulu ke outbox SEBELUM upload apapun dimulai.
                // 3. Setiap file diupload lewat ReliableUploader (verifikasi
                //    checksum + retry otomatis), bukan SmbUploader polos lagi.
                // 4. commitState() + clearOutbox() HANYA dipanggil kalau SEMUA
                //    file di atas sukses & terverifikasi.
                val result = withContext(Dispatchers.IO) {
                    val pending = ExInOutSync.loadPendingOutbox(db, store)
                    val r = if (pending != null) {
                        resumedFromOutbox = true
                        pending
                    } else {
                        val fresh = ExInOutSync.sync(db, store, ssid, gid)
                        ExInOutSync.saveOutboxPending(db, fresh)
                        fresh
                    }

                    if (r.hasNewIn) {
                        ReliableUploader.uploadVerified(prosesPath, user, pass, Prefs.EXIO_FILE1, r.file1, domain)
                        ReliableUploader.uploadVerified(scanPath, user, pass, Prefs.EXIO_FILE2, r.file2, domain)
                    }
                    ReliableUploader.uploadVerified(prosesPath, user, pass, Prefs.EXIO_FILE3, r.file3, domain)
                    ReliableUploader.uploadVerified(scanPath, user, pass, Prefs.EXIO_FILE4, r.file4, domain)

                    // Semua file di atas sudah SUKSES & TERVERIFIKASI -> baru aman
                    // dikunci ke state permanen, dan outbox-nya boleh dibersihkan.
                    ExInOutSync.commitState(db, r)
                    ExInOutSync.clearOutbox(db, store)
                    r
                }
                pd.dismissSafely()
                val resumeNote = if (resumedFromOutbox)
                    "(Melanjutkan sync sebelumnya yang sempat gagal — data tidak dihitung ulang dari awal.)\n\n" else ""
                showSyncResultDialog(
                    "Sync In/Out — $store",
                    "$resumeNote" +
                    "New IN: ${result.newInCount}   OUT: ${result.outCount}\nFiles sent to PC via SMB (verified).\n\n${result.log.joinToString("\n")}"
                )
            } catch (e: Exception) {
                pd.dismissSafely()
                // ★ FIX (Perbaikan Sinkronisasi): kalau gagal di sini, commitState()/clearOutbox()
                // belum sempat terpanggil. Kalau sebelumnya sudah sempat disimpan
                // ke outbox (baik baru saja atau dari percobaan sebelumnya), payload
                // itu TETAP TERSIMPAN di SQLite — sync berikutnya akan otomatis
                // melanjutkan (resume) dari titik yang sama, bukan mengulang dari
                // nol dan bukan pula kehilangan data.
                AlertDialog.Builder(this@KeepStockDataViewActivity)
                    .setTitle("Sync Failed")
                    .setMessage("${e.message}\n\nData belum tersimpan/terkunci — aman untuk mencoba sync ulang, akan otomatis melanjutkan dari titik yang sama.")
                    .setPositiveButton("OK", null).showSafely()
            }
        }
    }

    private fun syncRecon() {
        val ssid = exioSpreadsheetId(store)
        val gid = exioGid(store)
        if (ssid.isBlank() || gid.isBlank()) {
            Toast.makeText(this, "Spreadsheet ID/GID for $store not set yet (tap the gear icon in Keep Stock menu)", Toast.LENGTH_LONG).show()
            return
        }
        val scanPath = exioScanPath(store)
        val prosesPath = exioProsesPath(store)
        if (scanPath.isBlank() || prosesPath.isBlank()) {
            Toast.makeText(this, "SMB folders for $store not set yet (tap the gear icon in Keep Stock menu)", Toast.LENGTH_LONG).show()
            return
        }

        val pd = ProgressDialog(this).apply { setMessage("Running Sync Recon for $store..."); show() }
        lifecycleScope.launch {
            try {
                val user = smbUser; val pass = smbPass; val domain = smbDomain
                // ★ FIX: pakai ReliableUploader (verifikasi checksum + retry
                // otomatis) juga di Sync Recon, konsisten dengan Sync IN/OUT —
                // Sync Recon sendiri stateless (dihitung ulang tiap kali dari
                // snapshot saat itu, tidak ada state yang di-lock di SQLite),
                // jadi risiko utamanya murni "upload terkirim tapi corrupt/
                // partial" — itu yang dicegah verifikasi ini.
                val result = withContext(Dispatchers.IO) {
                    val r = KeepStockReconSync.sync(db, ssid, gid, store)
                    if (r.belumExcelIn.isNotEmpty()) {
                        ReliableUploader.uploadVerified(prosesPath, user, pass, Prefs.EXIO_FILE1, r.file1, domain)
                        ReliableUploader.uploadVerified(scanPath, user, pass, Prefs.EXIO_FILE2, r.file2, domain)
                    }
                    ReliableUploader.uploadVerified(prosesPath, user, pass, Prefs.EXIO_FILE3, r.file3, domain)
                    ReliableUploader.uploadVerified(scanPath, user, pass, Prefs.EXIO_FILE4, r.file4, domain)
                    r
                }
                pd.dismissSafely()
                showSyncResultDialog(
                    "Sync Recon — $store",
                    "SKU Belum Excel In : ${result.belumExcelIn.size}\n" +
                        "SKU Belum Excel Out: ${result.belumExcelOut.size}\n" +
                        "SKU Pindah No Ctn  : ${result.pindahNoCtn.size} (info)\n" +
                        "SKU Aktif          : ${result.skuAktif.size} (info)\n" +
                        "Files sent to PC via SMB.\n\n${result.log.joinToString("\n")}"
                )
            } catch (e: Exception) {
                pd.dismissSafely()
                AlertDialog.Builder(this@KeepStockDataViewActivity)
                    .setTitle("Sync Recon Failed")
                    .setMessage(e.message)
                    .setPositiveButton("OK", null).showSafely()
            }
        }
    }

    private fun showSyncResultDialog(title: String, message: String) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("OK", null)
            .showSafely()
    }

    // ────────────────────────────────────────────────────────────────────
    // Helper keluarga CTN & kategori Regular/Receiving
    // ────────────────────────────────────────────────────────────────────

    private fun ctnFamily(noCtn: String): String {
        val trimmed = noCtn.trim()
        val base = trimmed.replace(Regex("[A-Za-z]+$"), "")
        return base.ifBlank { trimmed }
    }

    /** ★ FIX (baru — Receiving = di luar Regular): Regular = No Ctn diawali
     *  A, B, C, D, atau R0. SELAIN itu (apa pun awalannya) dianggap
     *  Receiving — tidak lagi dibatasi daftar awalan tetap (X/M/S/RA dst).
     *  Jadi setiap No Ctn pasti masuk salah satu dari 2 kategori ini saja
     *  (tidak ada lagi kategori "OTHER" yang tidak terhitung di manapun). */
    private fun ctnCategory(noCtn: String): String {
        val n = noCtn.trim().uppercase()
        return when {
            n.startsWith("R0") -> "REGULAR"
            n.startsWith("A") || n.startsWith("B") || n.startsWith("C") || n.startsWith("D") -> "REGULAR"
            else -> "RECEIVING"
        }
    }

    private fun computeHeaderStats(rows: List<KeepStockSheetReader.KsRow>): HeaderStats {
        val regularCtns = HashSet<String>()
        val regularSkus = HashSet<String>()
        val receivingCtns = HashSet<String>()
        val receivingSkus = HashSet<String>()
        rows.forEach { r ->
            when (ctnCategory(r.noCtn)) {
                "REGULAR" -> { regularCtns.add(r.noCtn); regularSkus.add(r.sku) }
                "RECEIVING" -> { receivingCtns.add(r.noCtn); receivingSkus.add(r.sku) }
            }
        }
        return HeaderStats(regularCtns.size, regularSkus.size, receivingCtns.size, receivingSkus.size)
    }

    private fun buildEnrichedRows(rawRows: List<KeepStockSheetReader.KsRow>): List<EnrichedRow> {
        data class SkuStats(val familyToCtns: MutableMap<String, MutableSet<String>> = mutableMapOf(), var totalQty: Double = 0.0)

        val statsBySku = HashMap<String, SkuStats>()
        rawRows.forEach { r ->
            val qtyNum = r.qty.toDoubleOrNull() ?: 0.0
            val fam = ctnFamily(r.noCtn)
            val st = statsBySku.getOrPut(r.sku) { SkuStats() }
            st.familyToCtns.getOrPut(fam) { mutableSetOf() }.add(r.noCtn)
            st.totalQty += qtyNum
        }

        val catalogCache = HashMap<String, Map<String, String>?>()

        return rawRows.map { r ->
            val st = statsBySku.getValue(r.sku)
            val fam = ctnFamily(r.noCtn)
            val isDup = st.familyToCtns.size > 1
            val dupCtns = st.familyToCtns.filterKeys { it != fam }.values.flatten().distinct().sorted()
            val totalCtnCount = st.familyToCtns.values.sumOf { it.size }

            val cat = catalogCache.getOrPut(r.sku) { db.findCatalog(r.sku) }
            val shelf = cat?.get("shelf")?.takeIf { it.isNotBlank() } ?: "-"
            val desc = cat?.get("desc")?.takeIf { it.isNotBlank() } ?: "-"
            val sysQty = cat?.get("balance")?.takeIf { it.isNotBlank() } ?: "-"

            EnrichedRow(
                ksRow = r,
                shelf = shelf,
                desc = desc,
                systemQty = sysQty,
                diffLabel = computeDiffLabel(sysQty, st.totalQty),
                isDuplicate = isDup,
                duplicateCtns = dupCtns,
                totalKsQtyAllCtn = st.totalQty,
                appearsInMultipleCtn = totalCtnCount > 1
            )
        }
    }

    private fun computeDiffLabel(systemQty: String, ksQtyAggregate: Double): String {
        val sys = systemQty.toDoubleOrNull() ?: return "No system data"
        val diff = sys - ksQtyAggregate
        return when {
            diff == 0.0 -> "SKU Belum Display"
            diff > 0 -> "Sudah Display ${diff.toInt()}"
            else -> "Keep Stock +${(-diff).toInt()}"
        }
    }

    private fun setCategoryFilter(filter: String) {
        activeCategoryFilter = filter
        val active = Color.WHITE
        val inactive = Color.BLACK
        listOf(chipAll to "ALL", chipRegular to "REGULAR", chipReceiving to "RECEIVING", chipDuplicate to "DUPLICATE").forEach { (chip, key) ->
            if (key == filter) {
                chip.setBackgroundColor(androidx.core.content.ContextCompat.getColor(this, R.color.purple_header))
                chip.setTextColor(active)
                chip.setTypeface(null, android.graphics.Typeface.BOLD)
            } else {
                chip.setBackgroundColor(androidx.core.content.ContextCompat.getColor(this, R.color.background))
                chip.setTextColor(inactive)
                chip.setTypeface(null, android.graphics.Typeface.NORMAL)
            }
        }
    }

    private var currentGroups: List<GroupItem> = emptyList()

    private fun applyFilter(query: String) {
        val q = query.trim().lowercase()
        val filtered = allRows.filter { row ->
            val matchesSearch = q.isBlank() ||
                row.ksRow.noCtn.lowercase().contains(q) ||
                row.ksRow.sku.lowercase().contains(q) ||
                row.ksRow.qty.lowercase().contains(q) ||
                row.diffLabel.lowercase().contains(q)
            val matchesCategory = when (activeCategoryFilter) {
                "REGULAR" -> ctnCategory(row.ksRow.noCtn) == "REGULAR"
                "RECEIVING" -> ctnCategory(row.ksRow.noCtn) == "RECEIVING"
                "DUPLICATE" -> row.isDuplicate
                else -> true
            }
            matchesSearch && matchesCategory
        }
        val grouped = LinkedHashMap<String, MutableList<EnrichedRow>>()
        for (r in filtered) {
            grouped.getOrPut(r.ksRow.noCtn.ifBlank { "(empty)" }) { mutableListOf() }.add(r)
        }
        val groups = grouped.map { GroupItem(it.key, it.value) }
        currentGroups = groups
        listAdapter.update(groups)
        for (i in groups.indices) elv.expandGroup(i)
        gridAdapter.update(groups)
        tvFilteredCount.text = "Total: ${filtered.size} row(s) in ${groups.size} CTN"
    }

    // ────────────────────────────────────────────────────────────────────
    // ADD (multi SKU/QTY) / EDIT / MOVE / DELETE (per SKU) -> GAS Web App
    // ────────────────────────────────────────────────────────────────────

    private fun requireWebAppConfigured(): Boolean {
        if (ksWebAppUrl.isBlank()) {
            AlertDialog.Builder(this)
                .setTitle("Not configured")
                .setMessage("GAS Web App URL is not set yet (Setting menu).")
                .setPositiveButton("OK", null).showSafely()
            return false
        }
        return true
    }

    private fun showRowActionsDialog(row: EnrichedRow) {
        val options = arrayOf("Edit", "Move to Another CTN", "Delete")
        AlertDialog.Builder(this)
            .setTitle("NO CTN: ${row.ksRow.noCtn}  •  SKU: ${row.ksRow.sku}  •  QTY: ${row.ksRow.qty}")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> showEditDialog(row)
                    1 -> showMoveDialog(row)
                    2 -> confirmDelete(row)
                }
            }
            .setNegativeButton("Cancel", null)
            .showSafely()
    }

    private fun showAddDialog() {
        if (!requireWebAppConfigured()) return
        val view = LayoutInflater.from(this).inflate(R.layout.dialog_ks_add_multi, null)
        val etNoCtn = view.findViewById<EditText>(R.id.etDlgNoCtn)
        val container = view.findViewById<LinearLayout>(R.id.containerSkuRows)
        val btnAddRow = view.findViewById<View>(R.id.btnAddSkuRow)

        fun addSkuRow() {
            val rowView = LayoutInflater.from(this).inflate(R.layout.item_ks_add_row, container, false)
            rowView.findViewById<View>(R.id.btnRemoveRow).setOnClickListener {
                if (container.childCount > 1) container.removeView(rowView)
            }
            container.addView(rowView)
        }
        addSkuRow()
        btnAddRow.setOnClickListener { addSkuRow() }

        AlertDialog.Builder(this)
            .setTitle("Add Data — $store")
            .setView(view)
            .setPositiveButton("SAVE") { _, _ ->
                val noCtn = etNoCtn.text.toString().trim()
                if (noCtn.isBlank()) {
                    Toast.makeText(this, "NO CTN is required", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                val items = mutableListOf<Pair<String, String>>()
                for (i in 0 until container.childCount) {
                    val row = container.getChildAt(i)
                    val sku = row.findViewById<EditText>(R.id.etRowSku).text.toString().trim()
                    val qty = row.findViewById<EditText>(R.id.etRowQty).text.toString().trim().ifBlank { "1" }
                    if (sku.isNotBlank()) items.add(sku to qty)
                }
                if (items.isEmpty()) {
                    Toast.makeText(this, "Add at least 1 SKU", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                runGasOp(
                    "Adding ${items.size} SKU...",
                    historyAction = "ADD",
                    after = Triple(noCtn, items.joinToString(", ") { it.first }, items.joinToString(", ") { it.second })
                ) {
                    KeepStockGasClient.addRows(ksWebAppUrl, ksApiToken, store, noCtn, items)
                }
            }
            .setNegativeButton("Cancel", null)
            .showSafely()
    }

    private fun showEditDialog(row: EnrichedRow) {
        if (!requireWebAppConfigured()) return
        val view = LayoutInflater.from(this).inflate(R.layout.dialog_ks_row, null)
        val etNoCtn = view.findViewById<EditText>(R.id.etDlgNoCtn).apply { setText(row.ksRow.noCtn) }
        val etSku = view.findViewById<EditText>(R.id.etDlgSku).apply { setText(row.ksRow.sku) }
        val etQty = view.findViewById<EditText>(R.id.etDlgQty).apply { setText(row.ksRow.qty) }
        AlertDialog.Builder(this)
            .setTitle("Edit Data (Row ${row.ksRow.rowNumber})")
            .setView(view)
            .setPositiveButton("SAVE") { _, _ ->
                val noCtn = etNoCtn.text.toString().trim()
                val sku = etSku.text.toString().trim()
                val qty = etQty.text.toString().trim()
                if (noCtn.isBlank() || sku.isBlank()) {
                    Toast.makeText(this, "NO CTN and SKU are required", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                runGasOp(
                    "Saving...",
                    historyAction = "EDIT",
                    before = Triple(row.ksRow.noCtn, row.ksRow.sku, row.ksRow.qty),
                    after = Triple(noCtn, sku, qty)
                ) { KeepStockGasClient.updateRow(ksWebAppUrl, ksApiToken, store, row.ksRow.rowNumber, noCtn, sku, qty) }
            }
            .setNegativeButton("Cancel", null)
            .showSafely()
    }

    private fun showMoveDialog(row: EnrichedRow) {
        if (!requireWebAppConfigured()) return
        val view = LayoutInflater.from(this).inflate(R.layout.dialog_ks_move, null)
        val etNoCtn = view.findViewById<EditText>(R.id.etDlgMoveNoCtn)
        AlertDialog.Builder(this)
            .setTitle("Move SKU ${row.ksRow.sku}")
            .setView(view)
            .setPositiveButton("MOVE") { _, _ ->
                val newNoCtn = etNoCtn.text.toString().trim()
                if (newNoCtn.isBlank()) {
                    Toast.makeText(this, "New NO CTN is required", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                runGasOp(
                    "Moving...",
                    historyAction = "MOVE",
                    before = Triple(row.ksRow.noCtn, row.ksRow.sku, row.ksRow.qty),
                    after = Triple(newNoCtn, row.ksRow.sku, row.ksRow.qty)
                ) { KeepStockGasClient.updateRow(ksWebAppUrl, ksApiToken, store, row.ksRow.rowNumber, newNoCtn, row.ksRow.sku, row.ksRow.qty) }
            }
            .setNegativeButton("Cancel", null)
            .showSafely()
    }

    private fun confirmDelete(row: EnrichedRow) {
        if (!requireWebAppConfigured()) return
        AlertDialog.Builder(this)
            .setTitle("Delete Data")
            .setMessage("Delete NO CTN ${row.ksRow.noCtn} — SKU ${row.ksRow.sku} — QTY ${row.ksRow.qty}?\nThis clears all 3 fields (NO CTN, SKU, QTY) for this row.")
            .setPositiveButton("DELETE") { _, _ ->
                runGasOp(
                    "Deleting...",
                    historyAction = "DELETE",
                    before = Triple(row.ksRow.noCtn, row.ksRow.sku, row.ksRow.qty),
                    after = Triple("", "", "")
                ) { KeepStockGasClient.deleteRow(ksWebAppUrl, ksApiToken, store, row.ksRow.rowNumber) }
            }
            .setNegativeButton("Cancel", null)
            .showSafely()
    }

    // ────────────────────────────────────────────────────────────────────
    // ★ FIX (poin 1): aksi BULK per NO CTN — Edit/Move seluruh isi CTN,
    // atau Delete seluruh isi CTN sekaligus (bukan cuma per SKU lagi).
    // ────────────────────────────────────────────────────────────────────

    private fun showGroupActionsDialog(group: GroupItem) {
        val options = arrayOf("Edit / Move No Ctn (${group.items.size} SKU)", "Delete This No Ctn (${group.items.size} SKU)")
        AlertDialog.Builder(this)
            .setTitle("NO CTN: ${group.noCtn}")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> showEditCtnDialog(group)
                    1 -> confirmDeleteCtn(group)
                }
            }
            .setNegativeButton("Cancel", null)
            .showSafely()
    }

    /** Rename NO CTN untuk SEMUA SKU di dalam grup ini sekaligus (Edit dan Pindah adalah aksi yang sama). */
    private fun showEditCtnDialog(group: GroupItem) {
        if (!requireWebAppConfigured()) return
        val view = LayoutInflater.from(this).inflate(R.layout.dialog_ks_move, null)
        val etNoCtn = view.findViewById<EditText>(R.id.etDlgMoveNoCtn).apply { setText(group.noCtn) }
        AlertDialog.Builder(this)
            .setTitle("Edit / Move No Ctn — ${group.noCtn}")
            .setMessage("Rename this NO CTN. All ${group.items.size} SKU inside will move together.")
            .setView(view)
            .setPositiveButton("SAVE") { _, _ ->
                val newCtn = etNoCtn.text.toString().trim()
                if (newCtn.isBlank()) {
                    Toast.makeText(this, "New NO CTN is required", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                runBulkGasOp(
                    "Moving ${group.items.size} SKU...",
                    historyAction = "MOVE_CTN",
                    before = Triple(group.noCtn, "(${group.items.size} SKU)", ""),
                    after = Triple(newCtn, "(${group.items.size} SKU)", "")
                ) {
                    group.items.map { row ->
                        KeepStockGasClient.updateRow(ksWebAppUrl, ksApiToken, store, row.ksRow.rowNumber, newCtn, row.ksRow.sku, row.ksRow.qty)
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .showSafely()
    }

    private fun confirmDeleteCtn(group: GroupItem) {
        if (!requireWebAppConfigured()) return
        AlertDialog.Builder(this)
            .setTitle("Delete NO CTN ${group.noCtn}")
            .setMessage("Delete ALL ${group.items.size} SKU under NO CTN ${group.noCtn}? This cannot be undone.")
            .setPositiveButton("DELETE ALL") { _, _ ->
                runBulkGasOp(
                    "Deleting ${group.items.size} SKU...",
                    historyAction = "DELETE_CTN",
                    before = Triple(group.noCtn, "(${group.items.size} SKU)", ""),
                    after = Triple("", "", "")
                ) {
                    group.items.map { row -> KeepStockGasClient.deleteRow(ksWebAppUrl, ksApiToken, store, row.ksRow.rowNumber) }
                }
            }
            .setNegativeButton("Cancel", null)
            .showSafely()
    }

    /**
     * ★ FIX (baru): Bersihkan Data Keep Stock — hapus SEMUA data (semua NO
     * CTN, SKU, dan Qty) untuk toko yang sedang login. Konfirmasi dulu,
     * lalu hapus baris demi baris lewat `KeepStockGasClient.deleteRow`
     * (fungsi yang sama dipakai fitur Delete per-baris — tidak ada
     * endpoint/struktur data baru), lalu refresh data otomatis.
     */
    private fun confirmClearAllKeepStockData() {
        if (!requireWebAppConfigured()) return
        if (allRows.isEmpty()) {
            Toast.makeText(this, "No data to delete.", Toast.LENGTH_SHORT).show()
            return
        }
        val totalRows = allRows.size
        AlertDialog.Builder(this)
            .setTitle("Clear Keep Stock Data")
            .setMessage("All Keep Stock data will be permanently deleted. Continue?")
            .setPositiveButton("Delete") { _, _ ->
                val rowsToDelete = allRows
                val pd = ProgressDialog(this).apply { setMessage("Deleting $totalRows row(s)..."); show() }
                lifecycleScope.launch {
                    try {
                        val results = withContext(Dispatchers.IO) {
                            rowsToDelete.map { row ->
                                KeepStockGasClient.deleteRow(ksWebAppUrl, ksApiToken, store, row.ksRow.rowNumber)
                            }
                        }
                        val failed = results.count { !it.optBoolean("ok", false) }
                        withContext(Dispatchers.IO) {
                            db.insertKsHistory(
                                store, pic, "CLEAR_ALL",
                                noCtnBefore = "(ALL)", skuBefore = "($totalRows row(s))", qtyBefore = "",
                                noCtnAfter = "", skuAfter = "", qtyAfter = ""
                            )
                        }
                        pd.dismissSafely()
                        loadData()
                        if (failed == 0) {
                            Toast.makeText(this@KeepStockDataViewActivity,
                                "All Keep Stock data was successfully deleted.", Toast.LENGTH_LONG).show()
                        } else {
                            AlertDialog.Builder(this@KeepStockDataViewActivity)
                                .setTitle("Some rows failed to delete")
                                .setMessage("$failed of $totalRows row(s) failed to delete. Please refresh and try again.")
                                .setPositiveButton("OK", null).showSafely()
                        }
                    } catch (e: Exception) {
                        pd.dismissSafely()
                        AlertDialog.Builder(this@KeepStockDataViewActivity)
                            .setTitle("Failed")
                            .setMessage("Could not reach the Web App. (${e.message})")
                            .setPositiveButton("OK", null).showSafely()
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .showSafely()
    }

    /** Dialog detail isi 1 NO CTN (dipakai dari mode Grid — tap kotak) + tombol aksi bulk. */
    private fun showBoxDetailDialog(group: GroupItem) {
        val view = LayoutInflater.from(this).inflate(R.layout.dialog_ks_box_detail, null)
        view.findViewById<TextView>(R.id.tvBoxDetailTitle).text = "NO CTN: ${group.noCtn} (${group.items.size} SKU)"

        val dialog = AlertDialog.Builder(this).setView(view).setNegativeButton("Close", null).create()

        val lv = view.findViewById<ListView>(R.id.lvBoxDetailSkus)
        lv.adapter = object : BaseAdapter() {
            override fun getCount() = group.items.size
            override fun getItem(position: Int) = group.items[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val v = convertView ?: LayoutInflater.from(this@KeepStockDataViewActivity).inflate(R.layout.item_ks_child, parent, false)
                bindChildRowView(v, group.items[position])
                return v
            }
        }
        lv.setOnItemClickListener { _, _, position, _ ->
            dialog.dismiss()
            showRowActionsDialog(group.items[position])
        }
        view.findViewById<View>(R.id.btnBoxCtnActions).setOnClickListener {
            dialog.dismiss()
            showGroupActionsDialog(group)
        }

        dialog.show()
    }

    /**
     * @param historyAction ADD / EDIT / MOVE / DELETE, atau null kalau aksi ini tidak perlu dicatat.
     * @param before/after  (noCtn, sku, qty) sebelum & sesudah — dicatat ke riwayat lokal kalau sukses.
     */
    private fun runGasOp(
        progressMsg: String,
        historyAction: String? = null,
        before: Triple<String, String, String>? = null,
        after: Triple<String, String, String>? = null,
        op: suspend () -> JSONObject
    ) {
        val pd = ProgressDialog(this).apply { setMessage(progressMsg); show() }
        lifecycleScope.launch {
            try {
                val result = withContext(Dispatchers.IO) { op() }
                pd.dismissSafely()
                if (result.optBoolean("ok", false)) {
                    Toast.makeText(this@KeepStockDataViewActivity, result.optString("message", "Done"), Toast.LENGTH_SHORT).show()
                    if (historyAction != null) {
                        withContext(Dispatchers.IO) {
                            db.insertKsHistory(
                                store, pic, historyAction,
                                noCtnBefore = before?.first.orEmpty(), skuBefore = before?.second.orEmpty(), qtyBefore = before?.third.orEmpty(),
                                noCtnAfter = after?.first.orEmpty(), skuAfter = after?.second.orEmpty(), qtyAfter = after?.third.orEmpty()
                            )
                        }
                    }
                    loadData()
                } else {
                    AlertDialog.Builder(this@KeepStockDataViewActivity)
                        .setTitle("Failed")
                        .setMessage(result.optString("error", "Unknown error"))
                        .setPositiveButton("OK", null).showSafely()
                }
            } catch (e: Exception) {
                pd.dismissSafely()
                AlertDialog.Builder(this@KeepStockDataViewActivity)
                    .setTitle("Failed")
                    .setMessage("Could not reach the Web App. (${e.message})")
                    .setPositiveButton("OK", null).showSafely()
            }
        }
    }

    /** ★ FIX (poin 1): versi bulk dari runGasOp — jalankan beberapa updateRow/deleteRow sekaligus (1 per SKU dalam CTN). */
    private fun runBulkGasOp(
        progressMsg: String,
        historyAction: String,
        before: Triple<String, String, String>,
        after: Triple<String, String, String>,
        op: suspend () -> List<JSONObject>
    ) {
        val pd = ProgressDialog(this).apply { setMessage(progressMsg); show() }
        lifecycleScope.launch {
            try {
                val results = withContext(Dispatchers.IO) { op() }
                pd.dismissSafely()
                val failed = results.count { !it.optBoolean("ok", false) }
                withContext(Dispatchers.IO) {
                    db.insertKsHistory(
                        store, pic, historyAction,
                        noCtnBefore = before.first, skuBefore = before.second, qtyBefore = before.third,
                        noCtnAfter = after.first, skuAfter = after.second, qtyAfter = after.third
                    )
                }
                if (failed == 0) {
                    Toast.makeText(this@KeepStockDataViewActivity, "Done (${results.size} row(s))", Toast.LENGTH_SHORT).show()
                } else {
                    AlertDialog.Builder(this@KeepStockDataViewActivity)
                        .setTitle("Partially Failed")
                        .setMessage("$failed of ${results.size} row(s) failed. Please refresh and check the data.")
                        .setPositiveButton("OK", null).showSafely()
                }
                loadData()
            } catch (e: Exception) {
                pd.dismissSafely()
                AlertDialog.Builder(this@KeepStockDataViewActivity)
                    .setTitle("Failed")
                    .setMessage("Could not reach the Web App. (${e.message})")
                    .setPositiveButton("OK", null).showSafely()
            }
        }
    }

    /** ★ FIX: dipakai bersama oleh GroupedAdapter.getChildView & dialog detail box (mode Grid), biar tidak duplikat kode. */
    private fun bindChildRowView(v: View, row: EnrichedRow) {
        v.findViewById<TextView>(R.id.tvChildSku).text = "SKU: ${row.ksRow.sku}"
        v.findViewById<TextView>(R.id.tvChildQty).text = "QTY: ${row.ksRow.qty}"
        v.findViewById<TextView>(R.id.tvChildShelf).text = "Shelf: ${row.shelf}"
        v.findViewById<TextView>(R.id.tvChildSysQty).text = "Sys Qty: ${row.systemQty}"
        v.findViewById<TextView>(R.id.tvChildDesc).text = row.desc

        val tvDiff = v.findViewById<TextView>(R.id.tvChildDiff)
        tvDiff.text = row.diffLabel
        tvDiff.setTextColor(
            when {
                row.diffLabel == "SKU Belum Display" -> 0xFF888888.toInt()
                row.diffLabel.startsWith("Sudah Display") -> 0xFF00B894.toInt()
                row.diffLabel.startsWith("Keep Stock") -> 0xFFE17055.toInt()
                else -> 0xFF888888.toInt()
            }
        )

        val tvTotalQty = v.findViewById<TextView>(R.id.tvChildTotalQty)
        if (row.appearsInMultipleCtn) {
            tvTotalQty.visibility = View.VISIBLE
            tvTotalQty.text = "Total Qty (all CTN): ${row.totalKsQtyAllCtn.toInt()}"
        } else {
            tvTotalQty.visibility = View.GONE
        }

        val root = v.findViewById<LinearLayout>(R.id.rootChildRow)
        val tvDup = v.findViewById<TextView>(R.id.tvChildDupInfo)
        if (row.isDuplicate) {
            root.setBackgroundColor(0xFFFFCC80.toInt())
            tvDup.visibility = View.VISIBLE
            tvDup.text = "⚠ Duplicate SKU — also in: ${row.duplicateCtns.joinToString(", ")}"
        } else {
            root.setBackgroundColor(androidx.core.content.ContextCompat.getColor(v.context, R.color.background))
            tvDup.visibility = View.GONE
        }
    }

    // ────────────────────────────────────────────────────────────────────
    // Adapters: List mode (ExpandableListView) & Grid mode (GridView)
    // ────────────────────────────────────────────────────────────────────

    private inner class GroupedAdapter(private var groups: List<GroupItem>) : BaseExpandableListAdapter() {

        fun update(newGroups: List<GroupItem>) {
            groups = newGroups
            notifyDataSetChanged()
        }

        fun getGroupItem(position: Int): GroupItem = groups[position]

        override fun getGroupCount() = groups.size
        override fun getChildrenCount(groupPosition: Int) = groups[groupPosition].items.size
        override fun getGroup(groupPosition: Int) = groups[groupPosition]
        override fun getChild(groupPosition: Int, childPosition: Int) = groups[groupPosition].items[childPosition]
        override fun getGroupId(groupPosition: Int) = groupPosition.toLong()
        override fun getChildId(groupPosition: Int, childPosition: Int) = childPosition.toLong()
        override fun hasStableIds() = false

        override fun getGroupView(groupPosition: Int, isExpanded: Boolean, convertView: View?, parent: ViewGroup?): View {
            val v = convertView ?: LayoutInflater.from(parent!!.context).inflate(R.layout.item_ks_group, parent, false)
            val group = groups[groupPosition]
            v.findViewById<TextView>(R.id.tvGroupNoCtn).text = "NO CTN: ${group.noCtn}"
            v.findViewById<TextView>(R.id.tvGroupCount).text = "${group.items.size} item(s)"
            // ★ FIX (poin 1): tap ikon di header grup -> aksi bulk (Edit/Move/Delete seluruh CTN)
            v.findViewById<View>(R.id.btnGroupMenu).setOnClickListener { showGroupActionsDialog(group) }
            return v
        }

        override fun getChildView(groupPosition: Int, childPosition: Int, isLastChild: Boolean, convertView: View?, parent: ViewGroup?): View {
            val v = convertView ?: LayoutInflater.from(parent!!.context).inflate(R.layout.item_ks_child, parent, false)
            bindChildRowView(v, groups[groupPosition].items[childPosition])
            return v
        }

        override fun isChildSelectable(groupPosition: Int, childPosition: Int) = true
    }

    /** ★ FIX (poin 4): tiap NO CTN jadi 1 kotak ikon box di mode Grid. */
    private inner class BoxGridAdapter(private var groups: List<GroupItem>) : BaseAdapter() {

        fun update(newGroups: List<GroupItem>) {
            groups = newGroups
            notifyDataSetChanged()
        }

        override fun getCount() = groups.size
        override fun getItem(position: Int): GroupItem = groups[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val v = convertView ?: LayoutInflater.from(parent!!.context).inflate(R.layout.item_ks_box, parent, false)
            val group = groups[position]
            v.findViewById<TextView>(R.id.tvBoxNoCtn).text = group.noCtn
            v.findViewById<TextView>(R.id.tvBoxCount).text = "${group.items.size} SKU"
            v.findViewById<View>(R.id.dotBoxDuplicate).visibility =
                if (group.items.any { it.isDuplicate }) View.VISIBLE else View.GONE
            // ★ FIX: tampilkan daftar SKU + Qty saja (TANPA Keterangan/desc,
            // supaya baris tidak panjang) — "SKU x Qty" per baris. Maksimal
            // 3 SKU pertama yang ditampilkan (selaras dgn minLines=maxLines=3
            // di layout) supaya ukuran tiap kotak grid PERSIS SAMA, tidak ada
            // kotak yang lebih tinggi/pendek dari kotak lain. Kalau SKU lebih
            // dari 3, baris ke-3 diganti ringkasan "+N lainnya" (bukan
            // ditambah sebagai baris ke-4) supaya tetap muat pas 3 baris.
            val maxShown = 3
            val totalItems = group.items.size
            val skuLines = if (totalItems > maxShown) {
                val shownItems = group.items.take(maxShown - 1)
                val extra = totalItems - shownItems.size
                shownItems.map { row -> "${row.ksRow.sku} x${row.ksRow.qty.ifBlank { "1" }}" } + "+$extra lainnya"
            } else {
                group.items.map { row -> "${row.ksRow.sku} x${row.ksRow.qty.ifBlank { "1" }}" }
            }
            v.findViewById<TextView>(R.id.tvBoxSkuList).text = skuLines.joinToString("\n")
            return v
        }
    }
}
