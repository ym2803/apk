package com.tms.qubeapps.qubedatacollector

import android.content.Context

object ColMappingPrefs {

    private const val NAME = "QubeColMapping"

    private const val K_SKU           = "col_sku"
    private const val K_BALANCE       = "col_balance"
    private const val K_SHELF         = "col_shelf"
    private const val K_PRICE         = "col_price"
    private const val K_DESC          = "col_desc"
    // ★ FIX: mapping kolom untuk field tambahan (Discount, Disc Start/End Date, Long SKU, Keep Stock)
    private const val K_DISCOUNT      = "col_discount"
    private const val K_DISC_START    = "col_disc_start"
    private const val K_DISC_END      = "col_disc_end"
    private const val K_LONGSKU       = "col_long_sku"
    private const val K_KEEPSTOCK     = "col_keep_stock"
    private const val K_SEPARATOR     = "col_separator"
    private const val K_DISPLAY_ORDER = "col_display_order"
    private const val K_PREVIEW_ROW   = "col_preview_row"
    private const val K_TOTAL_COLS    = "col_total_cols"
    // Flag: apakah user sudah pernah simpan mapping secara eksplisit
    private const val K_USER_SAVED    = "col_user_saved"
    // ★ FIX (baru — tampilan Result 1 kolom vertikal): jumlah baris yang
    // ditampilkan di kartu RESULT (Shelf Price Enquire), 10 = semua slot
    // ditampilkan (font lebih kecil), 5 = hanya 5 slot pertama ditampilkan
    // (font lebih besar). Diatur dari menu SET COLUMNS.
    private const val K_RESULT_ROWS    = "result_row_count"

    const val DEFAULT_DISPLAY_ORDER = "SKU,Shelf,Price,Desc"

    data class Mapping(
        // ★ FIX: default disamakan dengan tampilan Column Mapping standar
        val colSku      : Int    = 1,
        val colBalance  : Int    = 19,
        val colShelf    : Int    = 2,
        val colPrice    : Int    = 3,
        val colDesc     : Int    = 4,
        val colDiscount : Int    = 13,
        val colDiscStart: Int    = 14,
        val colDiscEnd  : Int    = 15,
        val colLongSku  : Int    = 23,
        val colKeepStock: Int    = 22,
        val separator   : String = ",",
        val displayOrder: String = DEFAULT_DISPLAY_ORDER,
        val previewRow  : String = "",
        val totalCols   : Int    = 0,
        val userSaved   : Boolean= false, // true = user sudah set manual
        // ★ FIX (baru): jumlah baris tampilan kartu RESULT — 10 atau 5.
        val resultRowCount: Int = 10
    )

    fun save(ctx: Context, m: Mapping) {
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).edit()
            .putInt(K_SKU,              m.colSku)
            .putInt(K_BALANCE,          m.colBalance)
            .putInt(K_SHELF,            m.colShelf)
            .putInt(K_PRICE,            m.colPrice)
            .putInt(K_DESC,             m.colDesc)
            .putInt(K_DISCOUNT,         m.colDiscount)
            .putInt(K_DISC_START,       m.colDiscStart)
            .putInt(K_DISC_END,         m.colDiscEnd)
            .putInt(K_LONGSKU,          m.colLongSku)
            .putInt(K_KEEPSTOCK,        m.colKeepStock)
            .putString(K_SEPARATOR,     m.separator)
            .putString(K_DISPLAY_ORDER, m.displayOrder)
            .putString(K_PREVIEW_ROW,   m.previewRow)
            .putInt(K_TOTAL_COLS,       m.totalCols)
            .putBoolean(K_USER_SAVED,   m.userSaved)
            .putInt(K_RESULT_ROWS,      m.resultRowCount)
            .apply()
    }

    fun load(ctx: Context): Mapping {
        val sp = ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE)
        return Mapping(
            colSku       = sp.getInt(K_SKU,     1),
            colBalance   = sp.getInt(K_BALANCE, 19),
            colShelf     = sp.getInt(K_SHELF,   2),
            colPrice     = sp.getInt(K_PRICE,   3),
            colDesc      = sp.getInt(K_DESC,    4),
            colDiscount  = sp.getInt(K_DISCOUNT,   13),
            colDiscStart = sp.getInt(K_DISC_START, 14),
            colDiscEnd   = sp.getInt(K_DISC_END,   15),
            colLongSku   = sp.getInt(K_LONGSKU,    23),
            colKeepStock = sp.getInt(K_KEEPSTOCK,  22),
            separator    = sp.getString(K_SEPARATOR,     ",")  ?: ",",
            displayOrder = sp.getString(K_DISPLAY_ORDER, DEFAULT_DISPLAY_ORDER) ?: DEFAULT_DISPLAY_ORDER,
            previewRow   = sp.getString(K_PREVIEW_ROW,  "")   ?: "",
            totalCols    = sp.getInt(K_TOTAL_COLS,       0),
            userSaved    = sp.getBoolean(K_USER_SAVED,   false),
            resultRowCount = sp.getInt(K_RESULT_ROWS,    10)
        )
    }

    fun getCol(parts: List<String>, colNum: Int): String {
        if (colNum <= 0)            return "-"
        if (colNum > parts.size)    return "-"
        return parts[colNum - 1].trim()
    }

    /**
     * ★ FIX (import 02.txt): Description sering mengandung koma, tab, dan
     * enter mentah (tidak di-escape/quote sama sekali di sumbernya). Ini
     * menyebabkan 2 masalah:
     *
     *  1. ENTER di tengah deskripsi → dianggap baris baru oleh parser lama
     *     (raw.lineSequence()), jadi 1 record data terpecah jadi 2+ baris
     *     yang rusak, dan sisa kolom sesudah Desc (termasuk kolom ke-23
     *     yang dipakai fitur Barcode Filter) jadi ikut hilang/salah.
     *  2. KOMA di tengah deskripsi → naive split(",") menghasilkan kolom
     *     EKSTRA yang menggeser semua kolom sesudah Desc.
     *
     * `reassembleRecords()` menggabungkan kembali baris fisik yang terpecah
     * (masalah #1) berdasarkan jumlah kolom target, dan `splitLineSmart()`
     * menggabungkan kolom ekstra kembali ke kolom Desc (masalah #2) — tanpa
     * mengubah data kolom lain sama sekali.
     */
    fun reassembleRecords(raw: String, sep: String): Sequence<String> {
        // ★ FIX: totalCols yang dipakai untuk deteksi "record sudah lengkap atau
        // belum" dihitung dari MODE (jumlah kolom yang paling sering muncul) di
        // antara baris fisik pertama, BUKAN cuma dari baris pertama saja — supaya
        // tetap akurat walau baris paling pertama kebetulan yang rusak/terpotong.
        val sampleLines = raw.lineSequence().filter { it.isNotBlank() }.take(50).toList()
        val counts = sampleLines.map { it.trimEnd('\r', '\n', ' ').split(sep).size }
        val modeTotalCols = counts.groupingBy { it }.eachCount().maxByOrNull { it.value }?.key
            ?: counts.firstOrNull() ?: 1

        return sequence {
            val lineIterator = raw.lineSequence().iterator()
            var buffer: String? = null
            while (lineIterator.hasNext()) {
                val line = lineIterator.next()
                if (line.isBlank() && buffer == null) continue
                buffer = if (buffer == null) line else buffer + " " + line.trim()
                val fieldCount = buffer!!.trimEnd('\r', '\n', ' ').split(sep).size
                if (fieldCount >= modeTotalCols) {
                    yield(buffer!!)
                    buffer = null
                }
                // kalau belum cukup kolom → baris berikutnya masih bagian dari
                // deskripsi yang terpotong ENTER, terus digabung sampai cukup.
            }
            if (!buffer.isNullOrBlank()) yield(buffer!!) // sisa terakhir, walau kurang lengkap
        }
    }

    /**
     * Split baris jadi kolom, lalu kalau jumlah kolomnya LEBIH BANYAK dari
     * totalCols (karena ada koma mentah di dalam Desc), gabungkan kolom
     * ekstra itu balik ke posisi kolom Desc — supaya kolom-kolom lain
     * (termasuk kolom ke-23 untuk Barcode Filter) tidak ikut bergeser.
     */
    fun splitLineSmart(line: String, sep: String, totalCols: Int, descColIndex: Int): List<String> {
        val parts = splitLine(line, sep)
        if (parts.size <= totalCols || descColIndex <= 0 || totalCols <= 0) return parts

        val extra = parts.size - totalCols
        val descStart = descColIndex - 1
        val descEnd = descStart + extra
        if (descStart < 0 || descEnd >= parts.size) return parts // fallback aman kalau posisi tidak masuk akal

        val merged = mutableListOf<String>()
        merged.addAll(parts.subList(0, descStart))
        merged.add(parts.subList(descStart, descEnd + 1).joinToString(sep))
        merged.addAll(parts.subList(descEnd + 1, parts.size))
        return merged
    }

    /**
     * Split baris file dengan benar.
     * FIX utama kolom ke-9: trimEnd('\r') sebelum split agar karakter
     * Windows line-ending tidak menempel di nilai kolom terakhir.
     */
    fun splitLine(line: String, sep: String): List<String> {
        val cleaned = line.trimEnd('\r', '\n', ' ')
        if (cleaned.isEmpty()) return emptyList()
        return cleaned.split(sep)
    }

    /**
     * Auto-detect mapping kolom dari baris sample file.
     * Dipanggil saat download selesai HANYA jika user belum pernah save mapping.
     *
     * Logika deteksi untuk format:
     *   SKU, Shelf, Price, Balance, ?, Date, ?, SKU2, Desc
     *   [1]   [2]    [3]    [4]    [5]  [6]  [7]  [8]  [9]
     *
     * Heuristik:
     * - Kolom SKU    = kolom pertama non-kosong yang isinya alphanumeric
     * - Kolom Shelf  = kolom yang isinya mirip kode rak (huruf+angka+strip, contoh AG04-01)
     * - Kolom Price  = kolom berisi angka dengan titik desimal (harga)
     * - Kolom Balance= kolom berisi angka bulat kecil (stok)
     * - Kolom Desc   = kolom TERAKHIR yang berisi teks (paling sering di akhir baris)
     */
    fun autoDetect(parts: List<String>): Mapping {
        var iSku     = 1
        var iShelf   = 0
        var iPrice   = 0
        var iBalance = 0
        var iDesc    = 0

        // Cari kolom Price dulu (mengandung titik desimal & nilai > 100)
        for (i in parts.indices) {
            val v = parts[i].trim()
            val d = v.toDoubleOrNull()
            if (d != null && v.contains(".") && d > 100) {
                iPrice = i + 1; break
            }
        }

        // Cari kolom Balance: angka bulat kecil setelah harga
        if (iPrice > 0) {
            for (i in iPrice until parts.size) {  // cari setelah kolom harga
                val v = parts[i].trim()
                val n = v.toLongOrNull()
                if (n != null && n < 100000 && v.isNotBlank()) {
                    iBalance = i + 1; break
                }
            }
        }

        // Cari kolom Shelf: mengandung huruf + angka + strip (contoh: AG04-01)
        for (i in parts.indices) {
            val v = parts[i].trim()
            if (v.matches(Regex("[A-Za-z]{1,4}\\d{2}-\\d{2}.*")) && i + 1 != iPrice) {
                iShelf = i + 1; break
            }
        }

        // Cari kolom Desc: kolom NON-KOSONG terakhir yang isinya text murni (bukan angka/tanggal)
        for (i in parts.indices.reversed()) {
            val v = parts[i].trim()
            if (v.isBlank()) continue
            if (v.toDoubleOrNull() != null) continue          // skip angka
            if (v.matches(Regex("\\d{2}/\\d{2}/\\d{4}"))) continue  // skip tanggal
            if (i + 1 == iShelf || i + 1 == iPrice) continue  // skip shelf/price
            // Kolom terakhir berisi text = Desc
            iDesc = i + 1
            break
        }

        return Mapping(
            colSku     = iSku,
            colShelf   = if (iShelf   > 0) iShelf   else 2,
            colPrice   = if (iPrice   > 0) iPrice   else 3,
            colBalance = if (iBalance > 0) iBalance else 4,
            colDesc    = if (iDesc    > 0) iDesc    else parts.size,  // default kolom terakhir
            totalCols  = parts.size
        )
    }
}
