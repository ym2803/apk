package com.tms.qubeapps.qubedatacollector

import android.app.AlertDialog
import android.app.ProgressDialog
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import com.tms.qubeapps.qubedatacollector.Prefs.exioGid
import com.tms.qubeapps.qubedatacollector.Prefs.exioSpreadsheetId
import com.tms.qubeapps.qubedatacollector.Prefs.ksApiToken
import com.tms.qubeapps.qubedatacollector.Prefs.ksWebAppUrl
import com.tms.qubeapps.qubedatacollector.Prefs.outFileName
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

/**
 * ★ FIX (baru — Denah Custom per No Ctn, Keep Stock > View & Edit Data):
 * layar freeform buat gambar & lihat peta lokasi box (No Ctn), mirip contoh
 * denah Excel yang dikasih user (kotak2 bebas posisi + banner label seperti
 * RECEIVING/CASHIER). Lihat DenahCanvasView untuk logika kanvasnya, dan
 * DenahLayoutPrefs untuk model data + cache lokal.
 *
 * Layout disimpan PER TOKO lewat KeepStockGasClient.saveLayout/getLayout
 * (Web App Google Apps Script yang sama dipakai fitur Keep Stock lain) —
 * jadi SEMUA user yang login ke toko yang sama lihat & edit denah yang SAMA.
 * Lihat GAS_KS_addon_LAYOUT.gs.txt di root project untuk kode Apps Script
 * yang perlu ditambahkan supaya action "saveLayout"/"getLayout" jalan.
 */
class DenahLayoutActivity : BaseActivity() {

    private lateinit var store: String
    private var pic: String = ""

    private lateinit var canvas: DenahCanvasView
    private lateinit var btnMenu: View
    private lateinit var btnSelectBlock: Button
    private lateinit var tvHint: View
    private lateinit var rowEditActionsAll: View
    private lateinit var rowSummary: View
    private lateinit var btnSave: View
    private lateinit var tvEmpty: TextView
    private lateinit var tvFilled: TextView
    private lateinit var tvTotal: TextView

    // ── ★ FIX (baru — Fase 7 "Offline / PENDING SYNC") ──
    private lateinit var tvPendingSync: TextView

    // ── ★ FIX (baru — Fase 1 "UNPLACED BOX", Android sebagai editor koordinat) ──
    private lateinit var rowUnplacedBox: View
    private lateinit var tvUnplacedHeader: TextView
    private lateinit var llUnplacedChips: LinearLayout
    /** No Ctn dari Keep Stock yang BELUM punya Tile (posisi) di denah ini. */
    private var unplacedCodes: MutableList<String> = mutableListOf()

    private var isEditMode = false
    private var showGrid = true

    // ── ★ FIX (baru — Fase 3 "Drag Bebas / Snap-to-Grid opsional") ──
    private var snapEnabled = true
    private var snapGridSize = 1
    private val snapGridSizeOptions = intArrayOf(1, 5, 10, 25, 50)

    /** ★ FIX (baru — Batas Total Box): kalau diisi (> 0), Auto-Generate & +BOX
     * manual akan ditolak/dipotong supaya total box CTN di denah tidak
     * melebihi batas ini — supaya tidak generate kelewat banyak tanpa sadar. */
    private var maxTotalBoxLimit: Int? = null

    private var tiles: MutableList<DenahLayoutPrefs.Tile> = mutableListOf()
    private var aliases: MutableList<DenahLayoutPrefs.Alias> = mutableListOf()
    private var rawOccupancy: Map<String, Boolean> = emptyMap()
    private var isDirty = false

    // ── ★ FIX (baru — Undo/Redo): riwayat state (tiles+aliases) sebelum tiap
    // perubahan, supaya bisa dibatalkan/diulang. Disimpan sebagai snapshot
    // JSON (ringan & aman dari referensi objek yang sama). Dibatasi 30 langkah
    // supaya tidak membengkak di layout yang besar.
    private val undoStack = ArrayDeque<String>()
    private val redoStack = ArrayDeque<String>()
    private val MAX_HISTORY = 30

    private fun snapshotJson(): String =
        DenahLayoutPrefs.toJson(DenahLayoutPrefs.Layout(store = store, tiles = tiles, aliases = aliases)).toString()

    /** Panggil SEBELUM melakukan perubahan tiles/aliases apapun yang mau bisa di-undo. */
    private fun pushUndoSnapshot() {
        undoStack.addLast(snapshotJson())
        while (undoStack.size > MAX_HISTORY) undoStack.removeFirst()
        redoStack.clear()
    }

    private fun restoreSnapshot(json: String) {
        val layout = DenahLayoutPrefs.fromJson(JSONObject(json))
        tiles = layout.tiles.toMutableList()
        aliases = layout.aliases.toMutableList()
        canvas.tiles = tiles
        isDirty = true
        updateSummary()
    }

    private fun doUndo() {
        if (undoStack.isEmpty()) { Toast.makeText(this, "Tidak ada yang bisa di-undo", Toast.LENGTH_SHORT).show(); return }
        redoStack.addLast(snapshotJson())
        restoreSnapshot(undoStack.removeLast())
    }

    private fun doRedo() {
        if (redoStack.isEmpty()) { Toast.makeText(this, "Tidak ada yang bisa di-redo", Toast.LENGTH_SHORT).show(); return }
        undoStack.addLast(snapshotJson())
        restoreSnapshot(redoStack.removeLast())
    }

    private fun confirmResetAllBoxes() {
        AlertDialog.Builder(this)
            .setTitle("Reset / Hapus Semua Box")
            .setMessage("Semua box & label di denah ini akan dihapus (posisi drag manual TIDAK bisa di-undo lewat data KS, tapi masih bisa Undo di sini kalau belum keluar layar). Lanjutkan?")
            .setPositiveButton("Hapus Semua") { _, _ ->
                pushUndoSnapshot()
                tiles.clear()
                canvas.tiles = tiles
                isDirty = true
                updateSummary()
                Toast.makeText(this, "Semua box & label dihapus", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Batal", null)
            .showSafely()
    }

    /** ★ FIX (baru — Batas Total Box): dialog set/ubah batas total box CTN di denah ini. */
    private fun showBoxLimitDialog() {
        val et = EditText(this).apply {
            hint = "Kosongkan = tidak ada batas"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setPadding(32, 24, 32, 24)
            maxTotalBoxLimit?.let { setText(it.toString()) }
        }
        val currentTotal = tiles.count { it.type == "CTN" }
        AlertDialog.Builder(this)
            .setTitle("Batas Total Box")
            .setMessage("Tentukan batas MAKSIMAL jumlah box (No Ctn) di denah ini, supaya Auto-Generate / tambah box tidak menghasilkan box kelewat banyak tanpa sadar. Total box saat ini: $currentTotal.")
            .setView(et)
            .setPositiveButton("Simpan") { _, _ ->
                val v = et.text.toString().trim().toIntOrNull()
                maxTotalBoxLimit = if (v != null && v > 0) v else null
                Toast.makeText(
                    this,
                    if (maxTotalBoxLimit != null) "Batas total box diset: $maxTotalBoxLimit" else "Batas total box dihapus (tidak dibatasi)",
                    Toast.LENGTH_SHORT
                ).show()
            }
            .setNegativeButton("Batal", null)
            .showSafely()
    }

    /**
     * Cek apakah menambah [addCount] box baru masih dalam batas. Kalau lewat
     * batas, tampilkan peringatan & return false (batalkan operasi) — dipakai
     * di semua jalur pembuatan box baru (Auto-Generate & +BOX manual).
     */
    private fun checkBoxLimitOrWarn(addCount: Int): Boolean {
        val limit = maxTotalBoxLimit ?: return true
        val currentTotal = tiles.count { it.type == "CTN" }
        if (currentTotal + addCount > limit) {
            Toast.makeText(
                this,
                "Melebihi Batas Total Box ($limit). Saat ini $currentTotal box, mau tambah $addCount. Naikkan batas dulu lewat tombol BATAS BOX kalau memang perlu.",
                Toast.LENGTH_LONG
            ).show()
            return false
        }
        return true
    }

    /** noCtn (base, uppercase-trim) -> semua kode yang menunjuk ke situ (dirinya sendiri + semua alias). */
    private fun aliasesFor(baseNoCtn: String?): List<String> {
        val key = baseNoCtn?.trim()?.uppercase() ?: return emptyList()
        val result = mutableListOf(key)
        aliases.forEach { a -> if (a.baseNoCtn.trim().uppercase() == key) result.add(a.code.trim().uppercase()) }
        return result
    }

    /**
     * ★ FIX: gabungkan occupancy mentah (dari sheet, per kode literal) dengan
     * alias — 1 kotak CTN dianggap ISI kalau kode-nya SENDIRI atau SALAH SATU
     * alias-nya (mis. A001A, A001B, ...) tercatat ada isi di sheet. Supaya
     * kotak fisik tetap kelihatan "ISI" walau yang tercatat cuma kode alias-nya.
     */
    private fun computeResolvedOccupancy(): Map<String, Boolean> {
        val result = mutableMapOf<String, Boolean>()
        tiles.filter { it.type == "CTN" && !it.noCtn.isNullOrBlank() }.forEach { t ->
            val key = t.noCtn!!.trim().uppercase()
            val filled = aliasesFor(key).any { rawOccupancy[it] == true }
            result[key] = filled
        }
        return result
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_denah_layout)

        store = intent.getStringExtra(KeepStockLoginActivity.EXTRA_STORE) ?: ""
        pic = intent.getStringExtra(KeepStockLoginActivity.EXTRA_PIC) ?: ""
        findViewById<TextView>(R.id.tvDenahTitle).text = "CUSTOM LAYOUT — $store"

        canvas = findViewById(R.id.denahCanvas)
        btnMenu = findViewById(R.id.btnDenahMenu)
        btnSelectBlock = findViewById(R.id.btnDenahSelectBlock)
        tvHint = findViewById(R.id.tvDenahHint)
        rowEditActionsAll = findViewById(R.id.rowDenahEditActionsAll)
        rowSummary = findViewById(R.id.rowDenahSummary)
        btnSave = findViewById(R.id.btnDenahSave)
        tvEmpty = findViewById(R.id.tvDenahEmpty)
        tvFilled = findViewById(R.id.tvDenahFilled)
        tvTotal = findViewById(R.id.tvDenahTotal)
        tvPendingSync = findViewById(R.id.tvPendingSync)
        rowUnplacedBox = findViewById(R.id.rowUnplacedBox)
        tvUnplacedHeader = findViewById(R.id.tvUnplacedHeader)
        llUnplacedChips = findViewById(R.id.llUnplacedChips)

        canvas.setBaseGridUnitDp(56)
        canvas.onTileTap = { tile -> if (canvas.editable) showEditTileDialog(tile) else showTileDetailDialog(tile) }
        canvas.onTileMoved = { tile, newX, newY, newOffsetX, newOffsetY ->
            val idx = tiles.indexOfFirst { it.id == tile.id }
            if (idx >= 0) {
                pushUndoSnapshot()
                // ★ FIX (baru — Fase 3): newOffsetX/newOffsetY ikut disimpan — 0 kalau Snap ON
                // (box nempel grid seperti biasa), atau nilai bebas kalau Snap OFF (drag bebas).
                tiles[idx] = tiles[idx].copy(x = newX, y = newY, offsetX = newOffsetX, offsetY = newOffsetY)
                // ★ FIX (baru): geser 1 box manual TIDAK LAGI memicu auto-isi box kosong di
                // sekitarnya (dulu geser A1->B2 otomatis bikin box kosong nongol di A2 & B1).
                // Sekarang cuma urus kalau box didrop pas nabrak box lain di titik yang sama
                // (tabrakan posisi tetap dicek berdasarkan x/y sel acuan, bukan offset halus).
                if (tile.type == "CTN") resolveOverlapsOnly()
                canvas.tiles = tiles
                isDirty = true
                updateSummary()
            }
        }
        canvas.showGridLines = showGrid
        canvas.snapEnabled = snapEnabled
        canvas.snapGridSize = snapGridSize

        // ★ FIX (baru — Blok Pilih Banyak Box): 1 kali pushUndoSnapshot() untuk SELURUH
        // box yang dipindah bersama (bukan per-box), supaya 1x Undo = 1x drag-blok.
        canvas.onTilesGroupMoved = { results ->
            if (results.isNotEmpty()) {
                pushUndoSnapshot()
                results.forEach { r ->
                    val idx = tiles.indexOfFirst { it.id == r.tileId }
                    if (idx >= 0) {
                        tiles[idx] = tiles[idx].copy(x = r.newX, y = r.newY, offsetX = r.newOffsetX, offsetY = r.newOffsetY)
                    }
                }
                resolveOverlapsOnly()
                canvas.tiles = tiles
                isDirty = true
                updateSummary()
                Toast.makeText(this, "${results.size} box dipindahkan bersama", Toast.LENGTH_SHORT).show()
            }
        }
        canvas.onSelectionChanged = { count -> updateSelectBlockButton(count) }

        findViewById<View>(R.id.btnBackDenah).setOnClickListener { confirmBackIfDirty() }
        findViewById<View>(R.id.btnDenahResetZoom).setOnClickListener { canvas.resetView() }
        findViewById<View>(R.id.btnDenahRefresh).setOnClickListener { confirmReload() }
        findViewById<View>(R.id.btnDenahAddBox).setOnClickListener { showAddBoxDialog() }
        findViewById<View>(R.id.btnDenahAddLabel).setOnClickListener { showAddLabelDialog() }
        findViewById<View>(R.id.btnDenahAutoGen).setOnClickListener { showAutoGenerateChooserDialog() }
        findViewById<View>(R.id.btnDenahExport).setOnClickListener { showExportFormatDialog() }
        findViewById<View>(R.id.btnDenahUndo).setOnClickListener { doUndo() }
        findViewById<View>(R.id.btnDenahRedo).setOnClickListener { doRedo() }
        findViewById<View>(R.id.btnDenahBoxLimit).setOnClickListener { showBoxLimitDialog() }
        findViewById<View>(R.id.btnDenahReset).setOnClickListener { confirmResetAllBoxes() }
        btnSelectBlock.setOnClickListener { toggleSelectBlockMode() }
        findViewById<View>(R.id.btnDenahAddRuler).setOnClickListener { showAddRulerDialog() }
        findViewById<View>(R.id.btnDenahAddObject).setOnClickListener { showAddObjectChooserDialog() }
        findViewById<View>(R.id.btnDenahUpdateLayout).setOnClickListener { updateLayoutFromKsIncremental() }
        findViewById<View>(R.id.btnDenahOrphanBox).setOnClickListener { showOrphanBoxDialog() }
        btnSave.setOnClickListener { saveLayout() }

        btnMenu.setOnClickListener { showHeaderDropdownMenu() }
        applyEditModeUi()

        // Tampilkan cache lokal dulu (instan), baru sync ke server di background.
        DenahLayoutPrefs.loadCached(this, store)?.let {
            tiles = it.tiles.toMutableList()
            aliases = it.aliases.toMutableList()
            canvas.setBaseGridUnitDp(it.gridUnitDp)
            canvas.tiles = tiles
        }

        loadLayoutFromServer()
        loadOccupancy()
        // ★ FIX (baru — Fase 1): populate panel UNPLACED BOX begitu layar dibuka.
        refreshUnplacedFromKeepStock()
        // ★ FIX (baru — Fase 7): kalau sesi sebelumnya sempat gagal sync (offline),
        // badge "PENDING SYNC" langsung kelihatan begitu layar dibuka lagi.
        updatePendingSyncBadge()
    }

    override fun onBackPressed() = confirmBackIfDirty()

    /**
     * ★ FIX (baru — Fase 7 "Offline / PENDING SYNC", spesifikasi poin 19):
     * tampilkan/sembunyikan strip kuning "PENDING SYNC" sesuai flag persisten
     * di DenahLayoutPrefs. Dipanggil saat layar dibuka & tiap kali status
     * sync berubah (berhasil kirim / gagal kirim) di saveLayout().
     */
    private fun updatePendingSyncBadge() {
        tvPendingSync.visibility = if (DenahLayoutPrefs.isPendingSync(this, store)) View.VISIBLE else View.GONE
    }

    /** Sinkronkan tampilan (canvas.editable, tombol2, dsb.) dengan [isEditMode] saat ini. */
    private fun applyEditModeUi() {
        canvas.editable = isEditMode
        tvHint.visibility = if (isEditMode) View.VISIBLE else View.GONE
        rowEditActionsAll.visibility = if (isEditMode) View.VISIBLE else View.GONE
        btnSave.visibility = if (isEditMode) View.VISIBLE else View.GONE
        rowSummary.visibility = if (isEditMode) View.GONE else View.VISIBLE
        // ★ FIX (baru — Blok Pilih Banyak Box): keluar dari mode Edit otomatis matikan mode
        // seleksi juga, supaya tidak ada state "nyangkut" waktu balik ke mode View.
        if (!isEditMode && canvas.selectionMode) {
            canvas.selectionMode = false
            updateSelectBlockButton(0)
        }
        // ★ FIX (baru): panel UNPLACED BOX cuma relevan waktu mode EDIT (cuma di situ
        // box bisa ditaruh ke kanvas) — refreshUnplacedBoxUi() yang atur GONE/VISIBLE
        // akhirnya (tetap GONE kalau memang tidak ada yang unplaced).
        refreshUnplacedBoxUi()
    }

    /**
     * ★ FIX (baru — Blok Pilih Banyak Box): nyalakan/matikan mode seleksi. Aktif ->
     * drag di area kosong/box belum-terpilih menggambar kotak seleksi (rubber-band),
     * tap box = pilih/batal 1-1, drag box yang SUDAH terpilih = pindahkan SEMUA box
     * terpilih sekaligus (lihat DenahCanvasView.handleSelectionTouch & onTilesGroupMoved).
     */
    private fun toggleSelectBlockMode() {
        canvas.selectionMode = !canvas.selectionMode
        updateSelectBlockButton(0)
        if (canvas.selectionMode) {
            Toast.makeText(
                this,
                "Mode Pilih Blok aktif: drag di area kosong untuk pilih beberapa box, lalu drag salah satu box terpilih untuk pindahkan bersama. Tap box untuk pilih/batal satu-satu.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    /** Update teks & warna tombol "Pilih Blok" sesuai status aktif/tidak + jumlah box terpilih. */
    private fun updateSelectBlockButton(selectedCount: Int) {
        if (canvas.selectionMode) {
            btnSelectBlock.text = if (selectedCount > 0) "☑ $selectedCount Dipilih" else "☑ Pilih Blok"
            btnSelectBlock.backgroundTintList = android.content.res.ColorStateList.valueOf(android.graphics.Color.parseColor("#1A237E"))
        } else {
            btnSelectBlock.text = "☐ Pilih Blok"
            btnSelectBlock.backgroundTintList = android.content.res.ColorStateList.valueOf(android.graphics.Color.parseColor("#5C6BC0"))
        }
    }

    /**
     * ★ FIX (baru — Fase 1, sesuai spesifikasi "Android sebagai editor
     * koordinat X/Y"): tarik daftar NO CTN dari Keep Stock, lalu bandingkan
     * dengan Tile yang SUDAH punya posisi di denah ini. Yang belum ada
     * Tile-nya ditampilkan di panel UNPLACED BOX — TIDAK diberi posisi
     * otomatis/asumsi apapun (sesuai poin 10 & 13 spesifikasi: box baru/
     * belum ditempatkan HARUS masuk UNPLACED BOX, bukan digeser otomatis
     * atau ditaruh sembarang oleh Auto-Generate).
     */
    private fun refreshUnplacedFromKeepStock() {
        val ssid = exioSpreadsheetId(store)
        val gid = exioGid(store)
        if (ssid.isBlank() || gid.isBlank()) return
        lifecycleScope.launch {
            try {
                val allCodes = withContext(Dispatchers.IO) {
                    KeepStockSheetReader.fetchRows(ssid, gid).map { it.noCtn.trim().uppercase() }.filter { it.isNotBlank() }.toSet()
                }
                if (allCodes.isEmpty()) return@launch
                val (boxCodes, _) = splitCodesIntoBoxesAndAliases(allCodes)
                val placedCodes = tiles.filter { it.type == "CTN" }.mapNotNull { it.noCtn?.trim()?.uppercase() }.toSet()
                val unplaced = boxCodes.filter { it !in placedCodes }.toMutableList()
                naturalSort(unplaced)
                unplacedCodes = unplaced
                refreshUnplacedBoxUi()
            } catch (e: Exception) {
                // Diam-diam gagal (mis. offline) — panel unplaced tetap pakai data terakhir yang ada.
            }
        }
    }

    /** Render ulang panel UNPLACED BOX (chip per No Ctn) berdasarkan [unplacedCodes] saat ini. */
    private fun refreshUnplacedBoxUi() {
        if (!isEditMode || unplacedCodes.isEmpty()) {
            rowUnplacedBox.visibility = View.GONE
            return
        }
        rowUnplacedBox.visibility = View.VISIBLE
        tvUnplacedHeader.text = "UNPLACED BOX (${unplacedCodes.size}) — tap untuk taruh ke kanvas"
        llUnplacedChips.removeAllViews()
        val density = resources.displayMetrics.density
        unplacedCodes.forEach { code ->
            val chip = TextView(this).apply {
                text = code
                textSize = 12f
                setTextColor(android.graphics.Color.WHITE)
                setBackgroundColor(android.graphics.Color.parseColor("#FB8C00"))
                setPadding((10 * density).toInt(), (6 * density).toInt(), (10 * density).toInt(), (6 * density).toInt())
                val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                lp.marginEnd = (6 * density).toInt()
                layoutParams = lp
                setOnClickListener { placeUnplacedBox(code) }
            }
            llUnplacedChips.addView(chip)
        }
    }

    /**
     * Taruh 1 kode dari UNPLACED BOX ke kanvas (di titik kosong terdekat yang
     * ditemukan lewat findFreeCell() — mekanisme yang SAMA dipakai +BOX
     * manual, jadi tidak ada logika baru yang beresiko). Box langsung bisa
     * digeser (drag) begitu muncul di kanvas untuk disesuaikan ke posisi
     * fisik yang benar — pemindahan halus/bebas piksel direncanakan di fase
     * berikutnya, untuk sekarang user tinggal drag pakai mekanisme drag yang
     * sudah ada.
     */
    private fun placeUnplacedBox(code: String) {
        pushUndoSnapshot()
        val pos = findFreeCell()
        tiles.add(
            DenahLayoutPrefs.Tile(
                id = "t${System.currentTimeMillis()}_unplaced",
                type = "CTN", noCtn = code, x = pos.first, y = pos.second, w = 1, h = 1
            )
        )
        resolveOverlapsOnly()
        canvas.tiles = tiles
        isDirty = true
        updateSummary()
        unplacedCodes.remove(code)
        refreshUnplacedBoxUi()
        Toast.makeText(this, "$code ditaruh di kanvas — geser (drag) ke posisi fisik yang benar", Toast.LENGTH_SHORT).show()
    }

    /**
     * ★ FIX (baru — Grid ON/OFF & Mode Edit dipindah ke dropdown "⋮"; Fase 3
     * tambah Snap ON/OFF + Grid Size di menu yang sama): dulu 2 ToggleButton
     * terpisah di header, sekarang digabung jadi 1 menu dropdown yang muncul
     * DI BAWAH ikon "⋮" (posisi default PopupMenu Android — anchor-nya
     * persis ikon ini di header, jadi otomatis "di bawah judul"). Item
     * dicentang (✓) supaya kelihatan status ON/OFF-nya. Tap item lain kali
     * buka lagi menu ini kalau mau ubah yang satunya.
     */
    private fun showHeaderDropdownMenu() {
        val popup = PopupMenu(this, btnMenu)
        val itemGrid = popup.menu.add(0, 1, 0, if (showGrid) "✓ Tampilkan Grid" else "Tampilkan Grid")
        val itemEdit = popup.menu.add(0, 2, 1, if (isEditMode) "✓ Mode Edit (EDIT ON)" else "Mode Edit (VIEW ONLY)")
        // ★ FIX (baru — Fase 3): Snap ON/OFF + pilihan ukuran grid (1/5/10/25/50 sesuai spesifikasi).
        val itemSnap = popup.menu.add(0, 3, 2, if (snapEnabled) "✓ Snap to Grid ON" else "Snap to Grid OFF (drag bebas)")
        val itemGridSize = popup.menu.add(0, 4, 3, "Grid Size: $snapGridSize")
        // ★ FIX (baru — Fase 8 "Search", spesifikasi poin 18): cari No Ctn/SKU/Deskripsi,
        // ketemu langsung zoom + highlight ke box-nya di kanvas.
        popup.menu.add(0, 5, 4, "🔍 Cari Box (No Ctn/SKU/Deskripsi)")
        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> {
                    showGrid = !showGrid
                    canvas.showGridLines = showGrid
                    itemGrid.title = if (showGrid) "✓ Tampilkan Grid" else "Tampilkan Grid"
                }
                2 -> {
                    isEditMode = !isEditMode
                    applyEditModeUi()
                    itemEdit.title = if (isEditMode) "✓ Mode Edit (EDIT ON)" else "Mode Edit (VIEW ONLY)"
                }
                3 -> {
                    snapEnabled = !snapEnabled
                    canvas.snapEnabled = snapEnabled
                    itemSnap.title = if (snapEnabled) "✓ Snap to Grid ON" else "Snap to Grid OFF (drag bebas)"
                    Toast.makeText(
                        this,
                        if (snapEnabled) "Snap to Grid ON — box akan nempel grid saat digeser" else "Snap to Grid OFF — box bisa digeser bebas, tidak nempel grid",
                        Toast.LENGTH_SHORT
                    ).show()
                }
                4 -> showSnapGridSizeDialog(itemGridSize)
                5 -> showSearchDialog()
            }
            false
        }
        popup.show()
    }

    /** Dialog pilih ukuran Snap Grid (1/5/10/25/50 sel) — dipakai waktu Snap ON. */
    private fun showSnapGridSizeDialog(menuItem: android.view.MenuItem) {
        val labels = snapGridSizeOptions.map { "$it sel" }.toTypedArray()
        val currentIdx = snapGridSizeOptions.indexOf(snapGridSize).coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle("Grid Size (Snap)")
            .setSingleChoiceItems(labels, currentIdx) { dialog, which ->
                snapGridSize = snapGridSizeOptions[which]
                canvas.snapGridSize = snapGridSize
                menuItem.title = "Grid Size: $snapGridSize"
                dialog.dismiss()
            }
            .setNegativeButton("Batal", null)
            .showSafely()
    }

    /**
     * ★ FIX (baru — Fase 8 "Search", spesifikasi poin 18): cari box
     * berdasarkan No Ctn, SKU, atau Deskripsi. Ketemu -> kanvas otomatis
     * zoom + pan ke box itu dan menyalakan highlight (hijau, lewat
     * canvas.highlightNoCtn yang sebenarnya SUDAH ADA infrastrukturnya dari
     * awal tapi belum ada UI pemicunya sampai sekarang).
     */
    private fun showSearchDialog() {
        val et = EditText(this).apply { hint = "No Ctn / SKU / Deskripsi" }
        AlertDialog.Builder(this)
            .setTitle("Cari Box")
            .setView(et)
            .setPositiveButton("Cari") { _, _ ->
                val q = et.text.toString().trim()
                if (q.isNotBlank()) performSearch(q)
            }
            .setNegativeButton("Batal", null)
            .showSafely()
    }

    private fun focusAndHighlight(tile: DenahLayoutPrefs.Tile) {
        canvas.focusOnTile(tile)
        Toast.makeText(this, "Ditemukan: ${tile.noCtn}", Toast.LENGTH_SHORT).show()
    }

    private fun performSearch(query: String) {
        val q = query.trim().uppercase()
        // (1) Coba cocok langsung ke No Ctn tile yang SUDAH ADA di kanvas dulu (cepat, tanpa network).
        val directTile = tiles.firstOrNull { it.type == "CTN" && it.noCtn?.trim()?.uppercase()?.contains(q) == true }
        if (directTile != null) {
            focusAndHighlight(directTile)
            return
        }
        // (2) Belum ketemu lewat No Ctn -> cari lewat SKU / Deskripsi (butuh data KS + katalog lokal).
        val ssid = exioSpreadsheetId(store)
        val gid = exioGid(store)
        if (ssid.isBlank() || gid.isBlank()) {
            Toast.makeText(this, "Tidak ditemukan: $query", Toast.LENGTH_LONG).show()
            return
        }
        val pd = ProgressDialog(this).apply { setMessage("Mencari..."); show() }
        lifecycleScope.launch {
            try {
                val rows = withContext(Dispatchers.IO) { KeepStockSheetReader.fetchRows(ssid, gid) }
                val db = AppDatabase(this@DenahLayoutActivity)
                val match = withContext(Dispatchers.IO) {
                    rows.firstOrNull { r ->
                        r.sku.trim().uppercase().contains(q) ||
                            (db.findCatalog(r.sku)?.get("desc")?.trim()?.uppercase()?.contains(q) == true)
                    }
                }
                pd.dismissSafely()
                if (match == null) {
                    Toast.makeText(this@DenahLayoutActivity, "Tidak ditemukan: $query", Toast.LENGTH_LONG).show()
                    return@launch
                }
                val noCtnCode = match.noCtn.trim().uppercase()
                val tile = tiles.firstOrNull { it.type == "CTN" && it.noCtn?.trim()?.uppercase() == noCtnCode }
                if (tile != null) {
                    focusAndHighlight(tile)
                } else {
                    Toast.makeText(
                        this@DenahLayoutActivity,
                        "Ketemu SKU/Deskripsi (No Ctn: ${match.noCtn}), tapi box-nya belum ditaruh di denah ini — cek panel UNPLACED BOX.",
                        Toast.LENGTH_LONG
                    ).show()
                }
            } catch (e: Exception) {
                pd.dismissSafely()
                Toast.makeText(this@DenahLayoutActivity, "Gagal mencari: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun confirmBackIfDirty() {
        if (isDirty) {
            AlertDialog.Builder(this)
                .setTitle("Unsaved changes")
                .setMessage("Layout belum disimpan. Keluar tanpa simpan?")
                .setPositiveButton("Keluar") { _, _ -> finish() }
                .setNegativeButton("Batal", null)
                .showSafely()
        } else finish()
    }

    private fun confirmReload() {
        if (isDirty) {
            AlertDialog.Builder(this)
                .setTitle("Unsaved changes")
                .setMessage("Reload akan membuang perubahan yang belum disimpan. Lanjutkan?")
                .setPositiveButton("Reload") { _, _ -> loadLayoutFromServer(); loadOccupancy() }
                .setNegativeButton("Batal", null)
                .showSafely()
        } else { loadLayoutFromServer(); loadOccupancy() }
    }

    // ── Load layout (server, dengan fallback cache) ─────────────────────────
    private fun loadLayoutFromServer() {
        val url = ksWebAppUrl; val token = ksApiToken
        if (url.isBlank() || token.isBlank()) return // offline / belum login — cukup pakai cache lokal
        lifecycleScope.launch {
            try {
                val result = withContext(Dispatchers.IO) { KeepStockGasClient.getLayout(url, token, store) }
                if (result.optBoolean("ok", false)) {
                    val layoutObj = result.optJSONObject("layout")
                    if (layoutObj != null) {
                        val layout = DenahLayoutPrefs.fromJson(layoutObj)
                        tiles = layout.tiles.toMutableList()
                        aliases = layout.aliases.toMutableList()
                        canvas.setBaseGridUnitDp(if (layout.gridUnitDp > 0) layout.gridUnitDp else 56)
                        canvas.tiles = tiles
                        DenahLayoutPrefs.saveCached(this@DenahLayoutActivity, layout.copy(store = store))
                        isDirty = false
                        undoStack.clear(); redoStack.clear()
                        updateSummary()
                        // ★ FIX (baru — Fase 1): sinkronkan ulang panel UNPLACED BOX SETELAH
                        // tiles dari server selesai dimuat (lebih akurat dari yang dipanggil
                        // di onCreate, yang jalan sebelum network selesai).
                        refreshUnplacedFromKeepStock()
                        // ★ FIX (baru — Fase 2, best-effort): kalau Web App SUDAH punya addon V2
                        // (BOX_POSITION), timpa X/Y/W/H/Rotation/Locked/Visible tile yang cocok
                        // No Ctn-nya dengan data ternormalisasi itu (lebih baru/akurat). Kalau
                        // addon V2 belum dipasang, fungsi ini gagal diam-diam — TIDAK mempengaruhi
                        // apapun yang sudah dimuat dari blob di atas.
                        tryOverlayNormalizedBoxPositions()
                    }
                }
            } catch (e: Exception) {
                // Diam-diam pakai cache lokal kalau server tidak bisa diakses (mis. belum ada
                // handler saveLayout/getLayout di Apps Script — lihat GAS_KS_addon_LAYOUT.gs.txt).
            }
        }
    }

    /**
     * ★ FIX (baru — Fase 2, best-effort & aman): kalau Web App SUDAH
     * di-update dengan addon V2 (GAS_KS_addon_LAYOUT_V2.gs.txt), pakai
     * POSISI dari sheet ternormalisasi BOX_POSITION sebagai X/Y/W/H/
     * Rotation/Locked/Visible PALING BARU untuk tile yang cocok No
     * Ctn-nya (menimpa posisi dari blob lama kalau beda). Tile yang TIDAK
     * ada di hasil (mis. LABEL/RULER/slot kosong) TIDAK disentuh sama
     * sekali. Kalau addon belum dipasang / request gagal / hasil kosong,
     * fungsi ini DIAM SAJA — layar tetap pakai apa yang sudah dimuat dari
     * blob seperti biasa, TIDAK PERNAH bikin error/crash.
     */
    private fun tryOverlayNormalizedBoxPositions() {
        val url = ksWebAppUrl; val token = ksApiToken
        if (url.isBlank() || token.isBlank()) return
        lifecycleScope.launch {
            try {
                val result = withContext(Dispatchers.IO) { KeepStockGasClient.getBoxPositions(url, token, store) }
                if (!result.optBoolean("ok", false)) return@launch
                val arr = result.optJSONArray("positions") ?: return@launch
                if (arr.length() == 0) return@launch
                var changed = false
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val noCtn = o.optString("no_ctn", "").trim()
                    if (noCtn.isBlank()) continue
                    val idx = tiles.indexOfFirst { it.type == "CTN" && it.noCtn?.trim()?.equals(noCtn, ignoreCase = true) == true }
                    if (idx >= 0) {
                        val old = tiles[idx]
                        // ★ FIX (baru — Fase 3): X/Y dari sheet ternormalisasi itu posisi ABSOLUT
                        // (bisa pecahan hasil drag bebas) — pecah jadi (x/y sel acuan, bulat bawah)
                        // + (offsetX/offsetY sisa pecahannya), supaya presisi drag bebas tidak hilang.
                        val absX = o.optDouble("x", (old.x + old.offsetX).toDouble()).toFloat()
                        val absY = o.optDouble("y", (old.y + old.offsetY).toDouble()).toFloat()
                        val cellX = kotlin.math.floor(absX).toInt()
                        val cellY = kotlin.math.floor(absY).toInt()
                        tiles[idx] = old.copy(
                            x = cellX,
                            y = cellY,
                            offsetX = absX - cellX,
                            offsetY = absY - cellY,
                            w = o.optInt("width", old.w).takeIf { it > 0 } ?: old.w,
                            h = o.optInt("height", old.h).takeIf { it > 0 } ?: old.h,
                            rotation = o.optDouble("rotation", old.rotation.toDouble()).toFloat(),
                            locked = o.optBoolean("locked", old.locked),
                            visible = o.optBoolean("visible", old.visible)
                        )
                        changed = true
                    }
                }
                if (changed) {
                    canvas.tiles = tiles
                    updateSummary()
                }
            } catch (e: Exception) {
                // Diam-diam — addon V2 kemungkinan belum dipasang di Web App, itu tidak masalah.
            }
        }
    }

    /**
     * ★ FIX (baru — Fase 2, best-effort & aman): SELAIN blob (saveLayout,
     * tetap jalan seperti biasa — lihat saveLayout()), kirim juga snapshot
     * posisi box (No Ctn) ke sheet ternormalisasi BOX_POSITION lewat
     * saveBoxPositions (upsert per STORE_CODE+NO_CTN), supaya Google Sheet
     * punya representasi per-baris sesuai spesifikasi baru (bukan cuma 1
     * JSON blob). Best-effort & FIRE-AND-FORGET: kalau addon V2 belum
     * dipasang di Web App / gagal, GAGAL DIAM-DIAM saja — tidak
     * mempengaruhi hasil SAVE utama (blob) yang sudah berhasil.
     */
    private fun trySaveNormalizedBoxPositions() {
        val url = ksWebAppUrl; val token = ksApiToken
        if (url.isBlank() || token.isBlank()) return
        val positions = tiles.filter { it.type == "CTN" && !it.noCtn.isNullOrBlank() }.map { t ->
            JSONObject().apply {
                put("object_id", t.id)
                put("no_ctn", t.noCtn)
                // ★ FIX (baru — Fase 3): kirim posisi ABSOLUT (x + offsetX, y + offsetY) supaya
                // hasil drag bebas (Snap OFF) ikut tersimpan akurat di sheet ternormalisasi —
                // skema BOX_POSITION cuma punya kolom X/Y tunggal, tidak ada kolom offset terpisah.
                put("x", t.x + t.offsetX)
                put("y", t.y + t.offsetY)
                put("width", t.w); put("height", t.h)
                put("rotation", t.rotation)
                put("locked", t.locked)
                put("visible", t.visible)
            }
        }
        if (positions.isEmpty()) return
        lifecycleScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    KeepStockGasClient.saveBoxPositions(url, token, store, positions, pic.ifBlank { "unknown" })
                }
            } catch (e: Exception) {
                // Diam-diam — addon V2 kemungkinan belum dipasang, tidak masalah (blob tetap sumber utama untuk sekarang).
            }
        }
    }

    // ── Load occupancy (isi/kosong per No Ctn) dari data KeepStock sheet ────
    private fun loadOccupancy() {
        val ssid = exioSpreadsheetId(store)
        val gid = exioGid(store)
        if (ssid.isBlank() || gid.isBlank()) return
        lifecycleScope.launch {
            try {
                val map = withContext(Dispatchers.IO) {
                    val rows = KeepStockSheetReader.fetchRows(ssid, gid)
                    val result = mutableMapOf<String, Boolean>()
                    rows.forEach { r ->
                        val key = r.noCtn.trim().uppercase()
                        if (key.isBlank()) return@forEach
                        val hasQty = r.sku.isNotBlank() && (r.qty.toDoubleOrNull() ?: 0.0) != 0.0
                        if (hasQty) result[key] = true else result.putIfAbsent(key, false)
                    }
                    result
                }
                rawOccupancy = map
                updateSummary()
            } catch (e: Exception) {
                // Data occupancy gagal diambil — kotak tetap tampil, cuma warnanya default "kosong".
            }
        }
    }

    private fun updateSummary() {
        val ctnTiles = tiles.filter { it.type == "CTN" }
        val resolved = computeResolvedOccupancy()
        canvas.occupancy = resolved
        // ★ FIX (baru — samakan dengan contoh denah user): BOX ISI/KOSONG sekarang berdasarkan
        // SLOT FISIK terisi No Ctn atau tidak (bukan lagi status stok di GSheet), supaya
        // "TOTAL BOX" = total slot grid (termasuk slot kosong putih bernomor), sama seperti gambar.
        val total = ctnTiles.size
        val filled = ctnTiles.count { !it.noCtn.isNullOrBlank() }
        val empty = total - filled
        tvEmpty.text = "BOX KOSONG\n$empty"
        tvFilled.text = "BOX ISI\n$filled"
        tvTotal.text = "TOTAL BOX\n$total"

        // ★ FIX (baru — Fase 1, UNPLACED BOX): setiap kali summary dihitung ulang
        // (dipanggil dari hampir semua aksi yang mengubah tiles: Auto-Generate,
        // Update Layout, tambah/hapus/geser box, dsb.), buang dari daftar
        // unplaced kode2 yang SEKARANG SUDAH punya Tile — murni lokal (tidak
        // fetch ulang ke KS), jadi aman & instan dipanggil sesering apapun.
        if (::rowUnplacedBox.isInitialized && unplacedCodes.isNotEmpty()) {
            val placedNow = ctnTiles.mapNotNull { it.noCtn?.trim()?.uppercase() }.toSet()
            val before = unplacedCodes.size
            unplacedCodes.removeAll { it in placedNow }
            if (unplacedCodes.size != before) refreshUnplacedBoxUi()
        }
    }

    // ── Tambah kotak No Ctn baru ─────────────────────────────────────────
    private fun showAddBoxDialog() {
        val et = EditText(this).apply { hint = "Contoh: A093"; setPadding(32, 24, 32, 24) }
        AlertDialog.Builder(this)
            .setTitle("Tambah Box (No Ctn)")
            .setView(et)
            .setPositiveButton("Tambah") { _, _ ->
                val noCtn = et.text.toString().trim()
                if (noCtn.isBlank()) {
                    Toast.makeText(this, "No Ctn tidak boleh kosong", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                if (!checkBoxLimitOrWarn(1)) return@setPositiveButton
                pushUndoSnapshot()
                val pos = findFreeCell()
                tiles.add(
                    DenahLayoutPrefs.Tile(
                        id = "t${System.currentTimeMillis()}",
                        type = "CTN", noCtn = noCtn,
                        x = pos.first, y = pos.second, w = 1, h = 1
                    )
                )
                // ★ FIX (baru): tambah 1 box manual juga TIDAK memicu auto-isi box kosong di
                // sekitarnya lagi — cuma urus kalau posisinya kebetulan nabrak box lain.
                resolveOverlapsOnly()
                canvas.tiles = tiles
                isDirty = true
                updateSummary()
            }
            .setNegativeButton("Batal", null)
            .showSafely()
    }

    // ── Tambah banner label (RECEIVING/CASHIER/dst) ─────────────────────
    private fun showAddLabelDialog() {
        val view = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 24, 48, 0)
        }
        val etLabel = EditText(this).apply { hint = "Contoh: RECEIVING" }
        val colors = listOf("Orange" to "#F5A623", "Blue" to "#2B5A8A", "Green" to "#2E7D32", "Gray" to "#6A6A6A", "Red" to "#C62828")
        val spinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@DenahLayoutActivity, android.R.layout.simple_spinner_dropdown_item, colors.map { it.first })
        }
        val etWidth = EditText(this).apply { hint = "Lebar (jumlah kotak, default 3)"; inputType = android.text.InputType.TYPE_CLASS_NUMBER }
        val etHeight = EditText(this).apply { hint = "Tinggi (jumlah kotak, default 1)"; inputType = android.text.InputType.TYPE_CLASS_NUMBER }
        view.addView(etLabel); view.addView(spinner); view.addView(etWidth); view.addView(etHeight)

        AlertDialog.Builder(this)
            .setTitle("Tambah Label")
            .setView(view)
            .setPositiveButton("Tambah") { _, _ ->
                val label = etLabel.text.toString().trim()
                if (label.isBlank()) {
                    Toast.makeText(this, "Teks label tidak boleh kosong", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                val w = etWidth.text.toString().toIntOrNull()?.coerceIn(1, 20) ?: 3
                val h = etHeight.text.toString().toIntOrNull()?.coerceIn(1, 20) ?: 1
                val colorHex = colors.getOrNull(spinner.selectedItemPosition)?.second ?: "#F5A623"
                pushUndoSnapshot()
                val pos = findFreeCell()
                tiles.add(
                    DenahLayoutPrefs.Tile(
                        id = "t${System.currentTimeMillis()}",
                        type = "LABEL", label = label,
                        x = pos.first, y = pos.second, w = w, h = h, colorHex = colorHex
                    )
                )
                canvas.tiles = tiles
                isDirty = true
            }
            .setNegativeButton("Batal", null)
            .showSafely()
    }

    /** Cari kotak (grid 1x1) kosong pertama, scan dari kiri-atas — dipakai sebagai posisi awal tile baru. */
    private fun findFreeCell(): Pair<Int, Int> {
        val occupied = HashSet<Long>()
        tiles.forEach { t -> for (dx in 0 until t.w) for (dy in 0 until t.h) occupied.add((t.x + dx).toLong() * 10000 + (t.y + dy)) }
        for (y in 0 until 60) for (x in 0 until 60) {
            if (!occupied.contains(x.toLong() * 10000 + y)) return x to y
        }
        return 0 to 0
    }

    // ── ★ FIX (baru — anti box dobel/tumpang tindih + auto-isi titik kosong) ──
    private val NA_LABEL = "BOX N/A"

    /**
     * Helper bersama: pindahkan [tilesToMove] (box CTN — boleh yang punya
     * No Ctn ataupun slot kosong) ke kolom "BOX N/A" (dibuat kalau belum
     * ada), ditumpuk ke bawah di kolom itu. Dipakai untuk 2 skenario:
     * box yang kalah tabrakan posisi, DAN (★ FIX baru) box/slot yang
     * kelebihan dari Batas Total Box saat auto-fill grid.
     */
    private fun moveTilesToNaColumn(tilesToMove: List<DenahLayoutPrefs.Tile>, markReview: Boolean) {
        if (tilesToMove.isEmpty()) return
        val ctnAll = tiles.filter { it.type == "CTN" }
        val naLabelTile = tiles.firstOrNull { it.type == "LABEL" && it.label == NA_LABEL }
        val naX: Int
        val naYStart: Int
        if (naLabelTile != null) {
            naX = naLabelTile.x
            naYStart = naLabelTile.y
        } else {
            val maxX = ctnAll.maxOfOrNull { it.x } ?: 0
            naX = maxX + 2
            naYStart = ctnAll.minOfOrNull { it.y } ?: 0
            tiles.add(
                DenahLayoutPrefs.Tile(
                    id = "t${System.currentTimeMillis()}_naLabel",
                    type = "LABEL", label = NA_LABEL,
                    x = naX, y = (naYStart - 1).coerceAtLeast(0), w = 1, h = 1,
                    colorHex = "#C62828"
                )
            )
        }
        val naOccupiedY = tiles.filter { it.type == "CTN" && it.x == naX }.map { it.y }.toMutableSet()
        var naY = naYStart
        tilesToMove.forEach { moved ->
            while (naY in naOccupiedY) naY++
            val idx = tiles.indexOfFirst { it.id == moved.id }
            if (idx >= 0) {
                tiles[idx] = if (markReview) {
                    tiles[idx].copy(x = naX, y = naY, needsReview = true, colorHex = "#F44336")
                } else {
                    // ★ FIX (baru — overflow Batas Total Box): dipindah biasa (bukan tabrakan),
                    // jadi TIDAK ditandai merah — cukup warna aslinya (putih kalau slot kosong,
                    // oranye/apa adanya kalau box beneran) dipertahankan.
                    tiles[idx].copy(x = naX, y = naY)
                }
                naOccupiedY.add(naY)
            }
            naY++
        }
    }

    /**
     * ★ FIX (baru — hilangkan auto-isi box kosong saat drag manual): dulu
     * geser 1 box (mis. dari A1 ke B2) memicu resolveOverlapsAndFillGaps()
     * PENUH, yang otomatis membuat box kosong baru di titik lain (mis. A2 &
     * B1) karena bounding box grid melebar mengikuti posisi baru itu — bikin
     * box tak diinginkan muncul sendiri. Ini fungsi KHUSUS drag manual: HANYA
     * urus tabrakan posisi (poin 1 di resolveOverlapsAndFillGaps), TIDAK
     * ikut mengisi titik kosong di sekitarnya sama sekali.
     */
    private fun resolveOverlapsOnly() {
        val ctnAll = tiles.filter { it.type == "CTN" }
        if (ctnAll.isEmpty()) return
        val allCodesUpper = ctnAll.mapNotNull { it.noCtn?.trim()?.uppercase() }.toSet()

        val byPos = ctnAll.groupBy { it.x to it.y }
        val losers = mutableListOf<DenahLayoutPrefs.Tile>()
        byPos.values.filter { it.size > 1 }.forEach { group ->
            fun isAliasLike(code: String): Boolean {
                if (code.length <= 1 || !code.last().isLetter()) return false
                return code.dropLast(1) in allCodesUpper
            }
            val sorted = group.sortedWith(
                compareBy(
                    { it.noCtn.isNullOrBlank() }, // slot kosong kalah duluan lawan box beneran
                    { it.noCtn?.let { c -> isAliasLike(c.trim().uppercase()) } ?: false }, // alias-like (mis. A007C) kalah duluan
                    { it.noCtn?.length ?: 0 },
                    { it.noCtn ?: "" }
                )
            )
            losers.addAll(sorted.drop(1).filter { !it.noCtn.isNullOrBlank() })
            tiles.removeAll { t -> sorted.drop(1).any { it.id == t.id && it.noCtn.isNullOrBlank() } }
        }

        if (losers.isNotEmpty()) moveTilesToNaColumn(losers, markReview = true)
    }

    /**
     * Dipanggil setelah Auto-Generate (Custom Dimension/Auto-Fit/Block) untuk
     * menata grid baru secara utuh:
     *  1. TIDAK PERNAH ada 2 box CTN di titik (x,y) yang sama. Kalau tabrakan
     *     (mis. A007C dan A009 sama2 di 1 titik), yang "menang" tetap di
     *     titik itu (diprioritaskan kode TANPA akhiran huruf / alias, atau
     *     kode paling pendek), yang kalah dipindah otomatis ke kolom "BOX N/A"
     *     DAN ditandai MERAH (needsReview) supaya kelihatan perlu dicek.
     *  2. Titik kosong DI DALAM area grid (bounding box semua box, di luar
     *     kolom BOX N/A) otomatis diisi SLOT KOSONG putih bernomor urut fisik
     *     (slotNo) — BUKAN lanjutan No Ctn, persis seperti contoh denah user
     *     (kotak putih bernomor 1,2,3... independen dari kode A058 dsb).
     *  3. ★ FIX (baru — Batas Total Box): kalau [maxTotalBoxLimit] aktif,
     *     total box DI LAYOUT (box beneran + slot kosong putih) TIDAK PERNAH
     *     melebihi batas itu. Kalau area grid butuh lebih banyak slot dari
     *     batas (mis. batas 100 tapi grid butuh 120), yang MUAT sesuai urutan
     *     fisik (baris demi baris) ditaruh di layout, SISANYA (baik box
     *     beneran maupun yang harusnya jadi slot kosong) dipindah ke BOX N/A.
     *
     * ★ FIX (baru): TIDAK LAGI dipanggil saat drag/geser box manual satuan —
     * geser 1 box sekarang cuma urus tabrakan posisi lewat resolveOverlapsOnly(),
     * tidak ikut membuat box kosong baru di sekitarnya (lihat onTileMoved).
     */
    private fun resolveOverlapsAndFillGaps() {
        val ctnAll = tiles.filter { it.type == "CTN" }
        if (ctnAll.isEmpty()) return
        val allCodesUpper = ctnAll.mapNotNull { it.noCtn?.trim()?.uppercase() }.toSet()

        // (1) Tabrakan posisi -> pemenang tetap, sisanya dipindah ke kolom BOX N/A + ditandai merah.
        //     Slot kosong (noCtn blank) TIDAK ikut dianggap tabrakan — box asli selalu menang lawan slot kosong.
        val byPos = ctnAll.groupBy { it.x to it.y }
        val losers = mutableListOf<DenahLayoutPrefs.Tile>()
        byPos.values.filter { it.size > 1 }.forEach { group ->
            fun isAliasLike(code: String): Boolean {
                if (code.length <= 1 || !code.last().isLetter()) return false
                return code.dropLast(1) in allCodesUpper
            }
            val sorted = group.sortedWith(
                compareBy(
                    { it.noCtn.isNullOrBlank() }, // slot kosong kalah duluan lawan box beneran
                    { it.noCtn?.let { c -> isAliasLike(c.trim().uppercase()) } ?: false }, // alias-like (mis. A007C) kalah duluan
                    { it.noCtn?.length ?: 0 },
                    { it.noCtn ?: "" }
                )
            )
            losers.addAll(sorted.drop(1).filter { !it.noCtn.isNullOrBlank() }) // slot kosong yang kalah langsung dihapus aja (bukan dipindah)
            tiles.removeAll { t -> sorted.drop(1).any { it.id == t.id && it.noCtn.isNullOrBlank() } }
        }

        if (losers.isNotEmpty()) moveTilesToNaColumn(losers, markReview = true)

        // (2) Isi titik kosong di dalam bounding box (di luar kolom BOX N/A) dengan SLOT KOSONG putih
        //     bernomor urut fisik (slotNo) — terpisah total dari sistem penomoran No Ctn — TAPI
        //     dibatasi sesuai Batas Total Box kalau aktif (lihat poin 3 di komentar atas).
        val ctnAfter = tiles.filter { it.type == "CTN" }
        if (ctnAfter.isEmpty()) return
        val naCols = tiles.filter { it.type == "LABEL" && it.label == NA_LABEL }.map { it.x }.toSet()
        val gridTiles = ctnAfter.filter { it.x !in naCols }
        if (gridTiles.isEmpty()) return
        val minX = gridTiles.minOf { it.x }; val maxX = gridTiles.maxOf { it.x }
        val minY = gridTiles.minOf { it.y }; val maxY = gridTiles.maxOf { it.y }
        val totalCells = (maxX - minX + 1).toLong() * (maxY - minY + 1).toLong()
        if (totalCells <= 0 || totalCells > 6000) return // pengaman: grid kelewat besar, jangan auto-isi (kemungkinan freeform, bukan grid rapat)

        var nextSlot = (tiles.mapNotNull { it.slotNo }.maxOrNull() ?: 0) + 1
        val existingByPos = gridTiles.associateBy { it.x to it.y }
        val limit = maxTotalBoxLimit

        // Urutan scan HARUS sama dengan urutan fisik box (baris demi baris, kiri->kanan, atas->bawah)
        // supaya nomor slot baru nyambung logis dengan yang lama, DAN supaya pemotongan Batas Total
        // Box (kalau aktif) konsisten & bisa diprediksi user (posisi paling akhir yang kena potong).
        data class ScanCell(val x: Int, val y: Int, val existingTile: DenahLayoutPrefs.Tile?)
        val scanCells = mutableListOf<ScanCell>()
        for (y in minY..maxY) for (x in minX..maxX) scanCells.add(ScanCell(x, y, existingByPos[x to y]))

        if (limit == null) {
            // Tanpa batas: perilaku lama — isi semua titik kosong.
            scanCells.filter { it.existingTile == null }.forEach { cell ->
                tiles.add(
                    DenahLayoutPrefs.Tile(
                        id = "t${System.currentTimeMillis()}_gap_${cell.x}_${cell.y}",
                        type = "CTN", noCtn = null, x = cell.x, y = cell.y, w = 1, h = 1,
                        colorHex = "#FFFFFF", slotNo = nextSlot
                    )
                )
                nextSlot++
            }
        } else {
            // ★ FIX (baru — Batas Total Box saat auto-fill grid): jangan asal tambah slot kosong
            // kalau bakal melebihi batas. Yang "muat" (sesuai urutan scan di atas) ditaruh di
            // layout; sisanya (box beneran ATAU calon slot kosong) dipindah ke BOX N/A.
            val keep = scanCells.take(limit)
            val overflow = scanCells.drop(limit)

            keep.filter { it.existingTile == null }.forEach { cell ->
                tiles.add(
                    DenahLayoutPrefs.Tile(
                        id = "t${System.currentTimeMillis()}_gap_${cell.x}_${cell.y}",
                        type = "CTN", noCtn = null, x = cell.x, y = cell.y, w = 1, h = 1,
                        colorHex = "#FFFFFF", slotNo = nextSlot
                    )
                )
                nextSlot++
            }

            // Posisi kosong yang overflow: TIDAK perlu dibuat tile-nya sama sekali (tidak ada yang
            // perlu dipindah — dari awal memang belum ada slot di posisi itu).
            // Box BENERAN yang overflow (sudah ada isinya tapi posisinya kepotong batas): pindahkan
            // ke BOX N/A supaya datanya tidak hilang, sesuai contoh: "sisanya simpan di box n/a
            // mau yang kosong atau isi".
            val overflowReal = overflow.mapNotNull { it.existingTile }
            if (overflowReal.isNotEmpty()) {
                moveTilesToNaColumn(overflowReal, markReview = false)
                Toast.makeText(
                    this,
                    "Batas Total Box ($limit) aktif: ${overflowReal.size} box dipindah ke BOX N/A karena melebihi batas.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    // ── Tap kotak mode EDIT: edit posisi/teks tile, hapus tile, ATAU edit langsung data KS (SKU/Qty) di gsheet ──
    private fun showEditTileDialog(tile: DenahLayoutPrefs.Tile) {
        // ★ FIX (baru — Fase 4 "Object Editor"): tipe objek statis baru (WALL/TEXT/AREA/
        // ARROW/DOOR) langsung buka form Edit Objek (resize/rotate/lock/visible/hapus),
        // tidak lewat chooser sederhana seperti LABEL/RULER lama.
        if (tile.type in objectTypeCodes) {
            showEditObjectDialog(tile)
            return
        }
        val title = if (tile.type == "CTN") "No Ctn: ${tile.noCtn}" else "Label: ${tile.label}"
        val items = if (tile.type == "CTN") {
            // ★ FIX (baru — Fase 5): tambah opsi "Edit Posisi (X/Y/Width/Height/Rotation)".
            arrayOf("Edit Data Stok (SKU/Qty) — langsung ke GSheet", "Edit Posisi (X/Y/Width/Height/Rotation)", "Edit No Ctn (tile)", "Hapus dari Denah")
        } else {
            arrayOf("Edit teks", "Hapus")
        }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setItems(items) { _, which ->
                if (tile.type == "CTN") {
                    when (which) {
                        0 -> showEditBoxDataDialog(tile)
                        1 -> showEditBoxPositionDialog(tile)
                        2 -> showRenameTileDialog(tile)
                        3 -> {
                            pushUndoSnapshot()
                            tiles.removeAll { it.id == tile.id }
                            canvas.tiles = tiles
                            isDirty = true
                            updateSummary()
                        }
                    }
                } else {
                    when (which) {
                        0 -> showRenameTileDialog(tile)
                        1 -> {
                            pushUndoSnapshot()
                            tiles.removeAll { it.id == tile.id }
                            canvas.tiles = tiles
                            isDirty = true
                            updateSummary()
                        }
                    }
                }
            }
            .setNegativeButton("Batal", null)
            .showSafely()
    }

    private fun showRenameTileDialog(tile: DenahLayoutPrefs.Tile) {
        val et = EditText(this).apply {
            setText(if (tile.type == "CTN") tile.noCtn else tile.label)
            setPadding(32, 24, 32, 24)
        }
        AlertDialog.Builder(this)
            .setTitle("Edit ${if (tile.type == "CTN") "No Ctn" else "Label"}")
            .setView(et)
            .setPositiveButton("Simpan") { _, _ ->
                val newText = et.text.toString().trim()
                if (newText.isBlank()) return@setPositiveButton
                val idx = tiles.indexOfFirst { it.id == tile.id }
                if (idx >= 0) {
                    pushUndoSnapshot()
                    tiles[idx] = if (tile.type == "CTN") tiles[idx].copy(noCtn = newText) else tiles[idx].copy(label = newText)
                    canvas.tiles = tiles
                    isDirty = true
                    updateSummary()
                }
            }
            .setNegativeButton("Batal", null)
            .showSafely()
    }

    // ── Tap kotak mode VIEW: lihat isi No Ctn ini (SKU/Qty) ──────────────
    private fun showTileDetailDialog(tile: DenahLayoutPrefs.Tile) {
        if (tile.type == "LABEL") return
        val ssid = exioSpreadsheetId(store)
        val gid = exioGid(store)
        if (ssid.isBlank() || gid.isBlank()) {
            Toast.makeText(this, "No Ctn: ${tile.noCtn}", Toast.LENGTH_SHORT).show()
            return
        }
        val pd = ProgressDialog(this).apply { setMessage("Loading..."); show() }
        lifecycleScope.launch {
            try {
                val codes = aliasesFor(tile.noCtn)
                val items = withContext(Dispatchers.IO) {
                    KeepStockSheetReader.fetchRows(ssid, gid)
                        .filter { r -> codes.contains(r.noCtn.trim().uppercase()) }
                }
                pd.dismissSafely()
                val aliasNote = if (codes.size > 1) "\n(termasuk alias: ${codes.drop(1).joinToString(", ")})" else ""
                val stockMsg = if (items.isEmpty()) {
                    "Box ini KOSONG (belum ada SKU tercatat).$aliasNote"
                } else {
                    items.joinToString("\n") { "• [${it.noCtn}] ${it.sku}  x${it.qty}" } + aliasNote
                }
                // ★ FIX (baru — Fase 5, spesifikasi poin 6 "Edit Detail"): tambahkan Description
                // (dibaca READ-ONLY dari cache katalog lokal berdasarkan SKU pertama box ini — BUKAN
                // dari Keep Stock, jadi tidak melanggar aturan "Layout tidak boleh mengubah Keep Stock")
                // dan info Posisi (X/Y/Width/Height/Rotation) saat ini.
                val descLine = items.firstOrNull()?.let { row ->
                    try {
                        val cat = AppDatabase(this@DenahLayoutActivity).findCatalog(row.sku)
                        val d = cat?.get("desc")
                        if (!d.isNullOrBlank() && d != "-") "\nDescription: $d" else ""
                    } catch (e: Exception) { "" }
                } ?: ""
                val posLine = "\n\nPosisi: X=${"%.1f".format(tile.x + tile.offsetX)}  Y=${"%.1f".format(tile.y + tile.offsetY)}  " +
                    "Width=${tile.w}  Height=${tile.h}  Rotation=${tile.rotation.toInt()}°"
                val msg = stockMsg + descLine + posLine
                AlertDialog.Builder(this@DenahLayoutActivity)
                    .setTitle("NO CTN: ${tile.noCtn}")
                    .setMessage(msg)
                    .setPositiveButton("Edit Data Stok") { _, _ -> showEditBoxDataDialog(tile) }
                    // ★ FIX (baru — Fase 5): "Edit Posisi" (X/Y/Width/Height/Rotation manual) —
                    // tersedia dari dialog detail ini juga (sama seperti "Edit Data Stok" yang
                    // sudah lebih dulu ada di sini), konsisten dipakai dari mode VIEW maupun EDIT.
                    .setNeutralButton("Edit Posisi") { _, _ -> showEditBoxPositionDialog(tile) }
                    .setNegativeButton("Tutup", null)
                    .showSafely()
            } catch (e: Exception) {
                pd.dismissSafely()
                Toast.makeText(this@DenahLayoutActivity, "Gagal ambil detail: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    /**
     * ★ FIX (baru — Fase 5, spesifikasi poin 6 "Edit Detail"): form manual
     * X/Y/Width/Height/Rotation untuk 1 box No Ctn — pelengkap drag (yang
     * cuma bisa geser posisi) supaya user bisa masukkan angka PERSIS kalau
     * mau (mis. menyalin posisi dari denah lain, atau presisi milimeter).
     * SAVE di sini cuma memperbarui posisi LOKAL (tiles), sama seperti hasil
     * drag — belum ke server sampai tombol SAVE LAYOUT utama ditekan.
     */
    private fun showEditBoxPositionDialog(tile: DenahLayoutPrefs.Tile) {
        val form = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 24, 48, 0) }
        val etX = numberFieldDecimal("X", (tile.x + tile.offsetX).toString())
        val etY = numberFieldDecimal("Y", (tile.y + tile.offsetY).toString())
        val etW = numberField("Width (satuan sel)", tile.w.toString())
        val etH = numberField("Height (satuan sel)", tile.h.toString())
        val etRotation = numberField("Rotation (derajat, 0-359)", tile.rotation.toInt().toString())
        form.addView(labeled("Posisi — No Ctn: ${tile.noCtn}"))
        form.addView(etX); form.addView(etY); form.addView(etW); form.addView(etH); form.addView(etRotation)

        AlertDialog.Builder(this)
            .setTitle("Edit Posisi")
            .setView(form)
            .setPositiveButton("Simpan") { _, _ ->
                val absX = etX.text.toString().toFloatOrNull() ?: (tile.x + tile.offsetX)
                val absY = etY.text.toString().toFloatOrNull() ?: (tile.y + tile.offsetY)
                val newW = etW.text.toString().toIntOrNull()?.coerceIn(1, 200) ?: tile.w
                val newH = etH.text.toString().toIntOrNull()?.coerceIn(1, 200) ?: tile.h
                val newRotation = (etRotation.text.toString().toIntOrNull() ?: 0).let { ((it % 360) + 360) % 360 }.toFloat()
                val idx = tiles.indexOfFirst { it.id == tile.id }
                if (idx >= 0) {
                    pushUndoSnapshot()
                    // ★ FIX: X/Y yang diketik bisa pecahan (posisi bebas, sama seperti hasil drag
                    // Snap OFF) — dipecah lagi jadi (sel acuan bulat bawah) + (offset sisa pecahan).
                    val cellX = kotlin.math.floor(absX).toInt()
                    val cellY = kotlin.math.floor(absY).toInt()
                    tiles[idx] = tiles[idx].copy(
                        x = cellX, y = cellY,
                        offsetX = absX - cellX, offsetY = absY - cellY,
                        w = newW, h = newH, rotation = newRotation
                    )
                    resolveOverlapsOnly() // posisi baru mungkin nabrak box lain di titik yang sama
                    canvas.tiles = tiles
                    isDirty = true
                    updateSummary()
                }
            }
            .setNegativeButton("Batal", null)
            .showSafely()
    }

    // ── ★ FIX (baru — Edit Data Stok langsung dari Box Layout): tap sebuah
    // box (mode VIEW maupun EDIT) bisa langsung TAMBAH/HAPUS/GANTI No Ctn,
    // SKU, Qty untuk box itu — dan perubahannya LANGSUNG ditulis ke data KS
    // di Google Sheet lewat KeepStockGasClient (action "addRows"/"updateRow",
    // sama seperti dipakai menu Keep Stock > View & Edit Data). Setelah
    // sukses, occupancy denah di-refresh supaya warna ISI/KOSONG ikut update.
    private fun showEditBoxDataDialog(tile: DenahLayoutPrefs.Tile) {
        val ssid = exioSpreadsheetId(store)
        val gid = exioGid(store)
        val url = ksWebAppUrl; val token = ksApiToken
        if (ssid.isBlank() || gid.isBlank()) {
            Toast.makeText(this, "Spreadsheet KeepStock toko ini belum diset", Toast.LENGTH_LONG).show()
            return
        }
        if (url.isBlank() || token.isBlank()) {
            Toast.makeText(this, "Web App URL / Token Keep Stock belum diset (Setting)", Toast.LENGTH_LONG).show()
            return
        }
        val pd = ProgressDialog(this).apply { setMessage("Loading data stok..."); show() }
        lifecycleScope.launch {
            try {
                val codes = aliasesFor(tile.noCtn)
                val rows = withContext(Dispatchers.IO) {
                    KeepStockSheetReader.fetchRows(ssid, gid).filter { r -> codes.contains(r.noCtn.trim().uppercase()) }
                }
                pd.dismissSafely()
                renderEditBoxDataDialog(tile, rows)
            } catch (e: Exception) {
                pd.dismissSafely()
                Toast.makeText(this@DenahLayoutActivity, "Gagal ambil data: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun renderEditBoxDataDialog(tile: DenahLayoutPrefs.Tile, rows: List<KeepStockSheetReader.KsRow>) {
        val container = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 16, 40, 0) }
        if (rows.isEmpty()) {
            container.addView(TextView(this).apply { text = "Box ini KOSONG (belum ada SKU tercatat)."; textSize = 12f; setPadding(0, 0, 0, 12) })
        }
        rows.forEach { r ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 8, 0, 8) }
            row.addView(TextView(this).apply {
                text = "[${r.noCtn}] ${r.sku}  x${r.qty}"
                textSize = 12f
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            })
            val btnEdit = TextView(this).apply { text = "Edit"; setTextColor(android.graphics.Color.parseColor("#2B5A8A")); textSize = 12f; setPadding(16, 0, 16, 0) }
            btnEdit.setOnClickListener { showEditKsRowDialog(tile, r) }
            val btnDel = TextView(this).apply { text = "Hapus"; setTextColor(android.graphics.Color.parseColor("#C62828")); textSize = 12f }
            btnDel.setOnClickListener { confirmDeleteKsRow(tile, r) }
            row.addView(btnEdit); row.addView(btnDel)
            container.addView(row)
        }
        val scroll = android.widget.ScrollView(this).apply { addView(container) }

        AlertDialog.Builder(this)
            .setTitle("Data Stok — NO CTN: ${tile.noCtn}")
            .setView(scroll)
            .setPositiveButton("+ Tambah SKU") { _, _ -> showAddKsRowDialog(tile) }
            .setNegativeButton("Tutup", null)
            .showSafely()
    }

    /** Form tambah SKU baru untuk box ini — langsung addRows ke GSheet (action "addRows"). */
    private fun showAddKsRowDialog(tile: DenahLayoutPrefs.Tile) {
        val form = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 8, 40, 0) }
        val etNoCtn = EditText(this).apply { hint = "No Ctn"; setText(tile.noCtn) }
        val etSku = EditText(this).apply { hint = "SKU" }
        val etQty = EditText(this).apply { hint = "Qty"; inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL }
        form.addView(etNoCtn); form.addView(etSku); form.addView(etQty)
        AlertDialog.Builder(this)
            .setTitle("Tambah SKU — NO CTN: ${tile.noCtn}")
            .setView(form)
            .setPositiveButton("Simpan") { _, _ ->
                val noCtn = etNoCtn.text.toString().trim()
                val sku = etSku.text.toString().trim()
                val qty = etQty.text.toString().trim()
                if (noCtn.isBlank() || sku.isBlank()) {
                    Toast.makeText(this, "No Ctn & SKU wajib diisi", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                submitKsChange("Menambah SKU...") {
                    KeepStockGasClient.addRows(ksWebAppUrl, ksApiToken, store, noCtn, listOf(sku to qty))
                }
            }
            .setNegativeButton("Batal", null)
            .showSafely()
    }

    /** Form edit 1 baris data KS (No Ctn/SKU/Qty) — langsung updateRow ke GSheet. */
    private fun showEditKsRowDialog(tile: DenahLayoutPrefs.Tile, r: KeepStockSheetReader.KsRow) {
        val form = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 8, 40, 0) }
        val etNoCtn = EditText(this).apply { hint = "No Ctn"; setText(r.noCtn) }
        val etSku = EditText(this).apply { hint = "SKU"; setText(r.sku) }
        val etQty = EditText(this).apply { hint = "Qty"; setText(if (r.qty == "-") "" else r.qty); inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL }
        form.addView(etNoCtn); form.addView(etSku); form.addView(etQty)
        AlertDialog.Builder(this)
            .setTitle("Edit Baris — NO CTN: ${tile.noCtn}")
            .setView(form)
            .setPositiveButton("Simpan") { _, _ ->
                val noCtn = etNoCtn.text.toString().trim()
                val sku = etSku.text.toString().trim()
                val qty = etQty.text.toString().trim()
                if (noCtn.isBlank() || sku.isBlank()) {
                    Toast.makeText(this, "No Ctn & SKU wajib diisi", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                submitKsChange("Menyimpan perubahan...") {
                    KeepStockGasClient.updateRow(ksWebAppUrl, ksApiToken, store, r.rowNumber, noCtn, sku, qty)
                }
            }
            .setNegativeButton("Batal", null)
            .showSafely()
    }

    private fun confirmDeleteKsRow(tile: DenahLayoutPrefs.Tile, r: KeepStockSheetReader.KsRow) {
        AlertDialog.Builder(this)
            .setTitle("Hapus Baris")
            .setMessage("Hapus SKU \"${r.sku}\" (Qty ${r.qty}) dari No Ctn ${r.noCtn}?")
            .setPositiveButton("Hapus") { _, _ ->
                submitKsChange("Menghapus...") { KeepStockGasClient.deleteRow(ksWebAppUrl, ksApiToken, store, r.rowNumber) }
            }
            .setNegativeButton("Batal", null)
            .showSafely()
    }

    /** Helper bersama: kirim 1 perubahan (add/edit/delete) ke GSheet, lalu refresh occupancy denah kalau sukses. */
    private fun submitKsChange(loadingMsg: String, action: suspend () -> JSONObject) {
        val pd = ProgressDialog(this).apply { setMessage(loadingMsg); show() }
        lifecycleScope.launch {
            try {
                val result = withContext(Dispatchers.IO) { action() }
                pd.dismissSafely()
                if (result.optBoolean("ok", false)) {
                    Toast.makeText(this@DenahLayoutActivity, "Data stok tersimpan ke GSheet", Toast.LENGTH_SHORT).show()
                    loadOccupancy()
                } else {
                    Toast.makeText(this@DenahLayoutActivity, "Gagal simpan: ${result.optString("error", "unknown")}", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                pd.dismissSafely()
                Toast.makeText(this@DenahLayoutActivity, "Gagal konek ke server: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    // ── AUTO-GENERATE: pilih sumber urutan kode dasar ────────────────────
    private fun showAutoGenerateChooserDialog() {
        AlertDialog.Builder(this)
            .setTitle("Auto-Generate Denah")
            .setItems(
                arrayOf(
                    "Data KS Regular saja",
                    "Data KS Receiving saja",
                    "Semua Data (Regular + Receiving)",
                    "Pakai Box yang Sudah Ditaruh Manual (generate alias A-Z saja)"
                )
            ) { _, which ->
                when (which) {
                    0 -> readKsThenShowGridModeDialog(DataSource.REGULAR)
                    1 -> readKsThenShowGridModeDialog(DataSource.RECEIVING)
                    2 -> readKsThenShowGridModeDialog(DataSource.ALL)
                    else -> showManualSuffixDialog()
                }
            }
            .setNegativeButton("Batal", null)
            .showSafely()
    }

    private enum class DataSource { REGULAR, RECEIVING, ALL }

    /**
     * ★ FIX (baru — Auto Read No Ctn Regular): kategori REGULAR di sini
     * SENGAJA disamakan persis dengan rule di KeepStockDataViewActivity
     * (menu View & Edit Data > filter chip "Regular") — No Ctn diawali
     * A/B/C/D atau R0 dianggap REGULAR, selain itu RECEIVING. Kalau rule
     * di KeepStockDataViewActivity berubah, ubah juga di sini biar konsisten.
     */
    private fun isRegularCtn(noCtn: String): Boolean {
        val n = noCtn.trim().uppercase()
        return n.startsWith("R0") || n.startsWith("A") || n.startsWith("B") || n.startsWith("C") || n.startsWith("D")
    }

    /**
     * Kode dengan akhiran 1 huruf yang BASE-nya (tanpa huruf itu) JUGA ada
     * di data yang sama -> dianggap ALIAS ke base itu (bukan box sendiri).
     * Selain itu (tanpa akhiran huruf, ATAU akhiran huruf tapi base-nya
     * tidak ada) -> dianggap box sendiri. Ini beda dari generator sintetis
     * (poin A-Z offset) — di sini murni cocokkan string literal yang benar2
     * ada di data KS, bukan hitungan urutan.
     */
    private fun splitLiteralAlias(code: String, allCodes: Set<String>): Pair<String, String?> {
        if (code.length > 1 && code.last().isLetter()) {
            val base = code.dropLast(1)
            if (base in allCodes) return base to code
        }
        return code to null
    }

    private fun naturalSort(codes: MutableList<String>) {
        codes.sortWith(
            compareBy(
                { Regex("^[A-Za-z]*").find(it)?.value ?: "" },
                { Regex("\\d+").find(it)?.value?.toIntOrNull() ?: 0 },
                { it }
            )
        )
    }

    /** code -> box sendiri (bukan alias), dari [codes] mentah -> (boxCodes terurut, aliasPairs code->base). */
    private fun splitCodesIntoBoxesAndAliases(codes: Set<String>): Pair<List<String>, List<Pair<String, String>>> {
        val boxCodes = mutableListOf<String>()
        val aliasPairs = mutableListOf<Pair<String, String>>()
        codes.forEach { code ->
            val (base, aliasCode) = splitLiteralAlias(code, codes)
            if (aliasCode != null) aliasPairs.add(aliasCode to base) else boxCodes.add(code)
        }
        naturalSort(boxCodes)
        return boxCodes to aliasPairs
    }

    /**
     * ★ FIX (Tahap 1+2 — Auto-Generate): Tahap 1 = baca SELURUH data KS toko
     * ini dari sheet (sekali baca, otomatis, tanpa perlu pilih apa-apa dulu).
     * Tahap 2 = filter sumber datanya sesuai pilihan user (Regular saja /
     * Receiving saja / Semua). Lanjut ke Tahap 3 (pilih mode grid) begitu
     * datanya siap.
     */
    private fun readKsThenShowGridModeDialog(source: DataSource) {
        val ssid = exioSpreadsheetId(store)
        val gid = exioGid(store)
        if (ssid.isBlank() || gid.isBlank()) {
            Toast.makeText(this, "Spreadsheet KeepStock toko ini belum diset", Toast.LENGTH_LONG).show()
            return
        }
        val pd = ProgressDialog(this).apply { setMessage("Tahap 1: Membaca seluruh data KS..."); show() }
        lifecycleScope.launch {
            try {
                // Tahap 1: baca SEMUA No Ctn unik dari sheet (tidak peduli kategori dulu).
                val allCodes = withContext(Dispatchers.IO) {
                    KeepStockSheetReader.fetchRows(ssid, gid).map { it.noCtn.trim().uppercase() }.filter { it.isNotBlank() }.toSet()
                }
                pd.dismissSafely()
                if (allCodes.isEmpty()) {
                    Toast.makeText(this@DenahLayoutActivity, "Tidak ada data No Ctn ditemukan di data KS toko ini", Toast.LENGTH_LONG).show()
                    return@launch
                }
                // Tahap 2: filter sesuai sumber data yang dipilih.
                val filtered = when (source) {
                    DataSource.REGULAR -> allCodes.filter { isRegularCtn(it) }.toSet()
                    DataSource.RECEIVING -> allCodes.filter { !isRegularCtn(it) }.toSet()
                    DataSource.ALL -> allCodes
                }
                if (filtered.isEmpty()) {
                    val label = when (source) { DataSource.REGULAR -> "REGULAR"; DataSource.RECEIVING -> "RECEIVING"; DataSource.ALL -> "" }
                    Toast.makeText(this@DenahLayoutActivity, "Tidak ada No Ctn kategori $label ditemukan", Toast.LENGTH_LONG).show()
                    return@launch
                }
                val (boxCodes, aliasPairs) = splitCodesIntoBoxesAndAliases(filtered)
                // Untuk mode Auto-Fit Block, kalau sumbernya "Semua", tetap butuh pemisahan per
                // kategori (Regular vs Receiving) supaya keduanya digambar sebagai 2 blok terpisah
                // seperti contoh gambar (blok kiri/tengah = Regular, blok Receiving = Receiving).
                val regularBoxCodes: List<String>
                val receivingBoxCodes: List<String>
                if (source == DataSource.ALL) {
                    val (rb, _) = splitCodesIntoBoxesAndAliases(allCodes.filter { isRegularCtn(it) }.toSet())
                    val (cb, _) = splitCodesIntoBoxesAndAliases(allCodes.filter { !isRegularCtn(it) }.toSet())
                    regularBoxCodes = rb; receivingBoxCodes = cb
                } else {
                    regularBoxCodes = if (source == DataSource.REGULAR) boxCodes else emptyList()
                    receivingBoxCodes = if (source == DataSource.RECEIVING) boxCodes else emptyList()
                }
                showGridModeChooserDialog(boxCodes, aliasPairs, regularBoxCodes, receivingBoxCodes)
            } catch (e: Exception) {
                pd.dismissSafely()
                Toast.makeText(this@DenahLayoutActivity, "Gagal baca data KS: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    /** Tahap 3: pilih mode pembuatan grid — Custom Dimension atau Auto-Fit Block. */
    private fun showGridModeChooserDialog(
        boxCodes: List<String>, aliasPairs: List<Pair<String, String>>,
        regularBoxCodes: List<String>, receivingBoxCodes: List<String>
    ) {
        AlertDialog.Builder(this)
            .setTitle("Ditemukan ${boxCodes.size} box + ${aliasPairs.size} alias — Pilih Mode Grid")
            .setItems(
                arrayOf(
                    "Custom Dimension (isi jumlah kolom & baris manual, mirip Insert Table Word)",
                    "Auto-Fit Block (otomatis susun ke bentuk layout fisik + kolom BOX N/A)",
                    "Block Custom / L-Shape (atur baris mulai-akhir per blok, bisa lebih dari 1 blok)"
                )
            ) { _, which ->
                when (which) {
                    0 -> showCustomDimensionDialog(boxCodes, aliasPairs)
                    1 -> applyAutoFitBlock(regularBoxCodes, receivingBoxCodes, aliasPairs)
                    else -> {
                        pendingShapeBlocks.clear()
                        shapeBlockBoxCodes = boxCodes
                        shapeBlockAliasPairs = aliasPairs
                        showKsBlockListDialog()
                    }
                }
            }
            .setNegativeButton("Batal", null)
            .showSafely()
    }

    /**
     * ★ FIX (Tahap 3 — Custom Dimension, mirip "Insert Table" Word): user
     * cukup isi Number of Columns & Number of Rows + Direction Flow, tidak
     * perlu mikir start/end/step manual lagi.
     */
    private fun showCustomDimensionDialog(boxCodes: List<String>, aliasPairs: List<Pair<String, String>>) {
        val form = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 8, 40, 0) }
        form.addView(TextView(this).apply {
            text = "${boxCodes.size} box akan ditempatkan. Pastikan Kolom × Baris ≥ ${boxCodes.size}."
            textSize = 12f; setPadding(0, 0, 0, 12)
        })
        val etCols = numberField("Number of Columns (jumlah kolom)")
        val etRows = numberField("Number of Rows (jumlah baris)")
        val directionLabels = arrayOf(
            "Kiri ke Kanan (baris demi baris, atas ke bawah)",
            "Bawah ke Atas (kolom demi kolom)",
            "Zig-zag (baris berselang-seling arah)"
        )
        val spinnerDir = Spinner(this).apply { adapter = ArrayAdapter(this@DenahLayoutActivity, android.R.layout.simple_spinner_dropdown_item, directionLabels) }

        form.addView(labeled("Ukuran Grid")); form.addView(etCols); form.addView(etRows)
        form.addView(labeled("Direction Flow")); form.addView(spinnerDir)
        val scroll = android.widget.ScrollView(this).apply { addView(form) }

        AlertDialog.Builder(this)
            .setTitle("Custom Dimension")
            .setView(scroll)
            .setPositiveButton("Generate") { _, _ ->
                val cols = etCols.text.toString().toIntOrNull()
                val rows = etRows.text.toString().toIntOrNull()
                if (cols == null || cols <= 0 || rows == null || rows <= 0) {
                    Toast.makeText(this, "Number of Columns & Rows wajib diisi angka > 0", Toast.LENGTH_SHORT).show()
                    showCustomDimensionDialog(boxCodes, aliasPairs)
                    return@setPositiveButton
                }
                val positions = when (spinnerDir.selectedItemPosition) {
                    0 -> DenahAutoGenerator.generateGridPositions( // Kiri ke Kanan: baris demi baris, top-down
                        DenahAutoGenerator.GridMode.ROWS_FIRST, 1, rows, 1, emptySet(), 1, cols, 1, emptySet(), boxCodes.size, zigzag = false
                    )
                    1 -> DenahAutoGenerator.generateGridPositions( // Bawah ke Atas: kolom demi kolom, bottom-up per kolom
                        DenahAutoGenerator.GridMode.COLS_FIRST, 1, cols, 1, emptySet(), rows, 1, -1, emptySet(), boxCodes.size, zigzag = false
                    )
                    else -> DenahAutoGenerator.generateGridPositions( // Zig-zag: baris demi baris, arah selang-seling
                        DenahAutoGenerator.GridMode.ROWS_FIRST, 1, rows, 1, emptySet(), 1, cols, 1, emptySet(), boxCodes.size, zigzag = true
                    )
                }
                applyBoxesAndAliases(boxCodes, aliasPairs, positions, "ks")
            }
            .setNegativeButton("Batal", null)
            .showSafely()
    }

    /**
     * ★ FIX (Tahap 3 — Auto-Fit Block, mirip contoh denah user): susun
     * otomatis ke bentuk mendekati persegi per kategori (Regular & Receiving
     * digambar sebagai 2 blok TERPISAH berdampingan kalau sumbernya "Semua
     * Data"), lalu tambahkan 1 kolom "BOX N/A" (banner merah) di sisi paling
     * kanan sebagai area khusus/penampung — sesuai contoh layout fisik user.
     */
    private fun applyAutoFitBlock(regularBoxCodes: List<String>, receivingBoxCodes: List<String>, aliasPairs: List<Pair<String, String>>) {
        var xCursor = 1
        var maxRows = 1
        val allPlacedCodes = mutableListOf<String>()
        val allPositions = mutableListOf<Pair<Int, Int>>()

        fun placeBlock(codes: List<String>) {
            if (codes.isEmpty()) return
            val (cols, rows) = DenahAutoGenerator.autoFitDims(codes.size)
            val positions = DenahAutoGenerator.generateGridPositions(
                DenahAutoGenerator.GridMode.ROWS_FIRST, 1, rows, 1, emptySet(), xCursor, xCursor + cols - 1, 1, emptySet(), codes.size
            )
            allPlacedCodes.addAll(codes)
            allPositions.addAll(positions)
            maxRows = maxOf(maxRows, rows)
            xCursor += cols + 1 // +1 = gang/gap pemisah antar blok
        }

        placeBlock(regularBoxCodes)
        placeBlock(receivingBoxCodes)

        if (allPlacedCodes.isEmpty()) {
            Toast.makeText(this, "Tidak ada box untuk disusun", Toast.LENGTH_SHORT).show()
            return
        }

        applyBoxesAndAliases(allPlacedCodes, aliasPairs, allPositions, "autofit")

        // Kolom "BOX N/A" — area khusus/penampung di sisi paling kanan (banner, bukan box data asli,
        // karena status N/A belum ada tracking-nya di data KS — ini cuma penanda area fisiknya).
        val naX = xCursor
        tiles.removeAll { it.type == "LABEL" && it.label == "BOX N/A" }
        tiles.add(
            DenahLayoutPrefs.Tile(
                id = "t${System.currentTimeMillis()}_na",
                type = "LABEL", label = "BOX N/A",
                x = naX, y = 1, w = 1, h = maxRows.coerceAtLeast(1),
                colorHex = "#C62828"
            )
        )
        canvas.tiles = tiles
        isDirty = true
        updateSummary()
        Toast.makeText(
            this,
            "Auto-Fit Block: ${allPlacedCodes.size} box tersusun" +
                (if (regularBoxCodes.isNotEmpty() && receivingBoxCodes.isNotEmpty()) " (Regular + Receiving terpisah)" else "") +
                " + kolom BOX N/A ditambahkan",
            Toast.LENGTH_LONG
        ).show()
    }

    // ── Tahap 3: Block Custom / L-Shape (pakai kode ASLI dari data KS) ──────
    /**
     * ★ FIX (diminta user — jangan dihapus, dipindah jadi opsi ke-3 di
     * "Pilih Mode Grid"): logika PERSIS sama dengan generator block/L-shape
     * sebelumnya (baris mulai/akhir/step + kolom mulai/akhir/step, bisa
     * lebih dari 1 block buat bentuk L-shape/tingkat) — bedanya sekarang
     * kode yang ditempatkan adalah kode ASLI hasil baca data KS (Tahap 1-2),
     * BUKAN kode sintetis prefix+angka. Tiap block "memakan" sejumlah kode
     * berikutnya dari daftar boxCodes secara berurutan.
     */
    private data class ShapeBlock(
        val count: Int, val rowsFirst: Boolean,
        val rowStart: Int, val rowEnd: Int, val rowStep: Int, val rowSkip: Set<Int>,
        val colStart: Int, val colEnd: Int, val colStep: Int, val colSkip: Set<Int>
    ) {
        val summary: String
            get() = "$count box (${if (rowsFirst) "baris jalan" else "kolom jalan"}, baris $rowStart→$rowEnd, kolom $colStart→$colEnd)"
    }

    private val pendingShapeBlocks = mutableListOf<ShapeBlock>()
    private var shapeBlockBoxCodes: List<String> = emptyList()
    private var shapeBlockAliasPairs: List<Pair<String, String>> = emptyList()

    private fun shapeBlockRemaining(): Int = shapeBlockBoxCodes.size - pendingShapeBlocks.sumOf { it.count }

    /** Dialog "daftar block" untuk mode L-Shape berbasis data KS asli — bisa tumpuk >1 block. */
    private fun showKsBlockListDialog() {
        val container = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 16, 40, 0) }
        val remaining = shapeBlockRemaining()
        container.addView(TextView(this).apply {
            text = "Total box dari data KS: ${shapeBlockBoxCodes.size}   |   Sisa belum kebagian block: $remaining"
            textSize = 12f; setPadding(0, 0, 0, 10)
        })
        if (pendingShapeBlocks.isEmpty()) {
            container.addView(TextView(this).apply { text = "Belum ada block. Tambah block dulu (bisa lebih dari 1 buat bentuk L-shape/tingkat, seperti contoh gambar)."; textSize = 12f })
        } else {
            pendingShapeBlocks.forEachIndexed { i, b ->
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 6, 0, 6) }
                row.addView(TextView(this).apply {
                    text = "Block ${i + 1}: ${b.summary}"; textSize = 12f
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                })
                val btnDel = TextView(this).apply { text = "Hapus"; setTextColor(android.graphics.Color.parseColor("#C62828")); textSize = 12f; setPadding(16, 0, 0, 0) }
                btnDel.setOnClickListener { pendingShapeBlocks.removeAt(i); showKsBlockListDialog() }
                row.addView(btnDel)
                container.addView(row)
            }
        }
        val scroll = android.widget.ScrollView(this).apply { addView(container) }

        val builder = AlertDialog.Builder(this)
            .setTitle("Block Custom / L-Shape (${pendingShapeBlocks.size} block)")
            .setView(scroll)
            .setNegativeButton("Tutup", null)
        if (remaining > 0) builder.setPositiveButton("+ Tambah Block") { _, _ -> showKsBlockFormDialog() }
        if (pendingShapeBlocks.isNotEmpty()) builder.setNeutralButton("GENERATE SEMUA") { _, _ -> applyKsShapeBlocks() }
        builder.showSafely()
    }

    /** Form 1 block — SAMA PERSIS field-nya dengan generator L-shape sebelumnya (baris/kolom mulai-akhir-step). */
    private fun showKsBlockFormDialog() {
        val remaining = shapeBlockRemaining()
        val form = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 8, 40, 0) }
        form.addView(TextView(this).apply { text = "Sisa $remaining box belum kebagian block."; textSize = 12f; setPadding(0, 0, 0, 10) })

        val etCount = numberField("Jumlah box di block ini (contoh 57)", remaining.toString())

        val radioGroup = android.widget.RadioGroup(this).apply { orientation = LinearLayout.VERTICAL }
        val radioRowsFirst = android.widget.RadioButton(this).apply {
            text = "Kolom tetap per grup, baris berjalan (contoh: cluster kiri/kanan gambar)"; id = View.generateViewId(); isChecked = true
        }
        val radioColsFirst = android.widget.RadioButton(this).apply {
            text = "Baris tetap per grup, kolom berjalan (contoh: cluster tengah gambar)"; id = View.generateViewId()
        }
        radioGroup.addView(radioRowsFirst); radioGroup.addView(radioColsFirst)

        val etRowStart = numberField("Baris mulai")
        val etRowEnd = numberField("Baris akhir")
        val etRowStep = numberField("Baris step (+1 naik, -1 turun)", "-1")
        val etRowSkip = EditText(this).apply { hint = "Baris yang dilewati (opsional, pisah koma, contoh: 37)" }

        val etColStart = numberField("Kolom mulai")
        val etColEnd = numberField("Kolom akhir")
        val etColStep = numberField("Kolom step (+1 naik, -1 turun)", "1")
        val etColSkip = EditText(this).apply { hint = "Kolom yang dilewati (opsional, pisah koma)" }

        form.addView(etCount)
        form.addView(labeled("Urutan pengisian")); form.addView(radioGroup)
        form.addView(labeled("Baris")); form.addView(etRowStart); form.addView(etRowEnd); form.addView(etRowStep); form.addView(etRowSkip)
        form.addView(labeled("Kolom")); form.addView(etColStart); form.addView(etColEnd); form.addView(etColStep); form.addView(etColSkip)

        val scroll = android.widget.ScrollView(this).apply { addView(form) }

        AlertDialog.Builder(this)
            .setTitle("Block Baru")
            .setView(scroll)
            .setPositiveButton("+ Tambah ke Daftar") { _, _ ->
                val count = etCount.text.toString().toIntOrNull() ?: 0
                val rowStart = etRowStart.text.toString().toIntOrNull()
                val rowEnd = etRowEnd.text.toString().toIntOrNull()
                val rowStep = etRowStep.text.toString().toIntOrNull() ?: -1
                val rowSkip = DenahAutoGenerator.parseSkipList(etRowSkip.text.toString())
                val colStart = etColStart.text.toString().toIntOrNull()
                val colEnd = etColEnd.text.toString().toIntOrNull()
                val colStep = etColStep.text.toString().toIntOrNull() ?: 1
                val colSkip = DenahAutoGenerator.parseSkipList(etColSkip.text.toString())
                if (count <= 0 || count > remaining || rowStart == null || rowEnd == null || colStart == null || colEnd == null) {
                    Toast.makeText(this, "Jumlah box (maks $remaining), baris & kolom (mulai/akhir) wajib diisi", Toast.LENGTH_SHORT).show()
                    showKsBlockFormDialog()
                    return@setPositiveButton
                }
                pendingShapeBlocks.add(
                    ShapeBlock(count, radioRowsFirst.isChecked, rowStart, rowEnd, rowStep, rowSkip, colStart, colEnd, colStep, colSkip)
                )
                showKsBlockListDialog()
            }
            .setNegativeButton("Batal") { _, _ -> showKsBlockListDialog() }
            .showSafely()
    }

    /** Proses semua block L-shape sekaligus: tiap block "memakan" sejumlah kode berikutnya dari daftar. */
    private fun applyKsShapeBlocks() {
        val allPositions = mutableListOf<Pair<Int, Int>>()
        val allCodesUsed = mutableListOf<String>()
        var cursor = 0
        pendingShapeBlocks.forEach { b ->
            val codesForBlock = shapeBlockBoxCodes.subList(cursor, minOf(cursor + b.count, shapeBlockBoxCodes.size))
            val mode = if (b.rowsFirst) DenahAutoGenerator.GridMode.ROWS_FIRST else DenahAutoGenerator.GridMode.COLS_FIRST
            val positions = if (b.rowsFirst) {
                DenahAutoGenerator.generateGridPositions(mode, b.rowStart, b.rowEnd, b.rowStep, b.rowSkip, b.colStart, b.colEnd, b.colStep, b.colSkip, codesForBlock.size)
            } else {
                DenahAutoGenerator.generateGridPositions(mode, b.colStart, b.colEnd, b.colStep, b.colSkip, b.rowStart, b.rowEnd, b.rowStep, b.rowSkip, codesForBlock.size)
            }
            allCodesUsed.addAll(codesForBlock.take(positions.size))
            allPositions.addAll(positions)
            cursor += b.count
        }
        pendingShapeBlocks.clear()
        applyBoxesAndAliases(allCodesUsed, shapeBlockAliasPairs, allPositions, "ksblock")
    }

    /** Helper bersama: terapkan [codes] ke [positions] (1:1 berurutan) + [aliasPairs] ke kanvas. */
    private fun applyBoxesAndAliases(codes: List<String>, aliasPairs: List<Pair<String, String>>, positions: List<Pair<Int, Int>>, tag: String) {
        if (positions.isEmpty()) {
            Toast.makeText(this, "Range grid tidak menghasilkan posisi apapun — cek lagi angkanya", Toast.LENGTH_LONG).show()
            return
        }
        // ★ FIX (baru — Batas Total Box saat Auto-Generate/Edit Layout): dulu di sini operasi
        // langsung DITOLAK TOTAL kalau bakal melebihi batas. Sekarang TIDAK diblokir lagi —
        // box tetap ditempatkan dulu, lalu resolveOverlapsAndFillGaps() di bawah yang akan
        // menata ulang: yang MUAT sesuai batas ditaruh di layout, sisanya (box beneran atau
        // slot kosong) otomatis dipindah ke BOX N/A — sesuai ketentuan baru dari user.
        pushUndoSnapshot()
        // ★ FIX (baru — Nomor Slot Fisik): tiap posisi grid baru dikasih slotNo urut permanen,
        // nyambung dari slotNo tertinggi yang sudah ada (persis urutan fisik box di grid ini),
        // supaya nanti kalau No Ctn-nya dikosongkan/dipindah, nomor slot putihnya tetap ada.
        var nextSlot = (tiles.mapNotNull { it.slotNo }.maxOrNull() ?: 0) + 1
        codes.take(positions.size).forEachIndexed { i, code ->
            tiles.removeAll { it.type == "CTN" && it.noCtn?.trim()?.uppercase() == code }
            val (x, y) = positions[i]
            tiles.add(DenahLayoutPrefs.Tile(id = "t${System.currentTimeMillis()}_${tag}_$i", type = "CTN", noCtn = code, x = x, y = y, w = 1, h = 1, slotNo = nextSlot))
            nextSlot++
        }
        val newAliases = aliasPairs.map { (code, base) -> DenahLayoutPrefs.Alias(code, base) }
        aliases.removeAll { a -> newAliases.any { it.code == a.code } }
        aliases.addAll(newAliases)
        resolveOverlapsAndFillGaps()
        canvas.tiles = tiles
        isDirty = true
        updateSummary()
        val placed = minOf(positions.size, codes.size)
        val leftover = codes.size - placed
        val leftoverNote = if (leftover > 0) " ($leftover box belum kebagian posisi — grid kurang besar, tambah lagi lewat AUTO-GEN atau + BOX manual)" else ""
        Toast.makeText(this, "Ditempatkan $placed box + ${newAliases.size} alias.$leftoverNote", Toast.LENGTH_LONG).show()
    }

    // ── ★ FIX (baru — UPDATE LAYOUT: sync incremental, BEDA dari Auto-Generate) ──
    /**
     * Auto-Generate = generate ULANG TOTAL (posisi ditata ulang dari nol).
     * UPDATE LAYOUT = SINKRON RINGAN: posisi box yang SUDAH ADA di kanvas
     * TIDAK diubah sama sekali. Hanya:
     *  1. No Ctn BARU di data KS yang belum ada tile-nya -> ditaruh ke SLOT
     *     KOSONG (putih) pertama yang tersedia, urut berdasarkan slotNo.
     *  2. No Ctn YANG SUDAH DIHAPUS dari data KS (tile-nya masih ada di
     *     kanvas tapi kodenya sudah tidak ada lagi di sheet) -> tile-nya
     *     dikosongkan lagi jadi SLOT KOSONG putih (bukan dihapus), slotNo-nya
     *     tetap sama seperti semula.
     * Cocok dipakai rutin (harian/mingguan) tanpa merusak layout fisik yang
     * sudah disusun manual (drag-drag) sebelumnya.
     */
    private fun updateLayoutFromKsIncremental() {
        val ssid = exioSpreadsheetId(store)
        val gid = exioGid(store)
        if (ssid.isBlank() || gid.isBlank()) {
            Toast.makeText(this, "Spreadsheet KeepStock toko ini belum diset", Toast.LENGTH_LONG).show()
            return
        }
        if (tiles.none { it.type == "CTN" }) {
            Toast.makeText(this, "Belum ada grid di denah ini. Pakai AUTO-GEN dulu buat bikin grid awal.", Toast.LENGTH_LONG).show()
            return
        }
        val pd = ProgressDialog(this).apply { setMessage("Membaca data KS terbaru..."); show() }
        lifecycleScope.launch {
            try {
                val allCodes = withContext(Dispatchers.IO) {
                    KeepStockSheetReader.fetchRows(ssid, gid).map { it.noCtn.trim().uppercase() }.filter { it.isNotBlank() }.toSet()
                }
                pd.dismissSafely()
                if (allCodes.isEmpty()) {
                    Toast.makeText(this@DenahLayoutActivity, "Tidak ada data No Ctn ditemukan di data KS toko ini", Toast.LENGTH_LONG).show()
                    return@launch
                }
                val (boxCodes, _) = splitCodesIntoBoxesAndAliases(allCodes)
                val newCodesSet = boxCodes.toSet()

                val existingCtn = tiles.filter { it.type == "CTN" }
                val existingCodesUpper = existingCtn.mapNotNull { it.noCtn?.trim()?.uppercase() }.toSet()

                // (1) Kode yang hilang dari KS -> tandai ORPHAN (bukan langsung dikosongkan).
                val removedCodes = existingCodesUpper - newCodesSet
                // (2) Kode baru yang belum punya tile -> perlu ditaruh ke slot kosong.
                val addedCodes = (newCodesSet - existingCodesUpper).toMutableList()
                naturalSort(addedCodes)
                // (3) ★ FIX (baru — Fase 6): box ORPHAN yang ternyata sudah muncul lagi di KS ->
                // perlu di-un-orphan otomatis (dihitung di awal supaya tidak ke-skip early-return).
                val toUnorphanCount = existingCtn.count { it.orphan && it.noCtn?.trim()?.uppercase() in newCodesSet }

                if (removedCodes.isEmpty() && addedCodes.isEmpty() && toUnorphanCount == 0) {
                    Toast.makeText(this@DenahLayoutActivity, "Sudah sinkron, tidak ada perubahan dari data KS", Toast.LENGTH_LONG).show()
                    return@launch
                }

                pushUndoSnapshot()

                // ★ FIX (baru — Fase 6): kalau box yang tadinya ORPHAN ternyata MUNCUL LAGI di KS
                // (mis. sempat kehapus lalu ditambah ulang), otomatis lepas tanda orphan-nya —
                // ini aman & tidak melanggar "jangan auto-delete", karena datanya justru valid lagi.
                var unorphaned = 0
                tiles.indices.forEach { idx ->
                    val t = tiles[idx]
                    if (t.type == "CTN" && t.orphan && t.noCtn?.trim()?.uppercase() in newCodesSet) {
                        tiles[idx] = t.copy(orphan = false, colorHex = null)
                        unorphaned++
                    }
                }

                // ★ FIX (baru — Fase 6, spesifikasi poin 14 "Removed Box"): box yang No Ctn-nya
                // sudah hilang dari KS TIDAK LANGSUNG dikosongkan otomatis lagi — cuma ditandai
                // ORPHAN (warna amber) dan menunggu keputusan user (REMOVE/KEEP) lewat dialog
                // Orphan Box, supaya data tidak hilang diam-diam kalau ternyata cuma kehapus
                // sementara di Keep Stock / kesalahan input.
                removedCodes.forEach { code ->
                    val idx = tiles.indexOfFirst { it.type == "CTN" && it.noCtn?.trim()?.uppercase() == code }
                    if (idx >= 0) tiles[idx] = tiles[idx].copy(orphan = true, colorHex = "#FFA000")
                }
                // Isi slot kosong yang tersedia (urut slotNo) dengan kode baru. Slot yang ditandai
                // ORPHAN TIDAK dianggap kosong (noCtn-nya masih ada) — sengaja, supaya kode baru
                // tidak menimpa box yang masih menunggu keputusan REMOVE/KEEP.
                val emptySlots = tiles.withIndex()
                    .filter { (_, t) -> t.type == "CTN" && t.noCtn.isNullOrBlank() }
                    .sortedBy { (_, t) -> t.slotNo ?: Int.MAX_VALUE }
                    .map { it.index }
                    .toMutableList()

                var placedNew = 0
                addedCodes.forEach { code ->
                    if (emptySlots.isEmpty()) return@forEach
                    val idx = emptySlots.removeAt(0)
                    tiles[idx] = tiles[idx].copy(noCtn = code, colorHex = null)
                    placedNew++
                }
                val stillUnplaced = addedCodes.size - placedNew

                // ★ FIX (baru — Update Layout tidak boleh menambah box melebihi rentang data
                // Keep Stock): dulu resolveOverlapsAndFillGaps() mengisi SELURUH area kosong di
                // bounding box grid tanpa peduli berapa banyak data KS yang sebenarnya ada — kalau
                // geometri grid lebih besar dari jumlah data asli, bisa muncul box putih berlebihan
                // (contoh: KS cuma A001-A050 + B001-B030 = 80 item, tapi grid kebetulan punya 120
                // sel kosong -> 40 box putih ekstra yang tidak perlu). Sekarang, KHUSUS pas Update
                // Layout, batas total box (box beneran + box putih) dipatok ke jumlah total data KS
                // saat ini ($newCodesSet.size) — kalau user sudah set Batas Total Box manual yang
                // LEBIH KECIL, batas manual itu yang dipakai (tidak pernah dilonggarkan). Batas ini
                // cuma berlaku untuk operasi Update Layout ini saja, setelah selesai dikembalikan ke
                // setting manual semula supaya tidak mengubah preferensi user diam-diam.
                val savedLimit = maxTotalBoxLimit
                val ksTotalCount = newCodesSet.size
                maxTotalBoxLimit = if (savedLimit == null) ksTotalCount else minOf(savedLimit, ksTotalCount)
                resolveOverlapsAndFillGaps()
                maxTotalBoxLimit = savedLimit

                canvas.tiles = tiles
                isDirty = true
                updateSummary()

                val orphanCount = tiles.count { it.type == "CTN" && it.orphan }
                val msg = buildString {
                    append("Update Layout selesai. ")
                    if (placedNew > 0) append("$placedNew box baru ditempatkan. ")
                    if (removedCodes.isNotEmpty()) append("${removedCodes.size} box ditandai ORPHAN (sudah tidak ada di KS, cek dulu sebelum dihapus). ")
                    if (stillUnplaced > 0) append("$stillUnplaced box baru BELUM kebagian slot kosong — tambah grid lewat AUTO-GEN atau + BOX manual.")
                }
                if (orphanCount > 0) {
                    AlertDialog.Builder(this@DenahLayoutActivity)
                        .setTitle("Update Layout Selesai")
                        .setMessage("$msg\n\nAda $orphanCount box ORPHAN yang perlu dicek. Review sekarang?")
                        .setPositiveButton("Review Orphan Box") { _, _ -> showOrphanBoxDialog() }
                        .setNegativeButton("Nanti", null)
                        .showSafely()
                } else {
                    Toast.makeText(this@DenahLayoutActivity, msg, Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                pd.dismissSafely()
                Toast.makeText(this@DenahLayoutActivity, "Gagal update layout: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    /**
     * ★ FIX (baru — Fase 6 "Orphan Box", spesifikasi poin 14): daftar semua
     * box yang ditandai ORPHAN (No Ctn-nya sudah tidak ada di Keep Stock,
     * tapi belum diputuskan). Tiap baris ada 2 tombol:
     *  - REMOVE : box dikosongkan (jadi slot kosong putih lagi, slotNo tetap)
     *             — sama seperti auto-clear versi lama, tapi sekarang lewat
     *             keputusan eksplisit user.
     *  - KEEP   : tanda orphan dilepas, box kembali normal (warna oranye
     *             biasa) walau No Ctn-nya masih belum ada di KS — dipakai
     *             kalau user yakin datanya cuma sementara hilang.
     * Dialog ini bisa dibuka kapan saja lewat tombol "ORPHAN BOX" di baris
     * aksi mode Edit, tidak cuma otomatis muncul setelah Update Layout.
     */
    private fun showOrphanBoxDialog() {
        val orphanTiles = tiles.filter { it.type == "CTN" && it.orphan }
        if (orphanTiles.isEmpty()) {
            Toast.makeText(this, "Tidak ada Orphan Box saat ini", Toast.LENGTH_SHORT).show()
            return
        }
        val container = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 16, 40, 0) }
        orphanTiles.sortedBy { it.noCtn }.forEach { t ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 8, 0, 8) }
            row.addView(
                TextView(this).apply {
                    text = t.noCtn
                    textSize = 13f
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                }
            )
            val btnKeep = TextView(this).apply { text = "KEEP"; setTextColor(android.graphics.Color.parseColor("#2E7D32")); textSize = 12f; setPadding(16, 0, 16, 0) }
            val btnRemove = TextView(this).apply { text = "REMOVE"; setTextColor(android.graphics.Color.parseColor("#C62828")); textSize = 12f }
            btnKeep.setOnClickListener {
                val idx = tiles.indexOfFirst { it.id == t.id }
                if (idx >= 0) {
                    pushUndoSnapshot()
                    tiles[idx] = tiles[idx].copy(orphan = false, colorHex = null)
                    canvas.tiles = tiles
                    isDirty = true
                    updateSummary()
                }
                showOrphanBoxDialog() // refresh daftar (item ini sudah tidak orphan lagi)
            }
            btnRemove.setOnClickListener {
                val idx = tiles.indexOfFirst { it.id == t.id }
                if (idx >= 0) {
                    pushUndoSnapshot()
                    // Dikosongkan jadi slot putih lagi (BUKAN dihapus tile-nya) — slotNo tetap terjaga.
                    tiles[idx] = tiles[idx].copy(noCtn = null, orphan = false, colorHex = "#FFFFFF")
                    canvas.tiles = tiles
                    isDirty = true
                    updateSummary()
                }
                showOrphanBoxDialog() // refresh daftar
            }
            row.addView(btnKeep); row.addView(btnRemove)
            container.addView(row)
        }
        val scroll = android.widget.ScrollView(this).apply { addView(container) }
        AlertDialog.Builder(this)
            .setTitle("Orphan Box (${orphanTiles.size})")
            .setView(scroll)
            .setNegativeButton("Tutup", null)
            .showSafely()
    }

    // ── ★ FIX (baru — Ruler/dimension guide): tambah anotasi garis panah + angka ukuran cluster ──
    private fun showAddRulerDialog() {
        val form = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 24, 48, 0) }
        val radioGroup = android.widget.RadioGroup(this).apply { orientation = LinearLayout.HORIZONTAL }
        val radioH = android.widget.RadioButton(this).apply { text = "Horizontal (→)"; isChecked = true; id = View.generateViewId() }
        val radioV = android.widget.RadioButton(this).apply { text = "Vertikal (↓)"; id = View.generateViewId() }
        radioGroup.addView(radioH); radioGroup.addView(radioV)
        val etLength = EditText(this).apply { hint = "Panjang (jumlah kotak yang direntang, contoh 38)"; inputType = android.text.InputType.TYPE_CLASS_NUMBER }
        val etLabel = EditText(this).apply { hint = "Angka/teks tampil (kosongkan = otomatis pakai panjang di atas)" }
        form.addView(radioGroup); form.addView(etLength); form.addView(etLabel)

        AlertDialog.Builder(this)
            .setTitle("Tambah Ruler (Garis Ukuran)")
            .setView(form)
            .setPositiveButton("Tambah") { _, _ ->
                val len = etLength.text.toString().toIntOrNull()?.coerceIn(1, 200) ?: 1
                val isH = radioH.isChecked
                val customLabel = etLabel.text.toString().trim().ifBlank { null }
                pushUndoSnapshot()
                val pos = findFreeCell()
                tiles.add(
                    DenahLayoutPrefs.Tile(
                        id = "t${System.currentTimeMillis()}_ruler",
                        type = "RULER",
                        label = customLabel,
                        x = pos.first, y = pos.second,
                        w = if (isH) len else 1,
                        h = if (isH) 1 else len,
                        dir = if (isH) "H" else "V"
                    )
                )
                canvas.tiles = tiles
                isDirty = true
            }
            .setNegativeButton("Batal", null)
            .showSafely()
    }

    // ── ★ FIX (baru — Fase 4 "Object Editor", spesifikasi poin 16) ──────────
    /** Daftar tipe objek statis yang bisa ditambah — semua bukan No Ctn, murni anotasi denah. */
    private val objectTypeCodes = listOf("WALL", "TEXT", "AREA", "ARROW", "DOOR")
    private val objectTypeLabels = listOf("WALL (tembok)", "TEXT (tulisan bebas)", "AREA (zona/area)", "ARROW (panah arah)", "DOOR (pintu)")

    private fun showAddObjectChooserDialog() {
        AlertDialog.Builder(this)
            .setTitle("Tambah Objek")
            .setItems(objectTypeLabels.toTypedArray()) { _, which -> showAddObjectFormDialog(objectTypeCodes[which]) }
            .setNegativeButton("Batal", null)
            .showSafely()
    }

    /** Form pembuatan 1 objek baru sesuai [type] — field disesuaikan (TEXT/ARROW butuh teks, dst). */
    private fun showAddObjectFormDialog(type: String) {
        val form = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 24, 48, 0) }
        val needsText = type == "TEXT" || type == "AREA" || type == "ARROW"
        val etText = EditText(this).apply {
            hint = when (type) {
                "TEXT" -> "Isi tulisan (contoh: Fitting Room)"
                "AREA" -> "Nama area (opsional, contoh: Gudang)"
                "ARROW" -> "Keterangan panah (opsional)"
                else -> "Keterangan (opsional)"
            }
        }
        val etWidth = numberField("Lebar (satuan sel, default 3)", "3")
        val etHeight = numberField("Tinggi (satuan sel, default 3)", "3")
        form.addView(labeled(objectTypeLabels[objectTypeCodes.indexOf(type)]))
        if (needsText) form.addView(etText)
        form.addView(etWidth); form.addView(etHeight)

        AlertDialog.Builder(this)
            .setTitle("Tambah Objek Baru")
            .setView(form)
            .setPositiveButton("Tambah") { _, _ ->
                val w = etWidth.text.toString().toIntOrNull()?.coerceIn(1, 200) ?: 3
                val h = etHeight.text.toString().toIntOrNull()?.coerceIn(1, 200) ?: 3
                val text = etText.text.toString().trim().ifBlank { null }
                pushUndoSnapshot()
                val pos = findFreeCell()
                val defaultColor = when (type) {
                    "WALL" -> "#424242"
                    "AREA" -> "#7E57C2"
                    "DOOR" -> "#8D6E63"
                    else -> null
                }
                tiles.add(
                    DenahLayoutPrefs.Tile(
                        id = "t${System.currentTimeMillis()}_obj",
                        type = type,
                        label = text,
                        x = pos.first, y = pos.second,
                        w = w,
                        h = if (type == "ARROW") 1 else h,
                        colorHex = defaultColor
                    )
                )
                canvas.tiles = tiles
                isDirty = true
                updateSummary()
            }
            .setNegativeButton("Batal", null)
            .showSafely()
    }

    /**
     * ★ FIX (baru — Fase 4): dialog EDIT untuk objek statis (WALL/TEXT/AREA/
     * ARROW/DOOR) yang sudah ada di kanvas — cara AMAN untuk resize & rotate
     * (form angka, bukan drag-handle di kanvas yang butuh state-machine
     * sentuh baru & berisiko lebih tinggi untuk dicoba tanpa uji fisik).
     * Bisa juga: ubah teks, KUNCI (locked) supaya tidak kegeser tanpa
     * sengaja, SEMBUNYIKAN (visible) tanpa menghapus, dan HAPUS objek.
     */
    private fun showEditObjectDialog(tile: DenahLayoutPrefs.Tile) {
        val form = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 24, 48, 0) }
        val needsText = tile.type == "TEXT" || tile.type == "AREA" || tile.type == "ARROW"
        val etText = EditText(this).apply { hint = "Teks"; setText(tile.label ?: "") }
        val etWidth = numberField("Lebar (satuan sel)", tile.w.toString())
        val etHeight = numberField("Tinggi (satuan sel)", tile.h.toString())
        val etRotation = numberField("Rotasi (derajat, 0-359)", tile.rotation.toInt().toString())
        val cbLocked = android.widget.CheckBox(this).apply { text = "Kunci (tidak bisa digeser)"; isChecked = tile.locked }
        val cbVisible = android.widget.CheckBox(this).apply { text = "Tampilkan di kanvas"; isChecked = tile.visible }

        form.addView(labeled("Edit Objek — ${tile.type}"))
        if (needsText) form.addView(etText)
        form.addView(etWidth); form.addView(etHeight); form.addView(etRotation)
        form.addView(cbLocked); form.addView(cbVisible)

        AlertDialog.Builder(this)
            .setTitle("Edit Objek")
            .setView(form)
            .setPositiveButton("Simpan") { _, _ ->
                val idx = tiles.indexOfFirst { it.id == tile.id }
                if (idx >= 0) {
                    pushUndoSnapshot()
                    tiles[idx] = tiles[idx].copy(
                        label = if (needsText) etText.text.toString().trim().ifBlank { null } else tiles[idx].label,
                        w = etWidth.text.toString().toIntOrNull()?.coerceIn(1, 200) ?: tiles[idx].w,
                        h = etHeight.text.toString().toIntOrNull()?.coerceIn(1, 200) ?: tiles[idx].h,
                        rotation = (etRotation.text.toString().toIntOrNull() ?: 0).let { ((it % 360) + 360) % 360 }.toFloat(),
                        locked = cbLocked.isChecked,
                        visible = cbVisible.isChecked
                    )
                    canvas.tiles = tiles
                    isDirty = true
                    updateSummary()
                }
            }
            .setNeutralButton("Hapus") { _, _ ->
                pushUndoSnapshot()
                tiles.removeAll { it.id == tile.id }
                canvas.tiles = tiles
                isDirty = true
                updateSummary()
            }
            .setNegativeButton("Batal", null)
            .showSafely()
    }

    private fun labeled(text: String): TextView =
        TextView(this).apply { this.text = text; setPadding(0, 16, 0, 2); textSize = 12f }

    private fun numberField(hint: String, default: String = ""): EditText =
        EditText(this).apply {
            this.hint = hint
            setText(default)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_SIGNED
        }

    /** ★ FIX (baru — Fase 5): varian desimal (boleh koma/titik & minus) — dipakai untuk X/Y posisi bebas. */
    private fun numberFieldDecimal(hint: String, default: String = ""): EditText =
        EditText(this).apply {
            this.hint = hint
            setText(default)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or
                android.text.InputType.TYPE_NUMBER_FLAG_SIGNED or
                android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        }

    /**
     * ★ FIX (baru — Auto-Generate Suffix saja): kalau box dasarnya sudah
     * ditaruh manual (drag) di kanvas, cukup generate alias huruf A-Z-nya
     * saja berdasarkan urutan ANGKA kode2 itu (bukan posisi drag-nya).
     */
    private fun showManualSuffixDialog() {
        val etPrefix = EditText(this).apply { hint = "Prefix, contoh: A"; setText("A") }
        val etPadding = numberField("Jumlah digit angka (default 3)", "3")
        AlertDialog.Builder(this)
            .setTitle("Generate Alias dari Box Manual")
            .setMessage("Sistem akan mencari semua kotak dengan kode \"PREFIX+angka\" (tanpa huruf akhiran) yang sudah ada di kanvas, urutkan berdasarkan angkanya, lalu generate alias A-Z otomatis.")
            .setView(LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; setPadding(40, 8, 40, 0)
                addView(etPrefix); addView(etPadding)
            })
            .setPositiveButton("Generate") { _, _ ->
                val prefix = etPrefix.text.toString().trim().uppercase()
                val padding = etPadding.text.toString().toIntOrNull() ?: 3
                if (prefix.isBlank()) {
                    Toast.makeText(this, "Prefix wajib diisi", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                val regex = Regex("^${Regex.escape(prefix)}(\\d{$padding})$")
                val found = tiles
                    .filter { it.type == "CTN" && !it.noCtn.isNullOrBlank() }
                    .mapNotNull { t ->
                        val m = regex.find(t.noCtn!!.trim().uppercase())
                        val num = m?.groupValues?.get(1)?.toIntOrNull()
                        if (num != null) num to t.noCtn!!.trim().uppercase() else null
                    }
                    .sortedBy { it.first }
                    .map { it.second }
                if (found.isEmpty()) {
                    Toast.makeText(this, "Tidak ada box dengan pola \"$prefix + $padding digit angka\" di kanvas", Toast.LENGTH_LONG).show()
                    return@setPositiveButton
                }
                val newAliases = DenahAutoGenerator.generateSuffixAliases(found)
                pushUndoSnapshot()
                aliases.removeAll { a -> newAliases.any { it.code == a.code } }
                aliases.addAll(newAliases)
                isDirty = true
                updateSummary()
                Toast.makeText(this, "Generated ${newAliases.size} alias A-Z dari ${found.size} box", Toast.LENGTH_LONG).show()
            }
            .setNegativeButton("Batal", null)
            .showSafely()
    }

    // ── Export tabel (gaya sama dengan Stock Comparison) ──────────────────
    /**
     * ★ FIX (baru — Export Denah): pakai gaya export tabel yang SAMA dengan
     * menu Stock Comparison (PdfExporter/ExcelExporter.generateGenericTable),
     * bukan gambar visual kanvas. Kolom: No Ctn, Posisi (Kolom,Baris),
     * Status (ISI/KOSONG), Alias A-Z yang menunjuk ke box ini (kalau ada).
     */
    private fun showExportFormatDialog() {
        val ctnTiles = tiles.filter { it.type == "CTN" && !it.noCtn.isNullOrBlank() }
        if (ctnTiles.isEmpty()) {
            Toast.makeText(this, "Belum ada box untuk di-export", Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Export As")
            .setItems(arrayOf("PDF", "Excel (.xlsx)")) { _, which ->
                if (which == 0) exportDenahPdf(ctnTiles) else exportDenahExcel(ctnTiles)
            }
            .setNegativeButton("Cancel", null)
            .showSafely()
    }

    private fun buildExportTableRows(ctnTiles: List<DenahLayoutPrefs.Tile>): List<List<String>> {
        val resolved = computeResolvedOccupancy()
        val aliasOf = mutableMapOf<String, MutableList<String>>()
        aliases.forEach { a -> aliasOf.getOrPut(a.baseNoCtn.trim().uppercase()) { mutableListOf() }.add(a.code) }
        return ctnTiles
            .sortedWith(compareBy({ it.y }, { it.x }))
            .map { t ->
                val key = t.noCtn!!.trim().uppercase()
                val status = if (resolved[key] == true) "ISI" else "KOSONG"
                val aliasList = aliasOf[key].orEmpty().joinToString(", ")
                listOf(t.noCtn ?: "-", "${t.x},${t.y}", status, aliasList)
            }
    }

    private fun exportDenahPdf(ctnTiles: List<DenahLayoutPrefs.Tile>) {
        val pd = ProgressDialog(this).apply { setMessage("Generating PDF..."); show() }
        lifecycleScope.launch {
            try {
                val rows = buildExportTableRows(ctnTiles)
                val fileName = outFileName(this@DenahLayoutActivity, "DENAH_${store.replace(Regex("[^A-Za-z0-9]"), "")}").removeSuffix(".txt") + ".pdf"
                val savedPath = withContext(Dispatchers.IO) {
                    val bytes = PdfExporter.generateGenericTable(
                        title = "Denah Custom — $store",
                        headers = listOf("No Ctn", "Posisi (Kolom,Baris)", "Status", "Alias A-Z"),
                        rows = rows,
                        colWidths = listOf(120f, 150f, 90f, 195f)
                    )
                    OutputWriter.writeBytes(this@DenahLayoutActivity, fileName, bytes)
                }
                pd.dismissSafely()
                showExportSuccessDialog(savedPath, "PDF", "application/pdf")
            } catch (e: Exception) {
                pd.dismissSafely()
                Toast.makeText(this@DenahLayoutActivity, "Gagal export PDF: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun exportDenahExcel(ctnTiles: List<DenahLayoutPrefs.Tile>) {
        val pd = ProgressDialog(this).apply { setMessage("Generating Excel..."); show() }
        lifecycleScope.launch {
            try {
                val rows = buildExportTableRows(ctnTiles)
                val fileName = outFileName(this@DenahLayoutActivity, "DENAH_${store.replace(Regex("[^A-Za-z0-9]"), "")}").removeSuffix(".txt") + ".xlsx"
                val savedPath = withContext(Dispatchers.IO) {
                    val bytes = ExcelExporter.generateGenericTable(
                        title = "Denah Custom — $store",
                        headers = listOf("No Ctn", "Posisi (Kolom,Baris)", "Status", "Alias A-Z"),
                        rows = rows
                    )
                    OutputWriter.writeBytes(this@DenahLayoutActivity, fileName, bytes)
                }
                pd.dismissSafely()
                showExportSuccessDialog(savedPath, "Excel", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
            } catch (e: Exception) {
                pd.dismissSafely()
                Toast.makeText(this@DenahLayoutActivity, "Gagal export Excel: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun showExportSuccessDialog(savedPath: String, formatLabel: String, mimeType: String) {
        val builder = AlertDialog.Builder(this)
            .setTitle("Export $formatLabel Successful")
            .setMessage("$formatLabel saved:\n$savedPath")
            .setNegativeButton("Close", null)
            .setPositiveButton("Open $formatLabel") { _, _ ->
                try {
                    val file = java.io.File(savedPath)
                    val uri = androidx.core.content.FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
                    val intent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
                        setDataAndType(uri, mimeType)
                        addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    startActivity(intent)
                } catch (e: Exception) {
                    Toast.makeText(this, "Unable to open file: ${e.message}. Tersimpan di:\n$savedPath", Toast.LENGTH_LONG).show()
                }
            }
        builder.showSafely()
    }

    // ── Simpan layout ke server (per toko) + cache lokal ─────────────────
    private fun saveLayout() {
        val url = ksWebAppUrl; val token = ksApiToken
        val layout = DenahLayoutPrefs.Layout(store = store, gridUnitDp = 56, tiles = tiles, aliases = aliases, updatedAt = System.currentTimeMillis())
        DenahLayoutPrefs.saveCached(this, layout)

        if (url.isBlank() || token.isBlank()) {
            isDirty = false
            // ★ FIX (baru — Fase 7): Web App belum diset = tidak akan pernah bisa sync ke
            // server, tapi tetap tandai PENDING SYNC supaya user sadar datanya baru lokal.
            DenahLayoutPrefs.setPendingSync(this, store, true)
            updatePendingSyncBadge()
            Toast.makeText(this, "Layout tersimpan lokal (belum sync ke server — cek pengaturan Keep Stock)", Toast.LENGTH_LONG).show()
            return
        }
        val pd = ProgressDialog(this).apply { setMessage("Saving layout..."); show() }
        lifecycleScope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    KeepStockGasClient.saveLayout(url, token, store, DenahLayoutPrefs.toJson(layout))
                }
                pd.dismissSafely()
                if (result.optBoolean("ok", false)) {
                    isDirty = false
                    // ★ FIX (baru — Fase 7): berhasil kirim ke server -> lepas status PENDING SYNC.
                    DenahLayoutPrefs.setPendingSync(this@DenahLayoutActivity, store, false)
                    updatePendingSyncBadge()
                    Toast.makeText(this@DenahLayoutActivity, "Layout tersimpan untuk toko $store", Toast.LENGTH_SHORT).show()
                    // ★ FIX (baru — Fase 2, best-effort, fire-and-forget): kirim juga snapshot
                    // posisi ke sheet ternormalisasi BOX_POSITION. Tidak menunggu/tidak
                    // mempengaruhi Toast/isDirty di atas — sudah selesai duluan.
                    trySaveNormalizedBoxPositions()
                } else {
                    // ★ FIX (baru — Fase 7, spesifikasi poin 19): gagal kirim (server menolak) ->
                    // data TETAP AMAN di cache lokal (sudah disimpan di atas), tandai PENDING SYNC
                    // supaya user tahu perlu coba SAVE LAYOUT lagi nanti.
                    DenahLayoutPrefs.setPendingSync(this@DenahLayoutActivity, store, true)
                    updatePendingSyncBadge()
                    Toast.makeText(
                        this@DenahLayoutActivity,
                        "Gagal simpan ke server: ${result.optString("error", "unknown")}. Layout tetap tersimpan lokal di HP ini.",
                        Toast.LENGTH_LONG
                    ).show()
                }
            } catch (e: Exception) {
                pd.dismissSafely()
                // ★ FIX (baru — Fase 7): kemungkinan besar OFFLINE (exception koneksi) — data
                // tetap aman di cache lokal, tandai PENDING SYNC supaya user coba lagi nanti
                // begitu online (tinggal tekan SAVE LAYOUT lagi, tidak ada langkah khusus lain).
                DenahLayoutPrefs.setPendingSync(this@DenahLayoutActivity, store, true)
                updatePendingSyncBadge()
                Toast.makeText(
                    this@DenahLayoutActivity,
                    "Gagal konek ke server (${e.message}). Layout tetap tersimpan lokal di HP ini.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }
}
