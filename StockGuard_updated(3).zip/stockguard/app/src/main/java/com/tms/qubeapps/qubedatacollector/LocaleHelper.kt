package com.tms.qubeapps.qubedatacollector

import android.content.Context
import android.content.res.Configuration
import java.util.Locale

/**
 * Handles app language / locale switching.
 * Supported values for Prefs.appLanguage:
 *  - "system" -> follow the device's system language
 *  - "en"     -> force English (default)
 */
object LocaleHelper {

    const val LANG_SYSTEM = "system"
    const val LANG_ENGLISH = "en"

    /** Wraps the given context with the language stored in Prefs (default English). */
    fun wrap(context: Context): Context {
        val lang = Prefs.run { context.appLanguage }
        return applyLanguage(context, lang)
    }

    fun applyLanguage(context: Context, lang: String): Context {
        val locale = when (lang) {
            LANG_ENGLISH -> Locale("en")
            else -> getSystemLocale() // "system"
        }
        Locale.setDefault(locale)
        val config = Configuration(context.resources.configuration)
        config.setLocale(locale)
        return context.createConfigurationContext(config)
    }

    private fun getSystemLocale(): Locale {
        val list = Resources_getSystemLocales()
        return list ?: Locale.getDefault()
    }

    private fun Resources_getSystemLocales(): Locale? {
        return try {
            Configuration(android.content.res.Resources.getSystem().configuration).locales.get(0)
        } catch (e: Exception) {
            null
        }
    }
}
