pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // JitPack untuk zxing-android-embedded
        maven { url = uri("https://jitpack.io") }
    }
}

rootProject.name = "QubeDataCollector"
include(":app")
